/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.01.07
    Second Edit: 2025.07.02
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/
*/

#ifndef _PRECISION_LITERALS_HPP
#define _PRECISION_LITERALS_HPP

#include <gmp/gmp_base.hpp>
#include <gmp/gmp_solver.hpp>
#include <gmp/gmp_tensor.hpp>

namespace gmp
{
    //
    // Decimal Precision = Number of Bits x log10(2)
    // 
    namespace precision_float
    {
        using namespace gmp::calculus;
        namespace gmm = gmp::math;
        using gmp::operators::operator+;
        using gmp::operators::operator-;
        using gmp::operators::operator*;
        using gmp::operators::operator/;

        using gmp::math::operator%;
        using gmp::math::operator^;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
        using enum gmp::SolveMethod;
        using namespace gmp::output;
        using gmp::operator>>;
                       
        using integer_type = gmp::intnum;
        using fraction_type = gmp::ratnum;
        using real_type = gmp::real_float_t;
        using cplx_type = gmp::cplx_float_t;

        constexpr mpfr_prec_t digits = realnum_prec_v<real_type>;
        constexpr mpfr_prec_t digits10 = std::numeric_limits<float>::digits10; // 7
        constexpr mpfr_prec_t display_prec = (mpfr_prec_t)(digits10  * (2.0/3));
        constexpr mpfr_rnd_t  Mpfr_Rnd = realnum_rnd_v<real_type>;
        constexpr mpc_rnd_t   Cplx_Rnd = cplxnum_rnd_v<cplx_type>;

        /////// derivative operators for type double////////////
        // epsilon_float = 2^−24 = 5.96e-8
        // h_opt = epsilon^{ 1 /(n+1) }
        // where n is the order of accuracy of the stencil

        constexpr float h3 = 1.0e-4f;
        constexpr float h5 = 0.01136f;
        constexpr float h7 = 0.05147f;
        constexpr float h9 = 0.10248f;

        //// derivative operators for type float //////////
        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5c = drv5c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9b = drv9b<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9f = drv9f<VarID, Order, DX>;

        //// default derivative operators for type quadruple
        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif_b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif_c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif_f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif = drv3c<VarID, Order, DX>;
        
        //////////////////// Jacobian Operator /////////////////
        inline constexpr auto jac3b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac3c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac3f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac5b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac5c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac5f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac7b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac7c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac7f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac9b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac9c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac9f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac_b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac_c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac_f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac = jac_cmd<three_point, centered, h3>{};

        /////////////// metric tensor g_ij Operator //////////////////////
        inline constexpr auto mtt3b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt3c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt3f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt5b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt5c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt5f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt7b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt7c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt7f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt9b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt9c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt9f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt_b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt_c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt_f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt = mtt_cmd<three_point, centered, h3>{};

        /////////////// gradient operator ///////////////////////////////
        inline constexpr auto grd3b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd3c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd3f = grd_cmd<three_point, forward,  h3>{};

        inline constexpr auto grd5b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd5c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd5f = grd_cmd<five_point,  forward,  h5>{};

        inline constexpr auto grd7b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd7c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd7f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd9b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd9c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd9f = grd_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto grd_b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd_c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd_f = grd_cmd<three_point, forward, h3>{};

        inline constexpr auto grd = grd_cmd<three_point, centered, h3>{};

        /////////////// laplacian operator ///////////////////////////////
        inline constexpr auto lap3b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap3c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap3f = lap_cmd<three_point, forward,  h3>{};

        inline constexpr auto lap5b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap5c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap5f = lap_cmd<five_point,  forward,  h5>{};

        inline constexpr auto lap7b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap7c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap7f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap9b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap9c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap9f = lap_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto lap_b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap_c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap_f = lap_cmd<three_point, forward, h3>{};

        inline constexpr auto lap = lap_cmd<three_point, centered, h3>{};

        /////////////// divergence operator ///////////////////////////////
        inline constexpr auto dvg3b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg3c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg3f = dvg_cmd<three_point, forward,  h3>{};

        inline constexpr auto dvg5b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg5c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg5f = dvg_cmd<five_point,  forward,  h5>{};

        inline constexpr auto dvg7b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg7c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg7f = dvg_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto dvg9b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg9c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg9f = dvg_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto dvg_b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg_c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg_f = dvg_cmd<three_point, forward, h3>{};

        // Divergence - Flux per unit measure (line / area / volume)
        //
        //               ∬ 𝐅⋅𝑛𝑑𝑆
        // ∇⋅𝐅(𝑝) = lim —————————— 
        //         Δ𝑆→0     Δ𝑆
        //
        inline constexpr auto dvg = dvg_cmd<three_point, centered, h3>{};

        ///////////////////// curl operator ///////////////////////////////
        inline constexpr auto crl3b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl3c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl3f = crl_cmd<three_point, forward,  h3>{};

        inline constexpr auto crl5b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl5c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl5f = crl_cmd<five_point,  forward,  h5>{};

        inline constexpr auto crl7b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl7c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl7f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl9b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl9c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl9f = crl_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto crl_b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl_c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl_f = crl_cmd<three_point, forward, h3>{};

        // Curl - Circulation per unit area
        //
        //                       1   
        // ∇ × 𝐹(𝑝) ⋅ 𝐧  = lim ————— ∮ 𝐅 ⋅ d𝓁
        //                Δ𝐴⟶0 Δ𝐴       
        //
        inline constexpr auto crl = crl_cmd<three_point, centered, h3>{};

        //////////// literals for realnum ///////////////////

        inline real_type operator""_rn(unsigned long long value)
            {   return { value };  }

        inline real_type operator""_rn(long double value)
            {   return { (double)value }; }

        inline real_type operator""_rn(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplxnum ///////////////////
        inline cplx_type operator""_cn(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_re(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_im(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_type operator""_cn(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_re(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_im(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_type operator""_re(const char* value, size_t len)
            {   return { real_type{ value }, real_type{} }; }

        inline cplx_type operator""_im(const char* value, size_t len)
            { return { real_type{}, real_type{ value }}; }
        
        inline cplx_type operator""_cn(const char* value, size_t len)
            { return { value }; }
    }
    // end of namepsace gmp::precision_float;

    namespace precision_double
    {
        using namespace gmp::calculus;
        namespace gmm = gmp::math;
        using gmp::operators::operator+;
        using gmp::operators::operator-;
        using gmp::operators::operator*;
        using gmp::operators::operator/;

        using gmp::math::operator%;
        using gmp::math::operator^;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
        using enum gmp::SolveMethod;
        using namespace gmp::output;
        using gmp::operator>>;
               
        using integer_type = gmp::intnum;
        using fraction_type = gmp::ratnum;
        using real_type = gmp::real_double_t;
        using cplx_type = gmp::cplx_double_t;

        constexpr mpfr_prec_t digits = realnum_prec_v<real_type>;
        constexpr mpfr_prec_t digits10 = std::numeric_limits<double>::digits10; // 15
        constexpr mpfr_prec_t display_prec = (mpfr_prec_t)(digits10  * (2.0/3));
        constexpr mpfr_rnd_t  Mpfr_Rnd = realnum_rnd_v<real_type>;
        constexpr mpc_rnd_t   Cplx_Rnd = cplxnum_rnd_v<cplx_type>;

        /////// derivative operators for type double////////////
        // epsilon_double = 2^−53 = 1.1e-10
        // h_opt = epsilon^{ 1 /(n+1) }
        // where n is the order of accuracy of the stencil

        constexpr double h3 = 1.0e-8;
        constexpr double h5 = 1.78e-3;
        constexpr double h7 = 6.61e-3;
        constexpr double h9 = 2.05e-2;

        //// derivative operators for type double //////////
        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5c = drv5c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9b = drv9b<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9f = drv9f<VarID, Order, DX>;

        //// default derivative operators for type quadruple
        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif_b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif_c = drv5c<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif_f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto dif = drv5c<VarID, Order, DX>;

        //////////////////// Jacobian Operator /////////////////
        inline constexpr auto jac3b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac3c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac3f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac5b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac5c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac5f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac7b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac7c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac7f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac9b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac9c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac9f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac_b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac_c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac_f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac = jac_cmd<five_point,  centered, h5>{};

        /////////////// metric tensor g_ij Operator //////////////////////
        inline constexpr auto mtt3b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt3c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt3f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt5b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt5c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt5f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt7b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt7c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt7f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt9b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt9c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt9f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt_b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt_c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt_f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt = mtt_cmd<five_point,  centered, h5>{};

        /////////////// gradient operator ///////////////////////////////
        inline constexpr auto grd3b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd3c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd3f = grd_cmd<three_point, forward,  h3>{};

        inline constexpr auto grd5b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd5c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd5f = grd_cmd<five_point,  forward,  h5>{};

        inline constexpr auto grd7b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd7c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd7f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd9b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd9c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd9f = grd_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto grd_b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd_c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd_f = grd_cmd<five_point,  forward, h5>{};

        inline constexpr auto grd = grd_cmd<five_point,  centered, h5>{};

        /////////////// laplacian operator ///////////////////////////////
        inline constexpr auto lap3b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap3c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap3f = lap_cmd<three_point, forward,  h3>{};

        inline constexpr auto lap5b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap5c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap5f = lap_cmd<five_point,  forward,  h5>{};

        inline constexpr auto lap7b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap7c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap7f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap9b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap9c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap9f = lap_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto lap_b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap_c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap_f = lap_cmd<five_point,  forward, h5>{};

        inline constexpr auto lap = lap_cmd<five_point,  centered, h5>{};

        /////////////// divergence operator ///////////////////////////////
        inline constexpr auto dvg3b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg3c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg3f = dvg_cmd<three_point, forward,  h3>{};

        inline constexpr auto dvg5b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg5c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg5f = dvg_cmd<five_point,  forward,  h5>{};

        inline constexpr auto dvg7b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg7c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg7f = dvg_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto dvg9b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg9c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg9f = dvg_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto dvg_b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg_c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg_f = dvg_cmd<five_point,  forward, h5>{};

        // Divergence - Flux per unit measure (line / area / volume)
        //
        //               ∬ 𝐅⋅𝑛𝑑𝑆
        // ∇⋅𝐅(𝑝) = lim —————————— 
        //         Δ𝑆→0     Δ𝑆
        //
        inline constexpr auto dvg = dvg_cmd<five_point,  centered, h5>{};

        ///////////////////// curl operator ///////////////////////////////
        inline constexpr auto crl3b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl3c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl3f = crl_cmd<three_point, forward,  h3>{};

        inline constexpr auto crl5b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl5c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl5f = crl_cmd<five_point,  forward,  h5>{};

        inline constexpr auto crl7b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl7c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl7f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl9b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl9c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl9f = crl_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto crl_b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl_c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl_f = crl_cmd<five_point,  forward, h5>{};

        inline constexpr auto crl = crl_cmd<five_point,  centered, h5>{};
               
        //////////// literals for realnum ///////////////////

        inline real_type operator""_rn(unsigned long long value)
            {   return { value };  }

        inline real_type operator""_rn(long double value)
            {   return { (double)value }; }

        inline real_type operator""_rn(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplxnum ///////////////////
        inline cplx_type operator""_cn(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_re(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_im(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_type operator""_cn(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_re(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_im(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_type operator""_re(const char* value, size_t len)
            {   return { real_type{ value }, real_type{} }; }

        inline cplx_type operator""_im(const char* value, size_t len)
            { return { real_type{}, real_type{ value }}; }
        
        inline cplx_type operator""_cn(const char* value, size_t len)
            { return { value }; }
    }
    // end of namepsace gmp::precision_double;
    
    namespace precision_quadruple
    {
        using namespace gmp;
        using namespace gmp::calculus;
        namespace gmm = gmp::math;

        using gmp::tc;
        using gmp::tc_t;

        using gmp::vc;
        using gmp::vc_t;
        
        using gmp::operators::operator+;
        using gmp::operators::operator-;
        using gmp::operators::operator*;
        using gmp::operators::operator/;

        using gmp::operator+;
        using gmp::operator-;
        using gmp::operator*;
        using gmp::operator/;

        using gmp::math::operator%;
        using gmp::math::operator^;

        using namespace std::complex_literals;
        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
        using enum gmp::SolveMethod;
        using enum gmp::SolveMethod;
        using namespace gmp::output;
        using gmp::operator>>;
        using enum gmp::CastRtnType;
               
        using integer_type = gmp::intnum;
        using fraction_type = gmp::ratnum;
        using real_type = gmp::real_quadruple_t;
        using cplx_type = gmp::cplx_quadruple_t;

        constexpr mpfr_prec_t digits = realnum_prec_v<real_type>;
        constexpr mpfr_prec_t digits10 = gmp::bits_2_digits(digits); // 34
        constexpr mpfr_prec_t display_prec = (mpfr_prec_t)(digits10  * (2.0/3));
        constexpr mpfr_rnd_t  Mpfr_Rnd = realnum_rnd_v<real_type>;
        constexpr mpc_rnd_t   Cplx_Rnd = cplxnum_rnd_v<cplx_type>;

        // quad-precision machine epsilon (113-bit significand)
        // constexpr long double eps_q = std::ldexp(1.0L, -113);
        
        // 5-, 7-, 9-point defaults
        constexpr double h3 = 1.0e-17;
        constexpr double h5 = 1.573e-7;
        constexpr double h7 = 1.382e-5;
        constexpr double h9 = 1.661e-4;

        //// derivative operators for type quadruple   ///////
        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5c = drv5c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9b = drv9b<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9f = drv9f<VarID, Order, DX>;

        //// default derivative operators for type quadruple
        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif_b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif_c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif_f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif = drv7c<VarID, Order, DX>;

        //////////////////// Jacobian Operator /////////////////
        inline constexpr auto jac3b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac3c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac3f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac5b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac5c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac5f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac7b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac7c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac7f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac9b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac9c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac9f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac_b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac_c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac_f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac = jac_cmd<seven_point,  centered, h7>{};

        /////////////// metric tensor g_ij Operator //////////////////////
        inline constexpr auto mtt3b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt3c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt3f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt5b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt5c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt5f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt7b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt7c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt7f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt9b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt9c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt9f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt_b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt_c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt_f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt = mtt_cmd<seven_point,  centered, h7>{};

        /////////////// gradient operator ///////////////////////////////
        inline constexpr auto grd3b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd3c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd3f = grd_cmd<three_point, forward,  h3>{};

        inline constexpr auto grd5b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd5c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd5f = grd_cmd<five_point,  forward,  h5>{};

        inline constexpr auto grd7b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd7c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd7f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd9b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd9c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd9f = grd_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto grd_b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd_c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd_f = grd_cmd<seven_point,  forward,  h7>{};

        template<auto TimdID = -1>
        inline constexpr auto grd = grd_cmd<TimdID, seven_point,  centered, h7>{};

        /////////////// laplacian operator ///////////////////////////////
        inline constexpr auto lap3b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap3c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap3f = lap_cmd<three_point, forward,  h3>{};

        inline constexpr auto lap5b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap5c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap5f = lap_cmd<five_point,  forward,  h5>{};

        inline constexpr auto lap7b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap7c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap7f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap9b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap9c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap9f = lap_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto lap_b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap_c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap_f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap = lap_cmd<seven_point,  centered, h7>{};

        /////////////// divergence operator ///////////////////////////////
        inline constexpr auto dvg3b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg3c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg3f = dvg_cmd<three_point, forward,  h3>{};

        inline constexpr auto dvg5b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg5c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg5f = dvg_cmd<five_point,  forward,  h5>{};

        inline constexpr auto dvg7b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg7c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg7f = dvg_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto dvg9b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg9c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg9f = dvg_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto dvg_b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg_c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg_f = dvg_cmd<seven_point,  forward,  h7>{};

        // Divergence - Flux per unit measure (line / area / volume)
        //              
        // ∇⋅𝐅(𝑝) = lim Δ𝑆→0 ∬ 𝐅⋅𝑛𝑑𝑆 / Δ𝑆
        //
        inline constexpr auto dvg = dvg_cmd<seven_point,  centered, h7>{};

        ///////////////////// curl operator ///////////////////////////////
        inline constexpr auto crl3b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl3c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl3f = crl_cmd<three_point, forward,  h3>{};

        inline constexpr auto crl5b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl5c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl5f = crl_cmd<five_point,  forward,  h5>{};

        inline constexpr auto crl7b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl7c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl7f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl9b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl9c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl9f = crl_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto crl_b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl_c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl_f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl = crl_cmd<seven_point,  centered, h7>{};

        ///////////////////// christoffel 1st kind //////////////////////////
        inline constexpr auto chr13b = chr1_cmd<three_point, backward, h3>{};
        inline constexpr auto chr13c = chr1_cmd<three_point, centered, h3>{};
        inline constexpr auto chr13f = chr1_cmd<three_point, forward,  h3>{};

        inline constexpr auto chr15b = chr1_cmd<five_point,  backward, h5>{};
        inline constexpr auto chr15c = chr1_cmd<five_point,  centered, h5>{};
        inline constexpr auto chr15f = chr1_cmd<five_point,  forward,  h5>{};

        inline constexpr auto chr17b = chr1_cmd<seven_point,  backward, h7>{};
        inline constexpr auto chr17c = chr1_cmd<seven_point,  centered, h7>{};
        inline constexpr auto chr17f = chr1_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto chr19b = chr1_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr19c = chr1_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr19f = chr1_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto chr1b = chr1_cmd<nine_point,  backward, h7>{};
        inline constexpr auto chr1c = chr1_cmd<nine_point,  centered, h7>{};
        inline constexpr auto chr1f = chr1_cmd<nine_point,  forward, h7>{};

        inline constexpr auto chr1  = chr1_cmd<nine_point,  centered, h7>{};

        ///////////////////// christoffel 2nd kind //////////////////////////
        inline constexpr auto chr23b = chr2_cmd<three_point, backward, h3>{};
        inline constexpr auto chr23c = chr2_cmd<three_point, centered, h3>{};
        inline constexpr auto chr23f = chr2_cmd<three_point, forward,  h3>{};

        inline constexpr auto chr25b = chr2_cmd<five_point,  backward, h5>{};
        inline constexpr auto chr25c = chr2_cmd<five_point,  centered, h5>{};
        inline constexpr auto chr25f = chr2_cmd<five_point,  forward,  h5>{};

        inline constexpr auto chr27b = chr2_cmd<seven_point,  backward, h7>{};
        inline constexpr auto chr27c = chr2_cmd<seven_point,  centered, h7>{};
        inline constexpr auto chr27f = chr2_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto chr29b = chr2_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr29c = chr2_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr29f = chr2_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto chr2b = chr2_cmd<nine_point,  backward, h7>{};
        inline constexpr auto chr2c = chr2_cmd<nine_point,  centered, h7>{};
        inline constexpr auto chr2f = chr2_cmd<nine_point,  forward, h7>{};

        inline constexpr auto chr2  = chr2_cmd<nine_point,  centered, h7>{};

        ///////////// christoffel 2nd kind metric tensor form //////////
        inline constexpr auto chr3b = chr_cmd<three_point, backward, h3>{};
        inline constexpr auto chr3c = chr_cmd<three_point, centered, h3>{};
        inline constexpr auto chr3f = chr_cmd<three_point, forward,  h3>{};

        inline constexpr auto chr5b = chr_cmd<five_point,  backward, h5>{};
        inline constexpr auto chr5c = chr_cmd<five_point,  centered, h5>{};
        inline constexpr auto chr5f = chr_cmd<five_point,  forward,  h5>{};

        inline constexpr auto chr7b = chr_cmd<seven_point,  backward, h7>{};
        inline constexpr auto chr7c = chr_cmd<seven_point,  centered, h7>{};
        inline constexpr auto chr7f = chr_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto chr9b = chr_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr9c = chr_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr9f = chr_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto chrb = chr_cmd<nine_point,  backward, h7>{};
        inline constexpr auto chrc = chr_cmd<nine_point,  centered, h7>{};
        inline constexpr auto chrf = chr_cmd<nine_point,  forward, h7>{};

        inline constexpr auto chr  = chr_cmd<nine_point,  centered, h7>{};

        ///////////////// raw derivative coefficients //////////////////////
        inline constexpr auto rdc3b = rdc_cmd<three_point, backward, h3>{};
        inline constexpr auto rdc3c = rdc_cmd<three_point, centered, h3>{};
        inline constexpr auto rdc3f = rdc_cmd<three_point, forward,  h3>{};

        inline constexpr auto rdc5b = rdc_cmd<five_point,  backward, h5>{};
        inline constexpr auto rdc5c = rdc_cmd<five_point,  centered, h5>{};
        inline constexpr auto rdc5f = rdc_cmd<five_point,  forward,  h5>{};

        inline constexpr auto rdc7b = rdc_cmd<seven_point,  backward, h7>{};
        inline constexpr auto rdc7c = rdc_cmd<seven_point,  centered, h7>{};
        inline constexpr auto rdc7f = rdc_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto rdc9b = rdc_cmd<nine_point,  backward, h9>{};
        inline constexpr auto rdc9c = rdc_cmd<nine_point,  centered, h9>{};
        inline constexpr auto rdc9f = rdc_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto rdcb = rdc_cmd<nine_point,  backward, h7>{};
        inline constexpr auto rdcc = rdc_cmd<nine_point,  centered, h7>{};
        inline constexpr auto rdcf = rdc_cmd<nine_point,  forward, h7>{};

        inline constexpr auto rdc  = rdc_cmd<nine_point,  centered, h7>{};

        ///////////////// structure coefficients //////////////////////////
        inline constexpr auto stc3b = stc_cmd<three_point, backward, h3>{};
        inline constexpr auto stc3c = stc_cmd<three_point, centered, h3>{};
        inline constexpr auto stc3f = stc_cmd<three_point, forward,  h3>{};

        inline constexpr auto stc5b = stc_cmd<five_point,  backward, h5>{};
        inline constexpr auto stc5c = stc_cmd<five_point,  centered, h5>{};
        inline constexpr auto stc5f = stc_cmd<five_point,  forward,  h5>{};

        inline constexpr auto stc7b = stc_cmd<seven_point,  backward, h7>{};
        inline constexpr auto stc7c = stc_cmd<seven_point,  centered, h7>{};
        inline constexpr auto stc7f = stc_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto stc9b = stc_cmd<nine_point,  backward, h9>{};
        inline constexpr auto stc9c = stc_cmd<nine_point,  centered, h9>{};
        inline constexpr auto stc9f = stc_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto stcb = stc_cmd<nine_point,  backward, h7>{};
        inline constexpr auto stcc = stc_cmd<nine_point,  centered, h7>{};
        inline constexpr auto stcf = stc_cmd<nine_point,  forward, h7>{};

        inline constexpr auto stc  = stc_cmd<nine_point,  centered, h7>{};
        
        //////////// literals for realnum ///////////////////

        inline real_type operator""_rn(unsigned long long value)
            {   return { value };  }

        inline real_type operator""_rn(long double value)
            {   return { (double)value }; }

        inline real_type operator""_rn(const char* value, size_t len)
            {   return { value }; }

        ////////////////////////////////////////////////////////
        inline real_type operator""_fr(const char* value, size_t len)
        { 
            std::stringstream nus;
            
            if(len == 0) return {0};
            
            int comma = 0;

            while(comma < len)
            {
                if(value[comma] == ',' || value[comma] == '/') break;

                if (value[comma] != ' ') nus << value[comma];

                ++comma;
            }
            
            auto nu = nus.str();
            
            if(nu.empty()) nu = "1";

            if(comma == len) return { nu.c_str() };

            std::stringstream des;

            ++comma;
            while(comma < len)
            {
                if (value[comma] != ' ' || value[comma] == '/')
                    des << value[comma];
                
                ++comma;
            }
        
            auto de = des.str();
            
            if( de.empty() )
                return { nu.c_str() };
            else 
                return { ratnum{ nu.c_str(), de.c_str() } };
        }

        //////////// literals for cplxnum ///////////////////
        inline cplx_type operator""_cn(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_re(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_im(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_type operator""_cn(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_re(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_im(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_type operator""_re(const char* value, size_t len)
            {   return { real_type{ value }, real_type{} }; }

        inline cplx_type operator""_im(const char* value, size_t len)
            { return { real_type{}, real_type{ value }}; }
        
        inline cplx_type operator""_cn(const char* value, size_t len)
            { return { value }; }
    }
    // end of namepsace gmp::precision_quadruple; 

    namespace precision_octuple
    {
        using namespace gmp::calculus;
        namespace gmm = gmp::math;

        using gmp::operators::operator+;
        using gmp::operators::operator-;
        using gmp::operators::operator*;
        using gmp::operators::operator/;

        using gmp::math::operator%;
        using gmp::math::operator^;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
        using enum gmp::SolveMethod;
        using namespace gmp::output;
        using gmp::operator>>;
               
        using integer_type = gmp::intnum;
        using fraction_type = gmp::ratnum;
        using real_type = gmp::real_octuple_t;
        using cplx_type = gmp::cplx_octuple_t;

        constexpr mpfr_prec_t digits = realnum_prec_v<real_type>;
        constexpr mpfr_prec_t digits10 = gmp::bits_2_digits(digits); // 68
        constexpr mpfr_prec_t display_prec = (mpfr_prec_t)(digits10  * (2.0/3));
        constexpr mpfr_rnd_t  Mpfr_Rnd = realnum_rnd_v<real_type>;
        constexpr mpc_rnd_t   Cplx_Rnd = cplxnum_rnd_v<cplx_type>;

        // 5-, 7-, 9-point defaults
        constexpr double h3 = 1.0e-34;
        constexpr double h5 = 2.474253515e-14;
        constexpr double h7 = 1.909992090e-10;
        constexpr double h9 = 2.759321667e-08;

        //// derivative operators for type octuple   ///////
        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5c = drv5c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9b = drv9b<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9f = drv9f<VarID, Order, DX>;

        //// default derivative operators for type octuple
        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif_b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif_c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif_f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto dif = drv7c<VarID, Order, DX>;

        //////////////////// Jacobian Operator /////////////////
        inline constexpr auto jac3b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac3c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac3f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac5b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac5c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac5f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac7b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac7c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac7f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac9b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac9c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac9f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac_b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac_c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac_f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac = jac_cmd<seven_point,  centered, h7>{};

        /////////////// metric tensor g_ij Operator //////////////////////
        inline constexpr auto mtt3b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt3c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt3f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt5b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt5c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt5f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt7b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt7c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt7f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt9b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt9c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt9f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt_b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt_c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt_f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt = mtt_cmd<seven_point,  centered, h7>{};

        /////////////// gradient operator ///////////////////////////////
        inline constexpr auto grd3b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd3c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd3f = grd_cmd<three_point, forward,  h3>{};

        inline constexpr auto grd5b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd5c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd5f = grd_cmd<five_point,  forward,  h5>{};

        inline constexpr auto grd7b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd7c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd7f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd9b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd9c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd9f = grd_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto grd_b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd_c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd_f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd = grd_cmd<seven_point,  centered, h7>{};

        /////////////// laplacian operator ///////////////////////////////
        inline constexpr auto lap3b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap3c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap3f = lap_cmd<three_point, forward,  h3>{};

        inline constexpr auto lap5b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap5c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap5f = lap_cmd<five_point,  forward,  h5>{};

        inline constexpr auto lap7b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap7c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap7f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap9b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap9c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap9f = lap_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto lap_b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap_c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap_f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap = lap_cmd<seven_point,  centered, h7>{};

        /////////////// divergence operator ///////////////////////////////
        inline constexpr auto dvg3b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg3c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg3f = dvg_cmd<three_point, forward,  h3>{};

        inline constexpr auto dvg5b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg5c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg5f = dvg_cmd<five_point,  forward,  h5>{};

        inline constexpr auto dvg7b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg7c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg7f = dvg_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto dvg9b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg9c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg9f = dvg_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto dvg_b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg_c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg_f = dvg_cmd<seven_point,  forward,  h7>{};

        // Divergence - Flux per unit measure (line / area / volume)
        //              
        // ∇⋅𝐅(𝑝) = lim Δ𝑆→0 ∬ 𝐅⋅𝑛𝑑𝑆 / Δ𝑆
        //
        inline constexpr auto dvg = dvg_cmd<seven_point,  centered, h7>{};

        ///////////////////// curl operator ///////////////////////////////
        inline constexpr auto crl3b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl3c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl3f = crl_cmd<three_point, forward,  h3>{};

        inline constexpr auto crl5b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl5c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl5f = crl_cmd<five_point,  forward,  h5>{};

        inline constexpr auto crl7b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl7c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl7f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl9b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl9c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl9f = crl_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto crl_b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl_c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl_f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl = crl_cmd<seven_point,  centered, h7>{};

        //////////// literals for realnum ///////////////////

        inline real_type operator""_rn(unsigned long long value)
            {   return { value };  }

        inline real_type operator""_rn(long double value)
            {   return { (double)value }; }

        inline real_type operator""_rn(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplxnum ///////////////////
        inline cplx_type operator""_cn(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_re(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_im(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_type operator""_cn(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_re(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_im(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_type operator""_re(const char* value, size_t len)
            {   return { real_type{ value }, real_type{} }; }

        inline cplx_type operator""_im(const char* value, size_t len)
            { return { real_type{}, real_type{ value }}; }
        
        inline cplx_type operator""_cn(const char* value, size_t len)
            { return { value }; }
    }
    // end of namepsace gmp::precision_octuple; 

    namespace precision_huge
    {
        using namespace gmp::calculus;
        namespace gmm = gmp::math;

        using gmp::operators::operator+;
        using gmp::operators::operator-;
        using gmp::operators::operator*;
        using gmp::operators::operator/;

        using gmp::tc;
        using gmp::vc;

        using gmp::math::operator%;
        using gmp::math::operator^;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
        using enum gmp::SolveMethod;
        using namespace gmp::output;
        using gmp::operator>>;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
               
        using integer_type = gmp::intnum;
        using fraction_type = gmp::ratnum;
        using real_type = gmp::real_huge_t;
        using cplx_type = gmp::cplx_huge_t;

        constexpr mpfr_prec_t digits = realnum_prec_v<real_type>;
        constexpr mpfr_prec_t digits10 = gmp::bits_2_digits(digits); // 154
        constexpr mpfr_prec_t display_prec = (mpfr_prec_t)(digits10  * (2.0/3));
        constexpr mpfr_rnd_t  Mpfr_Rnd = realnum_rnd_v<real_type>;
        constexpr mpc_rnd_t   Cplx_Rnd = cplxnum_rnd_v<cplx_type>;

        // 5-, 7-, 9-point defaults
        constexpr double h3 = 1.0e-77;
        constexpr double h5 = 1.494611928e-31;
        constexpr double h7 = 9.589722309e-23;
        constexpr double h9 = 7.494419938e-18;

        //// derivative operators for type huge //// ///////
        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5c = drv5c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9b = drv9b<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9f = drv9f<VarID, Order, DX>;

        //// default derivative operators for type huge
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif_b = drv9b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif_c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif_f = drv9f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif = drv9c<VarID, Order, DX>;
        
        //////////////////// Jacobian Operator /////////////////
        inline constexpr auto jac3b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac3c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac3f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac5b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac5c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac5f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac7b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac7c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac7f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac9b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac9c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac9f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac_b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac_c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac_f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac = jac_cmd<nine_point,  centered, h9>{};

        /////////////// metric tensor g_ij Operator //////////////////////
        inline constexpr auto mtt3b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt3c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt3f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt5b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt5c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt5f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt7b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt7c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt7f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt9b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt9c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt9f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt_b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt_c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt_f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt = mtt_cmd<nine_point,  centered, h9>{};

        /////////////// gradient operator ///////////////////////////////
        inline constexpr auto grd3b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd3c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd3f = grd_cmd<three_point, forward,  h3>{};

        inline constexpr auto grd5b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd5c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd5f = grd_cmd<five_point,  forward,  h5>{};

        inline constexpr auto grd7b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd7c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd7f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd9b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd9c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd9f = grd_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto grd_b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd_c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd_f = grd_cmd<nine_point,  forward, h9>{};

        inline constexpr auto grd = grd_cmd<nine_point,  centered, h9>{};

        /////////////// laplacian operator ////////////////////////////////
        inline constexpr auto lap3b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap3c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap3f = lap_cmd<three_point, forward,  h3>{};

        inline constexpr auto lap5b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap5c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap5f = lap_cmd<five_point,  forward,  h5>{};

        inline constexpr auto lap7b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap7c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap7f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap9b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap9c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap9f = lap_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto lap_b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap_c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap_f = lap_cmd<nine_point,  forward, h9>{};

        inline constexpr auto lap = lap_cmd<nine_point,  centered, h9>{};

        /////////////// divergence operator ///////////////////////////////
        inline constexpr auto dvg3b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg3c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg3f = dvg_cmd<three_point, forward,  h3>{};

        inline constexpr auto dvg5b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg5c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg5f = dvg_cmd<five_point,  forward,  h5>{};

        inline constexpr auto dvg7b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg7c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg7f = dvg_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto dvg9b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg9c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg9f = dvg_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto dvg_b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg_c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg_f = dvg_cmd<nine_point,  forward, h9>{};

        // Divergence - Flux per unit measure (line / area / volume)
        //              
        // ∇⋅𝐅(𝑝) = lim Δ𝑆→0 ∬ 𝐅⋅𝑛𝑑𝑆 / Δ𝑆
        //
        inline constexpr auto dvg = dvg_cmd<nine_point,  centered, h9>{};

        ///////////////////// curl operator ///////////////////////////////
        inline constexpr auto crl3b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl3c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl3f = crl_cmd<three_point, forward,  h3>{};

        inline constexpr auto crl5b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl5c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl5f = crl_cmd<five_point,  forward,  h5>{};

        inline constexpr auto crl7b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl7c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl7f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl9b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl9c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl9f = crl_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto crl_b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl_c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl_f = crl_cmd<nine_point,  forward, h9>{};

        inline constexpr auto crl = crl_cmd<nine_point,  centered, h9>{};
    
        ///////////////////// christoffel 1st kind //////////////////////////
        inline constexpr auto chr13b = chr1_cmd<three_point, backward, h3>{};
        inline constexpr auto chr13c = chr1_cmd<three_point, centered, h3>{};
        inline constexpr auto chr13f = chr1_cmd<three_point, forward,  h3>{};

        inline constexpr auto chr15b = chr1_cmd<five_point,  backward, h5>{};
        inline constexpr auto chr15c = chr1_cmd<five_point,  centered, h5>{};
        inline constexpr auto chr15f = chr1_cmd<five_point,  forward,  h5>{};

        inline constexpr auto chr17b = chr1_cmd<seven_point,  backward, h7>{};
        inline constexpr auto chr17c = chr1_cmd<seven_point,  centered, h7>{};
        inline constexpr auto chr17f = chr1_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto chr19b = chr1_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr19c = chr1_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr19f = chr1_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto chr1b = chr1_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr1c = chr1_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr1f = chr1_cmd<nine_point,  forward, h9>{};

        inline constexpr auto chr1  = chr1_cmd<nine_point,  centered, h9>{};

        ///////////////////// christoffel 2nd kind //////////////////////////
        inline constexpr auto chr23b = chr2_cmd<three_point, backward, h3>{};
        inline constexpr auto chr23c = chr2_cmd<three_point, centered, h3>{};
        inline constexpr auto chr23f = chr2_cmd<three_point, forward,  h3>{};

        inline constexpr auto chr25b = chr2_cmd<five_point,  backward, h5>{};
        inline constexpr auto chr25c = chr2_cmd<five_point,  centered, h5>{};
        inline constexpr auto chr25f = chr2_cmd<five_point,  forward,  h5>{};

        inline constexpr auto chr27b = chr2_cmd<seven_point,  backward, h7>{};
        inline constexpr auto chr27c = chr2_cmd<seven_point,  centered, h7>{};
        inline constexpr auto chr27f = chr2_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto chr29b = chr2_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr29c = chr2_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr29f = chr2_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto chr2b = chr2_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr2c = chr2_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr2f = chr2_cmd<nine_point,  forward, h9>{};

        inline constexpr auto chr2  = chr2_cmd<nine_point,  centered, h9>{};

        ///////////// christoffel 2nd kind metric tensor form //////////
        inline constexpr auto chr3b = chr_cmd<three_point, backward, h3>{};
        inline constexpr auto chr3c = chr_cmd<three_point, centered, h3>{};
        inline constexpr auto chr3f = chr_cmd<three_point, forward,  h3>{};

        inline constexpr auto chr5b = chr_cmd<five_point,  backward, h5>{};
        inline constexpr auto chr5c = chr_cmd<five_point,  centered, h5>{};
        inline constexpr auto chr5f = chr_cmd<five_point,  forward,  h5>{};

        inline constexpr auto chr7b = chr_cmd<seven_point,  backward, h7>{};
        inline constexpr auto chr7c = chr_cmd<seven_point,  centered, h7>{};
        inline constexpr auto chr7f = chr_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto chr9b = chr_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chr9c = chr_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chr9f = chr_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto chrb = chr_cmd<nine_point,  backward, h9>{};
        inline constexpr auto chrc = chr_cmd<nine_point,  centered, h9>{};
        inline constexpr auto chrf = chr_cmd<nine_point,  forward, h9>{};

        inline constexpr auto chr  = chr_cmd<nine_point,  centered, h9>{};

        ///////////////// raw derivative coefficients //////////////////////
        inline constexpr auto rdc3b = rdc_cmd<three_point, backward, h3>{};
        inline constexpr auto rdc3c = rdc_cmd<three_point, centered, h3>{};
        inline constexpr auto rdc3f = rdc_cmd<three_point, forward,  h3>{};

        inline constexpr auto rdc5b = rdc_cmd<five_point,  backward, h5>{};
        inline constexpr auto rdc5c = rdc_cmd<five_point,  centered, h5>{};
        inline constexpr auto rdc5f = rdc_cmd<five_point,  forward,  h5>{};

        inline constexpr auto rdc7b = rdc_cmd<seven_point,  backward, h7>{};
        inline constexpr auto rdc7c = rdc_cmd<seven_point,  centered, h7>{};
        inline constexpr auto rdc7f = rdc_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto rdc9b = rdc_cmd<nine_point,  backward, h9>{};
        inline constexpr auto rdc9c = rdc_cmd<nine_point,  centered, h9>{};
        inline constexpr auto rdc9f = rdc_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto rdcb = rdc_cmd<nine_point,  backward, h9>{};
        inline constexpr auto rdcc = rdc_cmd<nine_point,  centered, h9>{};
        inline constexpr auto rdcf = rdc_cmd<nine_point,  forward, h9>{};

        inline constexpr auto rdc  = rdc_cmd<nine_point,  centered, h9>{};

        ///////////////// structure coefficients //////////////////////////
        inline constexpr auto stc3b = stc_cmd<three_point, backward, h3>{};
        inline constexpr auto stc3c = stc_cmd<three_point, centered, h3>{};
        inline constexpr auto stc3f = stc_cmd<three_point, forward,  h3>{};

        inline constexpr auto stc5b = stc_cmd<five_point,  backward, h5>{};
        inline constexpr auto stc5c = stc_cmd<five_point,  centered, h5>{};
        inline constexpr auto stc5f = stc_cmd<five_point,  forward,  h5>{};

        inline constexpr auto stc7b = stc_cmd<seven_point,  backward, h7>{};
        inline constexpr auto stc7c = stc_cmd<seven_point,  centered, h7>{};
        inline constexpr auto stc7f = stc_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto stc9b = stc_cmd<nine_point,  backward, h9>{};
        inline constexpr auto stc9c = stc_cmd<nine_point,  centered, h9>{};
        inline constexpr auto stc9f = stc_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto stcb = stc_cmd<nine_point,  backward, h9>{};
        inline constexpr auto stcc = stc_cmd<nine_point,  centered, h9>{};
        inline constexpr auto stcf = stc_cmd<nine_point,  forward, h9>{};

        inline constexpr auto stc  = stc_cmd<nine_point,  centered, h9>{};

        //////////// literals for realnum ///////////////////

        inline real_type operator""_rn(unsigned long long value)
            {   return { value };  }

        inline real_type operator""_rn(long double value)
            {   return { (double)value }; }

        inline real_type operator""_rn(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplxnum ///////////////////
        inline cplx_type operator""_cn(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_re(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_im(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_type operator""_cn(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_re(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_im(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_type operator""_re(const char* value, size_t len)
            {   return { real_type{ value }, real_type{} }; }

        inline cplx_type operator""_im(const char* value, size_t len)
            { return { real_type{}, real_type{ value }}; }
        
        inline cplx_type operator""_cn(const char* value, size_t len)
            { return { value }; }
    }
    // end of namepsace gmp::precision_huge; 

    namespace precision_super_huge
    {
        using namespace gmp::calculus;
        namespace gmm = gmp::math;

        using gmp::operators::operator+;
        using gmp::operators::operator-;
        using gmp::operators::operator*;
        using gmp::operators::operator/;

        using gmp::math::operator%;
        using gmp::math::operator^;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
        using enum gmp::SolveMethod;
        using namespace gmp::output;
        using gmp::operator>>;

        using namespace gmp::literals;
        using namespace gmp::operators;
        using enum gmp::PolyMode;
               
        using integer_type = gmp::intnum;
        using fraction_type = gmp::ratnum;
        using real_type = gmp::real_super_huge_t;
        using cplx_type = gmp::cplx_super_huge_t;

        constexpr mpfr_prec_t digits = realnum_prec_v<real_type>;
        constexpr mpfr_prec_t digits10 = gmp::bits_2_digits(digits); // 307
        constexpr mpfr_prec_t display_prec = (mpfr_prec_t)(digits10  * (2.0/3));
        constexpr mpfr_rnd_t  Mpfr_Rnd = realnum_rnd_v<real_type>;
        constexpr mpc_rnd_t   Cplx_Rnd = cplxnum_rnd_v<cplx_type>;

        // 5-, 7-, 9-point defaults
        constexpr double h3 = 1.0e-154;
        constexpr double h5 = 2.2338648165e-62;
        constexpr double h7 = 9.1962773968e-45;
        constexpr double h9 = 5.6166330208e-35;

        //// derivative operators for type super huge ///////
        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3b = drv3b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3c = drv3c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h3>
        inline constexpr auto d3f = drv3f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5b = drv5b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5c = drv5c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h5>
        inline constexpr auto d5f = drv5f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7b = drv7b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7c = drv7c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h7>
        inline constexpr auto d7f = drv7f<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9b = drv9b<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto d9f = drv9f<VarID, Order, DX>;

        //// default derivative operators for super huge
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif_b = drv9b<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif_c = drv9c<VarID, Order, DX>;

        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif_f = drv9f<VarID, Order, DX>;
        
        template<auto VarID = 0, auto Order = 1, auto DX= h9>
        inline constexpr auto dif = drv9c<VarID, Order, DX>;

        //////////////////// Jacobian Operator /////////////////
        inline constexpr auto jac3b = jac_cmd<three_point, backward, h3>{};
        inline constexpr auto jac3c = jac_cmd<three_point, centered, h3>{};
        inline constexpr auto jac3f = jac_cmd<three_point, forward,  h3>{};

        inline constexpr auto jac5b = jac_cmd<five_point,  backward, h5>{};
        inline constexpr auto jac5c = jac_cmd<five_point,  centered, h5>{};
        inline constexpr auto jac5f = jac_cmd<five_point,  forward,  h5>{};

        inline constexpr auto jac7b = jac_cmd<seven_point,  backward, h7>{};
        inline constexpr auto jac7c = jac_cmd<seven_point,  centered, h7>{};
        inline constexpr auto jac7f = jac_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto jac9b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac9c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac9f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac_b = jac_cmd<nine_point,  backward, h9>{};
        inline constexpr auto jac_c = jac_cmd<nine_point,  centered, h9>{};
        inline constexpr auto jac_f = jac_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto jac = jac_cmd<nine_point,  centered, h9>{};

        /////////////// metric tensor g_ij Operator //////////////////////
        inline constexpr auto mtt3b = mtt_cmd<three_point, backward, h3>{};
        inline constexpr auto mtt3c = mtt_cmd<three_point, centered, h3>{};
        inline constexpr auto mtt3f = mtt_cmd<three_point, forward,  h3>{};

        inline constexpr auto mtt5b = mtt_cmd<five_point,  backward, h5>{};
        inline constexpr auto mtt5c = mtt_cmd<five_point,  centered, h5>{};
        inline constexpr auto mtt5f = mtt_cmd<five_point,  forward,  h5>{};

        inline constexpr auto mtt7b = mtt_cmd<seven_point,  backward, h7>{};
        inline constexpr auto mtt7c = mtt_cmd<seven_point,  centered, h7>{};
        inline constexpr auto mtt7f = mtt_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto mtt9b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt9c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt9f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt_b = mtt_cmd<nine_point,  backward, h9>{};
        inline constexpr auto mtt_c = mtt_cmd<nine_point,  centered, h9>{};
        inline constexpr auto mtt_f = mtt_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto mtt = mtt_cmd<nine_point,  centered, h9>{};

        /////////////// gradient operator ///////////////////////////////
        inline constexpr auto grd3b = grd_cmd<three_point, backward, h3>{};
        inline constexpr auto grd3c = grd_cmd<three_point, centered, h3>{};
        inline constexpr auto grd3f = grd_cmd<three_point, forward,  h3>{};

        inline constexpr auto grd5b = grd_cmd<five_point,  backward, h5>{};
        inline constexpr auto grd5c = grd_cmd<five_point,  centered, h5>{};
        inline constexpr auto grd5f = grd_cmd<five_point,  forward,  h5>{};

        inline constexpr auto grd7b = grd_cmd<seven_point,  backward, h7>{};
        inline constexpr auto grd7c = grd_cmd<seven_point,  centered, h7>{};
        inline constexpr auto grd7f = grd_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto grd9b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd9c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd9f = grd_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto grd_b = grd_cmd<nine_point,  backward, h9>{};
        inline constexpr auto grd_c = grd_cmd<nine_point,  centered, h9>{};
        inline constexpr auto grd_f = grd_cmd<nine_point,  forward, h9>{};

        inline constexpr auto grd = grd_cmd<nine_point,  centered, h9>{};

        /////////////// laplacian operator ///////////////////////////////
        inline constexpr auto lap3b = lap_cmd<three_point, backward, h3>{};
        inline constexpr auto lap3c = lap_cmd<three_point, centered, h3>{};
        inline constexpr auto lap3f = lap_cmd<three_point, forward,  h3>{};

        inline constexpr auto lap5b = lap_cmd<five_point,  backward, h5>{};
        inline constexpr auto lap5c = lap_cmd<five_point,  centered, h5>{};
        inline constexpr auto lap5f = lap_cmd<five_point,  forward,  h5>{};

        inline constexpr auto lap7b = lap_cmd<seven_point,  backward, h7>{};
        inline constexpr auto lap7c = lap_cmd<seven_point,  centered, h7>{};
        inline constexpr auto lap7f = lap_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto lap9b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap9c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap9f = lap_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto lap_b = lap_cmd<nine_point,  backward, h9>{};
        inline constexpr auto lap_c = lap_cmd<nine_point,  centered, h9>{};
        inline constexpr auto lap_f = lap_cmd<nine_point,  forward, h9>{};

        inline constexpr auto lap = lap_cmd<nine_point,  centered, h9>{};

        /////////////// divergence operator ///////////////////////////////
        inline constexpr auto dvg3b = dvg_cmd<three_point, backward, h3>{};
        inline constexpr auto dvg3c = dvg_cmd<three_point, centered, h3>{};
        inline constexpr auto dvg3f = dvg_cmd<three_point, forward,  h3>{};

        inline constexpr auto dvg5b = dvg_cmd<five_point,  backward, h5>{};
        inline constexpr auto dvg5c = dvg_cmd<five_point,  centered, h5>{};
        inline constexpr auto dvg5f = dvg_cmd<five_point,  forward,  h5>{};

        inline constexpr auto dvg7b = dvg_cmd<seven_point,  backward, h7>{};
        inline constexpr auto dvg7c = dvg_cmd<seven_point,  centered, h7>{};
        inline constexpr auto dvg7f = dvg_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto dvg9b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg9c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg9f = dvg_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto dvg_b = dvg_cmd<nine_point,  backward, h9>{};
        inline constexpr auto dvg_c = dvg_cmd<nine_point,  centered, h9>{};
        inline constexpr auto dvg_f = dvg_cmd<nine_point,  forward, h9>{};

        // Divergence - Flux per unit measure (line / area / volume)
        //              
        // ∇⋅𝐅(𝑝) = lim Δ𝑆→0 ∬ 𝐅⋅𝑛𝑑𝑆 / Δ𝑆
        //
        inline constexpr auto dvg = dvg_cmd<nine_point,  centered, h9>{};

        ///////////////////// curl operator ///////////////////////////////
        inline constexpr auto crl3b = crl_cmd<three_point, backward, h3>{};
        inline constexpr auto crl3c = crl_cmd<three_point, centered, h3>{};
        inline constexpr auto crl3f = crl_cmd<three_point, forward,  h3>{};

        inline constexpr auto crl5b = crl_cmd<five_point,  backward, h5>{};
        inline constexpr auto crl5c = crl_cmd<five_point,  centered, h5>{};
        inline constexpr auto crl5f = crl_cmd<five_point,  forward,  h5>{};

        inline constexpr auto crl7b = crl_cmd<seven_point,  backward, h7>{};
        inline constexpr auto crl7c = crl_cmd<seven_point,  centered, h7>{};
        inline constexpr auto crl7f = crl_cmd<seven_point,  forward,  h7>{};

        inline constexpr auto crl9b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl9c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl9f = crl_cmd<nine_point,  forward,  h9>{};

        inline constexpr auto crl_b = crl_cmd<nine_point,  backward, h9>{};
        inline constexpr auto crl_c = crl_cmd<nine_point,  centered, h9>{};
        inline constexpr auto crl_f = crl_cmd<nine_point,  forward, h9>{};

        inline constexpr auto crl = crl_cmd<nine_point,  centered, h9>{};

        //////////// literals for realnum ///////////////////

        inline real_type operator""_rn(unsigned long long value)
            {   return { value };  }

        inline real_type operator""_rn(long double value)
            {   return { (double)value }; }

        inline real_type operator""_rn(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplxnum ///////////////////
        inline cplx_type operator""_cn(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_re(unsigned long long value)
            {   return { value }; }

        inline cplx_type operator""_im(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_type operator""_cn(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_re(long double value)
            {   return { (double)value }; }

        inline cplx_type operator""_im(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_type operator""_re(const char* value, size_t len)
            {   return { real_type{ value }, real_type{} }; }

        inline cplx_type operator""_im(const char* value, size_t len)
            { return { real_type{}, real_type{ value }}; }
        
        inline cplx_type operator""_cn(const char* value, size_t len)
            { return { value }; }
    }
    // end of namepsace gmp::precision_super_huge; 
}
// end of namepsace gmp; 

#endif
