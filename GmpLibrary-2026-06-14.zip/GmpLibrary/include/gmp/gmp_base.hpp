﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    First Edit: 2025.01.07
    Second Edit: 2025.07.02
    Third Edit: 2025.09.02 Tensor operators
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/

    Compiler switches:

    cl source.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
    nvcc source.cpp -o n.exe -arch=sm_75 -Xcompiler /std:c++latest -Xcompiler /EHsc

    clang++ source.cpp -o c.exe -std=c++23 -lgmp -lmpc -lmpfr -ltbb12
    clang++ source.cpp -o c.exe -std=c++23 -lgmp -lmpc -lmpfr -lopencl -ltbb12 -ltbbmalloc -ltbbmalloc_proxy

    g++ source.cpp -o g.exe -std=c++23 -lgmp -lmpc -lmpfr -ltbb12
    g++ source.cpp -o g.exe -std=c++23 -lgmp -lmpc -lmpfr -lopencl -ltbb12 -ltbbmalloc -ltbbmalloc_proxy

    For Memory Leak Test:  
    cl types.cpp /Fe: m.exe /std:c++latest /MDd /EHsc /nologo
*/

#ifndef _GMP_BASE_HPP
#define _GMP_BASE_HPP

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#if defined(_MSVC_LANG) || defined(__INTEL_LLVM_COMPILER)

    #if defined(_DEBUG) || defined(DEBUG)
        // #pragma message("DEBUG BUILD, liked with mpir_d, mpfr_d")
        #pragma comment(lib, "mpir_d.lib")
        #pragma comment(lib, "mpfr_d.lib")
        #pragma comment(lib, "mpc_d.lib")
    #else
        // #pragma message("NODEBUG BUILD, liked with mpir, mpfr")
        #pragma comment(lib, "mpir.lib")
        #pragma comment(lib, "mpfr.lib")
        #pragma comment(lib, "mpc.lib")
    #endif

    #pragma comment(lib, "tbbmalloc.lib")
    #pragma comment(lib, "tbbmalloc_proxy.lib")
    
#else

// IntelliSense is sometimes blind to complex || logic.
// Giving it preprocessed-friendly clues helps it calm down.

# define _Dummy_LANG 202002L  // for IntelliSense fallback

#endif

#include <iostream>
#include <memory>
#include <iomanip>
#include <cmath>
#include <complex>
#include <concepts>
#include <cstdlib>
#include <cstdio>
#include <tuple>
#include <cstring>
#include <string>
#include <compare>
#include <algorithm>
#include <regex>
#include <vector>
#include <cctype>
#include <numbers>
#include <type_traits>
#include <ranges>
#include <vector>
#include <limits>
#include <stdexcept>
#include <cassert>
#include <optional>

#ifndef TBB_PREVIEW_MEMORY_POOL
    #define TBB_PREVIEW_MEMORY_POOL 1
#endif

#include <tbb/tbb.h>
#include <tbb/memory_pool.h>
#include <tbb/parallel_invoke.h>

#include <gmp/gmp_check.hpp>
#include <gmp.h>
#include <mpreal.h>
#include <mpc.h>

#if defined(_MSVC_LANG) || defined(__INTEL_LLVM_COMPILER)   
    extern const int __gmp_bits_per_limb = sizeof(mp_limb_t)*8;
#endif 

#ifndef SIZEOF_UINTMAX_T
#define SIZEOF_UINTMAX_T	 sizeof(std::uintmax_t)
#endif 

#ifndef NLIMBS
#define NLIMBS ((8 * SIZEOF_UINTMAX_T + GMP_NUMB_BITS  - 1) / GMP_NUMB_BITS)
#endif

#if defined(__INTEL_LLVM_COMPILER)               /* icx / icx-cl */
#  if __INTEL_LLVM_COMPILER >= 1000000           /* ≥ 2021.2 (VVVVRRPP) */
#    define ICX_VER_MAJOR   (__INTEL_LLVM_COMPILER / 10000)
#    define ICX_VER_MINOR   (__INTEL_LLVM_COMPILER / 100 % 100)
#    define ICX_VER_PATCH   (__INTEL_LLVM_COMPILER % 100)
#  else                                          /* ≤ 2021.1 (VVVVRP)   */
#    define ICX_VER_MAJOR   (__INTEL_LLVM_COMPILER / 100)
#    define ICX_VER_MINOR   (__INTEL_LLVM_COMPILER / 10 % 10)
#    define ICX_VER_PATCH   (__INTEL_LLVM_COMPILER % 10)
#  endif
#endif

#if defined(_MSC_FULL_VER)                       /* MSVC / MSVC-clang */
#  if _MSC_FULL_VER >= 100000000                /* ≥ VS 2015 (VVRRPPPPP) */
#    define MSVC_VER_MAJOR  (_MSC_FULL_VER / 10000000)
#    define MSVC_VER_MINOR  (_MSC_FULL_VER / 100000 % 100)
#    define MSVC_VER_PATCH  (_MSC_FULL_VER % 100000)
#  else                                          /* < VS 2015 (VVRRPPPP)  */
#    define MSVC_VER_MAJOR  (_MSC_FULL_VER / 1000000)
#    define MSVC_VER_MINOR  (_MSC_FULL_VER / 10000 % 100)
#    define MSVC_VER_PATCH  (_MSC_FULL_VER % 10000)
#  endif
#endif

#define Gmp_Forward(CommonType, value) \
    static_cast<CommonType>(std::forward<decltype(value)>(value))

namespace gmp
{    
    using namespace std::complex_literals;

    template<typename T>
    concept nothrow_move_constructible_c =
        std::is_nothrow_move_constructible_v<std::remove_cvref_t<T>>;
        
    template<auto arg>
    consteval auto maximum() { return arg; }

    template<auto arg1, auto arg2, auto... args>
    consteval auto maximum()
    {
        return maximum< (arg1 > arg2 ? arg1 : arg2), args... >();
    }

    template<typename T> T fast_power(T x, int n)
    {
        if (n == 0)
        {
            return T{1};
        }
        else if(n > 0)
        {
            T result{1};

            while (n > 0)
            {
                if (n & 1) result *= x;

                x *= x; n >>= 1;
            }
            return result;
        }
        else // n < 0
        {
            return T{1} / fast_power(x, -n);
        }
    }

    template<typename T, typename A>
    T eval_tom_rule(const std::vector<T, A>& a, const T& x)
    {
        const std::size_t N = a.size();
        if (N == 0) return T{0};

        T u = exp(x);      // u = e^x
        T result = a.back();

        for (std::size_t i = N - 1; i-- > 0;)
        {
            result = std::fma(u, result, a[i]); // result = u * result + a[i]
        }

        return result;
    }


    template<auto arg, auto... args>
    constexpr auto max_v = maximum<arg, args...>();

    // force - cast return type 
    // ifpsble - cast if convertible
    // dont - don't cast
    enum class CastRtnType{ force, ifpsble, dont };

    template<typename S, typename T>
    concept same_c = std::same_as<std::remove_cvref_t<S>, std::remove_cvref_t<T>>;

    template<typename S, typename T>
    concept not_same_c = !same_c<S, T>;

    template<typename T, typename... Ts>
    concept all_same_c = (same_c<T, Ts> && ... );

    template<typename T, typename... Ts>
    concept at_least_one_different_c = !all_same_c<T, Ts...>;
   
    template<typename T>
    concept mpz_c = std::same_as<std::remove_cvref_t<T>, mpz_t>;
    
    template<typename T>
    concept mpq_c = std::same_as<std::remove_cvref_t<T>, mpq_t>;

    template<typename T>
    concept mpfr_c = std::same_as<std::remove_cvref_t<T>, mpfr_t>;

    template<typename T>
    concept mpc_c = std::same_as<std::remove_cvref_t<T>, mpc_t>;

    template<typename T>
    concept mp_zqfc_c = mpz_c<T> || mpq_c<T> || mpfr_c<T> || mpc_c<T>;

    namespace utils
    {
        namespace hidden
        {
            template<typename Type>
            struct st_dummy_type_container{ };
        }

        template<typename=void>
        void display_compiler_info()
        {
            std::cout << "\n==> C++ Compiler : ";

            // order of compiler testing does matter
            #if defined(__INTEL_LLVM_COMPILER)
                std::cout <<__VERSION__;
            #elif defined(__clang__)
                std::cout <<"LLVM clang++ version: " <<__clang_major__<<"."<<__clang_minor__<<"."<<__clang_patchlevel__;
            #elif defined(__GNUC__)
                std::cout << "GNU g++ version: " << __GNUC__<<"."<< __GNUC_MINOR__<<"."<<__GNUC_PATCHLEVEL__;
            #elif defined(__NVCC__)
                std::cout <<"CUDA C++ nvcc version: "<<__CUDACC_VER_MAJOR__<<"."<<__CUDACC_VER_MINOR__<<"."<<__CUDACC_VER_BUILD__;
            #elif defined(_MSVC_LANG)
                std::cout <<"Microsoft C++ cl version: "<< MSVC_VER_MAJOR <<"." <<MSVC_VER_MINOR<<"."<<MSVC_VER_PATCH;
            #else
                std::cout <<"Unknown";
            #endif

            std::cout << "\n\tGMP compile-time: " << __GNU_MP_VERSION 
              << "." << __GNU_MP_VERSION_MINOR 
              << "." << __GNU_MP_VERSION_PATCHLEVEL << std::endl;

            std::cout << "\tMPFR compile-time: "
              << MPFR_VERSION_MAJOR << "."
              << MPFR_VERSION_MINOR << "."
              << MPFR_VERSION_PATCHLEVEL <<"\n";

            std::cout << "\tMPC compile-time: "
              << MPC_VERSION_MAJOR << "."
              << MPC_VERSION_MINOR << "."
              << MPC_VERSION_PATCHLEVEL <<"\n";

            std::cout <<"\toneTBB version: " << TBB_VERSION_MAJOR 
                << "." <<  TBB_VERSION_MINOR << "\n" << std::endl;
        }

        template<typename Type>
        std::string type_tO_sTring()
        {
            #ifdef __NVCC__
                {   
                    std::string fname = typeid(hidden::st_dummy_type_container<Type>).name();

                    const char* to_str = "struct fft_ifft::utils::hidden::st_dummy_type_container<";

                    std::size_t len = strlen(to_str);

                    auto pos = fname.find(to_str);

                    if(pos != fname.npos) // we found substring 
                        fname = fname.substr(pos + len);
                    
                    // remove trailing "> "
                    fname.pop_back();

                    //////////////////////////////////////////////
                    
                    to_str = " __ptr64"; len = strlen(to_str);
                    while( (pos = fname.find(to_str)) != fname.npos)
                        fname.erase(pos, len);
                        
                    to_str = " __ptr32"; len = strlen(to_str);
                    while( (pos = fname.find(to_str)) != fname.npos)
                        fname.erase(pos, len);

                    to_str = "enum class"; len = strlen(to_str);
                    while( (pos = fname.find(to_str)) != fname.npos)
                        fname.erase(pos, len);

                    to_str = "enum"; len = strlen(to_str);
                    while( (pos = fname.find(to_str)) != fname.npos)
                        fname.erase(pos, len);

                    to_str = "class"; len = strlen(to_str);
                    while( (pos = fname.find(to_str)) != fname.npos)
                        fname.erase(pos, len);

                    to_str = "struct"; len = strlen(to_str);
                    while( (pos = fname.find(to_str)) != fname.npos)
                        fname.erase(pos, len);
                    
                    while(fname.back() == ' ') fname.pop_back();
                    
                    return fname;
                }

            #elif defined(__FUNCSIG__)
                std::string fname(__FUNCSIG__);
                const char* to_str = "tO_sTring<";
                size_t len = strlen(to_str);
                auto pos = fname.find("tO_sTring<");
                fname = fname.substr(pos+len);
                fname = fname.substr(0, fname.find_last_of('>'));

                //////////////////////////////////////////////
                    
                to_str = " __ptr64"; len = strlen(to_str);
                while( (pos = fname.find(to_str)) != fname.npos)
                    fname.erase(pos, len);
                    
                to_str = " __ptr32"; len = strlen(to_str);
                while( (pos = fname.find(to_str)) != fname.npos)
                    fname.erase(pos, len);

                to_str = "enum class"; len = strlen(to_str);
                while( (pos = fname.find(to_str)) != fname.npos)
                    fname.erase(pos, len);

                to_str = "enum"; len = strlen(to_str);
                while( (pos = fname.find(to_str)) != fname.npos)
                    fname.erase(pos, len);

                to_str = "class"; len = strlen(to_str);
                while( (pos = fname.find(to_str)) != fname.npos)
                    fname.erase(pos, len);

                to_str = "struct"; len = strlen(to_str);
                while( (pos = fname.find(to_str)) != fname.npos)
                    fname.erase(pos, len);
                
                while(fname.back() == ' ') fname.pop_back();
                
                return fname;
            #else
                
                std::string fname(__PRETTY_FUNCTION__);
                
                #ifdef __clang_major__
                    const char* ftext = "[Type = ";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    fname.pop_back();
                    return fname;

                #elif defined(__INTEL_LLVM_COMPILER)
                    const char* ftext = "type_tO_sTring<";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    pos = fname.find_last_of('>');
                    return fname.substr(0, pos);
                #else
                    const char* ftext = "[with Type = ";
                    auto pos = fname.find(ftext) + strlen(ftext);
                    fname = fname.substr(pos);
                    pos = fname.find_first_of(';');
                    return fname.substr(0, pos);
                    #endif
                #endif

        } // end of type_tO_sTring()
    }
}
// end of namespace gmp

#define Gmp_GetTypeName(type_arg, ...) \
    gmp::utils::type_tO_sTring<type_arg, ##__VA_ARGS__>()

#define Gmp_GetTypeCategory(instance_arg, ...) \
    gmp::utils::type_tO_sTring<decltype(instance_arg, ##__VA_ARGS__)>()

#define Gmp_Display(msg, func_name) \
    { std::cout << msg << func_name << std::endl << std::endl;}

#define Gmp_DisplayFunctionName() Gmp_Display("\n==> Function Name: ", __func__)
#define Gmp_DisplayCompilerInfo() { gmp::utils::display_compiler_info(); }

typedef void *(alloc_func_t)(size_t);
typedef void *(realloc_func_t)(void *, size_t, size_t);
typedef void (free_func_t)(void *, size_t);

inline std::tuple<alloc_func_t*, realloc_func_t*, free_func_t*>
    get_allocation_functions()
{
    std::tuple<alloc_func_t*, realloc_func_t*, free_func_t*> funcs;

    mp_get_memory_functions(&std::get<0>(funcs),
        &std::get<1>(funcs), &std::get<2>(funcs));

    return funcs;
}

// #if defined(__GNUC__) && !defined(__clang__)

inline void mpfr_get_z_gpp(mpz_t z, const mpfr_t src, mpfr_rnd_t rnd)
{
    mpfr_exp_t exp;

    char* cstr = mpfr_get_str(nullptr, &exp, 10, 0, src, rnd);

    if (cstr == nullptr)
    {
        mpz_set_ui(z, 0); return;
    }

    std::string digits(cstr);
    mpfr_free_str(cstr);

    bool is_negative = (digits[0] == '-');
    if (is_negative) digits.erase(0, 1);

    if (exp <= 0)
    {
        mpz_set_ui(z, 0); return;
    }

    std::string int_part = digits.substr(0, exp);
    
    if (is_negative) int_part = "-" + int_part;

    mpz_set_str(z, int_part.c_str(), 10);
}

inline int mpz_limb_count(const mpz_t op)
{
    int numb = (GMP_NUMB_BITS - GMP_NAIL_BITS);
    return (mpz_sizeinbase(op, 2) + numb-1)/numb;
}

inline int mpz_byte_count(const mpz_t op)
{
    int numb = (GMP_NUMB_BITS - GMP_NAIL_BITS);
    return ( (mpz_sizeinbase(op, 2) + numb-1)/numb ) * 8;
}

template<std::integral T>
bool mpz_fit_type(const mpz_t op) noexcept
{
    return ( mpz_sizeinbase(op, 2) <= sizeof(T) * 8 );
}

template<std::integral T>
std::optional<T> mpz_export_value(const mpz_t op) noexcept
{
    std::optional<T> rlt;
            
    int s = mpz_sgn(op);

    if(s == 0)
        rlt = T{};
    else if(mpz_fit_type<T>(op))
    {
        T val = 0; size_t count = 0;
        mpz_export(&val, &count, 1, sizeof(val), 0, 0, op);       
       
        rlt = s < 0 ? -val : val ;
    }

    return rlt;
}

template<std::integral T>
std::optional<T> mpfr_export_value(const mpfr_t op, mpfr_rnd_t rnd) noexcept
{
    mpz_t rop;
    mpz_init(rop);
    
    mpfr_get_z(rop, op, rnd);
    
    // Convert op to a mpz_t, after rounding it with respect to rnd. If op is NaN or an infinity,
    // the erange flag is set, rop is set to 0, and 0 is returned. Otherwise the return value is zero
    // when rop is equal to op (i.e., when op is an integer), positive when it is greater than op,
    // and negative when it is smaller than op; moreover, if rop differs from op, i.e., if op is not an
    // integer, the inexact flag is set.

    auto op_z = mpz_export_value<T>(rop);
    
    mpz_clear(rop);

    return op_z;
}

template<std::integral T>
std::optional<T> mpq_export_value(const mpq_t op) noexcept
{    
    mpz_t num, den, q;
    mpz_init(num); mpz_init(den); mpz_init(q);

    mpq_get_num(num, op);
    mpq_get_den(den, op);
    mpz_tdiv_q(q, num, den); // trunc toward 0

    auto opt = mpz_export_value<T>(q);
    
    mpz_clear(q); mpz_clear(den); mpz_clear(num);
    return opt;    
}

namespace gmp::hidden
{
    template<std::integral ReturnType>
    ReturnType mpz_get_integer(const mpz_t x) noexcept
    {   
        if constexpr(std::same_as<ReturnType, long long> 
                || std::same_as<ReturnType, unsigned long long>)
        {

            int base = 10;
            char* cstr = mpz_get_str(nullptr, base, x);  // GMP allocates memory
            char* end = nullptr;

            auto value = [&]
            {
                if constexpr(std::same_as<ReturnType, long long>)
                    return std::strtoll(cstr, &end, base);
                else if constexpr(std::same_as<ReturnType, unsigned long long>) 
                    return std::strtoull(cstr, &end, base);
            }();

            // Free GMP-allocated memory properly
            void (*freefunc)(void*, size_t);
            mp_get_memory_functions(nullptr, nullptr, &freefunc);
            freefunc(cstr, std::strlen(cstr) + 1);  // size includes null terminator
            
            return value;
        }
        else
        {
            if constexpr(std::is_signed_v<ReturnType>)
            {
                return static_cast<ReturnType>( mpz_get_si(x) );
            }
            else
            {
                return static_cast<ReturnType>( mpz_get_ui(x) );
            }
        }
    }

    template<std::integral ReturnType>
    ReturnType mpfr_get_integer(const mpfr_t x, mpfr_rnd_t rnd) noexcept
    {   
        if constexpr(std::same_as<ReturnType, long long>)
            return mpfr_get_sj(x, rnd);
        else if constexpr(std::same_as<ReturnType, unsigned long long>)
            return mpfr_get_uj(x, rnd);
        else if constexpr(std::same_as<ReturnType, long> 
            || std::same_as<ReturnType, int>)
            return mpfr_get_si(x, rnd);
        else if constexpr(std::same_as<ReturnType, unsigned long> 
            || std::same_as<ReturnType, unsigned int>)
            return mpfr_get_ui(x, rnd);
        else if constexpr(std::is_signed_v<ReturnType>)
            return static_cast<ReturnType>(mpfr_get_si(x, rnd));
        else 
            return static_cast<ReturnType>(mpfr_get_ui(x, rnd));
    }

    // mpfr_t x is assumed initialized
    template<std::floating_point ReturnType>
    ReturnType mpfr_get_floating(const mpfr_t x, mpfr_rnd_t rnd) noexcept
    {   
        if constexpr(std::same_as<ReturnType, float> 
                || std::same_as<ReturnType, double>)
            return static_cast<ReturnType>(mpfr_get_d(x, rnd));
        else
        { 
        #if defined(__GNUC__) && !defined(__clang__)
            // WARNING: mpfr_get_ld does not work
            // for gnu g++ compiler

            char* str = mpfr_get_str(nullptr, nullptr, 10, 0, x, rnd);
            long double value = strtold(str, nullptr);
            mpfr_free_str(str);
            return value;
        #else
            // for msvc, clang++, icx-cl compilers
            return mpfr_get_ld(x, rnd);
        #endif
        }
    }

    // mpz_t x is assumed initialized
    template<std::floating_point ReturnType>
    ReturnType mpz_get_floating(const mpz_t x,
        mpfr_prec_t prec = 113,  mpfr_rnd_t rnd = MPFR_RNDN) noexcept
    {   
        if constexpr(std::same_as<ReturnType, float> 
                || std::same_as<ReturnType, double>)
            return static_cast<ReturnType>(mpz_get_d(x));
        else
        { 
        #if defined(__GNUC__) && !defined(__clang__)
        
            // WARNING: mpfr_get_ld does not work
            // for gnu g++ compiler

            char* str = mpz_get_str(nullptr, 10, x);
            long double ld = std::strtold(str, nullptr);
            free(str); return ld;
        #else
            // for msvc, clang++, icx-cl compilers

            mpfr_t f;
            
            mpfr_init2(f, prec);    
            mpfr_set_z(f, x, rnd);  // convert mpz_t → mpfr_t

            long double ld = mpfr_get_ld(f, rnd); // now full precision
            mpfr_clear(f);
            
            return ld; 
        #endif
        }
    }


    // mpq_t x is assumed initialized
    template<std::floating_point ReturnType>
    ReturnType mpq_get_floating(const mpq_t x,
        mpfr_prec_t prec = 113,  mpfr_rnd_t rnd = MPFR_RNDN) noexcept
    {   
        if constexpr(std::same_as<ReturnType, float> 
                || std::same_as<ReturnType, double>)
            return static_cast<ReturnType>(mpq_get_d(x));
        else
        { 
        #if defined(__GNUC__) && !defined(__clang__)
        
            // WARNING: mpfr_get_ld does not work
            // for gnu g++ compiler

            char* str = mpq_get_str(nullptr, 10, x);
            long double ld = std::strtold(str, nullptr);
            free(str); return ld;
        #else
            // for msvc, clang++, icx-cl compilers

            mpfr_t f;
            
            mpfr_init2(f, prec);    
            mpfr_set_q(f, x, rnd);  // convert mpz_t → mpfr_t

            long double ld = mpfr_get_ld(f, rnd); // now full precision
            mpfr_clear(f);
            
            return ld; 
        #endif
        }
    }
}
// end of namespace hidden

void mpfr_swap_fix(mpfr_ptr u, mpfr_ptr v)
{
    mpfr_prec_t  p = u->_mpfr_prec;
    mpfr_sign_t  s = u->_mpfr_sign;
    mpfr_exp_t   e = u->_mpfr_exp;
    mp_limb_t   *d = u->_mpfr_d;

    u->_mpfr_prec = v->_mpfr_prec;
    u->_mpfr_sign = v->_mpfr_sign;
    u->_mpfr_exp  = v->_mpfr_exp;
    u->_mpfr_d    = v->_mpfr_d;

    v->_mpfr_prec = p;
    v->_mpfr_sign = s;
    v->_mpfr_exp  = e;
    v->_mpfr_d    = d;
}

inline void mpz_set_sx_ext(mpz_ptr z, intmax_t v)
{   
    std::uintmax_t i, uv = (v < 0 ? -v : v);

    z->_mp_d[0] = (mp_limb_t)uv;
    z->_mp_size = v < 0 ? -NLIMBS : v ? NLIMBS : 0;
}

inline void mpz_set_ux_ext(mpz_ptr z, uintmax_t v)
{   
    std::uintmax_t i, uv;

    z->_mp_d[0] = (mp_limb_t)v;
    z->_mp_size = (v ? NLIMBS : 0);
}

inline int mpc_add_d(mpc_t rop, const mpc_t op1,
            double op2, mpc_rnd_t rnd)
{
    return mpfr_add_d(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
}

inline int mpc_sub_si(mpc_t rop, const mpc_t op1,
            signed long int op2, mpc_rnd_t rnd)
{
    return mpfr_sub_si(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
}

inline int mpc_si_sub(mpc_t rop, signed long int op1,
            const mpc_t op2, mpc_rnd_t rnd)
{
    return mpfr_si_sub(mpc_realref(rop), op1, mpc_realref(op2), MPC_RND_RE(rnd));
}

inline int mpc_set_flt(mpc_t mp, float op1, mpc_rnd_t rnd)
{
           mpfr_set_flt(mpc_realref(mp), op1, MPC_RND_RE(rnd));
    return mpfr_set_si(mpc_realref(mp), 0, MPC_RND_IM(rnd));
}

inline int mpc_set_flt_flt(mpc_t mp, float op1, float op2, mpc_rnd_t rnd)
{
           mpfr_set_flt(mpc_realref(mp), op1, MPC_RND_RE(rnd));
    return mpfr_set_flt(mpc_imagref(mp), op2, MPC_RND_IM(rnd));
}

inline int mpc_sub_d(mpc_t rop, const mpc_t op1,
            double op2, mpc_rnd_t rnd)
{
    return mpfr_sub_d(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
}

inline int mpc_d_sub(mpc_t rop, double op1, const mpc_t op2, mpc_rnd_t rnd)
{
    return mpfr_d_sub(mpc_realref(rop), op1, mpc_realref(op2), MPC_RND_RE(rnd));
}

inline int mpc_sub_z(mpc_t rop, const mpc_t op1,
            const mpz_t op2, mpc_rnd_t rnd)
{
    return mpfr_sub_z(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
}

inline int mpc_z_sub(mpc_t rop, const mpz_t op1, const mpc_t op2, mpc_rnd_t rnd)
{
    return mpfr_z_sub(mpc_realref(rop), op1, mpc_realref(op2), MPC_RND_RE(rnd));
}

inline int mpc_sub_q(mpc_t rop, const mpc_t op1,
            const mpq_t op2, mpfr_rnd_t rnd)
{
    return mpfr_sub_q(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
}

inline int mpc_q_sub(mpc_t rop, const mpq_t op1, const mpc_t op2, mpfr_rnd_t rnd)
{
           mpfr_sub_q(mpc_realref(rop), mpc_realref(op2), op1, MPC_RND_RE(rnd));
    return mpfr_neg(mpc_realref(rop), mpc_realref(rop), MPC_RND_RE(rnd));
}

//////////////////////////////////////////////////////////////////////////
inline int mpc_mul_d(mpc_t rop, const mpc_t op1, double op2, mpc_rnd_t rnd)
{
           mpfr_mul_d(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
    return mpfr_mul_d(mpc_imagref(rop), mpc_imagref(op1), op2, MPC_RND_IM(rnd));
}

inline int mpc_div_si(mpc_t rop, const mpc_t op1, signed long op2, mpc_rnd_t rnd)
{
           mpfr_div_si(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
    return mpfr_div_si(mpc_imagref(rop), mpc_imagref(op1), op2, MPC_RND_IM(rnd));
}

inline int mpc_div_d(mpc_t rop, const mpc_t op1, double op2, mpc_rnd_t rnd)
{
           mpfr_div_d(mpc_realref(rop), mpc_realref(op1), op2, MPC_RND_RE(rnd));
    return mpfr_div_d(mpc_imagref(rop), mpc_imagref(op1), op2, MPC_RND_RE(rnd));
}

template<typename T>
    requires (std::same_as<T, float> || std::same_as<T, double>)
int mpc_add_cplx(mpc_t rop, const mpc_t op, const std::complex<T>& z, mpc_rnd_t rnd)
{
           mpfr_add_d(mpc_realref(rop), mpc_realref(op), (double)std::real(z), MPC_RND_RE(rnd));
    return mpfr_add_d(mpc_imagref(rop), mpc_imagref(op), (double)std::imag(z), MPC_RND_IM(rnd));
}

template<typename T>
    requires (std::same_as<T, float> || std::same_as<T, double>)
int mpc_sub_cplx(mpc_t rop, const mpc_t op, const std::complex<T>& z, mpc_rnd_t rnd)
{
           mpfr_sub_d(mpc_realref(rop), mpc_realref(op), (double)std::real(z), MPC_RND_RE(rnd));
    return mpfr_sub_d(mpc_imagref(rop), mpc_imagref(op), (double)std::imag(z), MPC_RND_IM(rnd));
}

#include <complex>
#include <cstdlib>   // for strtold
#include <mpc.h>
#include <mpfr.h>

inline long double mpfr_get_ld2(const mpfr_t op, mpfr_rnd_t rnd)
{
    #if defined(__GNUC__) && !defined(__clang__)

        char* str = mpfr_get_str(nullptr, nullptr, 10, 0, op, rnd);
        long double value = strtold(str, nullptr);
        mpfr_free_str(str);
        return value;
    #else
        return mpfr_get_ld(op, rnd);
    #endif
}

inline std::complex<long double> mpc_get_ld2(const mpc_t op, mpc_rnd_t rnd)
{
    return { mpfr_get_ld2(mpc_realref(op), MPC_RND_RE(rnd)),
             mpfr_get_ld2(mpc_imagref(op), MPC_RND_IM(rnd))};
}

inline void mpfr_get_z2(mpz_t z, const mpfr_t src, mpfr_rnd_t rnd)
{
#if defined(__GNUC__) && !defined(__clang__)
    mpfr_exp_t exp;
    char* cstr = mpfr_get_str(nullptr, &exp, 10, 0, src, rnd);

    if (cstr == nullptr)
    {
        mpz_set_ui(z, 0); return;
    }

    std::string digits(cstr);
    mpfr_free_str(cstr);

    bool is_negative = (digits[0] == '-');
    if (is_negative) digits.erase(0, 1);

    if (exp <= 0)
    {
        mpz_set_ui(z, 0); return;
    }

    std::string int_part = digits.substr(0, exp);
    if (is_negative) int_part = "-" + int_part;

    mpz_set_str(z, int_part.c_str(), 10);

#else
    mpfr_get_z(z, src, rnd);
#endif
}


namespace gmp
{   
    template<typename T, typename... Ts>
    concept common_with_c = (std::common_with<std::remove_cvref_t<T>, std::remove_cvref_t<Ts>> && ... );

    template<typename T>
    inline constexpr auto max_value_v = std::numeric_limits<T>::max();

    template<typename T>
    concept pointer_c = std::is_pointer_v<std::remove_cvref_t<T>>;

    template<typename T>
    concept non_pointer_c = !pointer_c<T>;

    template<typename FuncType>
    struct stack_unwinder
    {
        FuncType func;

        template<typename f1Type>
        stack_unwinder(f1Type&& f): func{ f }{ }

        template<typename f1Type, typename f2Type>
        stack_unwinder(f1Type&& f1, f2Type&& f2)
            : func{ std::forward<f2Type>(f2) } { f1(); }

        ~stack_unwinder() {  func(); }
    };
    
    template<typename f1Type>
        stack_unwinder(f1Type&& f)
            -> stack_unwinder<std::remove_cvref_t<f1Type>>;

    template<typename f1Type, typename f2Type>
        stack_unwinder(f1Type&& f1, f2Type&& f2) 
            -> stack_unwinder< std::remove_cvref_t<f2Type> >;

    inline auto free_local_cache()
    {
        return mpfr_free_cache2(MPFR_FREE_LOCAL_CACHE);
    }

    inline auto free_global_cache()
    {
        return mpfr_free_cache2(MPFR_FREE_GLOBAL_CACHE);
    }

    inline auto free_all_cache()
    {
        // mpfr_free_cache2(MPFR_FREE_LOCAL_CACHE | MPFR_FREE_GLOBAL_CACHE)
        // = mpfr_free_cache()
        return mpfr_mp_memory_cleanup();
    }
}
// end of namespace gmp

#define Gmp_Cleanup_Cache() \
    gmp::stack_unwinder cleAnupAllCacHe{ []{ gmp::free_all_cache(); } }

// Memory pool for MPFR allocation
extern tbb::memory_pool<std::allocator<char>> gmp_memory_pool;

namespace gmp::hidden
{
    // Custom allocation functions
    template<typename = void>
    void* mpfr_alloc(size_t size)
    {
        std::cout << size << " allocated\n";

        return gmp_memory_pool.malloc(size);
    }

    template<typename = void >
    void* mpfr_realloc(void* ptr, size_t old_size, size_t new_size) 
    {
        std::cout << new_size << " reallocated\n";

        void* new_ptr = gmp_memory_pool.malloc(new_size);
        if (new_ptr && ptr) {
            memcpy(new_ptr, ptr, std::min(old_size, new_size));
            gmp_memory_pool.free(ptr);
        }
        return new_ptr;
    }

    template<typename = void>
    void mpfr_free(void* ptr, size_t size) 
    {
        std::cout << size << " freed\n";

        gmp_memory_pool.free(ptr);
    }

    // Apply custom memory functions
    template<typename = void>
    void setup_mpfr_memory() 
    {
        mp_set_memory_functions(mpfr_alloc<>, mpfr_realloc<>, mpfr_free<>);
    }

    struct SetupMemoryPool
    {
        SetupMemoryPool()
        { 
            std::cout << "mempool initialized" << std::endl;

            setup_mpfr_memory<>();
        }
    };
}
// namespace gmp::hidden

#define Gmp_Setup_Memory_Pool() \
    tbb::memory_pool<std::allocator<char>> gmp_memory_pool;   \
    gmp::hidden::SetupMemoryPool setup_mem_pool 

namespace gmp
{
    enum class BinOpr{ add, sub, mul, div, dot, cross };
    
    namespace operators
    {
        namespace hidden
        {
            template<auto Dimension, auto Nth>
            auto create_variable() noexcept
            {
                return [](auto... args) constexpr
                    requires(sizeof...(args) == Dimension)
                {
                    return std::get<Nth>( std::tuple{ args... } );
                };
            }
        
            template<auto Dimension = 1, auto... Indices>
            auto make_variables() noexcept
            {
                if constexpr(Dimension == 1)
                {
                    return [](auto num) { return num; };
                }
                else
                {
                    constexpr auto N = sizeof...(Indices);

                    if constexpr(N == 0)
                    {

                        return []<typename T, T...n>(std::integer_sequence<T, n...>)
                        {
                            return std::tuple{ create_variable<Dimension, n>() ... };

                        }(std::make_integer_sequence<int, Dimension>{});
                        
                    }
                    else 
                    {
                        auto vars = 
                            std::tuple{ create_variable<Dimension, Indices>() ... };

                        if constexpr(N == 1)
                            return create_variable<Dimension, Indices...>();
                        else 
                        {
                            return std::tuple
                            { 
                                create_variable<Dimension, Indices>() ...
                            };
                        }
                    }
                }
            }
        }
        // end of namespace hidden

        // 070- How to Implement Operable Variables, variables, oprvar
        // https://www.youtube.com/watch?v=MfdqImXMlNw&t=10s

        // operable variables
        template<auto Dimension = 1, auto... Indices>
            inline auto oprvar = hidden::make_variables<Dimension, Indices...>();

        // composable variables
        template<auto Dimension = 1, auto... Indices>
            inline auto comvar = hidden::make_variables<Dimension, Indices...>();
    }
    // end of namespace operators

    template<typename = void> struct non_type{};

    template<typename T>
    concept non_type_c = std::same_as< std::remove_cvref_t<T>, non_type<>>;

    template<typename T>
    using make_signed_t = std::conditional_t<
            requires { typename std::make_signed_t<T>; },
            std::make_signed_t<T>, T>;
   
    // canonical: ascending power a_0 + a_1 x + a_2 x^2 + ... a_n x^n, n + 1 terms
    // standard:  descending power a_n x^n + ... + a_2 x^2 + a_1 x + a_0, n + 1 terms
    enum class PolyMode 
    { 
        canonical, // ascending power a_0 + a_1 x + a_2 x^2 + ... a_n x^n, n + 1 terms
        standard   // descending power a_n x^n + ... + a_2 x^2 + a_1 x + a_0, n + 1 terms
    };
    
    template<typename = void>
    std::ostream& operator<<(std::ostream& os, PolyMode pmode) noexcept
    {
        switch(pmode)
        {
            case PolyMode::canonical:
                os << "canonical"; return os;
            case PolyMode::standard:
                os << "standard"; return os;
            default: 
                os << "unknown"; return os;
        }
    }

    enum class SolveMethod
    { 
        newton,     // Newton-raphson: f(x_n)/df(x_n)
        halley,     // Halley's method or Householder's method 2nd order
        householder // Householder's method 3rd order
    };

    template<typename = void>
    std::ostream& operator<<(std::ostream& os, SolveMethod smethod) noexcept
    {
        switch(smethod)
        {
            case SolveMethod::newton:
                os << "newton"; return os;
            case SolveMethod::halley:
                os << "halley"; return os;
            case SolveMethod::householder:
                os << "householder"; return os;
            default: 
                os << "unknown"; return os;
        }
    }

    // type container
    template<typename... Types> struct type_container{ };

    // type container
    template<typename... Types>
    inline constexpr auto tc = type_container<Types...>{ };

    template<typename... Types>
    using tc_t = type_container<Types...>;

    // value container
    template<auto... Values> struct value_container{ };

    template<auto... Values>
    inline constexpr auto vc = value_container<Values...>{ };

    template<auto... Values>
    using vc_t = value_container<Values...>;

    template<auto v>
    inline constexpr auto pwr = value_container<v>{};

    inline constexpr int MaxInvocableCount = 17;
    
    namespace hidden
    {
        template<typename T>
        struct st_is_value_container: std::false_type { };

        template<auto... args>
        struct st_is_value_container< value_container<args...> >: std::true_type { };
    
        template<typename T> struct st_is_type_container: std::false_type{ };

        template<typename... Types> 
            struct st_is_type_container< type_container<Types...> >: std::true_type{ };

        template<typename T> struct st_ele_size
        {
        constexpr static int value = max_value_v<int>;
        };

        template<typename... Types>
        struct st_ele_size<std::tuple<Types...>>
        {
        constexpr static int value = sizeof...(Types);
        };

        template<typename Type, std::size_t N>
        struct st_ele_size<std::array<Type, N>>
        {
        constexpr static int value = N;
        };

        template<typename... Types>
        struct st_ele_size<type_container<Types...>>
        {
            constexpr static int value = sizeof...(Types);
        };

        template<auto... args>
        struct st_ele_size< value_container<args...> >
        {
            constexpr static int value = sizeof...(args);
        };

        template<typename T>
        struct st_element_type
        {
            using type = T;
        };

        template<typename T, typename A>
        struct st_element_type<std::vector<T, A>>
        {
            using type = T;
        };

        template<typename T, std::size_t N>
        struct st_element_type<std::array<T, N>>
        {
            using type = T;
        };

        template<> 
        struct st_element_type<std::tuple<>>
        {
            using type = non_type<>;
        };

        template<typename T, common_with_c<T>... Ts>
        struct st_element_type<std::tuple<T, Ts...>>
        {
            using type = std::common_type_t<T, Ts...>;
        };
    }
    // end of namespace hidden

    template<typename T>
    concept type_container_c = hidden::st_is_type_container< std::remove_cvref_t<T> >::value;

    template<typename T>
    constexpr auto element_size_v = hidden::st_ele_size<std::remove_cvref_t<T>>::value;

     template<typename T>
     using element_type_t = typename hidden::st_element_type<std::remove_cvref_t<T>>::type;
   
    template<typename T>
    concept value_container_c = hidden::st_is_value_container<std::remove_cvref_t<T>>::value;

    template<int index, auto arg, auto... args>
        constexpr auto get(value_container<arg, args...>) noexcept
    {
        if constexpr(index == 0)
            return arg;
        else if constexpr( sizeof...(args) > 0 && index > 0)
            return get<index-1>(value_container<args...>{});
        else
            return max_value_v<int>;
    }

    template<auto... args>
    constexpr int element_size(value_container<args...>) noexcept
    {
        return sizeof...(args);
    }

    template<typename... Types>
    constexpr int element_size(std::tuple<Types...>) noexcept
    {
        return sizeof...(Types);
    }

    template<typename... Types>
    constexpr int element_size(type_container<Types...>) noexcept
    {
        return sizeof...(Types);
    }

    template<auto n>
    constexpr auto all_the_same_values(value_container<n>) noexcept
    {
        return true;
    }

    template<auto n1, auto n2, auto...ns>
    constexpr auto all_the_same_values(value_container<n1, n2, ns...>) noexcept
    {
        return ( (n1 == n2) && ... && (n1 == ns) );
    }

    template<auto n1, auto n2, auto...ns>
    constexpr auto arg_param_count(value_container<n1, n2, ns...>) noexcept
    {
        if constexpr( ( (n1 == n2) && ... && (n1 == ns) ) )
            return n1;
        else
            return MaxInvocableCount;
    }

    template<auto n, auto... ns>
    constexpr auto maximum_values(value_container<n, ns...>) noexcept
    {
        return maximum<n, ns...>();
    }

    template<auto n>
    constexpr auto at_least_one_not_zero(value_container<n>) noexcept
    {
        return n != 0;
    }

    template<auto n1, auto n2, auto...ns>
    constexpr auto at_least_one_not_zero(value_container<n1, n2, ns...>) noexcept
    {
        return (n1 != 0) || ( (n2 != 0) || ... || (ns != 0) );
    }

    namespace hidden
    {
        template<auto Start, auto Step, auto End, auto... Seqs>
        constexpr auto make_sequence_forward(value_container<Seqs...>)
        {
            if constexpr(Step > 0) // ascending sequence
            {
                if constexpr(Start > End)
                    return value_container<Seqs...>{};
                else
                {
                    if constexpr( Start + Step < End )
                        return make_sequence_forward<Start + Step, Step, End>
                                ( value_container<Seqs..., Start + Step> { } );
                    else
                        return value_container<Seqs...>{};
                }
            }
            else if constexpr(Step < 0) // descending sequence
            {
                if constexpr(Start < End)
                    return value_container<Seqs...>{};
                else
                {
                    if constexpr( Start + Step > End )
                        return make_sequence_forward<Start + Step, Step, End>
                                ( value_container<Seqs..., Start + Step> { } );
                    else
                        return value_container<Seqs...>{};
                }
            }
        }
        // end of make_sequence_forward()

        template<auto Start, auto Step, auto End, auto... Seqs>
        constexpr auto make_backward_sequence(value_container<Seqs...>)
        {
            if constexpr(Step > 0) // ascending sequence
            {
                if constexpr(Start > End)
                    return value_container<Seqs...>{};
                else
                {
                    if constexpr( Start + Step < End )
                        return make_backward_sequence<Start + Step, Step, End>
                                ( value_container<Start + Step, Seqs...> { } );
                    else
                        return value_container<Seqs...>{};
                }
            }
            else if constexpr(Step < 0) // descending sequence
            {
                if constexpr(Start < End)
                    return value_container<Seqs...>{};
                else
                {
                    if constexpr( Start + Step > End )
                        return make_backward_sequence<Start + Step, Step, End>
                                ( value_container<Start + Step, Seqs...> { } );
                    else
                        return value_container<Seqs...>{};
                }
            }
        }
        // end of make_sequence_backward()
    }
    // end of namespace hidden
    
    template<auto Start, auto Step, auto End>
    constexpr auto forward_sequence()
    {
        if constexpr (Step > 0)
            return hidden::make_sequence_forward<Start, Step, End>( value_container<Start>{} );
        else if constexpr(Step < 0)
            return hidden::make_sequence_forward<Start, Step, End>( value_container<Start>{} );
        else // Step = 0
            return value_container<Start, End>{};
    }

    template<auto Start, auto End>
    constexpr auto forward_sequence()
    {
        return forward_sequence<Start, 1, End>();
    }

    template<auto End>
    constexpr auto forward_sequence()
    {
        return forward_sequence<0, 1, (long long)End>();
    }

    template<auto Start, auto Step, auto End>
    constexpr auto backward_sequence()
    {
        if constexpr (Step > 0)
            return hidden::make_backward_sequence<Start, Step, End>( value_container<Start>{} );
        else if constexpr(Step < 0)
            return hidden::make_backward_sequence<Start, Step, End>( value_container<Start>{} );
        else // Step = 0
            return value_container<End, Start>{};
    }

    enum class SeqDir{ forward, backward };

    template<SeqDir seqdir, auto Start, auto Step, auto End>
    constexpr auto make_sequence()
    {
        if constexpr(seqdir == SeqDir::forward)
            return forward_sequence<Start, Step, End>();
        else // if constexpr(seqdir == SeqDir::backward)
            return backward_sequence<Start, Step, End>();
    }

    namespace output
    {
        template<auto v, auto ...vs>
        void print_vc(std::ostream& os, value_container<v, vs...>)
        {
            os << v;

            if constexpr (sizeof...(vs) != 0)
            {
                os <<", "; print_vc(os, value_container<vs...>{});
            }
        }
       
        template<auto ... values>
        std::ostream& operator<<(std::ostream& os, value_container<values...>)
        {
            if constexpr(sizeof...(values) == 0)
            {
                os << "< >"; return os;
            }
            else
            {
                os << "< ";

                print_vc(os, value_container<values...>{});

                os <<" >"; return os;
            }
        }
        
        template<typename T, T v, T ...vs>
        void print_vc(std::ostream& os, std::integer_sequence<T, v, vs...>)
        {
            os << v;

            if constexpr (sizeof...(vs) != 0)
            {
                os <<", "; print_vc(os, std::integer_sequence<T, vs...>{});
            }
        }

        template<typename T, T ... values>
        std::ostream& operator<<(std::ostream& os, std::integer_sequence<T, values...>)
        {
            if constexpr(sizeof...(values) == 0)
            {
                os << "< " << Gmp_GetTypeName(T) <<" >"; return os;
            }
            else
            {
                os << "< " << Gmp_GetTypeName(T) <<", ";

                print_vc(os, std::integer_sequence<T, values...>{});

                os <<" >"; return os;
            }
        }
    }
    // end of namespace

    namespace hidden
    {
        template<auto n, auto... ns, auto... rs>
        constexpr auto reverse_seq(value_container<n, ns...>, value_container<rs...>) noexcept
        {
            if constexpr( sizeof...(ns) == 0 )
                return value_container<n, rs...>{};
            else
                return reverse_seq(value_container<ns...>{}, value_container<n, rs...>{});
        }

        template<auto... ns>
        constexpr auto reverse_seq(value_container<ns...>) noexcept
        {
            if constexpr(sizeof...(ns) == 0)
                return value_container<ns...>{};
            else
                return reverse_seq(value_container<ns...>{}, value_container<>{});
        }
        
        template<typename T, T n, T... ns, T... rs>
        constexpr auto reverse_seq(std::integer_sequence<T, n, ns...>,
                    std::integer_sequence<T, rs...>) noexcept
        {
            if constexpr( sizeof...(ns) == 0 )
                return std::integer_sequence<T, n, rs...>{};
            else
                return reverse_seq(std::integer_sequence<T, ns...>{},
                        std::integer_sequence<T, n, rs...>{});
        }

        template<typename T, T... ns>
        constexpr auto reverse_seq(std::integer_sequence<T, ns...>) noexcept
        {
            if constexpr(sizeof...(ns) == 0)
                return std::integer_sequence<T, ns...>{};
            else
                return reverse_seq(std::integer_sequence<T, ns...>{},
                            std::integer_sequence<T>{});
        }
    }
    // end of namespace hidden

    template<auto... ns>
    constexpr auto reverse_sequence(value_container<ns...>) noexcept
    {
        return hidden::reverse_seq(value_container<ns...>{});
    }

    template<typename T, T... ns>
    constexpr auto reverse_sequence(std::integer_sequence<T, ns...>) noexcept
    {
        return hidden::reverse_seq(std::integer_sequence<T, ns...>{});
    }

    namespace hidden
    {
        template<auto n, auto... ns, auto m, auto... ms>
        constexpr auto make_multiplers(value_container<n, ns...>,
                value_container<m, ms...>) noexcept
        {
            if constexpr(sizeof...(ns) == 0)
                return value_container<m, ms...>{};
            else
                return make_multiplers(value_container<ns...>{},
                        value_container<(int)m*n, (int)m, ms...>{});
        }

        template<auto n, auto... ns>
        constexpr auto make_multiplers(value_container<n, ns...>) noexcept
        {
            if constexpr(sizeof...(ns) == 0)
                return value_container<1>{};
            else
                return make_multiplers(value_container<n, ns...>{},
                        value_container<1>{});
        }
    }
    // end of namespace hidden

    template<auto... ns>
    constexpr auto make_multiplers(value_container<ns...>) noexcept
    {
        if constexpr(sizeof...(ns) == 0)
            return value_container<ns...>{};
        else
        {
            return hidden::make_multiplers(reverse_sequence(value_container<ns...>{}));
        }
    }

    template<typename T>
    using multiplier_t = decltype(make_multiplers(T{}));

    template<auto i, auto... is, auto n, auto... ns>
        requires (sizeof...(is) == sizeof...(ns))
    constexpr auto index_dot_product(value_container<i, is...>,
            value_container<n, ns...>) noexcept
    {
        return ( (i*n) + ... + (is * ns) );
    }

    namespace hidden
    {
        template<auto N, auto... is, auto n, auto... ns>
        requires (sizeof...(is) == sizeof...(ns))
        constexpr auto split_to_indices(value_container<is...>,
            value_container<n, ns...>) noexcept
        {
            if constexpr(sizeof...(ns) == 0)
            {
                return value_container<is..., N>{};
            }
            else if constexpr(sizeof...(ns) == 1)
            {
                return value_container<is..., N / n, N % n >{};
            }
            else // sizeof...(ns) >= 2
            {
                return split_to_indices<N % n>(value_container<is..., N/n>{}, value_container<ns...>{});
            }
        }

        template<auto N, auto n, auto... ns>
        constexpr auto split_to_indices(value_container<n, ns...>) noexcept
        {
            if constexpr(sizeof...(ns) == 0)
            {
                return value_container<N>{};
            }
            else if constexpr(sizeof...(ns) == 1)
            {
                // std::cout <<"N = " << N <<", n = " << n 
                //  << ", N % n = " << (N%n) << std::endl;

                return value_container<N / n, N % n >{};
            }
            else // sizeof...(ns) >= 2
            {
                return split_to_indices<N % n>(value_container<N/n>{}, value_container<ns...>{});
            }
        }
    }
    // end of namespace hidden

    template<auto N, auto n, auto... ns>
    constexpr auto split_to_indices(value_container<n, ns...>) noexcept
    {
        return hidden::split_to_indices<N>(value_container<n, ns...>{});
    }

    namespace hidden
    {
        template<auto i, auto... is, auto d, auto... ds>
        constexpr auto index_validity(value_container<i, is...>,
                                      value_container<d, ds...>) noexcept
        {
            if constexpr(sizeof... (is) == sizeof...(ds))
                return ( ( i >= 0 && i < d) && ... && (ds >=0 && is < ds) );
            else
                return false;
        }
    }
    // end of namespace hidden
    template<typename IdxType, typename DimType>
    concept valid_index_c = hidden::index_validity(IdxType{}, DimType{});

    template<typename Type, typename... Types>
    concept type_in_types_c = (std::same_as<Type, Types> || ...);

    template<typename Type, typename... Types>
    concept one_of_c = 
        type_in_types_c<std::remove_cvref_t<std::decay_t<Type>>, Types...>;

    template<typename FuncType, typename ReturnType,
        typename ArgType, auto ParamCount> struct function_info{};

    template<typename FuncType, typename ReturnType,
        typename ArgType, auto ParamCount>
    std::ostream& operator<<(std::ostream& os, 
        function_info<FuncType, ReturnType, ArgType, ParamCount>)
    {
        if constexpr(non_type_c<ReturnType>)
        {
             os << "function_info<"<< Gmp_GetTypeName(FuncType) <<", "
                << "non_type<>, " << Gmp_GetTypeName(ArgType) <<", "
               << ParamCount <<">"; return os;
        }
        else
        {
            os << "function_info<lambda, " << Gmp_GetTypeName(ReturnType) <<", "
                << Gmp_GetTypeName(ArgType) <<", "<< ParamCount <<">"; return os;
        }
    }

    namespace hidden
    {
        template<typename Fn, typename ArgType, typename... Ts>
        consteval auto get_function_info(type_container<Ts...>)
        {
            if constexpr (sizeof...(Ts) >= MaxInvocableCount)
            {
                if constexpr (std::is_invocable_v<Fn, Ts...>)
                    return function_info<Fn, std::invoke_result_t<Fn, Ts...>, ArgType, MaxInvocableCount>{};
                else
                    return function_info<Fn, non_type<>, ArgType, MaxInvocableCount>{};
            }
            else if constexpr (std::is_invocable_v<Fn, Ts...>)
            {
                return function_info<Fn, std::invoke_result_t<Fn, Ts...>, ArgType, (int) sizeof...(Ts) >{};
            }
            else
            {
                return get_function_info<Fn, ArgType>(type_container<ArgType, Ts...>{});
            }
        }
    }
    // end of namespace hidden
    template<typename ArgType, typename FuncType>
    consteval auto func_info(FuncType f)
    {
        return hidden::get_function_info
                <FuncType, std::remove_cvref_t<ArgType>>(type_container<>{});
    }

    template<typename FuncType, typename ArgType>
    constexpr auto func_info_v = hidden::get_function_info
                    <FuncType, std::remove_cvref_t<ArgType>>(type_container<>{});

    template<typename FuncType, typename ArgType>
    using func_info_t = decltype(func_info_v<FuncType, ArgType>);

    enum class FuncCat{ unknown, real_real, cplx_real, real_cplx, cplx_cplx };

    template<typename = void>
    std::ostream& operator <<(std::ostream& os, FuncCat fc)
    {
        // switch(fc)
        // {
        //     case FuncCat::real_real: 
        //         os <<"real-real"; break;

        //     case FuncCat::cplx_real: 
        //         os <<"cplx-real"; break;

        //     case FuncCat::real_cplx: 
        //         os <<"real-cplx"; break;

        //     case FuncCat::cplx_cplx: 
        //         os <<"cplx-cplx"; break;
            
        //     default:
        //         os <<"unknown";
        // }

        if(fc == FuncCat::real_real || fc == FuncCat::cplx_cplx)
            os << " holomorphic lambda";
        else if(fc == FuncCat::cplx_real || fc == FuncCat::real_cplx)
            os << " transcendental lambda";
        else 
            os << " lambda or value";

        return os;
    }

    namespace hidden
    {
        template<typename FuncType>
        struct st_lambda: std::false_type{ };
        
        template<typename FuncType, typename ReturnType,
        typename ArgType, auto ParamCount>
        struct st_lambda< function_info<FuncType, ReturnType, ArgType, ParamCount> >
        {
            static constexpr bool value = (ParamCount != MaxInvocableCount);
        };

        template<typename FuncType>
        struct st_lambda_info
        { 
            using return_type = non_type<>;
            using argtype = non_type<>;
            static constexpr auto value = MaxInvocableCount;
        };
        
        template<typename FuncType, typename ReturnType,
        typename ArgType, auto ParamCount>
        struct st_lambda_info< function_info<FuncType, ReturnType, ArgType, ParamCount> >
        {
            using return_type = ReturnType;
            using argtype = ArgType;
            static constexpr auto value = ParamCount;
        };

        template<typename FuncType>
        struct st_holomorphic_lambda: std::false_type{ };

        template<typename FuncType1, typename ReturnType1, typename ArgType1, auto ParamCount1,
                 typename FuncType2, typename ReturnType2, typename ArgType2, auto ParamCount2>
        struct st_holomorphic_lambda
            < type_container<function_info<FuncType1, ReturnType1, ArgType1, ParamCount1>, 
                             function_info<FuncType2, ReturnType2, ArgType2, ParamCount2>>>
        {
            static constexpr bool value = 
                same_c<ReturnType1, ArgType1> && same_c<ReturnType2, ArgType2> 
                    && (ParamCount1 != MaxInvocableCount) && (ParamCount1 == ParamCount2);
        };

        template<typename FuncType>
        struct st_transcendental_lambda: std::false_type{ };

        template<typename FuncType1, typename ReturnType1, typename ArgType1, auto ParamCount1,
                 typename FuncType2, typename ReturnType2, typename ArgType2, auto ParamCount2>
        struct st_transcendental_lambda
            < type_container<function_info<FuncType1, ReturnType1, ArgType1, ParamCount1>, 
                             function_info<FuncType2, ReturnType2, ArgType2, ParamCount2>>>
        {
            static constexpr bool value = 
                (ParamCount1 != MaxInvocableCount) || (ParamCount2 != MaxInvocableCount)
                && (ParamCount1 == ParamCount2);
        };
    }
        
    template<typename T>
        concept holomorphic_lambda_c = 
            hidden::st_holomorphic_lambda<
                type_container<
                    std::remove_cvref_t<func_info_t<T, float>>,
                    std::remove_cvref_t<func_info_t<T, std::complex<float>>>
                > >::value;
    
    template<typename T>
        concept transcendental_lambda_c = !holomorphic_lambda_c<T>;
   
    namespace hidden
    {
        template<typename FuncType1, typename ReturnType1, typename ArgType1, auto ParamCount1,
                    typename FuncType2, typename ReturnType2, typename ArgType2, auto ParamCount2>
        consteval auto func_arity(function_info<FuncType1, ReturnType1, ArgType1, ParamCount1>, 
                                function_info<FuncType2, ReturnType2, ArgType2, ParamCount2>)
        {
            return (ParamCount1 != MaxInvocableCount) ?
                        ParamCount1 : (ParamCount2 != MaxInvocableCount) ?
                            ParamCount2 : MaxInvocableCount;
        }
    }
    // end of namespace hidden

    template<typename ArgType1 = float,
             typename ArgType2 = std::complex<ArgType1>, typename FuncType>
    consteval auto func_arity(FuncType f)
    {
        return hidden::func_arity(func_info<ArgType1>(f), func_info<ArgType2>(f));
    }
    
    template<typename FuncType>
    constexpr auto arity_v = 
        hidden::func_arity(func_info_t<FuncType, float>{},
                func_info_t<FuncType, std::complex<float>>{});

    template<typename FuncType, typename... FuncTypes>
    constexpr auto max_arity_v = 
            maximum<arity_v<FuncType>, arity_v<FuncTypes>...>();

    template<typename FuncType, auto arity = arity_v<FuncType>>
    concept valid_function_c = (0 < arity && arity != MaxInvocableCount);

    namespace hidden
    {
        template<auto Count, typename T, typename... Ts>
        constexpr auto create_type_container(type_container<T, Ts...>)
        {
            if constexpr (sizeof...(Ts) + 1 < Count)
                return create_type_container<Count>(type_container<T, T, Ts...>{});
            else
                return type_container<T, Ts...>{};
        }

        template<auto Count, typename T>
        using arg_types_t = std::conditional_t< Count == 0, type_container<>, 
            decltype(create_type_container<Count>(type_container<T>{}))>;
        
        template<typename FuncType, typename... ArgTypes>
        constexpr bool callable_with_pack(type_container<ArgTypes...>)
        {
            return std::invocable<FuncType, ArgTypes...>;
        }

        template<typename FuncType, typename ArgType>
        constexpr bool parameter_packed()
        {
            return callable_with_pack<FuncType>
                ( arg_types_t<MaxInvocableCount, ArgType>{});
        }
      
        template<typename FuncType, typename ArgType, typename... ArgTypes>
        constexpr int fn_min_param_count() noexcept
        {
            if constexpr(std::invocable<FuncType, ArgType, ArgTypes...>)
                return sizeof...(ArgTypes) + 1;
            else if constexpr( sizeof...(ArgTypes) + 1 < MaxInvocableCount )
                return fn_min_param_count<FuncType, ArgType, ArgType, ArgTypes...>();
            else
                return MaxInvocableCount;
        }

        template<typename FuncType>
        constexpr int fn_count_param() noexcept
        {
            return std::invocable<FuncType> ? 0 : -1;
        }

        template<typename FuncType, typename ArgType, typename... ArgTypes>
        constexpr int fn_count_param() noexcept
        {
            constexpr int arg_count = 
                fn_min_param_count<FuncType, ArgType>();

            if constexpr (arg_count == MaxInvocableCount) // call-failed
            {
                if constexpr(sizeof...(ArgTypes) != 0)
                    return fn_count_param<FuncType, ArgTypes...>();
                else
                    return arg_count;
            }
            else
                return arg_count;
        }

        template<typename FuncType, typename ArgType, typename... ArgTypes>
        constexpr int count_parameters()
        {
            if constexpr(fn_count_param<FuncType>() == 0)
                return 0;
            else
            {
                return fn_count_param<FuncType, ArgType, ArgTypes...>();
            }
        }

        template<typename Tuple, std::size_t... I>
        auto reverse_tuple_impl(Tuple&& tup, std::index_sequence<I...>) {
            constexpr auto size = std::tuple_size_v<std::remove_reference_t<Tuple>>;
            return std::make_tuple(std::get<size - 1 - I>(std::forward<Tuple>(tup))...);
        }
    }
    // end of namespace hidden
    
    template<auto N, typename T>
    using create_type_container_t = hidden::arg_types_t<N, std::remove_cvref_t<T>>;

    template<typename Tuple>
    using last_tuple_element_t = 
        std::tuple_element_t<std::tuple_size_v<std::remove_cvref_t<Tuple>> - 1, std::remove_cvref_t<Tuple>>;
        
    template<typename Tuple>
    auto reverse_tuple(Tuple&& tup) {
        constexpr auto size = std::tuple_size_v<std::remove_reference_t<Tuple>>;
        return hidden::reverse_tuple_impl(std::forward<Tuple>(tup), std::make_index_sequence<size>{});
    }
    
    template<typename FuncType,
        typename ArgType = std::complex<float>, typename... ArgTypes>
    constexpr int parameter_count_v = 
        hidden::count_parameters<FuncType, ArgType, ArgTypes...>();

    template<auto N, typename FuncType>
    auto fix_parameter_count(FuncType&& f)
    {
        return [f](auto... args) 
            requires (sizeof...(args) == N)
        {
            return f(args...);
        };
    }
   
    // auto f = 1;  return MaxInvocableCount (17)
    // auto f = []() { return 1; }; return 0
    // auto f = [](auto... xs) { return 1; }; return 0
    // auto f = [](auto... xs) requires(sizeof...(xs) == 5) { return 1; }; returns 5
    template<typename FuncType, typename... ArgTypes>
    constexpr int parameter_count(FuncType&&, ArgTypes&&... )
    {
        return hidden::fn_count_param<FuncType, ArgTypes...>();
    }

    // auto f = 1;  return MaxInvocableCount (17)
    // auto f = []() { return 1; }; return 0
    // auto f = [](auto... xs) { return 1; }; return 0
    // auto f = [](auto... xs) requires(sizeof...(xs) == 5) { return 1; }; returns 5
    template<typename FuncType, typename ArgType = float>
    concept packed_parameter_c = hidden::parameter_packed<FuncType, ArgType>();

    namespace hidden
    {
        template<typename T> 
        struct st_is_std_vector: std::false_type { };

        template<typename S, typename T> 
        struct st_is_std_vector<std::vector<S, T>>: std::true_type { };

        template<typename T> 
        struct st_is_tbb_vector: std::false_type { };

        template<typename S, typename T> 
        struct st_is_tbb_vector<tbb::concurrent_vector<S, T>>: std::true_type { };

        template<typename T> 
        struct st_is_std_array: std::false_type { };

        template<typename T, std::size_t N> 
        struct st_is_std_array<std::array<T, N>>: std::true_type { };

        template<typename T>
        struct st_is_tuple: std::false_type { };

        template<typename ...Ts>
        struct st_is_tuple< std::tuple<Ts...> >: std::true_type { };
    }
       
    template<typename T>
    concept tuple_c = hidden::st_is_tuple<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept std_vector_c = hidden::st_is_std_vector<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept tbb_vector_c = hidden::st_is_tbb_vector<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept vector_c = std_vector_c<T> || tbb_vector_c<T>;

    template<typename T>
    concept std_array_c = hidden::st_is_std_array<std::remove_cvref_t<T>>::value;

    namespace hidden
    {
        template<typename S, typename T>
        struct st_same_size: std::false_type{ };

        template<typename S, typename T, std::size_t N>
        struct st_same_size< std::array<S, N>, std::array<T, N> >
                : std::true_type{ };

        template<typename... Ss, typename... Ts>
            requires (sizeof...(Ss) == sizeof...(Ts))
        struct st_same_size< std::tuple<Ss...>, std::tuple<Ts...> >
                : std::true_type{ };
    }

    template<typename S, typename T>
    concept same_size_c = hidden::st_same_size
            <std::remove_cvref_t<S>, std::remove_cvref_t<T>>::value;

    template<typename T>
    concept std_array_tuple_c = std_array_c<T> || tuple_c<T>;

    template<typename T>
    concept std_array_or_vector_c = std_array_c<T> || vector_c<T>;

    template<typename T>
    concept array_tuple_vector_c = 
        std_array_c<T> || tuple_c<T> || std_vector_c<T>;

    ///////////////////// type casts ///////////////////////////////
    namespace hidden
    {
        template<typename T, typename N>
        struct c_array_type;

        template<typename T, auto N1>
        struct c_array_type<T, value_container<N1>>
        {
            using type = T[(std::size_t)N1];
        };

        template<typename T, auto N1, auto N2>
        struct c_array_type<T, value_container<N1, N2>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2];
        };

        template<typename T, auto N1, auto N2, auto N3>
        struct c_array_type<T, value_container<N1, N2, N3>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4>
        struct c_array_type<T, value_container<N1, N2, N3, N4>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3]
                          [(std::size_t)N4];
        };

        template<typename T, auto N1, auto N2, auto N3,
            auto N4, auto N5>
        struct c_array_type<T, value_container<N1, N2, N3, N4, N5>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3]
                          [(std::size_t)N4][(std::size_t)N5];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6, auto N7>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6, N7>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6][(std::size_t)N7];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6, auto N7, auto N8>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6, N7, N8>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6][(std::size_t)N7][(std::size_t)N8];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6, auto N7, auto N8, auto N9>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6, N7, N8, N9>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6][(std::size_t)N7][(std::size_t)N8]
                          [(std::size_t)N9];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6, auto N7, auto N8, auto N9, auto N10>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6, N7, N8, N9, N10>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6][(std::size_t)N7][(std::size_t)N8]
                          [(std::size_t)N9][(std::size_t)N10];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6, auto N7, auto N8, auto N9, auto N10, auto N11>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6, N7, N8, N9, N10, N11>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6][(std::size_t)N7][(std::size_t)N8]
                          [(std::size_t)N9][(std::size_t)N10][(std::size_t)N11];
        };

        template<typename T, auto N1, auto N2, auto N3, auto N4,
            auto N5, auto N6, auto N7, auto N8, auto N9, auto N10,
            auto N11, auto N12>
        struct c_array_type<T, value_container<N1, N2, N3, N4,
            N5, N6, N7, N8, N9, N10, N11, N12>>
        {
            using type = T[(std::size_t)N1][(std::size_t)N2][(std::size_t)N3][(std::size_t)N4]
                          [(std::size_t)N5][(std::size_t)N6][(std::size_t)N7][(std::size_t)N8]
                          [(std::size_t)N9][(std::size_t)N10][(std::size_t)N11][(std::size_t)N12];
        };

        template<typename T>
        struct st_unique_ptr_c: std::false_type { };

        template<typename T, typename AllocType>
        struct st_unique_ptr_c<std::unique_ptr<T, AllocType>>: std::true_type { };

        template<typename T, typename AllocType>
        struct st_unique_ptr_c<std::unique_ptr<T[], AllocType>>: std::true_type { };

        template<typename T>
        struct st_shared_ptr_c: std::false_type { };

        template<typename T>
        struct st_shared_ptr_c<std::shared_ptr<T>>: std::true_type { };

        template<typename T>
        struct st_shared_ptr_c<std::shared_ptr<T[]>>: std::true_type { };
    }
    // end of namespace hidden

    template<typename T, value_container_c Dims>
    using c_array_t = typename hidden::c_array_type<std::remove_cvref_t<T>, Dims>::type;

    template<typename T>
    concept unique_ptr_c = hidden::st_unique_ptr_c<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept shared_ptr_c = hidden::st_shared_ptr_c<std::remove_cvref_t<T>>::value;

    template<auto N, auto...Ns, typename T, typename Deleter,
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::unique_ptr<T, Deleter>& uptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(*uptr);
    }

    template<auto N, auto...Ns, typename T, typename Deleter,
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::unique_ptr<T, Deleter> const& uptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(uptr[0]);
    }

    template<auto N, auto...Ns, typename T, typename Deleter,
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::unique_ptr<T[M], Deleter>& uptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(uptr[0]);
    }

    template<auto N, auto...Ns, typename T, typename Deleter,
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::unique_ptr<T[M], Deleter> const& uptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(uptr[0]);
    }

    template<auto N, auto...Ns, typename T, 
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::shared_ptr<T>& sptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(*sptr);
    }

    template<auto N, auto...Ns, typename T,
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::shared_ptr<T> const& sptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(*sptr);
    }

    template<auto N, auto...Ns, typename T, 
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::shared_ptr<T[M]>& sptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(sptr[0]);
    }

    template<auto N, auto...Ns, typename T,
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::shared_ptr<T[M]> const& sptr) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(sptr[0]);
    }

    template<auto N, auto...Ns, typename T, std::size_t AM,
        std::size_t M = (N * ... * Ns) > requires ( M == AM)
    auto& cast_ref(std::array<T, AM>& arg) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, std::size_t AM,
        std::size_t M = (N * ... * Ns) > requires ( M == AM)
    auto& cast_ref(std::array<T, AM>const& arg) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, std::size_t AM,
        std::size_t M = (N * ... * Ns) > requires ( M == AM)
    auto& cast_ref(value_container<N, Ns...>, std::array<T, AM>& arg) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, std::size_t AM,
        std::size_t M = (N * ... * Ns) > requires ( M == AM)
    auto& cast_ref(value_container<N, Ns...>, std::array<T, AM>const& arg) noexcept
    {
        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, typename AllocType, 
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::vector<T, AllocType>& arg) noexcept
    {
        assert(M == arg.size());

        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, typename AllocType, 
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(std::vector<T, AllocType> const& arg) noexcept
    {
        assert(M == arg.size());

        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, typename AllocType, 
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(value_container<N, Ns...>, 
            std::vector<T, AllocType>& arg) noexcept
    {
        assert(M == arg.size());

        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT& >(arg[0]);
    }

    template<auto N, auto...Ns, typename T, typename AllocType, 
        std::size_t M = (N * ... * Ns) > requires ( M > 0 )
    auto& cast_ref(value_container<N, Ns...>, 
        std::vector<T, AllocType> const& arg) noexcept
    {
        assert(M == arg.size());

        using AT = c_array_t<T, value_container<N, Ns...>>;
        return reinterpret_cast< AT const& >(arg[0]);
    }
       
    ///////////////////// end of type casts ////////////////////////


    template<std::size_t Index, typename T, std::size_t N>
    constexpr T get_or_zero(const std::array<T, N>& args)
    {
        if constexpr (Index < N)
            return args[Index];
        else
            return static_cast<T>(0);
    }

    template<std::size_t Index, typename T, typename... Ts,
        std::size_t N = sizeof...(Ts) + 1>
    constexpr T get_or_zero(const std::tuple<T, Ts...>& args)
    {
        if constexpr (Index < N)
            return std::get<Index>(args);
        else
            return static_cast<T>(0);
    }

    // WARNING: apply(f, args) does NOT allow f for a scalar type.
    // Do NOT modify this function. 
    template<typename FuncType, std_array_tuple_c ArgType,
        typename ele_t = std::tuple_element_t<0, ArgType>,
        int pCount = parameter_count_v<FuncType, ele_t>>
    decltype(auto) apply(FuncType&& func, ArgType args)
    {
        return [&]<auto ... n>
                (value_container<n...>) -> decltype(auto)
            {
                return func( std::move( get_or_zero<n>(args) ) ... );

            }( forward_sequence<pCount>());
    }

    namespace hidden
    {
        template<typename T>
        struct st_is_std_complex: std::false_type { };

        template<typename T>
        struct st_is_std_complex<std::complex<T>>: std::true_type 
        { 
            using type = T;
        };
    }
    // end of namespace hidden

    template<typename T>
    concept const_char_c = 
        std::same_as<std::remove_cvref_t<std::decay_t<T>>, const char*>;

    template<typename T>
    concept std_complex_c = 
        hidden::st_is_std_complex<std::remove_cvref_t<T>>::value;

    template<typename T>
    using std_complex_value_type = typename
        hidden::st_is_std_complex<std::remove_cvref_t<T>>::type;

    template<typename T>
    concept signed_csil_c = type_in_types_c<std::remove_cvref_t<T>,
                char, short, int, long>;

    template<typename T>
    concept unsigned_csil_c = type_in_types_c<std::remove_cvref_t<T>,
        unsigned char, unsigned short, unsigned int, unsigned long>;

    template<typename T>
    concept long_int_csil_c = signed_csil_c<T> || unsigned_csil_c<T>;

    template<typename T>
    concept float_double_c = type_in_types_c<std::remove_cvref_t<T>, float, double>;

    template<typename T>
    concept signed_integer_c = type_in_types_c<std::remove_cvref_t<T>,
        char, short, int, long, long long>;
    
    template<typename T>
    concept unsigned_integer_c = type_in_types_c<std::remove_cvref_t<T>,
        unsigned char, unsigned short, unsigned int, unsigned long, unsigned long long>;

    template<typename T>
    concept mcn_integer_c = signed_integer_c<T> || unsigned_integer_c<T>;

    template<typename T>
    concept mcn_floating_c = type_in_types_c<std::remove_cvref_t<T>, float, double>;
    template<typename T>
    concept mcn_number_c = type_in_types_c<std::remove_cvref_t<T>,
        char, short, int, long, long long,
        unsigned char, unsigned short, unsigned int, unsigned long, unsigned long long,
        float, double>;
    
    template<typename T>
    concept string_c = 
        type_in_types_c<std::remove_cvref_t<T>, const char*, std::string>;

    template<typename T>
    concept mpz_mcn_args_c = 
        type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
        char, short, int, long, long long, unsigned char,
        unsigned short, unsigned int, unsigned long, unsigned long long,
        long long, float, double, const char*>;

    namespace hidden
    {
        template<typename = void>
        std::string remove_chars(std::string q,
            const std::string& chars_to_remove = "',f")
        {
            for (char c : chars_to_remove) 
            {
                size_t pos = 0;
                while ((pos = q.find(c)) != std::string::npos) 
                    q.erase(pos, 1);
            }
            return q;
        }

        // Function to trim leading and trailing spaces
        std::string trim(const std::string& str) 
        {
            // Find the first non-space character
            auto start = std::find_if_not(str.begin(), str.end(),
                [](unsigned char ch) { return std::isspace(ch); });

            // Find the last non-space character
            auto end = std::find_if_not(str.rbegin(), str.rend(),
                [](unsigned char ch) { return std::isspace(ch); }).base();

            // If no non-space characters are found,
            // return an empty string
            if (start >= end) { return ""; }

            return std::string(start, end);
        }

        template<typename = void> std::string
        add_delimiter_right_to_left
            (const std::string str, char delimiter, int place = 3) 
        {
            if(str.empty() || place == 0 || str.size() <= place) return str;

            std::string result;

            int count = 0;
            for (int i = str.size() - 1; i >= 0; --i) 
            {
                result.insert(0, 1, str[i]); ++count;
            
                if (count % place == 0 && i > 0) 
                {
                    if(i != 1)
                        result.insert(0, 1, delimiter);
                    else if(str[0] != '+' && str[0] != '-')
                        result.insert(0, 1, delimiter);
                }
            }

            return result;
        }

        template<typename = void> std::string
        add_delimiter_left_to_right
            (const std::string str, char delimiter, int place = 3) 
        {
            if(str.empty() || place == 0 || str.size() <= place) return str;

            std::string result; int count = 0;

            for (char c : str) 
            {
                result += c; ++count;

                if (count % place == 0 && count != str.size()) 
                {
                    result += delimiter;
                }
            }
            return result;
        }

        std::vector<std::string>
            extract_floating_point_parts(std::string str) 
        {
            std::vector<std::string> parts;

            // Regular expression to capture integral, fractional, and exponential parts
            std::regex pattern_full("([+-]?\\d+)\\.(\\d+)(e[+-]?\\d+)");
            std::regex pattern_noexp("([+-]?\\d+)\\.(\\d+)");
        
            std::smatch matches;
            std::smatch matches_full;
            std::smatch matches_noexp;

            if (std::regex_match(str, matches, pattern_full)) 
            {
                parts.push_back(matches[1]); // Integral part
                parts.push_back(matches[2]); // Fractional part
                parts.push_back(matches[3]); // Exponential part
        
            } else if(std::regex_match(str, matches, pattern_noexp))
            {
                parts.push_back(matches[1]); // Integral part
                parts.push_back(matches[2]); // Fractional part
            }
            else
            {
                // Handle cases where the string doesn't match the expected format
                // (e.g., no decimal point, no exponent)
                if(str.back() == '.') str.pop_back();

                parts.push_back(str); 
            }

            return parts;
        }

        std::string group(std::string str, char delimiter = '\'', int place = 3)
        {
            std::vector<std::string> parts = 
                extract_floating_point_parts(str);

            if(parts.size() == 3)
            {
                return add_delimiter_right_to_left(parts[0], delimiter, place) 
                    + "." + add_delimiter_left_to_right(parts[1], delimiter, place)
                    + parts[2];
            }
            else if(parts.size() == 2)
            {
                return add_delimiter_right_to_left(parts[0], delimiter, place) 
                    + "." + add_delimiter_left_to_right(parts[1], delimiter, place);
            }
            else // parts.size() = 1
            {
                return add_delimiter_right_to_left(parts[0], delimiter, place);
            }
        }
    }
    // end of namespace hidden

    class intnum; // multiple precision integer number

    template<typename T>
    concept intnum_c = std::same_as<std::remove_cvref_t<T>, intnum>;
    
    template<typename T>
    concept integer_c = signed_integer_c<T> || unsigned_integer_c<T> || intnum_c<T>;

    class ratnum; // multiple precision rational number

    template<typename T>
    concept ratnum_c = std::same_as<std::remove_cvref_t<T>, ratnum>;

    template<mpfr_prec_t Precision, mpfr_rnd_t RndMode = MPFR_RNDN>
    class realnum; // multiple precision real number

    namespace hidden
    {
        template<typename T> struct st_is_realnum: std::false_type { };
        template<mpfr_prec_t Precision, mpfr_rnd_t RndMode>
        struct st_is_realnum<realnum<Precision, RndMode>>: std::true_type { }; 

        template<typename T>
        struct st_realnum
        {
            static constexpr auto mpfr_prec = sizeof(T) * 8;
            static constexpr auto mpfr_rnd = MPFR_RNDN;
        };

        template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
        struct st_realnum< realnum<Prec, RndMode> >
        { 
            static constexpr auto mpfr_prec = Prec;
            static constexpr auto mpfr_rnd = RndMode; 
        };

        template<template<auto...> class T> 
        struct st_realnum_tmpl: std::false_type{ };

        template<> 
        struct st_realnum_tmpl<realnum>: std::true_type{ };

        template<template<auto...> class T1, template<auto...> class T2> 
        struct st_same_value_template: std::false_type{ };

        template<template<auto...> class T> 
        struct st_same_value_template<T, T>: std::true_type{ };
    }

    template<template<auto...> class T1, template<auto...> class T2> 
    concept same_templates_c = hidden::st_same_value_template<T1, T2>::value;  

    template<typename T>
    concept realnum_c = 
        hidden::st_is_realnum<std::remove_cvref_t<T>>::value;
    
    template<template<auto...> class T> 
    concept realnum_tmpl_c = same_templates_c<T, realnum>;

    template<typename T>
    concept floating_c = mcn_floating_c<T> || realnum_c<T>;

    template<typename T>
    constexpr auto realnum_prec_v = 
        hidden::st_realnum< std::remove_cvref_t<T> >::mpfr_prec;

    template<typename T>
    constexpr auto realnum_rnd_v = 
        hidden::st_realnum<std::remove_cvref_t<T>>::mpfr_rnd;

    template<mpfr_prec_t MpfrPrec, mpc_rnd_t RndMode = MPC_RNDNN>
    class cplxnum; // multiple precision complex number

    namespace hidden
    {
        template<typename T> struct st_is_cplxnum: std::false_type { };
        template<mpfr_prec_t MpfrPrec, mpc_rnd_t RndMode>
        struct st_is_cplxnum<cplxnum<MpfrPrec, RndMode>>: std::true_type { };    

        template<typename T> struct st_cplxnum
        {
            static constexpr auto prec = sizeof(T)*8;
            static constexpr auto mpc_rnd  = MPC_RNDNN;
            static constexpr auto re_rnd  = MPC_RND_RE(MPC_RNDNN);
            static constexpr auto im_rnd  = MPC_RND_IM(MPC_RNDNN);
        };

        template<mpfr_prec_t Prec, mpc_rnd_t Rnd>
        struct st_cplxnum<cplxnum<Prec, Rnd>>
        {
            static constexpr auto prec = Prec;
            static constexpr auto mpc_rnd  = Rnd;
            static constexpr auto re_rnd  = MPC_RND_RE(Rnd);
            static constexpr auto im_rnd  = MPC_RND_IM(Rnd);
        };

        template<template<auto...> class T>
        struct st_cplxnum_tmpl: std::false_type { };

        template<>
        struct st_cplxnum_tmpl<cplxnum>: std::true_type { };
    }
    // end of namespace hidden

    template<typename T>
    concept cplxnum_c = hidden::st_is_cplxnum<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept ratnum_or_cplxnum_c = ratnum_c<T> || cplxnum_c<T>;

    template<typename T>
    concept gmp_non_cplx_c = intnum_c<T> || ratnum_c<T> || realnum_c<T>;

    template<typename T>
    concept gmp_type_c = intnum_c<T> || ratnum_c<T> || realnum_c<T> || cplxnum_c<T>;

    template<typename... Ts>
    concept at_least_one_gmp_type_c = ( gmp_type_c<Ts> || ...);

    template<typename T>
    concept non_gmp_type_c = !gmp_type_c<T>;

    template<template<auto...> class T>
    concept cplxnum_tmpl_c = hidden::st_cplxnum_tmpl<T>::value;

    template<typename T>
    constexpr auto cplxnum_prec_v = 
        hidden::st_cplxnum<std::remove_cvref_t<T>>::prec;

    template<typename T>
    constexpr auto cplxnum_rnd_v = 
        hidden::st_cplxnum<std::remove_cvref_t<T>>::mpc_rnd;

    template<typename T>
    constexpr auto cplxnum_re_rnd_v = 
        hidden::st_cplxnum<std::remove_cvref_t<T>>::re_rnd;

    template<typename T>
    constexpr auto cplxnum_im_rnd_v = 
        hidden::st_cplxnum<std::remove_cvref_t<T>>::im_rnd;

    template<typename T>
    concept complex_c = std_complex_c<T> || cplxnum_c<T>;
    
    template<typename T>
    concept ratnum_or_complex_c = ratnum_c<T> || complex_c<T>;

    template<typename T>
    concept gmp_real_cplx_c = realnum_c<T> || cplxnum_c<T>;

    template<typename T>
    concept std_real_cplx_c = std::floating_point< std::remove_cvref_t<T>> || std_complex_c<T>;

    template<typename T>
    concept non_complex_c = !complex_c<T>;

    template<typename Type>
    concept signed_int_long_c = 
        std::same_as<std::remove_cvref_t<Type>, signed long int> ||
            std::same_as<std::remove_cvref_t<Type>, signed int>;

    template<typename Type>
    concept unsigned_int_long_c = 
        std::same_as<std::remove_cvref_t<Type>, unsigned long int> ||
            std::same_as<std::remove_cvref_t<Type>, unsigned int>;

    template<typename Type>
    concept long_long_c = std::same_as<std::remove_cvref_t<Type>, unsigned long long> ||
            std::same_as<std::remove_cvref_t<Type>, signed long long>; 

    template<typename Type>
    concept double_long_c = std::same_as<std::remove_cvref_t<Type>, double>; 

    template<typename Type>
    concept double_long_long_c = std::same_as<std::remove_cvref_t<Type>, double> ||
            std::same_as<std::remove_cvref_t<Type>, unsigned long long> ||
            std::same_as<std::remove_cvref_t<Type>, signed long long> ||
            std::same_as<std::decay_t<std::remove_cvref_t<Type>>, const char*>; 

    namespace hidden
    {
        template<typename S, typename T>
        struct st_cplx_decompose
        {
            using real_type = std::common_type_t<S, T>;
            using cplx_type = std::complex<real_type>;
        };

        template<mpfr_prec_t MpfrPrec, mpfr_rnd_t MpfrRnd, std::floating_point CppFloatType>
        struct st_cplx_decompose<realnum<MpfrPrec, MpfrRnd>, CppFloatType>
        {
            using real_type = realnum<MpfrPrec, MpfrRnd>;
            using cplx_type = cplxnum<MpfrPrec, MPC_RND(MpfrRnd, MpfrRnd)>;
        };

        template<std::floating_point CppFloatType, mpfr_prec_t MpfrPrec, mpfr_rnd_t MpfrRnd>
        struct st_cplx_decompose<CppFloatType, realnum<MpfrPrec, MpfrRnd>>
        {
            using real_type = realnum<MpfrPrec, MpfrRnd>;
            using cplx_type = cplxnum<MpfrPrec, MPC_RND(MpfrRnd, MpfrRnd)>;
        };

        template<typename S, std::floating_point T>
        struct st_cplx_decompose<S, std::complex<T>>
        {
            using real_type = T;
            using cplx_type = std::complex<T>;
        };

        template<std::floating_point S, typename T>
        struct st_cplx_decompose<std::complex<S>, T>
        {
            using real_type = S;
            using cplx_type = std::complex<S>;
        };

        template<mpfr_prec_t MpfrPrec, mpfr_rnd_t MpfrRnd, mpc_rnd_t MpcRnd>
        struct st_cplx_decompose<realnum<MpfrPrec, MpfrRnd>, cplxnum<MpfrPrec, MpcRnd>>
        {
            using real_type = realnum<MpfrPrec, MPC_RND_RE(MpcRnd)>;
            using cplx_type = cplxnum<MpfrPrec, MpcRnd>;
        };

        template<mpfr_prec_t MpfrPrec, mpfr_rnd_t MpfrRnd, mpc_rnd_t MpcRnd>
        struct st_cplx_decompose<cplxnum<MpfrPrec, MpcRnd>, realnum<MpfrPrec, MpfrRnd>>
        {
            using real_type = realnum<MpfrPrec, MPC_RND_RE(MpcRnd)>;
            using cplx_type = cplxnum<MpfrPrec, MpcRnd>;
        };

        template<mpfr_prec_t MpfrPrec, mpc_rnd_t MpcRnd, std::floating_point CppFloatType>
        struct st_cplx_decompose<CppFloatType, cplxnum<MpfrPrec, MpcRnd>>
        {
            using real_type = realnum<MpfrPrec, MPC_RND_RE(MpcRnd)>;
            using cplx_type = cplxnum<MpfrPrec, MpcRnd>;
        };

        template<mpfr_prec_t MpfrPrec, mpc_rnd_t MpcRnd, std::floating_point CppFloatType>
        struct st_cplx_decompose<cplxnum<MpfrPrec, MpcRnd>, CppFloatType>
        {
            using real_type = realnum<MpfrPrec, MPC_RND_RE(MpcRnd)>;
            using cplx_type = cplxnum<MpfrPrec, MpcRnd>;
        };
    }
    // end of namespace hidden

    template<typename S, typename T>
    using real_type_t = typename hidden::st_cplx_decompose<S, T>::real_type;

    template<typename S, typename T>
    using cplx_type_t = typename hidden::st_cplx_decompose<S, T>::cplx_type;

    template<typename T>
    concept differentiable_c = one_of_c<T, float, double> 
        || realnum_c<T> || std_complex_c<T> || cplxnum_c<T>;

    template<typename T>
    concept primi_integer_c = one_of_c<T,
        short, unsigned short, int, unsigned int, long, unsigned long,
        long long, unsigned long long>;

    template<typename T>
    concept primi_floating_c = std::floating_point<std::remove_cvref_t<T>>;

    template<typename T>
    concept primi_int_floating_c = primi_integer_c<T> ||
        std::floating_point<std::remove_cvref_t<T>>;
    
    template<typename T>
    concept primi_complex_c = one_of_c<T, std::complex<float>, std::complex<double>>;

    template<typename T>
    concept primi_number_c = primi_integer_c<T> || 
                primi_floating_c<T> || primi_complex_c<T>;

    template<typename T>            
    decltype(auto)smart_double(T&& v) noexcept
    {
        if constexpr(std::integral<std::remove_cvref_t<T>>)
        {
            return static_cast<double>(v);
        }
        else
        {
            return std::forward<T>(v);
        }
    }

    template<typename... Ts>
    concept at_leat_one_primi_number_c = (primi_number_c<Ts>|| ...);

    template<typename... Ts>
    concept all_primi_number_c = (primi_number_c<Ts>&& ...);
    
    template<typename BaseType, typename ExpType>
    constexpr auto fast_power(BaseType base, ExpType exp)
    {
        BaseType r = BaseType{1};
        BaseType p = base;

        unsigned long long u = (unsigned long long)exp;

        while(u != 0)
        {
            if(u & 1) r *= p;
            u >>= 1;  p *= p;
        }

        return r;
    }

    ///////////////////////////////////////////////////

    template<typename S, typename T>
    concept binary_operable_c = requires(S s, T t)
    {
        { s + t } -> std::convertible_to< std::common_type_t<S, T> >;
        { s - t } -> std::convertible_to< std::common_type_t<S, T> >;
        { s * t } -> std::convertible_to< std::common_type_t<S, T> >;
        { s / t } -> std::convertible_to< std::common_type_t<S, T> >;
    };

    template<typename S, typename T>
    concept binary_add_c = requires(S s, T t)
    {
        { s + t } -> std::convertible_to< std::common_type_t<S, T> >;
    };

    template<typename S, typename T>
    concept binary_sub_c = requires(S s, T t)
    {
        { s - t } -> std::convertible_to< std::common_type_t<S, T> >;
    };

    template<typename S, typename T>
    concept binary_mul_c = requires(S s, T t)
    {
        { s * t } -> std::convertible_to< std::common_type_t<S, T> >;
    };

    template<typename S, typename T>
    concept binary_div_c = requires(S s, T t)
    {
        { s / t } -> std::convertible_to< std::common_type_t<S, T> >;
    };

    ///////////////////////////////////////////////////////////////////

    template<typename ReturnType, std::floating_point ArgType>
    consteval ReturnType cst_floor(ArgType v)
    {
        return (ReturnType)v;   
    }

    template<typename ReturnType, std::floating_point ArgType>
    consteval ReturnType cst_ceil(ArgType v)
    {
        if ( (ReturnType)(v * 10) - ((ReturnType)v * 10))
            return (ReturnType)(v) + 1;
        else
            return (ReturnType)v;
    }

    /*
        2^10 = Q = 1024 ≈ 1000 = 10^3

        2^10 = Q ≈ 10^3

        2^(binary digits) = Q ≈ 10^(decimal digits)

        bits = binary digits = 10
        digits = decimal digits = 3

        2^bits = Q ≈ 10^digits 

        log2 (2^bits) = log2(Q)

        bits = log2(Q)

        bits/log2(Q) = 1 .... Eq. (1)

       =========================
        10^digits = Q 
        log10(10^digits) = log10 (Q)

        digits = log10(Q)

        digits/log10(Q) = 1 .... Eq. (2)

        =========================
        16^hexits = Q 
        log16(16^hexits) = log16 (Q)

        hexits = log16(Q)

        hexits/log16(Q) = 1 .... Eq. (3)

        =============================

        Eq. (1) = Eq. (2) = 1

        bits/log2(Q) = digits/log10(Q)

        bits = digits * log2(Q) / log10(Q)

                            logₙ(Q)
                logₘ(n) = —————————— identity
                            logₘ(Q)   
    
                log2(Q) / log10(Q) = log2(10)

        // digits to bits
        bits = digits * log2(10)

        =============================
        digits/log10(Q) = bits/log2(Q)

        digits = bits * log10(Q) / log2(Q)

                log10(Q) / log2(Q) = log10 (2)

        // bits to digits
        digits = bits * log10(2)

        ========================================

        bits / log2(Q) = hexits / log16(Q)

        bits = hexits * log2(Q) / log16(Q)
             = hexits * log2(16)
             = hexits * log2(2^4)
             = hexits * 4

        hexits = bits / 4;

        ======================================
        digits / log10(Q) = hexits / log16(Q)

        digits = hexits * log10(Q) / log16(Q)
               = hexits * log10(16)

        hexits = digits / log10(16)

    */

    template<typename ArgType>
    consteval auto digits_2_bits(ArgType d)
    {
        // digits to bits
        // bits = digits * log2(10)

        constexpr double LOG2_10 = 3.3219280948873624;

        return gmp::cst_ceil<mpfr_prec_t>( d * LOG2_10 );
    }

    template<typename ArgType>
    consteval auto bits_2_digits(ArgType b)
    {
        // bits to digits
        // digits = bits * log10(2)
        
        constexpr double LOG10_2 = 0.30102999566398119;

        return gmp::cst_floor<mpfr_prec_t>(b * LOG10_2);
    }

    inline void mpz_reset(mpz_ptr z)
    {
        std::memset(z, 0, sizeof(mpz_t));
        // z->_mp_alloc = 0; z->_mp_size = 0; z->_mp_d = NULL;
    }

    inline void mpz_cleanup(mpz_ptr z)
    {
        if(z->_mp_d)
        { 

#ifdef MEM_CHECK
            std::cout << "mpz - memory cleaned" << std::endl;
#endif 

            mpz_clear(z);
        }
        else
        {

#ifdef MEM_CHECK
            std::cout << "mpz - memory cleaned skipped" << std::endl;
#endif
            ;
        }

        mpz_reset(z);
    }
    
    inline void mpq_reset(mpq_ptr mp)
    {
        mpz_reset(mpq_numref(mp));
        mpz_reset(mpq_denref(mp));
    }
    
    inline void mpq_cleanup(mpq_ptr mp)
    {
        if(mpq_numref(mp)->_mp_d && mpq_denref(mp)->_mp_d) 
        {

#ifdef MEM_CHECK
            std::cout << "mpq - memory cleaned" << std::endl;
#endif 

            mpq_clear(mp);

        }
        else
        {

#ifdef MEM_CHECK
            std::cout << "mpq - memory cleanup skipped" << std::endl;
#endif 

            ;
        }
        
        mpq_reset(mp);
    }
    
    inline void mpfr_reset(mpfr_ptr mp)
    {
        std::memset(mp, 0, sizeof(mpfr_t));

        // mp->_mpfr_sign = 0;
        // mp->_mpfr_prec = 0;
        // mp->_mpfr_exp  = 0;
        // mp->_mpfr_d    = NULL;
    }

    inline void mpfr_cleanup(mpfr_ptr mp)
    {
        if(mp->_mpfr_d)
        {

#ifdef MEM_CHECK
            std::cout << "mpfr - memory cleaned" << std::endl;
#endif 

            mpfr_clear(mp);

        }
        else
        {

#ifdef MEM_CHECK
            std::cout << "mpfr - memory cleanup skipped" << std::endl;
#endif 
            ;
        }
        
        mpfr_reset(mp);
    }

    inline void mpc_clean(mpc_ptr mp)
    {
        mpfr_reset(mp->re);
        mpfr_reset(mp->im);
    }

    inline void show_mpz_internal(mpz_srcptr z)
    {
        std::cout <<"_mp_alloc = " << z->_mp_alloc << "\n"
                  <<"_mp_size  = " << z->_mp_size << "\n"
                  <<"_mp_alloc = " << z->_mp_alloc << std::endl;
    }

    inline void show_mpq_internal(mpq_srcptr q)
    {
        std::cout << "numerator\n";
        show_mpz_internal(mpq_numref(q));

        std::cout << "denominator\n";
        show_mpz_internal(mpq_denref(q));
    }
    
    inline void show_mpfr_internal(mpfr_srcptr mp)
    {
        std::cout << "mp->_mpfr_sign = " << mp->_mpfr_sign << "\n"
                  << "mp->_mpfr_prec = " << mp->_mpfr_prec << "\n"
                  << "mp->_mpfr_exp  = " << mp->_mpfr_exp << "\n"
                  << "mp->_mpfr_d    = " << mp->_mpfr_d << std::endl;
    }

    inline void show_mpc_internal(mpc_srcptr mp)
    {
        std::cout << "Real part:\n";
        show_mpfr_internal(mp->re); 
        std::cout << "\nImag part:\n";
        show_mpfr_internal(mp->im);
    }

    inline void mpc_cleanup(mpc_ptr mp)
    {
        if(mp->re->_mpfr_d && mp->im->_mpfr_d)
        {

#ifdef MEM_CHECK
            std::cout << "mpc - memory cleaned" << std::endl;
#endif 
            mpc_clear(mp);

        }
        else
        {

#ifdef MEM_CHECK
            std::cout << "mpc - memory cleanup skipped" << std::endl;
#endif
            ;
        }
        
        mpc_clean(mp);
    }

    ////////////////////////////////////////////////////////
    template<type_in_types_c<char, short, int, long> ArgType>
    void mpz_set_mcn_type(mpz_ptr mp, ArgType op)
    {   mpz_set_si(mp, (signed long)op); }

    template<type_in_types_c<unsigned char,
        unsigned short, unsigned int, unsigned long> ArgType>
    void mpz_set_mcn_type(mpz_ptr mp, ArgType op)
    {   mpz_set_ui(mp, (unsigned long)op); }

    template<type_in_types_c<long long, unsigned long long> ArgType>
    void mpz_set_mcn_type(mpz_ptr mp, ArgType op)
    {
        auto str = std::to_string(op);
        mpz_set_str(mp, str.c_str(), 10);
    }

    template<type_in_types_c<float, double> ArgType>
    void mpz_set_mcn_type(mpz_ptr mp, ArgType op)
    {
        std::ostringstream os;
        os.precision(std::numeric_limits<ArgType>::max_digits10);
        os << op;
        
        mpfr_t fr; mpfr_init(fr);
        mpfr_set_str(fr, os.str().c_str(), 10, MPFR_RNDN);
        mpfr_get_z2(mp, fr, MPFR_RNDN); 
        mpfr_clear(fr);
    }

    void mpz_set_mcn_type(mpz_ptr mp, const char* op)
    {
        auto str = hidden::remove_chars(op);
        mpz_set_str(mp, str.c_str(), 10);
    }

    //////////////////////////////////////////////////////    
    template<type_in_types_c<char, short, int, long> ArgType>
    void mpz_init_set_mcn_type(mpz_ptr mp, ArgType op)
    {   mpz_init_set_si(mp, (signed long)op); }

    template<type_in_types_c<unsigned char,
        unsigned short, unsigned int, unsigned long> ArgType>
    void mpz_init_set_mcn_type(mpz_ptr mp, ArgType op)
    {   mpz_init_set_ui(mp, (unsigned long)op); }

    // template<type_in_types_c<long long, unsigned long long> ArgType>
    // void mpz_init_set_mcn_type(mpz_ptr mp, ArgType op)
    // {
    //     // auto str = std::to_string(op);
    //     // mpz_init_set_str(mp, str.c_str(), 10);
    // }

    void mpz_init_set_mcn_type(mpz_ptr mp, unsigned long long op)
    {
        mpz_init2(mp, std::numeric_limits<unsigned long long>::digits);
        mpz_set_ux_ext(mp, op);
    }

    void mpz_init_set_mcn_type(mpz_ptr mp, long long op)
    {
        mpz_init2(mp, std::numeric_limits<long long>::digits);
        mpz_set_sx_ext(mp, op);
    }

    template<type_in_types_c<float, double> ArgType>
    void mpz_init_set_mcn_type(mpz_ptr mp, ArgType op)
    {   
        mpz_init(mp);

        std::ostringstream os;
        os.precision(std::numeric_limits<ArgType>::max_digits10);
        os << op;
        
        mpfr_t fr; mpfr_init(fr);
        mpfr_set_str(fr, os.str().c_str(), 10, MPFR_RNDN);
        mpfr_get_z2(mp, fr, MPFR_RNDN); 
        mpfr_clear(fr);
    }
    
    void mpz_init_set_mcn_type(mpz_ptr mp, const char* op)
    {
        auto str = hidden::remove_chars(op);
        mpz_init_set_str(mp, str.c_str(), 10);
    }
    
    // multiprecision integer
    class intnum
    {
        private:
            mpz_t mp{};

        public:
            intnum() { mpz_init_set_si(mp, 0); }

            intnum(mpz_mcn_args_c auto&& op)
            {   mpz_init_set_mcn_type(mp, op); }
                       
            intnum(const mpz_t& op) 
            {   mpz_init_set(mp, op); }
            
            intnum(mpz_t&& op) 
            {  mpz_swap(mp, op); }

            template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
            intnum(const realnum<Prec, RndMode>& rlm);

            intnum(const ratnum& op);

            intnum(const intnum& op) 
            {   mpz_init_set(mp, op.mp); }

            intnum(intnum&& op) 
            {   mpz_swap(mp, op.mp); }

            intnum& operator=(const intnum& op) 
            { 
                if(this != std::addressof(op))
                {
                    mpz_cleanup(mp);
                    mpz_init_set(mp, op.mpz_srcptr());
                }

                return *this;
            }

            intnum& operator=(intnum&& op) 
            { 
                if(this != std::addressof(op))
                {
                    invalidate();
                    mpz_swap(mp, op.mpz_ptr());
                }

                return *this;
            }

            intnum operator-() const
            { 
                mpz_t result{}; mpz_init(result);
                mpz_neg(result, this->mp);
                return { std::move(result) };
            }

            int sign() const { return mpz_sgn(mp); }
            bool is_positive() const { return mpz_sgn(mp) > 0; }
            
            bool is_zero() const { return mpz_sgn(mp) == 0; }

            bool is_negative() const { return mpz_sgn(mp) < 0; }

            // flip sign in place
            void flip_sign()
            { mpz_neg(mp, this->mpz_srcptr()); }

            void display_info() const
            {
                show_mpz_internal(mp);
            }

            operator ratnum() const;
                        
            void invalidate() { mpz_cleanup(mp); }
            void reset() { mpz_reset(mp); }
        
            const mpz_t& mpz_ref() const { return mp; }
            mpz_t& mpz_ref() { return mp; }

            mpz_srcptr mpz_srcptr() const { return mp; }
            mpz_ptr mpz_ptr() { return mp; }

            inline explicit operator bool () const
            {   return !is_zero(); }

            template<primi_integer_c T>
            explicit operator T() const noexcept
            {
                auto rlt = mpz_export_value<T>(this->mp);

                if(rlt.has_value())
                {
                    if constexpr(std::is_unsigned_v<T>)
                    {
                        if( mpz_sgn(mp) < 0 && rlt.value() > 0 )
                        {
                            std::cout <<"\nRUNTIME ERROR: negative number\n"
                                "\tis assigned to " << Gmp_GetTypeName(T) <<"\n\n";
                        }
                    }

                    return rlt.value();
                }
                else
                {
                    std::cout <<"\nRUNTIME ERROR: OVERFLOW\n"
                                "\tconversion from intnum to "
                                << Gmp_GetTypeName(T) <<"\n\n";

                    return std::numeric_limits<T>::max();
                }
            }

            inline explicit operator float () const noexcept
            {   return (float)mpz_get_d(mp); }

            inline explicit operator double () const noexcept
            {   return mpz_get_d(mp); }

            // inline explicit operator long double() const noexcept
            // {
            //     return hidden::mpz_get_floating<long double>(mp);
            // }

            template<float_double_c T>
            explicit operator std::complex<T>() const noexcept
            {
                T d = (T)(*this); return { d, T{0} };
            }

            // WARNING: don't define it
            // realnum has constructor that takes intnum

            // template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
            // operator realnum<Prec, RndMode>() const;

            // WARNING: don't define it
            // cplxnum has constructor that takes intnum

            // template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
            // operator cplxnum<Prec, RndMode>() const;

            template<auto BufSize = 256>
            std::string string(int base = 10,
                bool respect_showpos = true) const
            {
                std::ostringstream format;
                const std::ios::fmtflags flags = std::cout.flags();

                auto size = mpz_sizeinbase(mp, base) + 2;

                if(size < BufSize)
                {
                    char buffer[BufSize]{ };
                    mpz_get_str(buffer, base, mp);
                    
                    std::string str{buffer};

                    if(str[0] != '-' && (flags & std::ios::showpos))
                        return respect_showpos ? "+" + str : str;
                    else
                        return str;
                }
                else
                {
                    auto ptr = mpz_get_str(NULL, base, mp);           
                    std::string str(ptr); free(ptr);

                    if(str[0] != '-' && (flags & std::ios::showpos))
                        return respect_showpos ? "+" + str : str;
                    else
                        return str;
                }
            }

            template<auto BufSize = 256>
            std::string flat(int place = 3, int base = 10, bool respect_showpos = true) const
            {
                constexpr char delimiter = '\'';
                
                return hidden::add_delimiter_right_to_left
                       ( this->string<BufSize>(base, respect_showpos), delimiter, place);
            }

            template<auto BufSize = 256>
            std::string group(char delimiter = '\'',
                int place = 3, int base = 10, bool respect_showpos = true) const
            {
                return hidden::add_delimiter_right_to_left
                       ( this->string<BufSize>(base, respect_showpos), delimiter, place);
            }
            
            template<auto BufSize = 256>
            std::string group(int place, int base = 10, bool respect_showpos = true) const
            {
                constexpr char delimiter = '\'';

                return hidden::add_delimiter_right_to_left
                       ( this->string<BufSize>(base, respect_showpos), delimiter, place);
            }

            ~intnum() { invalidate(); }

            //////////////////////////////////////// addition operators ////////////////////
            intnum& operator++()
            {
                mpz_add_ui(mp, mp, (unsigned long int)1); return *this;
            }

            intnum operator++(int)
            {
                auto rtn = *this;
                mpz_add_ui(mp, mp, 1); return rtn;
            }

            intnum& operator--()
            {
                mpz_sub_ui(mp, mp, 1); return *this;
            }

            intnum operator--(int)
            {
                auto rtn = *this;
                mpz_sub_ui(mp, mp, 1); return rtn;
            }

            intnum& operator+=(const intnum& op) 
                { mpz_add(mp, mp, op.mp); return *this; }

            intnum& operator+=(mpz_mcn_args_c auto op) 
            { 
                if constexpr(unsigned_csil_c<decltype(op)>)
                {   
                    mpz_add_ui(mp, mp, op); 
                    return *this; 
                }
                else
                {
                    *this += intnum{op};
                    return *this; 
                }
            }

            intnum& operator-=(const intnum& op) 
            { mpz_sub(mp, mp, op.mp); return *this; }

            intnum& operator-=(mpz_mcn_args_c auto op) 
            { 
                if constexpr(unsigned_csil_c<decltype(op)>)
                {
                    mpz_sub_ui(mp, mp, (unsigned long)op);
                    return *this; 
                }
                else
                {
                    *this -= intnum{op}; 
                    return *this; 
                }
            }

            intnum& operator*=(const intnum& op) 
            { mpz_mul(mp, mp, op.mp); return *this; }

            intnum& operator*=(mpz_mcn_args_c auto op) 
            {
                if constexpr(unsigned_csil_c<decltype(op)>)
                {
                    mpz_mul_ui(mp, mp, (unsigned long)op);
                    return *this;
                }
                else if constexpr(signed_csil_c<decltype(op)>)
                {
                    mpz_mul_si(mp, mp, (signed long)op);
                    return *this;
                }
                else
                {
                    *this *= intnum{op};
                    return *this; 
                }
            }

            intnum& operator/=(const intnum& op) 
                { mpz_div(mp, mp, op.mp); return *this; }

            intnum& operator/=(mpz_mcn_args_c auto op) 
                { *this /= intnum{op}; return *this; }

            std::strong_ordering operator<=>(const intnum& other) const noexcept 
            {
                int cmp = mpz_cmp(this->mp, other.mpz_srcptr());

                if (cmp < 0) 
                    return std::strong_ordering::less;
                else if (cmp > 0) 
                    return std::strong_ordering::greater;
                else
                    return std::strong_ordering::equal;
            }
    };
    // end of class intnum

    namespace hidden
    {
        template<typename RawReturnType,
                typename ReturnType = std::remove_cvref_t<RawReturnType>>
            requires intnum_c<ReturnType>
        ReturnType mpfr_get_integer(const mpfr_t x, mpfr_rnd_t rnd) noexcept
        {
        #if defined(__GNUC__) && !defined(__clang__)
            mpfr_exp_t exp;
            char* cstr = mpfr_get_str(nullptr, &exp, 10, 0, x, rnd);

            intnum z{cstr};
            mpfr_free_str(cstr);   // ✅ free memory
            return z;

        #else
            intnum z;
            mpfr_get_z(z.mpz_ptr(), x, rnd);
            return z;
        #endif
        }
    }

    // end of namespace hidden
    
    std::ostream& operator<<(std::ostream& os, const intnum& z) noexcept
    {
        os << z.string(); return os;
    }
       
    ////////////////////////////////////////
    intnum operator<< (const intnum& z, mcn_integer_c auto bitcount)
    {
        intnum x;
        mpz_mul_2exp(x.mpz_ptr(), z.mpz_srcptr(), (unsigned long)bitcount);
        return x;        
    }

    intnum operator>> (const intnum& z, mcn_integer_c auto bitcount)
    {
        intnum x;
        mpz_fdiv_q_2exp(x.mpz_ptr(), z.mpz_srcptr(), (unsigned long)bitcount);
        return x;
    }

    intnum operator& (const intnum& op1, const intnum& op2)
    {
        intnum x;
        mpz_and(x.mpz_ptr(), op1.mpz_srcptr(), op2.mpz_srcptr());
        return x;
    }

    intnum operator| (const intnum& op1, const intnum& op2)
    {
        intnum x;
        mpz_ior(x.mpz_ptr(), op1.mpz_srcptr(), op2.mpz_srcptr());
        return x;
    }

    intnum operator^ (const intnum& op1, const intnum& op2)
    {
        intnum x;
        mpz_xor(x.mpz_ptr(), op1.mpz_srcptr(), op2.mpz_srcptr());
        return x;
    }

    intnum operator% (const intnum& op1, const intnum& op2)
    {
        intnum x;
        mpz_mod(x.mpz_ptr(), op1.mpz_srcptr(), op2.mpz_srcptr());
        return x;
    }

    /////////////// binary addion operators for intnum /////////////////////////
    namespace hidden
    {
        /////////////// intnum binary operation //////////////////////////
        template<BinOpr opr, intnum_c LeftType, intnum_c RightType>
        decltype(auto) gmp_binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
        {
            using L = decltype(lhs);
            using R = decltype(rhs);

            if constexpr (opr == BinOpr::add)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpz_add(lhs.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpz_add(rhs.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    intnum x{ lhs };
                    mpz_add(x.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());        
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::mul)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpz_mul(lhs.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpz_mul(rhs.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    intnum x{ lhs };
                    mpz_mul(x.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());        
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::sub)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpz_sub(lhs.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());
                    return std::move(lhs);
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpz_sub(rhs.mpz_ptr(), rhs.mpz_srcptr(), lhs.mpz_srcptr());
                     mpz_neg(rhs.mpz_ptr(), rhs.mpz_ptr());  // flip sign
                    return std::move(rhs);
                }
                else // both are lvalue reference
                {
                    intnum x{ lhs };
                    mpz_sub(x.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());        
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::div)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpz_div(lhs.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());
                    return std::move(lhs);
                }
                else // both are lvalue reference
                {
                    intnum x{ lhs };
                    mpz_div(x.mpz_ptr(), lhs.mpz_srcptr(), rhs.mpz_srcptr());        
                    return x;
                }
            }
        }
    }
    // end of namespace hidden

    template<intnum_c LeftType, intnum_c RightType>
    decltype(auto) operator + (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::add>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<intnum_c LeftType, intnum_c RightType>
    decltype(auto) operator - (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::sub>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<intnum_c LeftType, intnum_c RightType>
    decltype(auto) operator * (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::mul>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<intnum_c LeftType, intnum_c RightType>
    decltype(auto) operator / (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::div>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    //////////////////////////////////////////////////////////////////
    
    intnum operator+(intnum_c auto&& lhs, mpz_mcn_args_c auto&& rhs)
    {   return lhs + intnum{ rhs }; }

    intnum operator+(mpz_mcn_args_c auto&& lhs, intnum_c auto&& rhs)
    {   return intnum{lhs} + rhs; }
   
    intnum operator-(intnum_c auto&& lhs, mpz_mcn_args_c auto&& rhs)
    {   return lhs - intnum{ rhs }; }

    intnum operator-(mpz_mcn_args_c auto&& lhs, intnum_c auto&& rhs)
    {   return intnum{lhs} - rhs; }
   
    intnum operator*(intnum_c auto&& lhs, mpz_mcn_args_c auto&& rhs)
    {   return lhs * intnum{ rhs }; }

    intnum operator*(mpz_mcn_args_c auto&& lhs, intnum_c auto&& rhs)
    {   return intnum{lhs} * rhs; }
        
    intnum operator/(intnum_c auto&& lhs, mpz_mcn_args_c auto&& rhs)
    {   return lhs / intnum{ rhs }; }

    intnum operator/(mpz_mcn_args_c auto&& lhs, intnum_c auto&& rhs)
    {   return intnum{ lhs } / rhs; }

    /////////////// comparison operators /////////////////////

    bool operator==(const intnum& lhs, const intnum& rhs)
    {   return mpz_cmp(lhs.mpz_srcptr(), rhs.mpz_srcptr()) == 0; }

    template<typename T> requires type_in_types_c
        <T, char, short, int, signed long>
    bool operator==(const intnum& lhs, T rhs)
    {   return mpz_cmp_si(lhs.mpz_srcptr(), (signed long)rhs) == 0; }

    template<typename T> requires type_in_types_c
        <T, unsigned char, unsigned short, unsigned int, unsigned long>
    bool operator==(const intnum& lhs, T rhs)
    {   return mpz_cmp_ui(lhs.mpz_srcptr(), (unsigned long)rhs) == 0; }

    template<typename T>
        requires type_in_types_c<T, long long, unsigned long long>
    bool operator==(const intnum& lhs, T rhs)
    {   return lhs == intnum{ rhs }; }

    bool operator==(const intnum& lhs, float rhs)
    {   return mpz_cmp_d(lhs.mpz_srcptr(), (double)rhs) == 0; }

    bool operator==(const intnum& lhs, double rhs)
    {   return mpz_cmp_d(lhs.mpz_srcptr(), rhs) == 0; }

    // intnum::operator long long() const noexcept
    // {
    //     // Sign quick path
    //     int s = mpz_sgn(mp);
        
    //     if (s == 0) return 0;

    //     auto limb_count = mpz_limb_count(mp);
    //     auto byte_count = mpz_byte_count(mp);

    //     std::cout <<"fit to long long = " << mpz_fit_type<long long>(mp) << std::endl;

    //     std::cout << "limb_count = " << limb_count << std::endl;
    //     std::cout << "byte_count = " << byte_count << std::endl << std::endl;

        


    //     long long val = 0;
    //     size_t count = 0;
    //     mpz_export(&val, &count, 1, sizeof(val), 0, 0, mp);

    //     intnum x;

    //     std::cout << "count = " << count << std::endl;

    //     mpz_import(x.mp, count, 1, sizeof(long long), 0, 0, &val);

    //     std::cout <<"imported x = " << x << std::endl;

    //     if (*this == x)
    //     {
    //         std::cout << "success " << std::endl;
    //         return val;
    //     }
    //     else
    //     {
    //         std::cout << "failed" << std::endl;
    //         return std::numeric_limits<long long>::max();
    //     }

    //     // return val;
    // }

    // bool operator==(const intnum& lhs, long double rhs)
    // {   
    //     return lhs == (double)rhs;
    // }

    //////////////////////// mpz functions ///////////////////////

    // returns factorial of n ≥ 0
    inline intnum fact(auto&& n)
    {    
        intnum f{1};

        if(n == 0)
            return f;
        else
        {
            mpz_fac_ui(f.mpz_ptr(), (unsigned long)n);
            return f;
        }
    }

    inline intnum abs(const intnum& op)
    {
        intnum x;
        mpz_abs(x.mpz_ptr(), op.mpz_srcptr());
        return x;
    }
    
    inline intnum sqrt(const intnum& op)
    {
        intnum x;
        mpz_sqrt(x.mpz_ptr(), op.mpz_srcptr());
        return x;
    }

    std::tuple<intnum, intnum> sqrtrem(const intnum& op)
    {
        mpz_t rop1; mpz_t rop2; 
        mpz_inits(rop1, rop2, NULL);
        mpz_sqrtrem(rop1, rop2, op.mpz_srcptr());
        return { intnum{std::move(rop1) }, intnum{std::move(rop2) } };
    }
    
    // multiprecision rational number
    class ratnum
    {
        private:
            mpq_t mp{};
        
        public:
            inline void canonicalize() { mpq_canonicalize(mp); }
        public:

            ratnum() { mpq_init(mp); mpq_set_si(mp, 0, 1); }

            ratnum(mpz_mcn_args_c auto p)
            {
                intnum x{p};
                mpz_swap(mpq_numref(mp), x.mpz_ptr());
                mpz_init_set_si(mpq_denref(mp), 1);
                x.reset();
            }

            ratnum(mpz_mcn_args_c auto p, mpz_mcn_args_c auto q)
            {
                intnum x{p}; intnum y{q};

                mpz_swap(mpq_numref(mp), x.mpz_ptr());
                mpz_swap(mpq_denref(mp), y.mpz_ptr());
                
                x.reset(); y.reset();
                
                canonicalize();
            }
            
            ratnum(intnum_c auto&& op)
            {   
                if constexpr(std::is_rvalue_reference_v<decltype(op)>)
                {
                    mpz_swap(mpq_numref(mp), op.mpz_ptr());
                    mpz_init_set_si(mpq_denref(mp), 1);
                }
                else
                {
                    mpz_init_set(mpq_numref(mp), op.mpz_srcptr());
                    mpz_init_set_si(mpq_denref(mp), 1);
                }
            }

            ratnum(intnum_c auto&& p, intnum_c auto&& q)
            {
                // mpq_init(mp); why I don't need this

                if constexpr( std::is_rvalue_reference_v<decltype(p)> 
                             && std::is_rvalue_reference_v<decltype(q)> )
                {                
                    mpz_swap(mpq_numref(mp), p.mpz_ptr());
                    mpz_swap(mpq_denref(mp), q.mpz_ptr());
                }
                else if constexpr( std::is_rvalue_reference_v<decltype(p)> 
                                 && !std::is_rvalue_reference_v<decltype(q)> )
                {                
                    mpz_swap(mpq_numref(mp), p.mpz_ptr());
                    mpz_init_set(mpq_denref(mp), q.mpz_srcptr());
                }
                else if constexpr( !std::is_rvalue_reference_v<decltype(p)> 
                                 && std::is_rvalue_reference_v<decltype(q)> )
                {   
                    mpz_init_set(mpq_numref(mp), p.mpz_srcptr());
                    mpz_swap(mpq_denref(mp), q.mpz_ptr());
                }
                else if constexpr( !std::is_rvalue_reference_v<decltype(p)> 
                                 && !std::is_rvalue_reference_v<decltype(q)> )
                {   
                    mpz_init_set(mpq_numref(mp), p.mpz_srcptr());
                    mpz_init_set(mpq_denref(mp), q.mpz_srcptr());
                }

                canonicalize();
            }

            ratnum(const mpq_t& op)
            {   
                mpq_init(mp); mpq_set(mp, op); 
            }

            ratnum(mpq_t&& op) 
            {   
                mpq_swap(mp, op); 
            }

            // copy constructor
            ratnum(const ratnum& op)
            {   mpq_init(mp); mpq_set(mp, op.mpq_srcptr()); }

            // move constructor
            ratnum(ratnum&& op)
            {   mpq_swap(mp, op.mpq_ptr()); }

            // copy assignment
            ratnum& operator=(const ratnum& op)
            {
                if(this != std::addressof(op))
                {
                    mpq_set(mp, op.mpq_srcptr());
                }
                
                return *this;
            }

            // move assignment
            ratnum& operator=(ratnum&& op)
            {
                if(this != std::addressof(op))
                {
                    this->invalidate();
                    mpq_swap(mp, op.mpq_ptr());
                }
                
                return *this;
            }

            ratnum operator-() const
            {
                ratnum x; 
                mpq_neg(x.mpq_ptr(), this->mpq_srcptr());
                return x;
            }

            ratnum& operator++() 
            { 
                mpz_add(mpq_numref(mp), mpq_numref(mp), mpq_denref(mp));
                canonicalize();
                return *this; 
            }

            ratnum operator++(int) 
            { 
                auto x = *this;
                mpz_add(mpq_numref(mp), mpq_numref(mp), mpq_denref(mp));
                canonicalize();
                
                return x; 
            }

            ratnum& operator--()
            {
                mpz_sub(mpq_numref(mp), mpq_numref(mp), mpq_denref(mp));
                canonicalize();
                return *this; 
            }

            ratnum operator--(int)
            { 
                auto x = *this;
                mpz_sub(mpq_numref(mp), mpq_numref(mp), mpq_denref(mp));
                canonicalize();
                
                return x; 
            }

            // return the reciprocal or inverted rational number
            // if p/q, q/p is returned
            ratnum inv() const
            {
                ratnum x; 
                mpq_inv(x.mpq_ptr(), this->mpq_srcptr());
                x.canonicalize();
                
                return x;
            }

            explicit operator float() const noexcept
            { return (float) mpq_get_d(mp); }
            
            operator double() const noexcept
            { return mpq_get_d(mp); }

            explicit operator intnum() const
            {
                intnum result;
                // truncate toward zero
                mpz_tdiv_q(result.mpz_ptr(), mpq_numref(mp), mpq_denref(mp)); 

                return result;
            }

            template<primi_integer_c T>
            explicit operator T() const noexcept
            {
                auto rlt = mpq_export_value<T>(this->mp);

                if(rlt.has_value())
                {
                    if constexpr(std::is_unsigned_v<T>)
                    {
                        if( mpq_sgn(mp) < 0 && rlt.value() > 0 )
                        {
                            std::cout <<"\nRUNTIME ERROR: negative number\n"
                                "\tis assigned to " << Gmp_GetTypeName(T) <<"\n\n";
                        }
                    }

                    return rlt.value();
                }
                else
                {
                    std::cout <<"\nRUNTIME ERROR: OVERFLOW\n"
                                "\tconversion from intnum to "
                                << Gmp_GetTypeName(T) <<"\n\n";

                    return std::numeric_limits<T>::max();
                }
            }

            template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
            operator realnum<Prec, RndMode>() const;

            void invalidate() { mpq_cleanup(mp); }
            
            ~ratnum() { invalidate(); }

            mpq_ptr mpq_ptr() { return mp; }
            mpq_srcptr mpq_srcptr() const { return mp; }
           
            intnum num() const 
            { 
                mpz_t p; mpz_init(p); mpq_get_num(p, mp);
                return { std::move(p) };
            }

            intnum den() const 
            { 
                mpz_t q; mpz_init(q); mpq_get_den(q, mp);
                return { std::move(q) };
            }
            
            /////////// += ,-=, *=, /= operators //////////////
            ratnum& operator+=(const ratnum& op) 
            { 
                mpq_add(mp, mp, op.mp);
                canonicalize(); return *this; 
            }

            ratnum& operator+=(intnum_c auto&& op) 
            { 
                mpz_add(mpq_numref(mp), mpq_numref(mp), op.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ratnum& operator+=(mpz_mcn_args_c auto op) 
            { 
                intnum x{ op };
                mpz_add(mpq_numref(mp), mpq_numref(mp), x.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ratnum& operator-=(const ratnum& op) 
            { 
                mpq_sub(mp, mp, op.mp);
                canonicalize(); return *this; 
            }

            ratnum& operator-=(intnum_c auto&& op) 
            { 
                mpz_sub(mpq_numref(mp), mpq_numref(mp), op.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ratnum& operator-=(mpz_mcn_args_c auto op) 
            { 
                intnum x{ op };
                mpz_sub(mpq_numref(mp), mpq_numref(mp), x.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ratnum& operator*=(const ratnum& op) 
            { 
                mpq_mul(mp, mp, op.mp);
                canonicalize(); return *this; 
            }

            ratnum& operator*=(intnum_c auto&& op) 
            { 
                mpz_mul(mpq_numref(mp), mpq_numref(mp), op.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ratnum& operator*=(mpz_mcn_args_c auto op) 
            { 
                intnum x{ op };
                mpz_mul(mpq_numref(mp), mpq_numref(mp), x.mpz_srcptr());
                canonicalize(); return *this; 
            }
            
            ratnum& operator/=(const ratnum& op) 
            { 
                mpq_div(mp, mp, op.mp);
                canonicalize(); return *this; 
            }

            ratnum& operator/=(intnum_c auto&& op) 
            { 
                mpz_div(mpq_numref(mp), mpq_numref(mp), op.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ratnum& operator/=(mpz_mcn_args_c auto op) 
            { 
                intnum x{ op };
                mpz_div(mpq_numref(mp), mpq_numref(mp), x.mpz_srcptr());
                canonicalize(); return *this; 
            }

            ////////////////////////////////////////
                
            template<auto BufSize = 256>
            std::string string(int base = 10) const
            {
                return num().string<BufSize>(base) 
                        + "/" + den().string<BufSize>(base, false);
            }

            template<auto BufSize = 256>
            std::string flat(int place = 3, int base = 10) const
            {
                constexpr char delimiter = '\'';

                return num().group<BufSize>(delimiter, place, base) 
                        + "/" + den().group<BufSize>(delimiter, place, base, false);
            }

            template<auto BufSize = 256>
            std::string group_flat(char delimiter = '\'',
                int place = 3, int base = 10) const
            {
                return num().group<BufSize>(delimiter, place, base) 
                        + "/" + den().group<BufSize>(delimiter, place, base, false);
            }

            template<auto BufSize = 256>
            std::string group_flat(int place, int base = 10) const
            {
                constexpr char delimiter = '\'';
                return num().group<BufSize>(delimiter, place, base) 
                        + "/" + den().group<BufSize>(delimiter, place, base, false);
            }

            template<auto BufSize = 256>
            std::string group(int place, int base = 10) const
            {
                constexpr char delimiter = '\'';
                return "[" + num().group<BufSize>(delimiter, place, base) 
                        + "/" + den().group<BufSize>(delimiter, place, base, false) + "]";
            }

            template<auto BufSize = 256>
            std::string group(char delimiter = '\'',
                int place = 3, int base = 10) const
            {
                return "[" + num().group<BufSize>(delimiter, place, base) 
                        + "/" + den().group<BufSize>(delimiter, place, base, false) + "]";
            }
    };
    // end of class ratnum

    intnum::operator ratnum() const
    {
        return ratnum{ *this };
    } 

    template<typename CharType>
    std::basic_ostream<CharType>& operator<<
        (std::basic_ostream<CharType>& os, const ratnum& q)
    {
        os << "[" << q.string() << "]"; return os;
    }

    namespace hidden
    {
        /////////////// ratnum binary operation ///////////////////////////
        template<BinOpr opr, ratnum_c LeftType, ratnum_c RightType>
        decltype(auto) gmp_binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
        {
            using L = decltype(lhs);
            using R = decltype(rhs);

            if constexpr (opr == BinOpr::add)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpq_add(lhs.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(lhs.mpq_ptr());
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpq_add(rhs.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(rhs.mpq_ptr());
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    ratnum x{ lhs };
                    mpq_add(x.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());     
                    mpq_canonicalize(x.mpq_ptr());   
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::mul)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpq_mul(lhs.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(lhs.mpq_ptr());
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpq_mul(rhs.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(rhs.mpq_ptr());
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    ratnum x{ lhs };
                    mpq_mul(x.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());      
                    mpq_canonicalize(x.mpq_ptr());  
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::sub)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpq_sub(lhs.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(lhs.mpq_ptr());
                    return std::move(lhs);
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpq_sub(rhs.mpq_ptr(), rhs.mpq_srcptr(), lhs.mpq_srcptr());
                    mpz_neg(mpq_numref(rhs.mpq_ptr()), mpq_numref(rhs.mpq_ptr()));  // flip sign
                    mpq_canonicalize(rhs.mpq_ptr());
                    
                    return std::move(rhs);
                }
                else // both are lvalue reference
                {
                    ratnum x{ lhs };
                    mpq_sub(x.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(x.mpq_ptr());
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::div)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpq_div(lhs.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());
                    mpq_canonicalize(lhs.mpq_ptr());
                    return std::move(lhs);
                }
                else // both are lvalue reference
                {
                    ratnum x{ lhs };
                    mpq_div(x.mpq_ptr(), lhs.mpq_srcptr(), rhs.mpq_srcptr());       
                    mpq_canonicalize(x.mpq_ptr()); 
                    return x;
                }
            }
        }
    }
    // end of namespace hidden
    
    /////////////// binary operators for ratnum /////////////////////////

    template<ratnum_c LeftType, ratnum_c RightType>
    decltype(auto) operator + (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::add>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<ratnum_c LeftType, ratnum_c RightType>
    decltype(auto) operator - (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::sub>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<ratnum_c LeftType, ratnum_c RightType>
    decltype(auto) operator * (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::mul>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<ratnum_c LeftType, ratnum_c RightType>
    decltype(auto) operator / (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::div>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<typename T>
    concept ratnum_mcn_arg_c = type_in_types_c< std::remove_cvref_t<T>,
         char, short, int, long, long long, unsigned char,
         unsigned short, unsigned int, unsigned long long, float,
         double, const char*, intnum>;

    ratnum operator+(ratnum_c auto&& lhs, ratnum_mcn_arg_c auto&& rhs)
    {
        return lhs + ratnum{ rhs };
    }

    ratnum operator+(ratnum_mcn_arg_c auto&& lhs, ratnum_c auto&& rhs)
    {
        return ratnum{lhs} + rhs;
    }
       
    ratnum operator-(ratnum_c auto&& lhs, ratnum_mcn_arg_c auto&& rhs)
    {
        return lhs - ratnum{ rhs };
    }

    ratnum operator-(ratnum_mcn_arg_c auto&& lhs, ratnum_c auto&& rhs)
    {
        return ratnum{lhs} - rhs;
    }
       
    ratnum operator*(ratnum_c auto&& lhs, ratnum_mcn_arg_c auto&& rhs)
    {
        return lhs * ratnum{ rhs };
    }

    ratnum operator*(ratnum_mcn_arg_c auto&& lhs, ratnum_c auto&& rhs)
    {
        return ratnum{lhs} * rhs;
    }
       
    ratnum operator/(ratnum_c auto&& lhs, ratnum_mcn_arg_c auto&& rhs)
    {
        return lhs / ratnum{ rhs };
    }

    ratnum operator/(ratnum_mcn_arg_c auto&& lhs, ratnum_c auto&& rhs)
    {
        return ratnum{lhs} / rhs;
    }

    /////////////////////////////////////////////////////////////
   
    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode, typename ArgType>
        requires(type_in_types_c<std::remove_cvref_t<ArgType>, char, short, int, long>)
    void mpfr_init_set_arg(mpfr_ptr mp, ArgType&& op)
    {
        mpfr_init2(mp, BitPrec); 
        mpfr_set_si(mp, (signed long)op, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode, typename ArgType>
        requires(type_in_types_c<std::remove_cvref_t<ArgType>,
            unsigned char, unsigned short, unsigned int, unsigned long>)
    void mpfr_init_set_arg(mpfr_ptr mp, ArgType&& op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_ui(mp, (unsigned long)op, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, long long op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_sj(mp, op, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, unsigned long long op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_uj(mp, op, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode, typename ArgType>
        requires type_in_types_c<ArgType, float, double>
    void mpfr_init_set_arg(mpfr_ptr mp, ArgType op)
    {
        // std::ostringstream os;
        // os.precision(std::numeric_limits<ArgType>::max_digits10);
        // os << op; mpfr_init2(mp, BitPrec);
        // mpfr_set_str(mp, os.str().c_str(), 10, RndMode);

        mpfr_init2(mp, BitPrec);

        if constexpr(same_c<ArgType, float>)
            mpfr_set_flt(mp, op, RndMode);
        else if constexpr(same_c<ArgType, double>)
            mpfr_set_d(mp, op, RndMode);
        else
        {
           
        // #if defined(__GNUC__) && !defined(__clang__)
        //     // 36 digits from long double
        //     char buf[128];
        //     std::snprintf(buf, sizeof(buf), "%.36Lf", op); 
        //     mpfr_set_str(mp, buf, 10, RndMode);
            
        // #else 
                mpfr_set_ld(mp, op, RndMode);
        // #endif

        }
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, const intnum& op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_z(mp, op.mpz_srcptr(), RndMode);
    }
    
    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, mpz_srcptr op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_z(mp, op, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, const char* op)
    {
        std::string str = 
            hidden::remove_chars( op, "' " );

        mpfr_init2(mp, BitPrec);
        mpfr_set_str(mp, str.c_str(), 10, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, const ratnum& op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_q(mp, op.mpq_srcptr(), RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, mpq_srcptr op)
    {
        mpfr_init2(mp, BitPrec);
        mpfr_set_q(mp, op, RndMode);
    }

    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    void mpfr_init_set_arg(mpfr_ptr mp, mpfr_srcptr op)
    {
        mpfr_init2(mp, BitPrec); mpfr_set(mp, op, RndMode);
    }
            
    template<typename T>
    concept realnum_constructor_arg_c = 
        type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
        char, short, int, long, unsigned char, unsigned short,
        unsigned int, unsigned long, long long, unsigned long long,
        float, double, mpz_ptr, mpq_ptr,
        intnum, ratnum, const char*>;

    template<typename T>
    concept realnum_arg_c = 
        type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
        char, short, int, long, unsigned char, unsigned short,
        unsigned int, unsigned long, long long, unsigned long long,
        float, double, intnum, ratnum, const char*>;
    
    // multiprecision real number
    template<mpfr_prec_t BitPrec, mpfr_rnd_t RndMode>
    class realnum
    {
        private:
            mpfr_t mp{};
            
        public:
            constexpr static mpfr_prec_t digits = BitPrec;
                
            constexpr static mpfr_prec_t digits10 = 
                gmp::digits_2_bits<mpfr_prec_t>(BitPrec);

            constexpr static mpfr_rnd_t mpfr_rnd = RndMode;
            using cplxnum_type = cplxnum<BitPrec, MPC_RND(RndMode, RndMode)>;
        
        public:
            realnum(bool init = true)
            { 
                if(init)
                {
                    mpfr_init2(mp, BitPrec); mpfr_set_si(mp, 0, RndMode); 
                }
            }

            realnum(realnum_constructor_arg_c auto&& op)
                { 
                    mpfr_init_set_arg<BitPrec, RndMode>
                            (mp, std::forward<decltype(op)>(op)); 
                }

            // deep copy - copy constructor
            realnum(const mpfr_t& op)
            { 
                mpfr_init2(mp, BitPrec);
                mpfr_set(mp, op, RndMode);        
            }

            // shallow copy - move constructor
            realnum(mpfr_t&& op)
            { 
                // mpfr_init2(mp, BitPrec); should be disabled
                mpfr_swap(mp, op);      
            }
                
            // deep copy - copy constructor
            realnum(const realnum& op)
            {
                mpfr_init2(mp, BitPrec);
                mpfr_set(mp, op.mpfr_srcptr(), RndMode);
            }

            // shallow copy - move constructor
            realnum(realnum&& op)
            {
                //std::cout << "move constructor" << std::endl;  
                // mpfr_init2(mp, BitPrec);
                // mpfr_set(mp, r.mpfr_srcptr(), RndMode);

                // display_info();

                mpfr_swap(mp, op.mp);
            }

            // conversion constructor from another
            // realnum of possibly different precision/rnd mode
            template<mpfr_prec_t PrecOther, mpfr_rnd_t RndOther>
                requires (BitPrec != PrecOther && RndMode == RndOther)
            explicit realnum(const realnum<PrecOther, RndOther>& other)
            {
                mpfr_init2(mp, BitPrec); // initialize with target precision
                mpfr_set(mp, other.mpfr_srcptr(), RndMode); // assign value with target rounding
            }

            // deep copy - copy assignment
            realnum& operator=(const realnum& op)
            {
                if(this != std::addressof(op))
                {
                    mpfr_set(this->mp, op.mpfr_srcptr(), RndMode);
                }

                return *this;
            }

            // shallow copy - move assignment
            realnum& operator=(realnum&& op)
            {
                if(this != std::addressof(op))
                {
                    this->invalidate();
                    mpfr_swap(mp, op.mpfr_ptr());
                }

                return *this;
            }

            explicit operator bool () const
            {   return mpfr_zero_p(mp) == 0; }

            template<primi_integer_c T>
            explicit operator T() const noexcept
            {
                auto opt_z = mpfr_export_value<T>(this->mp, RndMode);

                if(opt_z.has_value())
                {
                    if constexpr(std::is_unsigned_v<T>)
                    {
                        if( mpfr_sgn(mp) < 0 && opt_z.value() > 0 )
                        {
                            std::cout <<"\nRUNTIME ERROR: negative number\n"
                                "\tis assigned to " << Gmp_GetTypeName(T) <<"\n\n";
                        }
                    }

                    return opt_z.value();
                }
                else
                {
                    std::cout <<"\nRUNTIME ERROR: OVERFLOW\n"
                                "\tconversion from " << Gmp_GetTypeName(realnum)
                                <<" to " << Gmp_GetTypeName(T) <<"\n\n";

                    return std::numeric_limits<T>::max();
                }
            }
                        
            explicit operator float () const
            {   return mpfr_get_flt(mp, RndMode); }
            
            explicit operator double () const
            {   return mpfr_get_d(mp, RndMode); }

            template<float_double_c T>
            explicit operator std::complex<T>() const noexcept
            {
                if constexpr(same_c<T, float>)
                {
                    T v = mpfr_get_flt(mp, RndMode);
                    return {v};
                }
                else
                {
                    T v = mpfr_get_d(mp, RndMode);
                    return {v};
                }
            }
 
            explicit operator ratnum() const noexcept
            {
                ratnum rop;
                mpfr_get_q(rop.mpq_ptr(), this->mp);
                return rop;
            }

            explicit operator intnum() const
            {
                // std::cout <<"here" << std::endl;

            #if defined(__GNUC__) && !defined(__clang__)

                // std::cout <<"here" << std::endl;

                // Extract digits in base 10
                mp_exp_t exp;
                char* cstr = mpfr_get_str(nullptr, &exp, 10, 0, this->mp, RndMode);

                if (!cstr)
                    return intnum{0}; // fallback safety

                std::string digits(cstr);
                mpfr_free_str(cstr);

                bool is_negative = (digits[0] == '-');
                if (is_negative) digits.erase(0, 1);

                if (exp <= 0)
                    return intnum{0}; // number < 1

                // Construct integer part
                std::string int_part = digits.substr(0, exp);
                if (is_negative) int_part = "-" + int_part;

                return intnum{1};

            #else
                // fallback for other compilers
                intnum rlt;
                mpfr_get_z2(rlt.mpz_ptr(), this->mp, RndMode);
                return rlt;
            #endif
            }
            
            template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
            operator realnum<Prec, Rnd>() const &
            {
                if constexpr(Prec < BitPrec)
                {
                    realnum<Prec, Rnd> rmp;
                    mpfr_set(rmp.mpfr_ptr(), this->mp, Rnd);

                    return rmp;
                }
                else if constexpr(Prec == BitPrec)
                   return *this;
                else   
                {
                    realnum<Prec, Rnd> rmp;

                    // exact copy; Rnd ignored when target has higher prec
                    mpfr_set(rmp.mpfr_ptr(), this->mp, Rnd); 
                    
                    return rmp;
                }
            }

            template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
            operator realnum<Prec, Rnd>() &&
            {             
                mpfr_prec_round(this->mp, Prec, Rnd);
                
                realnum<Prec, Rnd> rmp{false};
                mpfr_swap(rmp.mpfr_ptr(), this->mp);
                return rmp;
            }
            
            mpfr_ptr    mpfr_ptr() { return mp; }
            mpfr_srcptr mpfr_srcptr() const { return mp; }

            template<auto Percent = 0.8>
            realnum& clean_zero()
            {   
                using real_percent = 
                        realnum<(mpfr_prec_t)(BitPrec * Percent), RndMode>;

                const auto eps = real_percent::constant_epsilon();
                
                if( mpfr_cmpabs(mp, eps.mpfr_srcptr()) < 0 )
                    mpfr_set_zero(mp, mpfr_signbit(mp));

                return *this;
            }

            template<auto Percent = 0.8>
            realnum clean_zero() const
            {
                auto c = *this;
                
                c.template clean_zero<Percent>();
                
                return c;
            }

            // template<auto Percent = 0.8>
            // realnum clean_zero() && 
            // {
            //     using real_percent = 
            //         realnum<(mpfr_prec_t)(BitPrec * Percent), RndMode>;

            //     const auto eps = real_percent::constant_epsilon();

            //     mpfr_abs(this->mp, this->mp, RndMode);

            //     if (mpfr_cmpabs(this->mp, eps.mpfr_srcptr()) < 0)  // ← must be `< 0`
            //         mpfr_set_zero(this->mp, mpfr_signbit(this->mp));

            //     mpfr_t rtn{}; 
            //     mpfr_swap(rtn, this->mp);

            //     return { rtn };  // ← Let RVO apply naturally
            // }

            void flip_sign()
            {
                mpfr_neg(mp, mp, RndMode);
            }

            bool is_zero() const 
                { return mpfr_zero_p(mp) != 0; }

            realnum operator-() const
            {
                realnum rlt; 
                mpfr_neg(rlt.mpfr_ptr(), this->mpfr_srcptr(), RndMode);
                return rlt; 
            }

            realnum& operator++()
            {
                mpfr_add_si(mp, this->mpfr_srcptr(), 1, RndMode);            
                return *this;
            }

            realnum operator++(int) const
            {
                realnum x = *this;
                mpfr_add_si(mp, this->mpfr_srcptr(), 1, RndMode);
                return x;
            }

            realnum& operator--()
            {
                mpfr_sub_si(mp, this->mpfr_srcptr(), 1, RndMode);
                return *this;
            }

            realnum operator--(int) const
            {
                realnum x = *this;
                mpfr_sub_si(mp, this->mpfr_srcptr(), 1, RndMode);
                return x;
            }

            void display_info() const
            {
                std::cout <<"Precision = " << digits10 <<" decimal places\n";
                std::cout <<"Bits      = " << BitPrec <<" binary didits\n";
                gmp::show_mpfr_internal(mp);
            }

            void reset() { mpfr_reset(mp); }
            
            void invalidate() 
            { 
                mpfr_cleanup(mp);
            }

            ~realnum() { invalidate(); }

            ////////////////////// unary addition operators ///////////////
            realnum& operator+=(const mpfr_t op)
            {
                mpfr_add(mp, mp, op, RndMode);
                return *this;
            }

            realnum& operator+=(const realnum& op)
            {
                mpfr_add(mp, mp, op.mp, RndMode);
                return *this;
            }

            realnum& operator+=(unsigned_csil_c auto&& op)
            {   mpfr_add_ui(mp, mp, (unsigned long)op, RndMode);
                return *this; }
            
            realnum& operator+=(signed_csil_c auto&& op)
            {   mpfr_add_si(mp, mp, (signed long)op, RndMode);
                return *this; }

            realnum& operator+=(float_double_c auto&& op)
            {   mpfr_add_d(mp, mp, (double)op, RndMode);
                return *this; }

            realnum& operator+=(const mpz_t op)
            {   mpfr_add_z(mp, mp, op, RndMode);
                return *this; }

            realnum& operator+=(const mpq_t op)
            {   mpfr_add_q(mp, mp, op, RndMode);
                return *this; }

            realnum& operator+=(intnum_c auto&& op)
            {   mpfr_add_z(mp, mp, op.mpz_srcptr(), RndMode);
                return *this; }

            realnum& operator+=(ratnum_c auto&& op)
            {   mpfr_add_q(mp, mp, op.mpq_srcptr(), RndMode);
                return *this; }

            template<typename T>
                requires type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
                    long long, unsigned long long, const char*>
            realnum& operator+=(T&& op)
            {
                *this += realnum{ std::forward<T>(op) };
                 return *this;
            }

            ////////////////////////////////////////
            realnum& operator-=(const mpfr_t op)
            {
                mpfr_sub(mp, mp, op, RndMode);
                return *this;
            }

            realnum& operator-=(const realnum& op)
            {
                mpfr_sub(mp, mp, op.mp, RndMode);
                return *this;
            }

            realnum& operator-=(unsigned_csil_c auto&& op)
            {
                mpfr_sub_ui(mp, mp, (unsigned long)op, RndMode);
                return *this;
            }

            realnum& operator-=(signed_csil_c auto&& op)
            {
                mpfr_sub_si(mp, mp, (signed long)op, RndMode);
                return *this;
            }

            realnum& operator-=(float_double_c auto&& op)
            {
                mpfr_sub_d(mp, mp, (double)op, RndMode);
                return *this;
            }

            realnum& operator-=(const mpz_t op)
            {
                mpfr_sub_z(mp, mp, op, RndMode);
                return *this;
            }

            realnum& operator-=(const mpq_t op)
            {
                mpfr_sub_q(mp, mp, op, RndMode);
                return *this;
            }

            realnum& operator-=(intnum_c auto&& op)
            {
                mpfr_sub_z(mp, mp, op.mpz_srcptr(), RndMode);
                return *this;
            }

            realnum& operator-=(ratnum_c auto&& op)
            {
                mpfr_sub_q(mp, mp, op.mpq_srcptr(), RndMode);
                return *this;
            }

            template<typename T>
                requires type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
                    long long, unsigned long long, const char*>
            realnum& operator-=(T&& op)
            {
                *this -= realnum{ std::forward<T>(op) };
                 return *this;
            }

            //////////////////////////////////////////////////
            realnum& operator*=(const mpfr_t op)
            {
                /*
                    From The Multiple Precision Floating-Point Reliable Library, Edition 4.2.1, August 2023

                    For efficiency reasons, avoid to initialize and clear out a variable in
                    loops. Instead, initialize it before entering the loop, and clear it out after the loop has exited.
                    You do not need to be concerned about allocating additional space for MPFR variables, since
                    any variable has a significand of fixed size. Hence unless you change its precision, or clear and
                    reinitialize it, a floating-point variable will have the same allocated space during all its life.
                    As a general rule, all MPFR functions expect output arguments before input arguments. This
                    notation is based on an analogy with the assignment operator. MPFR allows you to use the same
                    variable for both input and output in the same expression. For example, the main function for
                    floating-point multiplication, mpfr_mul, can be used like this: mpfr_mul (x, x, x, rnd). This
                    computes the square of x with rounding mode rnd and puts the result back in x.
                */

                mpfr_mul(mp, mp, op, RndMode);
                return *this;
            }

            realnum& operator*=(const realnum& op)
            {
                /*
                    From The Multiple Precision Floating-Point Reliable Library, Edition 4.2.1, August 2023
                    
                    For efficiency reasons, avoid to initialize and clear out a variable in
                    loops. Instead, initialize it before entering the loop, and clear it out after the loop has exited.
                    You do not need to be concerned about allocating additional space for MPFR variables, since
                    any variable has a significand of fixed size. Hence unless you change its precision, or clear and
                    reinitialize it, a floating-point variable will have the same allocated space during all its life.
                    As a general rule, all MPFR functions expect output arguments before input arguments. This
                    notation is based on an analogy with the assignment operator. MPFR allows you to use the same
                    variable for both input and output in the same expression. For example, the main function for
                    floating-point multiplication, mpfr_mul, can be used like this: mpfr_mul (x, x, x, rnd). This
                    computes the square of x with rounding mode rnd and puts the result back in x.
                */
                mpfr_mul(mp, mp, op.mp, RndMode);
                return *this;
            }

            realnum& operator*=(unsigned_csil_c auto&& op)
            {
                mpfr_mul_ui(mp, mp, (unsigned long)op, RndMode);
                return *this;
            }

            realnum& operator*=(signed_csil_c auto&& op)
            {
                mpfr_mul_si(mp, mp, (signed long)op, RndMode); 
                return *this;
            }

            realnum& operator*=(float_double_c auto&& op)
            {
                mpfr_mul_d(mp, mp, (double)op, RndMode);
                return *this;
            }

            realnum& operator*=(const mpz_t op)
            {
                mpfr_mul_z(mp, mp, op, RndMode); return *this;
            }

            realnum& operator*=(const mpq_t op)
            {
                mpfr_mul_q(mp, mp, op, RndMode); return *this;
            }

            realnum& operator*=(intnum_c auto&& op)
            {
                mpfr_mul_z(mp, mp, op.mpz_srcptr(), RndMode); return *this;
            }

            realnum& operator*=(ratnum_c auto&& op)
            {
                mpfr_mul_q(mp, mp, op.mpq_srcptr(), RndMode); return *this;
            }

            template<typename T>
                requires type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
                    long long, unsigned long long, const char*>
            realnum& operator*=(T&& op)
            {
                *this *= realnum{ std::forward<T>(op) }; return *this;
            }
            
            //////////////////////////////////////////////////
            realnum& operator/=(const mpfr_t op)
            {
                mpfr_div(mp, mp, op, RndMode);
                return *this;
            }

            realnum& operator/=(const realnum& op)
            {
                mpfr_div(mp, mp, op.mp, RndMode);
                return *this;
            }

            realnum& operator/=(unsigned_csil_c auto&& op)
            {
                mpfr_div_ui(mp, mp, (unsigned long)op, RndMode);
                return *this;
            }

            realnum& operator/=(signed_csil_c auto&& op)
            {
                mpfr_div_si(mp, mp, (signed long)op, RndMode); 
                return *this;
            }

            realnum& operator/=(float_double_c auto&& op)
            {
                mpfr_div_d(mp, mp, (double)op, RndMode); return *this;
            }

            realnum& operator/=(const mpz_t op)
            {
                mpfr_div_z(mp, mp, op, RndMode); return *this;
            }

            realnum& operator/=(const mpq_t op)
            {
                mpfr_div_q(mp, mp, op, RndMode); return *this;
            }

            realnum& operator/=(intnum_c auto&& op)
            {
                mpfr_div_z(mp, mp, op.mpz_srcptr(), RndMode); return *this;
            }

            realnum& operator/=(ratnum_c auto&& op)
            {
                mpfr_div_q(mp, mp, op.mpq_srcptr(), RndMode); return *this;
            }

            template<typename T>
                requires type_in_types_c<std::remove_cvref_t<std::decay_t<T>>,
                    long long, unsigned long long, const char*>
            realnum& operator/=(T&& op)
            {
                *this /= realnum{ std::forward<T>(op) }; return *this;
            }
            
            ////////////////////////////////////////////////////
            std::string string(bool force_showpos = false) const
            {
                std::ostringstream format;
                const std::ios::fmtflags flags = std::cout.flags();
                
                if(mpfr_nan_p(mp)) return "nan";
                if(mpfr_inf_p(mp))
                {
                    if(mpfr_sgn(mp) > 0)
                        return "+inf";
                    else
                        return "-inf";
                }
                
                format << (force_showpos || (flags & std::ios::showpos) ? "%+" : "%");
                
                if (std::cout.precision() >= 0)
                    format << '.' << std::cout.precision() << "R*"
                        << ((flags & std::ios::floatfield) == std::ios::fixed ? 'f' :
                            (flags & std::ios::floatfield) == std::ios::scientific ? 'e' : 'g') ;
                else
                    format << "R*e";

                char *s = NULL;

                if(!(mpfr_asprintf(&s, format.str().c_str(), RndMode, mp) < 0))
                {
                    std::string result(s);
                    mpfr_free_str(s);
                    return result;
                }

                return "eRROR";
            }

            std::string group(int place, bool force_showpos = false) const
            {
                constexpr char delimiter = '\'';
                auto str = this->string(force_showpos);
                return hidden::group(str, delimiter, place);
            }

            std::string group(char delimiter = '\'',
                int place = 3, bool force_showpos = false) const
            {
                auto str = this->string(force_showpos);
                return hidden::group(str, delimiter, place);
            }

            std::string flat(int place = 3, bool force_showpos = false) const
            {
                constexpr char delimiter = '\'';
                auto str = this->string(force_showpos);
                return hidden::group(str, delimiter, place);
            }

            static const realnum constant_epsilon()
            {
                realnum cv{2}; mpfr_pow_si(cv.mpfr_ptr(),
                    cv.mpfr_srcptr(), (long)-(digits-1), RndMode);
                return cv;
            }

            static const realnum constant_as_zero(double percent = 0.75)
            {
                realnum cv{2}; mpfr_pow_si(cv.mpfr_ptr(),
                    cv.mpfr_srcptr(), (long)-((digits-1)*percent), RndMode);
                return cv;
            }

            static const realnum constant_pi()
            {   
                realnum cv; mpfr_const_pi(cv.mpfr_ptr(), RndMode); return cv; 
            }

            static const realnum constant_log2()
            {   
                realnum cv; mpfr_const_log2(cv.mpfr_ptr(), RndMode); return cv; 
            }

            static const realnum constant_log10()
            {   
                realnum cv; mpfr_const_log10(cv.mpfr_ptr(), RndMode); return cv; 
            }

            static const realnum constant_euler()
            {   
                realnum cv; mpfr_const_euler(cv.mpfr_ptr(), RndMode); return cv; 
            }
            
            static const realnum constant_catalan()
            {   
                realnum cv; mpfr_const_catalan(cv.mpfr_ptr(), RndMode); return cv; 
            }

            // sgn = 1 for positive infinity
            //     =-1 for negative infinity
            static realnum constant_infinity(int sgn = 1)
            {   
                realnum cv; mpfr_set_inf(cv.mpfr_ptr(), RndMode); return cv; 
            }

            ////////////////////////////////////
            
            auto abs() const
            {
                realnum r;
                mpfr_abs(r.mp, this->mp, RndMode);
                
                return r;
            }
    };
    // end of class realnum

    using real_float_t = realnum<(mpfr_prec_t)std::numeric_limits<float>::digits, MPFR_RNDN>;
    using real_double_t = realnum<(mpfr_prec_t)std::numeric_limits<double>::digits, MPFR_RNDN>;
    using real_quadruple_t = realnum<(mpfr_prec_t)113, MPFR_RNDN>;
    using real_octuple_t = realnum<(mpfr_prec_t)226, MPFR_RNDN>;
    using real_huge_t = realnum<(mpfr_prec_t)512, MPFR_RNDN>;
    using real_super_huge_t = realnum<(mpfr_prec_t)1024, MPFR_RNDN>;

    // log_10(2^(1024*6)) = 
    using real_extreme_t    = realnum<(mpfr_prec_t)1024*6, MPFR_RNDN>; 
       
    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    std::ostream&
    operator<< (std::ostream& os, const realnum<Prec, Rnd>& rm)
    {
        auto c = rm.clean_zero();
        os << c.string(); return os;
    }

    intnum::intnum(const ratnum& op)
    {
        mpz_init(mp); 

        realnum<256, MPFR_RNDN> p{op.num()};
        realnum<256, MPFR_RNDN> q{op.den()};

        p /= q; mpfr_get_z2(mp, p.mpfr_srcptr(), MPFR_RNDN);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
    intnum::intnum(const realnum<Prec, RndMode>& rlm)
    {
    #if defined(__GNUC__) && !defined(__clang__)
        mpz_init(mp);

        mp_exp_t exp;
        char* cstr = mpfr_get_str(nullptr, &exp, 10, 0, rlm.mpfr_srcptr(), RndMode);
        if (!cstr) {
            mpz_set_ui(mp, 0);
            return;
        }

        std::string digits(cstr);
        mpfr_free_str(cstr);

        bool is_negative = (digits[0] == '-');
        if (is_negative) digits.erase(0, 1);

        if (exp <= 0) {
            mpz_set_ui(mp, 0);
            return;
        }

        std::string int_part = digits.substr(0, exp);
        if (is_negative) int_part = "-" + int_part;

        mpz_set_str(mp, int_part.c_str(), 10);

    #else
        mpz_init(mp); 
        mpfr_get_z2(mp, rlm.mpfr_srcptr(), RndMode);
    #endif
    }
    
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
    ratnum::operator realnum<Prec, RndMode>() const
    {   
        realnum<Prec, RndMode> p{ this->num() };
        realnum<Prec, RndMode> q{ this->den() };
        return p/q;
    }
   
    namespace hidden
    {
        /////////////// realnum binary operation ///////////////////////////
        template<BinOpr opr, realnum_c LeftType, realnum_c RightType>
            requires same_c<LeftType, RightType>
        decltype(auto) gmp_binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
        {
            using L = decltype(lhs);
            using R = decltype(rhs);

            constexpr auto Prec = realnum_prec_v<LeftType>;
            constexpr auto RndMode = realnum_rnd_v<LeftType>;
                        
            if constexpr (opr == BinOpr::add)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpfr_add(lhs.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpfr_add(rhs.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    realnum<Prec, RndMode> x;
                    mpfr_add(x.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);                   
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::mul)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpfr_mul(lhs.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpfr_mul(rhs.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    realnum<Prec, RndMode> x;
                    mpfr_mul(x.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);      
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::sub)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpfr_sub(lhs.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return std::move(lhs);
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpfr_sub(rhs.mpfr_ptr(), rhs.mpfr_srcptr(), lhs.mpfr_srcptr(), RndMode);
                    mpfr_neg(rhs.mpfr_ptr(), rhs.mpfr_ptr(), RndMode);  // flip sign
                    return std::move(rhs);
                }
                else // both are lvalue reference
                {
                    realnum<Prec, RndMode> x;
                    mpfr_sub(x.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::div)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpfr_div(lhs.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);
                    return std::move(lhs);
                }
                else // both are lvalue reference
                {
                    realnum<Prec, RndMode> x;
                    mpfr_div(x.mpfr_ptr(), lhs.mpfr_srcptr(), rhs.mpfr_srcptr(), RndMode);       
                    return x;
                }
            }
        }
    
        /////////////// realnum binary operation ///////////////////////////
        template<BinOpr opr, realnum_c LeftType, realnum_c RightType>
            requires not_same_c<LeftType, RightType>
        decltype(auto) gmp_binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
        {
            constexpr auto LPrec = realnum_prec_v<LeftType>;
            constexpr auto LRndMode = realnum_rnd_v<LeftType>;

            constexpr auto RPrec = realnum_prec_v<RightType>;
            constexpr auto RRndMode = realnum_rnd_v<RightType>;

            if constexpr (LPrec > RPrec)
            {
                return [&]
                {
                    realnum<LPrec, LRndMode> rs{rhs};  // convert rhs to L's precision/rnd
                    return gmp_binary_operation<opr>(std::forward<LeftType>(lhs), std::move(rs));
                }();
            }
            else
            {
                return [&]
                {
                    realnum<RPrec, RRndMode> ls{lhs};  // convert lhs to R's precision/rnd
                    return gmp_binary_operation<opr>(std::move(ls), std::forward<RightType>(rhs));
                }();
            }
        }
    }
    // end of namespace hidden

    /////////////// binary operators for realnum /////////////////////////

    template<realnum_c LeftType, realnum_c RightType>
    decltype(auto) operator + (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::add>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<realnum_c LeftType, realnum_c RightType>
    decltype(auto) operator - (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::sub>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<realnum_c LeftType, realnum_c RightType>
    decltype(auto) operator * (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::mul>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<realnum_c LeftType, realnum_c RightType>
    decltype(auto) operator / (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::div>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }
    
    ///////////////////////////////////////////////////////////////////
    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd>&& operator+(realnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {
        lhs += rhs; return std::move(lhs);
    }

    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd>&& operator+(ArgType&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        rhs += lhs; return std::move(rhs);
    }

    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd> operator+(const realnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {
        realnum x = lhs; x += rhs; return x;
    }

    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd> operator+(ArgType&& lhs, const realnum<Prec, Rnd>& rhs)
    {
        realnum x = rhs; x += lhs; return x;
    }
    
    //////////////////////////////////////////////////////////////
    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd>&& operator-(realnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {
        lhs -= rhs; return std::move(lhs);
    }
    
    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd> operator-(const realnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {
        realnum x = lhs; x -= rhs; return x;
    }

    //////////////////////////////////////////////////////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>&&
    operator-(unsigned_csil_c auto&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        mpfr_ui_sub(rhs.mpfr_ptr(), (unsigned long)lhs, rhs.mpfr_srcptr(), Rnd);
        return std::move(rhs);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>&&
    operator-(signed_csil_c auto&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        mpfr_si_sub(rhs.mpfr_ptr(), (signed long)lhs, rhs.mpfr_srcptr(), Rnd);
        return std::move(rhs);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>&&
    operator-(float_double_c auto&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        mpfr_d_sub(rhs.mpfr_ptr(), (double)lhs, rhs.mpfr_srcptr(), Rnd);
        return std::move(rhs);
    }
       
    template<typename ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
        requires type_in_types_c<std::remove_cvref_t<std::decay_t<ArgType>>,
            long long, unsigned long long, 
            intnum, ratnum, const char*> realnum<Prec, Rnd>&&
    operator-(ArgType&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        rhs -= lhs; rhs.flip_sign(); return std::move(rhs);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>
    operator-(realnum_arg_c auto&& lhs, const realnum<Prec, Rnd>& rhs)
    {           
        realnum<Prec, Rnd> x{ rhs }; x -= lhs; return x;
    }

    ////////////////////// binary multiplication operators /////////////////////
    
    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd>&& operator*(realnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {
        lhs *= rhs; return std::move(lhs);
    }

    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd>&& operator*(ArgType&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        rhs *= lhs; return std::move(rhs);
    }

    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd> operator*(const realnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {
        realnum<Prec, Rnd> x{ lhs }; x *= rhs; return x;
    }

    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd> operator*(ArgType&& lhs, const realnum<Prec, Rnd>& rhs)
    {
        realnum<Prec, Rnd> x{ rhs }; x *= lhs; return x;
    }

    ////////////////////// binary division operators //////////////////////
    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd>&& operator/(realnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {
        lhs /= rhs; return std::move(lhs);
    }
    
    template<realnum_arg_c ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    realnum<Prec, Rnd> operator/(const realnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {
        realnum<Prec, Rnd> x{ lhs }; x /= rhs; return x;
    }

    //////////////////////////////////////////////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>&&
    operator/(unsigned_csil_c auto&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        mpfr_ui_div(rhs.mpfr_ptr(), (unsigned long)lhs, rhs.mpfr_srcptr(), Rnd);
        return std::move(rhs);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>&&
    operator/(signed_csil_c auto&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        mpfr_si_div(rhs.mpfr_ptr(), (signed long)lhs, rhs.mpfr_srcptr(), Rnd);
        return std::move(rhs);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>&&
    operator/(float_double_c auto&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        mpfr_d_div(rhs.mpfr_ptr(), (double)lhs, rhs.mpfr_srcptr(), Rnd);
        return std::move(rhs);
    }
        
    template<typename ArgType, mpfr_prec_t Prec, mpfr_rnd_t Rnd>
        requires type_in_types_c<std::remove_cvref_t<std::decay_t<ArgType>>,
            long long, unsigned long long, const char*>
    realnum<Prec, Rnd> operator/(ArgType&& lhs, realnum<Prec, Rnd>&& rhs)
    {
        realnum<Prec, Rnd> x{ lhs }; x /= rhs; return x;
    }
    
    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> realnum<Prec, Rnd>
    operator/(realnum_arg_c auto&& lhs, const realnum<Prec, Rnd>& rhs)
    {           
        realnum<Prec, Rnd> x{ lhs }; x /= rhs; return x;
    }
       
    ///////////// standard functions for realnum /////////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t Mpfr_Rnd>
    void set_nan(realnum<Prec, Mpfr_Rnd>& mp)
    {   mpfr_set_nan(mp.mpfr_ptr()) ; }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd>
    void set_nan(cplxnum<Prec, Rnd>& mp) noexcept
    {   
        mpfr_set_nan(mpc_realref(mp.mpc_ptr())); 
        mpfr_set_nan(mpc_imagref(mp.mpc_ptr())); 
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Mpfr_Rnd>
    bool isnan(const realnum<Prec, Mpfr_Rnd>& mp) noexcept
    {   return mpfr_nan_p(mp.mpfr_srcptr()) != 0; }
    
    template<mpfr_prec_t Prec, mpfr_rnd_t Mpfr_Rnd>
    bool isinf(const realnum<Prec, Mpfr_Rnd>& mp)
    {   return mpfr_inf_p(mp.mpfr_srcptr()) != 0; }

    template<mpfr_prec_t Prec, mpfr_rnd_t Mpfr_Rnd>
    bool isfinite(const realnum<Prec, Mpfr_Rnd>& mp)
    {   return mpfr_number_p(mp.mpfr_srcptr()); }

    template<mpfr_prec_t Prec, mpfr_rnd_t Mpfr_Rnd>
    bool iszero(const realnum<Prec, Mpfr_Rnd>& mp)
    {   return mpfr_sgn_p(mp.mpfr_srcptr()) == 0; }

    // template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    // auto ceil(const realnum<Prec, Rnd>& rlm)
    // {
    //     realnum<Prec, Rnd> x{};
    //     mpfr_ceil(x.mpfr_ptr(), rlm.mpfr_srcptr());
    //     return x;
    // }

    // template<std::floating_point ArgType>
    // auto ceil(const ArgType& arg)
    // {
    //     return std::ceil(arg);
    // }

    // template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    // auto floor(const realnum<Prec, Rnd>& rlm)
    // {
    //     realnum<Prec, Rnd> x{};
    //     mpfr_floor(x.mpfr_ptr(), rlm.mpfr_srcptr());
    //     return x;
    // }

    // template<std::floating_point ArgType>
    // auto floor(const ArgType& arg)
    // {
    //     return std::floor(arg);
    // }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto abs(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_abs(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto abs(const ArgType& arg)
    {
        return std::abs(arg);
    }
   
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto sqrt(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_sqrt(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto sqrt(const ArgType& arg)
    {
        return std::sqrt(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto exp(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_exp(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto exp(const ArgType& arg)
    {
        return std::exp(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto tgamma(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_gamma(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto tgamma(const ArgType& arg)
    {
        return std::tgamma(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto lgamma(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_lngamma(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);

        return x;
    }

    template<primi_number_c ArgType> 
    auto lgamma(const ArgType& arg)
    {
        return std::lgamma(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto log(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_log(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto log(const ArgType& arg)
    {
        return std::log(arg); 
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto sin(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_sin(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto sin(ArgType arg)
    {
        return std::sin(arg);
    }

    ///////////////////////////////////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto hypot(const realnum<Prec, RndMode>& x,
               const realnum<Prec, RndMode>& y,
               const same_c<realnum<Prec, RndMode>> auto&... zs) noexcept
    {
        if constexpr(sizeof...(zs) == 0)
        {
            realnum<Prec, RndMode> rlt;
            mpfr_hypot(rlt.mpfr_ptr(), x.mpfr_srcptr(), y.mpfr_srcptr(), RndMode);
            return rlt;
        }
        else
        {
            realnum<Prec, RndMode> rlt;
        
            const mpfr_ptr a[] = { (const mpfr_ptr)x.mpfr_srcptr(),
                                   (const mpfr_ptr)y.mpfr_srcptr(),
                                   (const mpfr_ptr)zs.mpfr_srcptr()... };

            mpfr_dot(rlt.mpfr_ptr(), a, a, 2 + sizeof...(zs), RndMode);
            mpfr_sqrt(rlt.mpfr_ptr(), rlt.mpfr_srcptr(), RndMode);

            return rlt;
        }
    }
          
    template<primi_number_c ArgType, primi_number_c... ArgTypes> 
    auto hypot(ArgType x, ArgType y, ArgTypes... zs) noexcept
    {
        if constexpr(std_complex_c<ArgType>)
        {
            return std::sqrt( ( (std::norm(x) + std::norm(y)) + ... + std::norm(zs)) );
        }
        else if constexpr(sizeof...(ArgTypes) < 2)
            return std::hypot(x, y, zs...);
        else
        {
            return std::sqrt( ( (x*x + y*y) + ... + (zs * zs) ) );
        }
    }
    
    /////////////////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto asin(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_asin(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto asin(ArgType arg)
    {
        return std::asin(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto sinh(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_sinh(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto sinh(ArgType arg)
    {
        return std::sinh(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto cosh(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_cosh(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto cosh(ArgType arg)
    {
        return std::cosh(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto tanh(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_tanh(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto tanh(ArgType arg)
    {
        return std::tanh(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto tan(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_tan(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto tan(ArgType arg)
    {
        return std::tan(arg);
    }

    /////////////////////////////////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto atan(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_atan(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto atan(ArgType arg)
    {
        return std::atan(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto atan2(const realnum<Prec, RndMode>& y, const realnum<Prec, RndMode>& x)
    {
        realnum<Prec, RndMode> v;
        mpfr_atan2(v.mpfr_ptr(), y.mpfr_srcptr(), x.mpfr_srcptr(), RndMode);
        return v;
    }

    template<primi_number_c ArgType> 
    auto atan2(ArgType y, ArgType x)
    {
        // should be fixed later for complex atan2
        if constexpr(std_complex_c<ArgType>)
            return std::atan2(y.real(), x.real());
        else
            return std::atan2(y, x);
    }

    ////////////////////////
  
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto cos(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_cos(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto cos(ArgType arg)
    {
        return std::cos(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode> 
    auto acos(const realnum<Prec, RndMode>& arg)
    {
        realnum<Prec, RndMode> x;
        mpfr_acos(x.mpfr_ptr(), arg.mpfr_srcptr(), RndMode);
        return x;
    }

    template<primi_number_c ArgType> 
    auto acos(ArgType arg)
    {
        return std::acos(arg);
    }
    
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode, typename ExpType>
        requires type_in_types_c<std::remove_cvref_t<ExpType>, 
            realnum<Prec, RndMode>, char, short, int, long, long long,
            unsigned char, unsigned short, unsigned int, unsigned long,
            unsigned long long, float, double, intnum, const char*>
    auto pow(const realnum<Prec, RndMode>& op1, ExpType&& op2)
    {
        realnum<Prec, RndMode> x;
        
        if constexpr(realnum_c<std::remove_cvref_t<ExpType>>)
            mpfr_pow(x.mpfr_ptr(), op1.mpfr_srcptr(), op2.mpfr_srcptr(), RndMode);
        else if constexpr(signed_csil_c<ExpType>)
            mpfr_pow_si(x.mpfr_ptr(), op1.mpfr_srcptr(), (signed long)op2, RndMode);
        else if constexpr(unsigned_csil_c<ExpType>)
            mpfr_pow_ui(x.mpfr_ptr(), op1.mpfr_srcptr(), (signed long)op2, RndMode);
        else if constexpr(std::same_as<std::remove_cvref_t<ExpType>, unsigned long long>)
            mpfr_pow_uj(x.mpfr_ptr(), op1.mpfr_srcptr(), (unsigned long long)op2, RndMode);
        else if constexpr(std::same_as<std::remove_cvref_t<ExpType>, signed long long>)
            mpfr_pow_sj(x.mpfr_ptr(), op1.mpfr_srcptr(), (signed long long)op2, RndMode);
        else if constexpr(intnum_c<ExpType>)
            mpfr_pow_z(x.mpfr_ptr(), op1.mpfr_srcptr(), op2.mpz_srcptr(), RndMode);
        else
        {
            realnum<Prec, RndMode> p{op2};
            
            mpfr_pow(x.mpfr_ptr(), op1.mpfr_srcptr(), p.mpfr_srcptr(), RndMode);
        }

        return x;
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode, typename BaseType>
        requires type_in_types_c<std::remove_cvref_t<BaseType>, 
            char, short, int, long, long long,
            unsigned char, unsigned short, unsigned int, unsigned long,
            unsigned long long, float, double, intnum, const char*>
    auto pow(BaseType&& base, const realnum<Prec, RndMode>& op2)
    {
        realnum<Prec, RndMode> x;

        if constexpr(unsigned_csil_c<BaseType>)
            mpfr_ui_pow(x.mpfr_ptr(), (unsigned long)base, op2, RndMode);
        else
        {
            realnum b{base};
            mpfr_pow(x.mpfr_ptr(), b.mpfr_srcptr(), op2.mpfr_srcptr(), RndMode);
        }

        return x;
    }

    template<primi_number_c BaseType, primi_number_c ExpType>
    auto pow(BaseType b, ExpType e)
    {
        return std::pow(b, e);
    }
    
    /////////////// comparison operators for realnum //////////////
    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> bool
    operator ==(const realnum<Prec, Rnd>& lhs, const realnum<Prec, Rnd>& rhs)
    {   return mpfr_cmp(lhs.mpfr_srcptr(), rhs.mpfr_srcptr()) == 0; }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> bool
    operator !=(const realnum<Prec, Rnd>& lhs, const realnum<Prec, Rnd>& rhs)
    {   return lhs != rhs; }
    
    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> std::strong_ordering 
    operator<=>(const realnum<Prec, Rnd>& lhs, const realnum<Prec, Rnd>& rhs)
    {
        int comparison = mpfr_cmp(lhs.mpfr_srcptr(), rhs.mpfr_srcptr());

        if(comparison == 0) 
            return std::strong_ordering::equal;
        else if(comparison < 0) 
            return std::strong_ordering::less;
        else
            return std::strong_ordering::greater;
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd> std::strong_ordering 
    operator<=>(const realnum<Prec, Rnd>& lhs, const intnum& ival)
    {
        realnum<Prec, Rnd> rhs{ival};

        int comparison = mpfr_cmp(lhs.mpfr_srcptr(), rhs.mpfr_srcptr());

        if(comparison == 0) 
            return std::strong_ordering::equal;
        else if(comparison < 0) 
            return std::strong_ordering::less;
        else
            return std::strong_ordering::greater;
    }
        
    namespace hidden
    {
        std::string cplx_format(const char* str_z)
        {
            std::string cz = remove_chars(str_z, "'f");

            // replace comma ',' with space ' '
            std::replace_if(cz.begin(), cz.end(),
                [](auto c) { return c == ','; }, ' ');
            
            cz = trim(cz);

            if(cz.front() != '(') cz.insert(cz.begin(), '(');
            if(cz.back() != ')') cz.push_back(')');

            return cz;
        }
    }
    // namespace hidden

    template<typename T>
    concept cplx_constor_arg_c = type_in_types_c<
        std::remove_cvref_t<std::decay_t<T>>,
        char, short, int, long, unsigned char, unsigned short,
        unsigned int, unsigned long, long long, unsigned long long,
        float, double, mpz_srcptr, mpq_srcptr,
        mpfr_ptr, mpfr_srcptr, intnum, ratnum, const char*> ||
        realnum_c<T> || std_complex_c<T>;
    
    template<mpfr_prec_t BitPrec, mpc_rnd_t RndMode,
        cplx_constor_arg_c reType>
    void cplx_init_set_args(mpc_ptr mp, reType&& re)
    {
        if constexpr (std::same_as<std::remove_cvref_t<std::decay_t<reType>>,
                        const char*>)
        {
            int len = strlen(re);
            int comma = 0;

            std::stringstream rstr;
            
            while(comma < len)
            {
                if(re[comma] == ',') break;

                if(re[comma] != '\'' && re[comma] != ' ')
                    rstr << re[comma];

                ++comma;
            }

            std::string rs = rstr.str();
            
            if(rs.empty()) rs = "0";
            
            if(comma == len)
            {
                mpc_init2(mp, BitPrec);
                mpc_set_str(mp, rs.c_str(), 10, RndMode);
                return;
            }

            std::stringstream istr;

            ++comma;
            while(comma < len)
            {
                if(re[comma] != '\'' && re[comma] != ' ')
                    istr << re[comma];

                ++comma;
            }

            std::string is = istr.str();

            if(is.empty()) is = "0";

            mpc_init2(mp, BitPrec);

            mpfr_t rpart, ipart;
            mpfr_init2(rpart, BitPrec);
            mpfr_init2(ipart, BitPrec);

            mpfr_set_str(rpart, rs.c_str(), 10, MPC_RND_RE(RndMode));
            mpfr_set_str(ipart, is.c_str(), 10, MPC_RND_IM(RndMode));

            mpfr_swap(mpc_realref(mp), rpart);
            mpfr_swap(mpc_imagref(mp), ipart);

            mpfr_clear(rpart);
            mpfr_clear(ipart);
        }
        else if constexpr(std_complex_c<reType>)
        {
            mpc_init2(mp, BitPrec);
            
            using value_type = std_complex_value_type<reType>;
            
            if constexpr(std::same_as<value_type, float>)
                mpc_set_flt_flt(mp, std::real(re), std::imag(re), RndMode);
            else if constexpr(std::same_as<value_type, double>)   
                mpc_set_d_d(mp, std::real(re), std::imag(re), RndMode);
        }
        else
        {
            // set real part
            if constexpr(realnum_c<reType>)
            {
                if constexpr(std::is_rvalue_reference_v<decltype(re)>)
                {
                    mpfr_swap(mpc_realref(mp), re.mpfr_ptr());
                    re.reset();
                }
                else
                {
                    mpfr_init2(mpc_realref(mp), BitPrec);
                    mpfr_set_fr(mpc_realref(mp), re.mpfr_srcptr(), MPC_RND_RE(RndMode));
                }
            }
            else
            {
                realnum<BitPrec, MPC_RND_RE(RndMode)> 
                    x{ std::forward<reType>(re) };
                
                mpfr_swap(mpc_realref(mp), x.mpfr_ptr());
                x.reset();
            }

            // set imag part
            mpfr_init2(mpc_imagref(mp), BitPrec);
            mpfr_set_si(mpc_imagref(mp), 0, MPC_RND_IM(RndMode));
        }
    }

    template<mpfr_prec_t BitPrec, mpc_rnd_t RndMode,
        cplx_constor_arg_c reType, cplx_constor_arg_c imType>
    void cplx_init_set_args(mpc_ptr mp, reType&& re, imType&& im)
    {
        // set real part
        if constexpr(realnum_c<reType>)
        {
            if constexpr(std::is_rvalue_reference_v<decltype(re)>)
            {
                mpfr_swap(mpc_realref(mp), re.mpfr_ptr());
                re.reset();
            }
            else
            {
                mpfr_init2(mpc_realref(mp), BitPrec);
                mpfr_set_fr(mpc_realref(mp), re.mpfr_srcptr(), MPC_RND_RE(RndMode));
            }
        }
        else
        {
            realnum<BitPrec, MPC_RND_RE(RndMode)> 
                x{ std::forward<reType>(re) };
            
            mpfr_swap(mpc_realref(mp), x.mpfr_ptr()); x.reset();
        }

        // set imag part
        if constexpr(realnum_c<imType>)
        {
            if constexpr(std::is_rvalue_reference_v<decltype(im)>)
            {
                mpfr_swap(mpc_imagref(mp), im.mpfr_ptr()); 
                im.reset();
            }
            else
            {
                mpfr_init2(mpc_imagref(mp), BitPrec);
                mpfr_set_fr(mpc_imagref(mp), im.mpfr_srcptr(), MPC_RND_IM(RndMode));
            }
        }
        else
        {
            realnum<BitPrec, MPC_RND_IM(RndMode)> 
                y{ std::forward<imType>(im) };
            
            mpfr_swap(mpc_imagref(mp), y.mpfr_ptr()); y.reset();
        }
    }
    
    // multiprecision complex number
    template<mpfr_prec_t BitPrec, mpc_rnd_t RndMode>
    class cplxnum
    {
        private:
            mpc_t mp{};

        public:
            
            using value_type = realnum<BitPrec, MPC_RND_RE(RndMode)>;

            constexpr static mpfr_prec_t digits = BitPrec;                        
            constexpr static mpc_rnd_t mpc_rnd = RndMode;

            constexpr static mpfr_prec_t digits10 = 
                    gmp::bits_2_digits<mpfr_prec_t>(digits);

            cplxnum(bool init = true) 
                {  
                    if(init)
                    {
                        mpc_init2(mp, BitPrec); 
                        mpc_set_si_si(mp, 0, 0, mpc_rnd); 
                    }
                }
            
            template<cplx_constor_arg_c reType>
            cplxnum(reType&& re) 
                { 
                    cplx_init_set_args<BitPrec, RndMode>
                        (mp, std::forward<reType>(re) );
                }
            
            template<cplx_constor_arg_c reType, cplx_constor_arg_c imType>
            cplxnum(reType&& re, imType&& im) 
                { 
                    cplx_init_set_args<BitPrec, RndMode>
                        (mp, std::forward<reType>(re), std::forward<imType>(im) );
                }

            template<mpfr_prec_t Prec, mpfr_rnd_t RoundMode>
            cplxnum(const realnum<Prec, RoundMode>& re) 
                {
                    mpc_init2(mp, BitPrec);
                    mpc_set_fr(mp, re.mpfr_srcptr(), mpc_rnd); 
                }

            cplxnum(const mpc_t& cz)
            {
                // std::cout <<"copied" << std::endl;
                mpc_init2(mp, BitPrec);
                mpc_set(mp, cz, mpc_rnd);
            }

            cplxnum(mpc_t&& cz)
            {
                // std::cout <<"mpc moved" << std::endl;
                mpc_swap(mp, cz);
            }

            cplxnum(const cplxnum& cz)
            {          
                // std::cout <<"copy constructed" << std::endl;
                mpc_init2(mp, BitPrec);
                mpc_set(mp, cz.mpc_srcptr(), mpc_rnd);
            }

            cplxnum(cplxnum&& cz)
            {
                // std::cout <<"move constructed" << std::endl;
                mpc_swap(mp, cz.mpc_ptr());
            }

            template<mpfr_prec_t PrecOther, mpc_rnd_t RndOther>
                requires (BitPrec != PrecOther && RndMode == RndOther)
            explicit cplxnum(const cplxnum<PrecOther, RndOther>& other)
            {
                mpc_init2(mp, BitPrec); // target precision
                mpc_set(mp, other.mpc_srcptr(), RndMode); // target rounding
            }

            // 1/z - inverse
            cplxnum inverse() const
            {
                cplxnum y = *this;
                realnum<BitPrec, MPC_RND_RE(RndMode)> x;
                
                mpc_norm(x.mpfr_ptr(), y.mpc_srcptr(), MPC_RND_RE(RndMode));

                mpc_conj(y.mpc_ptr(), y.mpc_srcptr(), RndMode);
                mpc_div_fr(y.mpc_ptr(), y.mpc_ptr(), x.mpfr_srcptr(), RndMode);

                return y;
            }

            // 1/z - inverse in place
            cplxnum& inv()
            {
                realnum<BitPrec, MPC_RND_RE(RndMode)> x;
                mpc_norm(x.mpfr_ptr(), mpc_srcptr(), MPC_RND_RE(RndMode));

                mpc_conj(mpc_ptr(), mpc_srcptr(), RndMode);
                mpc_div_fr(mpc_ptr(), mpc_ptr(), x.mpfr_srcptr(), RndMode);

                return *this;
            }

            auto norm() const noexcept
            {
                realnum<BitPrec, MPC_RND_RE(RndMode)> x;               
                mpc_norm(x.mpfr_ptr(), this->mpc_srcptr(), MPC_RND_RE(RndMode));
                return x;
            }

            auto conj() const noexcept
            {
                cplxnum x;
                
                mpc_conj(x.mpc_ptr(), this->mpc_srcptr(), RndMode);

                return x;
            }

            auto abs() const noexcept 
            {
                // |z| (real, ≥0)
                realnum<BitPrec, MPC_RND_RE(RndMode)> r;
                mpc_abs(r.mpfr_ptr(), this->mpc_srcptr(), MPC_RND_RE(RndMode));
                return r;
            }

            auto arg() const noexcept 
            {
                // ∠z (real)
                realnum<BitPrec, MPC_RND_RE(RndMode)> r;
                mpc_arg(r.mpfr_ptr(), this->mpc_srcptr(), MPC_RND_RE(RndMode));
                return r;
            }

            template<auto Percent = 0.8>
            cplxnum& clean_zero()
            {
                using real_percent = 
                    realnum<(mpfr_prec_t)(BitPrec * Percent), MPC_RND_RE(RndMode)>;

                const auto eps = real_percent::constant_epsilon();

                if (mpfr_cmpabs (mpc_realref(mp), eps.mpfr_srcptr()) < 0)          // guard
                    mpfr_set_zero (mpc_realref(mp),                  // mpfr_, not mfpr_
                                mpfr_signbit (mpc_realref(mp)));

                if (mpfr_cmpabs (mpc_imagref(mp), eps.mpfr_srcptr()) < 0)
                    mpfr_set_zero (mpc_imagref(mp),
                                mpfr_signbit (mpc_imagref(mp)));

                return *this;
            }
            
            template<auto Percent = 0.8>
            cplxnum clean_zero() const
            {
                auto c = *this;
                c.template clean_zero<Percent>();

                return c;
            }

            // template<auto Percent = 0.8>
            // cplxnum clean_zero() &&
            // {
            //     using real_percent = 
            //         realnum<(mpfr_prec_t)(BitPrec * Percent), MPC_RND_RE(RndMode)>;

            //     const auto eps = real_percent::constant_epsilon();

            //     if (mpfr_cmpabs (mpc_realref(mp), eps.mpfr_srcptr()) < 0)  // guard
            //         mpfr_set_zero (mpc_realref(mp),                        // mpfr_, not mfpr_
            //                     mpfr_signbit (mpc_realref(mp)));

            //     if (mpfr_cmpabs (mpc_imagref(mp), eps.mpfr_srcptr()) < 0)
            //         mpfr_set_zero (mpc_imagref(mp),
            //                     mpfr_signbit (mpc_imagref(mp)));
                
            //     return std::move(*this);
            // }

            std::string string() const
            {
                return "(" + real().string() +","
                        + imag().string() + ")";
            }

            std::string flat(int place = 3) const
            {
                constexpr char delimiter = '\'';

                return real().group(delimiter, place) +"_re"
                        + imag().group(delimiter, place, true) + "_im";
            }

            std::string group_flat(int place) const
            {
                constexpr char delimiter = '\'';
                return real().group(delimiter, place) +"_re"
                        + imag().group(delimiter, place, true) + "_im";
            }

            std::string group_flat(char delimiter = '\'', int place = 3) const
            {
                return real().group(delimiter, place) +"_re"
                        + imag().group(delimiter, place, true) + "_im";
            }

            std::string group(int place)
            {
                constexpr char delimiter = '\'';
                return "(" + real().group(delimiter, place) +","
                        + imag().group(delimiter, place) + ")";
            }

            std::string group(char delimiter = '\'', int place = 3)
            {
                return "(" + real().group(delimiter, place) +","
                        + imag().group(delimiter, place) + ")";
            }

            cplxnum operator-() const
            {
                mpc_t z; mpc_init2(z, BitPrec);
                mpc_neg(z, mp, mpc_rnd); return { std::move(z) };
            }

            cplxnum& operator=(const cplxnum& cz)
            {
                if(this != std::addressof(cz))
                {
                    // mpc_clear(mp); - this line is error
                    mpc_set(mp, cz.mpc_srcptr(), mpc_rnd);
                }

                return *this;
            }

            cplxnum& operator=(cplxnum&& cz)
            {
                if(this != std::addressof(cz))
                {
                    this->invalidate();
                    mpc_swap(mp, cz.mpc_ptr());
                }

                return *this;
            }

            mpc_ptr mpc_ptr() { return this->mp; }
            mpc_srcptr mpc_srcptr() const { return this->mp; }

            realnum<BitPrec, MPC_RND_RE(RndMode)> real() const 
            { 
                return { mpc_realref(mp) }; 
            }

            realnum<BitPrec, MPC_RND_IM(RndMode)> imag() const 
            { 
                return { mpc_imagref(mp) }; 
            }

            template<cplx_constor_arg_c ArgType>
            void set_real(ArgType&& arg) noexcept
            { 
                if constexpr(realnum_c<ArgType>)
                {
                    if constexpr(std::is_rvalue_reference_v<decltype(arg)>)
                    {
                        mpfr_swap(mpc_realref(mp), arg.mpfr_ptr());
                    }
                    else
                    {
                        mpfr_set_fr(mpc_realref(mp),
                            arg.mpfr_srcptr(), MPC_RND_RE(RndMode));
                    }
                }
                else
                {
                    realnum<BitPrec, MPC_RND_RE(RndMode)>
                            x{ std::forward<ArgType>(arg) };

                    mpfr_swap(mpc_realref(mp), x.mpfr_ptr());
                }
            }

            template<cplx_constor_arg_c ArgType>
            void set_imag(ArgType&& arg) noexcept
            { 
                if constexpr(realnum_c<ArgType>)
                {
                    if constexpr(std::is_rvalue_reference_v<decltype(arg)>)
                    {
                        mpfr_swap(mpc_imagref(mp), arg.mpfr_ptr());
                    }
                    else
                    {
                        mpfr_set_fr(mpc_imagref(mp),
                            arg.mpfr_srcptr(), MPC_RND_IM(RndMode));
                    }
                }
                else
                {
                    realnum<BitPrec, MPC_RND_IM(RndMode)>
                            y{ std::forward<ArgType>(arg) };

                    mpfr_swap(mpc_imagref(mp), y.mpfr_ptr());
                }
            }

            template<std::floating_point T>
            explicit operator std::complex<T>() const
            {               
                return std::complex<T>
                    {
                        (T)mpfr_get_d(mpc_realref(mp), MPC_RND_RE(RndMode)), 
                        (T)mpfr_get_d(mpc_imagref(mp), MPC_RND_IM(RndMode))
                    };   
            }

            void display_info() const
            {
                std::cout <<"Precision = " << digits10 <<" decimal places\n";
                std::cout <<"Bits      = " << digits <<" binary didits\n\n";
                
                gmp::show_mpc_internal(mp);
            }

            void invalidate() { mpc_cleanup(mp); }
           
            ~cplxnum() { invalidate(); }

            ////////////////////// unary +=, -=, *=, /= operators
            cplxnum& operator+=(const cplxnum& op)
            {
                mpc_add(mp, this->mpc_srcptr(), op.mpc_srcptr(), mpc_rnd);
                return *this;
            }

            template<cplx_constor_arg_c ArgType>
            cplxnum& operator+=(ArgType&& arg)
            {
                if constexpr(realnum_c<ArgType>)
                {
                    mpc_add_fr(mp, mp, arg.mpfr_srcptr(), RndMode);
                }
                else if constexpr(unsigned_csil_c<ArgType>)
                {
                    mpc_add_ui(mp, mp, (unsigned long)arg, RndMode);
                }
                else if constexpr(signed_csil_c<ArgType>)
                {
                    mpc_add_si(mp, mp, (signed long)arg, RndMode);
                }
                else if constexpr(float_double_c<ArgType>)
                {
                    mpc_add_d(mp, mp, (double)arg, RndMode);
                }
                else if constexpr(std_complex_c<ArgType>)
                {
                    using ele_t = std_complex_value_type<ArgType>;

                    if constexpr(!std::same_as<ele_t, long double>)
                        mpc_add_cplx(mp, mp, arg, RndMode);
                    else
                    {
                        cplxnum rhs{ arg };
                    
                        mpfr_add(mpc_realref(mp), mpc_realref(mp),
                            mpc_realref(rhs.mpc_srcptr()), MPC_RND_RE(RndMode));

                        mpfr_add(mpc_imagref(mp), mpc_imagref(mp),
                            mpc_imagref(rhs.mpc_srcptr()), MPC_RND_IM(RndMode));
                    }
                }
                else if constexpr(const_char_c<ArgType>)
                {
                    *this += cplxnum{ arg };
                }
                else
                {
                    realnum<BitPrec, MPC_RND_RE(RndMode)> x(false);
                    
                    mpfr_swap(mpc_realref(mp), x.mpfr_ptr());
                    x += arg;
                    mpfr_swap(mpc_realref(mp), x.mpfr_ptr());
                }

                return *this;
            }

            /////////////////////////////////////////////////////
            cplxnum& operator-=(const cplxnum& op)
            {
                mpc_sub(mp, this->mpc_srcptr(), op.mpc_srcptr(), mpc_rnd);
                return *this;
            }

            template<cplx_constor_arg_c ArgType>
            cplxnum& operator-=(ArgType&& arg)
            {
                if constexpr(realnum_c<ArgType>)
                {
                    mpc_sub_fr(mp, mp, arg.mpfr_srcptr(), RndMode);
                }
                else if constexpr(unsigned_csil_c<ArgType>)
                {
                    mpc_sub_ui(mp, mp, (unsigned long)arg, RndMode);
                }
                else if constexpr(signed_csil_c<ArgType>)
                {
                    mpc_sub_si(mp, mp, (signed long)arg, RndMode);
                }
                else if constexpr(float_double_c<ArgType>)
                {
                    mpc_sub_d(mp, mp, (double)arg, RndMode);
                }
                else if constexpr(std_complex_c<ArgType>)
                {
                    using ele_t = std_complex_value_type<ArgType>;

                    if constexpr(!std::same_as<ele_t, long double>)
                        mpc_sub_cplx(mp, mp, arg, RndMode);
                    else
                    {
                        cplxnum rhs{ arg };
                    
                        mpfr_sub(mpc_realref(mp), mpc_realref(mp),
                            mpc_realref(rhs.mpc_srcptr()), MPC_RND_RE(RndMode));

                        mpfr_sub(mpc_imagref(mp), mpc_imagref(mp),
                            mpc_imagref(rhs.mpc_srcptr()), MPC_RND_IM(RndMode));
                    }
                }
                else 
                {
                    *this -= cplxnum{ arg };
                }
                
                return *this;
            }

            /////////////////////////////////////////////////////
            cplxnum& operator*=(const cplxnum& op)
            {
                mpc_mul(mp, this->mpc_srcptr(), op.mpc_srcptr(), mpc_rnd);
                return *this;
            }

            template<cplx_constor_arg_c ArgType>
            cplxnum& operator*=(ArgType&& arg)
            {
                if constexpr(realnum_c<ArgType>)
                {
                    mpc_mul_fr(mp, mp, arg.mpfr_srcptr(), RndMode);
                }
                else if constexpr(unsigned_csil_c<ArgType>)
                {
                    mpc_mul_ui(mp, mp, (unsigned long)arg, RndMode);
                }
                else if constexpr(signed_csil_c<ArgType>)
                {
                    mpc_mul_si(mp, mp, (signed long)arg, RndMode);
                }
                else if constexpr(float_double_c<ArgType>)
                {
                    mpc_mul_d(mp, mp, (double)arg, RndMode);
                }
                else 
                {   *this *= cplxnum{ arg }; }
                
                return *this;
            }

            /////////////////////////////////////////////////////
            cplxnum& operator/=(const cplxnum& op)
            {
                mpc_div(mp, this->mpc_srcptr(), op.mpc_srcptr(), mpc_rnd);
                return *this;
            }

            template<cplx_constor_arg_c ArgType>
            cplxnum& operator/=(ArgType&& arg)
            {
                if constexpr(realnum_c<ArgType>)
                {
                    mpc_div_fr(mp, mp, arg.mpfr_srcptr(), RndMode);
                }
                else if constexpr(unsigned_csil_c<ArgType>)
                {
                    mpc_div_ui(mp, mp, (unsigned long)(arg), RndMode);
                }
                else if constexpr(signed_csil_c<ArgType>)
                {
                    mpc_div_si(mp, mp, (signed long)(arg), RndMode);
                }
                else if constexpr(float_double_c<ArgType>)
                {
                    mpc_div_d(mp, mp, (double)(arg), RndMode);
                }
                else 
                {   *this /= cplxnum{ arg }; }
                
                return *this;
            }
    };
    // end of class cplxnum
    
   
    using cplx_float_t = cplxnum<(mpfr_prec_t)std::numeric_limits<float>::digits, MPC_RNDNN>;
    using cplx_double_t = cplxnum<(mpfr_prec_t)std::numeric_limits<double>::digits, MPC_RNDNN>;
    using cplx_quadruple_t = cplxnum<(mpfr_prec_t)113, MPC_RNDNN>;
    using cplx_octuple_t = cplxnum<(mpfr_prec_t)226, MPC_RNDNN>;
    using cplx_huge_t = cplxnum<(mpfr_prec_t)512, MPC_RNDNN>;
    using cplx_super_huge_t = cplxnum<(mpfr_prec_t)1024, MPC_RNDNN>;

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd>
    std::ostream&
    operator<<(std::ostream& os, const cplxnum<Prec, Rnd>& z)
    {
        auto c = z.clean_zero();
        os <<"(" << c.real() <<"," << c.imag() <<")"; return os;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd> bool
    operator ==(const cplxnum<Prec, Rnd>& lhs, const cplxnum<Prec, Rnd>& rhs)
    {   
        return mpfr_cmp(mpc_realref(lhs.mpc_srcptr()), mpc_realref(rhs.mpc_srcptr())) == 0 &&
                mpfr_cmp(mpc_imagref(lhs.mpc_srcptr()), mpc_imagref(rhs.mpc_srcptr())) == 0;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd> bool
    operator !=(const cplxnum<Prec, Rnd>& lhs, const cplxnum<Prec, Rnd>& rhs)
    {   return lhs != rhs; }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd> std::strong_ordering 
    operator<=>(const cplxnum<Prec, Rnd>& lhs, const cplxnum<Prec, Rnd>& rhs)
    {
        auto ls = gmp::abs(lhs); auto rs = gmp::abs(rhs);

        return ls <=> rs;
    }
    
    namespace hidden
    {
        /////////////// cplxnum binary operation ///////////////////////////
        template<BinOpr opr, cplxnum_c LeftType, cplxnum_c RightType>
            requires same_c<LeftType, RightType>
        decltype(auto) gmp_binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
        {
            using L = decltype(lhs);
            using R = decltype(rhs);
            
            constexpr auto Prec = cplxnum_prec_v<LeftType>;
            constexpr auto RndMode = cplxnum_rnd_v<LeftType>;
            constexpr auto ReRnd = cplxnum_re_rnd_v<LeftType>;
            constexpr auto ImRnd = cplxnum_im_rnd_v<LeftType>;
            
            if constexpr (opr == BinOpr::add)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpc_add(lhs.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpc_add(rhs.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    cplxnum<Prec, RndMode> x;
                    mpc_add(x.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);     
                    
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::mul)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpc_mul(lhs.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return std::move(lhs); 
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpc_mul(rhs.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return std::move(rhs); 
                }
                else // both are lvalue reference
                {
                    cplxnum<Prec, RndMode> x;
                    mpc_mul(x.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);      
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::sub)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpc_sub(lhs.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return std::move(lhs);
                }
                else if constexpr(std::is_rvalue_reference_v<R>)
                {
                    mpc_sub(rhs.mpc_ptr(), rhs.mpc_srcptr(), lhs.mpc_srcptr(), RndMode);
                    
                    mpfr_neg(mpc_realref(rhs.mpc_ptr()), mpc_realref(rhs.mpc_ptr()), ReRnd);  // flip sign
                    mpfr_neg(mpc_imagref(rhs.mpc_ptr()), mpc_imagref(rhs.mpc_ptr()), ImRnd);   // flip sign
                                        
                    return std::move(rhs);
                }
                else // both are lvalue reference
                {
                    cplxnum<Prec, RndMode> x;
                    mpc_sub(x.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return x;
                }
            }
            else if constexpr (opr == BinOpr::div)
            {
                if constexpr(std::is_rvalue_reference_v<L>)
                {
                    mpc_div(lhs.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);
                    return std::move(lhs);
                }
                else // both are lvalue reference
                {
                    cplxnum<Prec, RndMode> x;
                    mpc_div(x.mpc_ptr(), lhs.mpc_srcptr(), rhs.mpc_srcptr(), RndMode);       
                    return x;
                }
            }
        }

        /////////////// cplxnum binary operation ///////////////////////////
        template<BinOpr opr, cplxnum_c LeftType, cplxnum_c RightType>
            requires not_same_c<LeftType, RightType>
        decltype(auto) gmp_binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
        {
            constexpr auto LPrec = cplxnum_prec_v<LeftType>;
            constexpr auto LRndMode = cplxnum_rnd_v<LeftType>;

            constexpr auto RPrec = cplxnum_prec_v<RightType>;
            constexpr auto RRndMode = cplxnum_rnd_v<RightType>;

            if constexpr (LPrec > RPrec)
            {
                return [&]
                {
                    cplxnum<LPrec, LRndMode> rs{rhs};  // convert rhs to L's precision/rnd
                    return gmp_binary_operation<opr>(std::forward<LeftType>(lhs), std::move(rs));
                }();
            }
            else
            {
                return [&]
                {
                    cplxnum<RPrec, RRndMode> ls{lhs};  // convert lhs to R's precision/rnd
                    return gmp_binary_operation<opr>(ls, std::forward<RightType>(rhs));
                }();
            }
        }
    }
    // end of namespace hidden
    
    /////////////// binary operators for cplxnum////////////////////////

    template<cplxnum_c LeftType, cplxnum_c RightType>
    decltype(auto) operator + (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::add>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<cplxnum_c LeftType, cplxnum_c RightType>
    decltype(auto) operator - (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::sub>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<cplxnum_c LeftType, cplxnum_c RightType>
    decltype(auto) operator * (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::mul>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    template<cplxnum_c LeftType, cplxnum_c RightType>
    decltype(auto) operator / (LeftType&& lhs, RightType&& rhs)
    {
        return hidden::gmp_binary_operation<BinOpr::div>
            (std::forward<LeftType>(lhs), std::forward<RightType>(rhs));
    }

    /////////////////////////////////////////////////////////////////////////
    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator+(const cplxnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {
        cplxnum<Prec, Rnd> x{ std::forward<ArgType>(rhs) };
        x += lhs; return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>&&
    operator+(cplxnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {
        lhs += rhs; return std::move(lhs); 
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator+(ArgType&& lhs, const cplxnum<Prec, Rnd>& rhs)
    {
        auto x = rhs; x += lhs; return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>&&
    operator+(ArgType&& lhs, cplxnum<Prec, Rnd>&& rhs)
    {
        rhs += lhs; return std::move(rhs);
    }
     
    /////////////////////////////////////////////////////////////////////////
    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator-(const cplxnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {   return lhs - cplxnum<Prec, Rnd>(rhs); }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>&&
    operator-(cplxnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {   lhs -= rhs; return std::move(lhs); }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator-(ArgType&& lhs, const cplxnum<Prec, Rnd>& rhs)
    {   return cplxnum<Prec, Rnd>(lhs) - rhs;  }
        
    /////////////////////////////////////////////////////////////////////////
    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator*(const cplxnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {
        cplxnum<Prec, Rnd> x{ lhs }; x *= rhs; return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>&&
    operator*(cplxnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {
        lhs *= rhs; return std::move(lhs);
    }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator*(ArgType&& lhs, const cplxnum<Prec, Rnd>& rhs)
    {
        cplxnum<Prec, Rnd> x{ rhs }; x *= lhs; return x;
    }

    /////////////////////////////////////////////////////////////////////////
    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator/(const cplxnum<Prec, Rnd>& lhs, ArgType&& rhs)
    {   cplxnum<Prec, Rnd> x{ lhs }; x /= rhs; return x;  }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>&&
    operator/(cplxnum<Prec, Rnd>&& lhs, ArgType&& rhs)
    {   lhs /= rhs; return std::move(lhs); }

    template<mpfr_prec_t Prec, mpc_rnd_t Rnd,
        cplx_constor_arg_c ArgType> cplxnum<Prec, Rnd>
    operator/(ArgType&& lhs, const cplxnum<Prec, Rnd>& rhs)
    {   return cplxnum<Prec, Rnd>{ lhs } / rhs; }
    
    //////////////////// standard functions for cplxnum ///////////////
    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto abs(const cplxnum<Prec, RndMode>& arg)
    {
        realnum<Prec, MPC_RND_RE(RndMode)> x;
        mpc_abs(x.mpfr_ptr(), arg.mpc_srcptr(), MPC_RND_RE(RndMode));
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto norm(const cplxnum<Prec, RndMode>& arg)
    {
        realnum<Prec, MPC_RND_RE(RndMode)> x;
        mpc_norm(x.mpfr_ptr(), arg.mpc_srcptr(), MPC_RND_RE(RndMode));
        return x;
    }
    
    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto conj(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_conj(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto arg(const cplxnum<Prec, RndMode>& op)
    {
        realnum<Prec, MPC_RND_RE(RndMode)> x;
        mpc_arg(x.mpfr_ptr(), op.mpc_srcptr(), MPC_RND_RE(RndMode));
        return x;
    }
    
    template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
    auto polar(const realnum<Prec, RndMode>& r, const realnum<Prec, RndMode>& theta)
    {
        return cplxnum<Prec, MPC_RND(RndMode, RndMode)>
            { r * gmp::cos(theta), r * gmp::sin(theta) };
    }

    template<primi_floating_c RadiusType, primi_floating_c ThetaType>
    auto polar(RadiusType r, ThetaType theta)
    {
        using ele_t = std::common_type_t<RadiusType, ThetaType>;

        return std::polar((ele_t)r, (ele_t)theta);
    }

    /*
    
        Case	std::proj(z) (C++)	mpc_proj(z) (MPC)
        x,  y finite     x+iy (unchanged)    x+iy (unchanged)
        x=∞,y finite         ∞+iNaN             ∞+i0
        x finite, y=∞,       ∞+iNaN,            ∞+i0
        x=∞, y=∞,            ∞+iNaN,            ∞+i0
    */
    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto proj(const cplxnum<Prec, RndMode>& op)
    {
        cplxnum<Prec, RndMode> x;
        mpc_proj(x.mpc_ptr(), op.mpc_srcptr(), RndMode);
        return x;
    }

    // template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    // auto tgamma(const cplxnum<Prec, RndMode>& arg)
    // {
    //     cplxnum<Prec, RndMode> x;
    //     mpc_gamma(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
    //     return x;
    // }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto sqr(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_sqr(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto sqrt(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_sqrt(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode, typename ExpType>
        requires type_in_types_c<std::remove_cvref_t<std::decay_t<ExpType>>,
        char, short, int, long, long long, signed char, unsigned short,
        unsigned int, unsigned long, unsigned long long, intnum, 
        cplxnum<Prec, RndMode>, realnum<Prec, MPC_RND_RE(RndMode)>,
        float, double, const char*>
    auto pow(const cplxnum<Prec, RndMode>& base, ExpType&& ex)
    {
        using exp_t = std::remove_cvref_t<ExpType>;

        if constexpr(cplxnum_c<exp_t>)
        {
            cplxnum<Prec, RndMode> x;
            mpc_pow(x.mpc_ptr(), base.mpc_srcptr(), ex.mpc_srcptr(), RndMode);
            return x;
        }
        else if constexpr(float_double_c<exp_t>)
        {
            cplxnum<Prec, RndMode> x;
            mpc_pow_d(x.mpc_ptr(), base.mpc_srcptr(), (double)ex, RndMode);
            return x;
        }
        // else if constexpr(std::same_as<exp_t, long double>)
        // {
        //     cplxnum<Prec, RndMode> x;
        //     mpc_pow_ld(x.mpc_ptr(), base.mpc_srcptr(), ex, RndMode);
        //     return x;
        // }
        else if constexpr(signed_csil_c<exp_t>)
        {
            cplxnum<Prec, RndMode> x;
            mpc_pow_si(x.mpc_ptr(), base.mpc_srcptr(), (signed long)ex, RndMode);
            return x;
        }
        else if constexpr(unsigned_csil_c<exp_t>)
        {
            cplxnum<Prec, RndMode> x;
            mpc_pow_ui(x.mpc_ptr(), base.mpc_srcptr(), (unsigned long)ex, RndMode);
            return x;
        }
        else if constexpr(intnum_c<exp_t>)
        {
            cplxnum<Prec, RndMode> x;
            mpc_pow_z(x.mpc_ptr(), base.mpc_srcptr(), ex.mpz_srcptr(), RndMode);
            return x;
        }
        else if constexpr(realnum_c<exp_t>)
        {
            cplxnum<Prec, RndMode> x;
            mpc_pow_fr(x.mpc_ptr(), base.mpc_srcptr(), ex.mpfr_srcptr(), RndMode);
            return x;
        }
        else
        {
            cplxnum<Prec, RndMode> x;
            cplxnum<Prec, RndMode> expo{ std::forward<ExpType>(ex) };

            mpc_pow(x.mpfr_ptr(), base.mpc_srcptr(),
                expo.mpc_srcptr(), RndMode);

            return x;
        }
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto sin(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_sin(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto sinh(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_sinh(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto cos(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_cos(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto cosh(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_cosh(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto tan(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_tan(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto tanh(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_tanh(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto cos_sin(const cplxnum<Prec, RndMode>& arg)
    {
        using cplx_t = cplxnum<Prec, RndMode>;
        std::array<cplx_t, 2> result{};

        mpc_sin_cos(result[1].mpc_ptr(), result[0].mpc_ptr(),
                    arg.mpc_srcptr(), RndMode, RndMode);

        return result;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto sin_cos(const cplxnum<Prec, RndMode>& arg)
    {
        using cplx_t = cplxnum<Prec, RndMode>;
        std::array<cplx_t, 2> result{};

        mpc_sin_cos(result[0].mpc_ptr(), result[1].mpc_ptr(),
                    arg.mpc_srcptr(), RndMode, RndMode);

        return result;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto exp(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_exp(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto log(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_log(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>
    auto log10(const cplxnum<Prec, RndMode>& arg)
    {
        cplxnum<Prec, RndMode> x;
        mpc_log10(x.mpc_ptr(), arg.mpc_srcptr(), RndMode);
        return x;
    }

    template<mpfr_prec_t Prec, mpc_rnd_t RndMode>  
    auto hypot(const cplxnum<Prec, RndMode>& x,
               const cplxnum<Prec, RndMode>& y,
               same_c<cplxnum<Prec, RndMode>> auto const&... zs) noexcept
    {
        return sqrt( ( (x.norm() + y.norm()) + ... + zs.norm() ) );
    }

    // for 𝑧ⁿ = 1, where n ≥ 1, k can be negative, positive, or zero
    // returns k-th power of the n-th root of unity 𝜔ₙᵏ = 𝑒^(2𝜋𝑘/𝑛)
    template<cplxnum_c CplxType, long_int_csil_c nType, long_int_csil_c kType>
    auto omega(nType n, kType k)
    {
        CplxType x{1};

        if(k == 0 ) return x;
        else if (k > 0)
        {
            mpc_rootofunity(x.mpc_ptr(), (unsigned long)n,
                (unsigned long)k, cplxnum_rnd_v<CplxType>);
            return x;
        }
        else // k < 0
        {
            mpc_rootofunity(x.mpc_ptr(), (unsigned long)n,
                (unsigned long)-k, cplxnum_rnd_v<CplxType>);

            return x.inv();
        }
    }

    // for 𝑧ⁿ = 1, where n ≥ 1, k ≥ 0
    // returns (1/n) ⋅ 𝑒^(-2𝜋𝑘/𝑛) = 1/(n⋅𝜔ₙᵏ)
    template<cplxnum_c CplxType, long_int_csil_c nType, long_int_csil_c kType>
    auto omega_n_inv(nType n, kType k)
    {
        CplxType x{1};

        if(n == 0)
            return std::move(x)/n;
        else
        {
            mpc_rootofunity(x.mpc_ptr(), (unsigned long)n,
                (unsigned long)k, cplxnum_rnd_v<CplxType>);
            
            x *= n; // n⋅𝜔ₙᵏ
            return x.inv(); // 1/(n⋅𝜔ₙᵏ)
        }
    }

    template<intnum_c lType, intnum_c rType>
    void swap(lType& a, rType& r)
    {
        mpz_swap(a.mpz_ptr(), r.mpz_ptr());
    }

    template<realnum_c lType, realnum_c rType>
    void swap(lType& a, rType& r)
    {
        mpfr_swap(a.mpfr_ptr(), r.mpfr_ptr());
    }

    template<cplxnum_c lType, cplxnum_c rType>
    void swap(lType& a, rType& r)
    {
        mpc_swap(a.mpc_ptr(), r.mpc_ptr());
    }

    template<gmp_type_c GmpType>
    std::ostream& operator>>(std::ostream& os, const GmpType&)
    {
        os << Gmp_GetTypeName(GmpType) ; return os;
    }

    namespace literals
    {   
        inline constexpr auto endl = "\n";
        inline constexpr auto endL = "\n\n";

        ////////// std::complex literals ////////////////////////
       
        constexpr std::complex<double> operator"" _r(long double val) 
        {
            return { static_cast<double>(val), 0.0 };
        }

        constexpr std::complex<double> operator"" _i(long double val) 
        {
            return { 0.0, static_cast<double>(val) };
        }

        constexpr std::complex<double> operator"" _rd(long double val) 
        {
            return { static_cast<double>(val), 0.0 };
        }

        constexpr std::complex<double> operator"" _id(long double val) 
        {
            return { 0.0, static_cast<double>(val) };
        }

        constexpr std::complex<float> operator"" _rf(long double val) 
        {
            return { static_cast<float>(val), 0.0f };
        }

        constexpr std::complex<float> operator"" _if(long double val) 
        {
            return { 0.0f, static_cast<float>(val) };
        }

        constexpr std::complex<double> operator"" _r(unsigned long long val) 
        {
            return { static_cast<double>(val), 0.0 };
        }

        constexpr std::complex<double> operator"" _i(unsigned long long val) 
        {
            return { 0.0, static_cast<double>(val) };
        }

        constexpr std::complex<double> operator"" _rd(unsigned long long val) 
        {
            return { static_cast<double>(val), 0.0 };
        }

        constexpr std::complex<double> operator"" _id(unsigned long long val) 
        {
            return { 0.0, static_cast<double>(val) };
        }

        constexpr std::complex<float> operator"" _rf(unsigned long long val) 
        {
            return { static_cast<float>(val), 0.0f };
        }

        constexpr std::complex<float> operator"" _if(unsigned long long val) 
        {
            return { 0.0f, static_cast<float>(val) };
        }

        //////////// literals for intnum ///////////////////
        inline gmp::intnum operator""_zn(unsigned long long value)
            { return { value }; }

        inline gmp::intnum operator""_zn(const char* value, size_t len)
            { return { value }; }

        //////////// literals for ratnum ///////////////////
        
        inline gmp::ratnum operator""_fn(unsigned long long value)
            { return { value }; }

        inline gmp::ratnum operator""_fn(const char* value, size_t len)
        { 
            std::stringstream nus;
            
            if(len == 0) return {0};
            
            int comma = 0;

            while(comma < len)
            {
                if(value[comma] == ',' || value[comma] == '/') break;

                if (value[comma] != ' ') nus << value[comma];

                ++comma;
            }
            
            auto nu = nus.str();
            
            if(nu.empty()) nu = "1";

            if(comma == len) return { nu.c_str() };

            std::stringstream des;

            ++comma;
            while(comma < len)
            {
                if (value[comma] != ' ' || value[comma] == '/')
                    des << value[comma];
                
                ++comma;
            }
        
            auto de = des.str();
            if(de.empty()) de = "1";

            return { nu.c_str(), de.c_str() }; 
        }

        inline gmp::ratnum operator""_nu(unsigned long long value)
            { return { value }; }

        inline gmp::ratnum operator""_n(unsigned long long value)
            { return { value }; }

        inline gmp::ratnum operator""_de(unsigned long long value)
            { return { (unsigned long long)1, value }; }

        inline gmp::ratnum operator""_nu(const char* value, size_t len)
            { return { value }; }

        inline gmp::ratnum operator""_n(const char* value, size_t len)
            { return { value }; }

        inline gmp::ratnum operator""_de(const char* value, size_t len)
            { return { "1", value }; }
            
        //////////// literals for real_float_t ///////////////////

        inline real_float_t operator""_rnf(unsigned long long value)
            {   return { value };  }

        inline real_float_t operator""_rnf(long double value)
            {   return { (float)value }; }

        inline real_float_t operator""_rnf(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplx_float_t ///////////////////
        inline cplx_float_t operator""_cnf(unsigned long long value)
            {   return { value }; }

        inline cplx_float_t operator""_ref(unsigned long long value)
            {   return { value }; }

        inline cplx_float_t operator""_imf(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_float_t operator""_cnf(long double value)
            {   return { (float)value }; }

        inline cplx_float_t operator""_ref(long double value)
            {   return { (float)value }; }

        inline cplx_float_t operator""_imf(long double value)
            {   return { (float)0, (float)value }; }

        inline cplx_float_t operator""_ref(const char* value, size_t len)
            {   return { real_float_t{ value }, real_float_t{} }; }

        inline cplx_float_t operator""_imf(const char* value, size_t len)
            { return { real_float_t{}, real_float_t{ value }}; }
        
        inline cplx_float_t operator""_cnf(const char* value, size_t len)
            { return { value }; }

        //////////// literals for real_double_t ///////////////////

        inline real_double_t operator""_rnd(unsigned long long value)
            {   return { value };  }

        inline real_double_t operator""_rnd(long double value)
            {   return { (double)value }; }

        inline real_double_t operator""_rnd(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplx_double_t ///////////////////
        inline cplx_double_t operator""_cnd(unsigned long long value)
            {   return { value }; }

        inline cplx_double_t operator""_red(unsigned long long value)
            {   return { value }; }

        inline cplx_double_t operator""_imd(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_double_t operator""_cnd(long double value)
            {   return { (double)value }; }

        inline cplx_double_t operator""_red(long double value)
            {   return { (double)value }; }

        inline cplx_double_t operator""_imd(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_double_t operator""_red(const char* value, size_t len)
            {   return { real_double_t{ value }, real_double_t{} }; }

        inline cplx_double_t operator""_imd(const char* value, size_t len)
            { return { real_double_t{}, real_double_t{ value }}; }
        
        inline cplx_double_t operator""_cnd(const char* value, size_t len)
            { return { value }; }

        //////////// literals for real_quadruple_t ///////////////////

        inline real_quadruple_t operator""_rnq(unsigned long long value)
            {   return { value };  }

        inline real_quadruple_t operator""_rnq(long double value)
            {   return { (double)value }; }

        inline real_quadruple_t operator""_rnq(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplx_quadruple_t ///////////////////
        inline cplx_quadruple_t operator""_cnq(unsigned long long value)
            {   return { value }; }

        inline cplx_quadruple_t operator""_req(unsigned long long value)
            {   return { value }; }

        inline cplx_quadruple_t operator""_imq(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_quadruple_t operator""_cnq(long double value)
            {   return { (double)value }; }

        inline cplx_quadruple_t operator""_req(long double value)
            {   return { (double)value }; }

        inline cplx_quadruple_t operator""_imq(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_quadruple_t operator""_req(const char* value, size_t len)
            {   return { real_quadruple_t{ value }, real_quadruple_t{} }; }

        inline cplx_quadruple_t operator""_imq(const char* value, size_t len)
            { return { real_quadruple_t{}, real_quadruple_t{ value }}; }
        
        inline cplx_quadruple_t operator""_cnq(const char* value, size_t len)
            { return { value }; }

        //////////// literals for real_octuple_t ///////////////////

        inline real_octuple_t operator""_rno(unsigned long long value)
            {   return { value };  }

        inline real_octuple_t operator""_rno(long double value)
            {   return { (double)value }; }

        inline real_octuple_t operator""_rno(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplx_octuple_t ///////////////////
        inline cplx_octuple_t operator""_cno(unsigned long long value)
            {   return { value }; }

        inline cplx_octuple_t operator""_reo(unsigned long long value)
            {   return { value }; }

        inline cplx_octuple_t operator""_imo(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_octuple_t operator""_cno(long double value)
            {   return { (double)value }; }

        inline cplx_octuple_t operator""_reo(long double value)
            {   return { (double)value }; }

        inline cplx_octuple_t operator""_imo(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_octuple_t operator""_reo(const char* value, size_t len)
            {   return { real_octuple_t{ value }, real_octuple_t{} }; }

        inline cplx_octuple_t operator""_imo(const char* value, size_t len)
            { return { real_octuple_t{}, real_octuple_t{ value }}; }
        
        inline cplx_octuple_t operator""_cno(const char* value, size_t len)
            { return { value }; }

        //////////// literals for real_huge_t ///////////////////

        inline real_huge_t operator""_rnh(unsigned long long value)
            {   return { value };  }

        inline real_huge_t operator""_rnh(long double value)
            {   return { (double)value }; }

        inline real_huge_t operator""_rnh(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplx_huge_t ///////////////////
        inline cplx_huge_t operator""_cnh(unsigned long long value)
            {   return { value }; }

        inline cplx_huge_t operator""_reh(unsigned long long value)
            {   return { value }; }

        inline cplx_huge_t operator""_imh(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_huge_t operator""_cnh(long double value)
            {   return { (double)value }; }

        inline cplx_huge_t operator""_reh(long double value)
            {   return { (double)value }; }

        inline cplx_huge_t operator""_imh(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_huge_t operator""_reh(const char* value, size_t len)
            {   return { real_huge_t{ value }, real_huge_t{} }; }

        inline cplx_huge_t operator""_imh(const char* value, size_t len)
            { return { real_huge_t{}, real_huge_t{ value }}; }
        
        inline cplx_huge_t operator""_cnh(const char* value, size_t len)
            { return { value }; }

        //////////// literals for real_super_huge_t ///////////////////

        inline real_super_huge_t operator""_rns(unsigned long long value)
            {   return { value };  }

        inline real_super_huge_t operator""_rns(long double value)
            {   return { (double)value }; }

        inline real_super_huge_t operator""_rns(const char* value, size_t len)
            {   return { value }; }

        //////////// literals for cplx_super_huge_t ///////////////////
        inline cplx_super_huge_t operator""_cns(unsigned long long value)
            {   return { value }; }

        inline cplx_super_huge_t operator""_res(unsigned long long value)
            {   return { value }; }

        inline cplx_super_huge_t operator""_ims(unsigned long long value)
            {   return { (unsigned long long)0, value }; }

        inline cplx_super_huge_t operator""_cns(long double value)
            {   return { (double)value }; }

        inline cplx_super_huge_t operator""_res(long double value)
            {   return { (double)value }; }

        inline cplx_super_huge_t operator""_ims(long double value)
            {   return { (double)0, (double)value }; }

        inline cplx_super_huge_t operator""_res(const char* value, size_t len)
            {   return { real_super_huge_t{ value }, real_super_huge_t{} }; }

        inline cplx_super_huge_t operator""_ims(const char* value, size_t len)
            { return { real_super_huge_t{}, real_super_huge_t{ value }}; }
        
        inline cplx_super_huge_t operator""_cns(const char* value, size_t len)
            { return { value }; }
    }
    // end of namespace literals

    namespace hidden
    {
        template<typename FuncType, typename ArgType>
        struct st_is_func
        {
            constexpr static int count = 
                parameter_count_v<FuncType, ArgType>;

            constexpr static bool value = (count >= 1) && (count < MaxInvocableCount);
        };
    }
    // end of namespace hidden

    template<typename FuncType, typename ArgType = float>
    concept function_c = hidden::st_is_func<FuncType, ArgType>::value;

    template<typename FuncType, typename ArgType = float>
    constexpr auto args_count_v = hidden::st_is_func<FuncType, ArgType>::count;

    template<typename T>
    concept scalar_c = one_of_c<T, unsigned char, unsigned short, unsigned int,
        unsigned long, unsigned long long, signed char, signed short, signed int,
        signed long, signed long long, intnum, ratnum, float, double, const char*,
        std::complex<float>, std::complex<double>>
        || realnum_c<T> || cplxnum_c<T>;

    template<typename T>
    concept integral_number_c = 
        one_of_c<T, int, long, long long, 
                unsigned int, unsigned long, unsigned long long, intnum>;

    template<typename T>
    concept exact_number_c = integral_number_c<T> || ratnum_c<T>;
    
    template<typename T>
    concept floating_number_c = one_of_c<T, float, double> || realnum_c<T>;

    template<typename T>
    concept rational_or_floating_number_c = ratnum_c<T> || floating_number_c<T>;

    template<typename T>
    concept non_complex_number_c = exact_number_c<T> || floating_number_c<T> ;

    template<typename T>
    concept complex_number_c = 
        one_of_c<T, std::complex<float>, std::complex<double>> || cplxnum_c<T>;

    template<typename T>
    concept real_number_c = exact_number_c<T> || floating_number_c<T>;
    
    template<typename T>
    concept number_c = real_number_c<T> || complex_number_c<T>;

    template<typename... Ts>
    concept at_least_one_number_c = (number_c<Ts> || ...);

    template<typename T>
    concept non_number_c = !number_c<T>;

    template<typename... Ts> 
    concept at_least_one_non_number_c = (non_number_c<Ts> || ...);

    template<typename... Ts> 
    concept all_numbers_c = (number_c<Ts> && ...);

    template<typename... Ts> 
    concept all_non_numbers_c = (non_number_c<Ts> && ...);

    template<typename FuncType1, typename ReturnType1, typename ArgType1, auto ParamCount1,
                typename FuncType2, typename ReturnType2, typename ArgType2, auto ParamCount2>
    constexpr auto func_cat(function_info<FuncType1, ReturnType1, ArgType1, ParamCount1>, 
                            function_info<FuncType2, ReturnType2, ArgType2, ParamCount2>)
    {
        constexpr bool return_real = (ParamCount1 != MaxInvocableCount) ?
                real_number_c<ReturnType1> : (ParamCount2 != MaxInvocableCount) ?
                real_number_c<ReturnType2> : false;

        constexpr bool return_cplx = (ParamCount1 != MaxInvocableCount) ?
                complex_number_c<ReturnType1> : (ParamCount2 != MaxInvocableCount) ?
                complex_number_c<ReturnType2> : false;

        constexpr bool argtype_real = (ParamCount1 != MaxInvocableCount) ?
                real_number_c<ArgType1> : (ParamCount2 != MaxInvocableCount) ?
                real_number_c<ArgType2> : false;

        constexpr bool argtype_cplx = (ParamCount1 != MaxInvocableCount) ?
                complex_number_c<ArgType1> : (ParamCount2 != MaxInvocableCount) ?
                complex_number_c<ArgType2> : false;

        return return_real && argtype_real ? FuncCat::real_real :
                return_cplx && argtype_real ? FuncCat::cplx_real :
                return_real && argtype_cplx ? FuncCat::real_cplx :
                return_cplx && argtype_cplx ? FuncCat::cplx_cplx : FuncCat::unknown;

        // constexpr bool value = 
        //     !( std::same_as<ReturnType1, ArgType1> && std::same_as<ReturnType2, ArgType2> 
        //         && (ParamCount1 != MaxInvocableCount) && (ParamCount1 == ParamCount2) );   
    }

    template<typename FuncType, typename ArgType1 = float,
                                typename ArgType2 = std::complex<ArgType1>>
    constexpr auto func_cat_v = 
        func_cat( func_info_t<FuncType, ArgType1>{}, func_info_t<FuncType, ArgType2>{} );
   
    using number_list_t = type_container<char, short, int, long, long long, intnum, ratnum,
        real_float_t, float, real_double_t, double, real_quadruple_t,
        real_octuple_t, real_huge_t, real_super_huge_t,
        cplx_float_t, std::complex<float>, cplx_double_t, std::complex<double>,
        cplx_quadruple_t, cplx_octuple_t, cplx_huge_t, cplx_super_huge_t>;
    
    template<typename S, int N = 0, typename T, typename... Ts>
    consteval int get_index(type_container<T, Ts...>) noexcept
    {
        if constexpr( std::same_as<S, T> )
            return N;
        else if constexpr( sizeof...(Ts) != 0)
            return get_index<S, N+1>(type_container<Ts...>{});
        else
            return -1; // type not in the list
    }
    
    template<typename S>
    constexpr int ordinal_v = get_index<std::remove_cvref_t<S>, 0>(number_list_t{});

    namespace hidden
    {
        template<typename T>
        struct st_make_complex
        {
            using type = T;
        };

        template<one_of_c<char, short, int, long> T>
        struct st_make_complex<T>
        {
            using type = std::complex<float>;
        };

        template<std::same_as<long long> T>
        struct st_make_complex<T>
        {
            using type = std::complex<double>;
        };

        template<one_of_c<intnum, ratnum> T>
        struct st_make_complex<T>
        {
            using type = real_quadruple_t;
        };

        template<one_of_c<float, double> T>
        struct st_make_complex<T>
        {
            using type = std::complex<T>;
        };

        template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
        struct st_make_complex<realnum<Prec, Rnd>>
        {
            using type = cplxnum<Prec, MPC_RND(Rnd, Rnd)>;
        };
    }

    template<typename T>
    using make_cplx_t = typename hidden::st_make_complex<std::remove_cvref_t<T>>::type;

    namespace hidden
    {
        template<typename S, typename T>
        struct st_ordinal_common_type
        {
            using type = std::conditional_t< ordinal_v<S> >= ordinal_v<T>, S, T>; 
        };

        template<non_complex_number_c S, complex_number_c T>
        struct st_ordinal_common_type<S, T>
        {
            using type = std::conditional_t< ordinal_v< make_cplx_t<S> > >= ordinal_v<T>, make_cplx_t<S>, T>; 
        };

        template<complex_number_c S, non_complex_number_c T>
        struct st_ordinal_common_type<S, T>
        {
            using type = std::conditional_t< ordinal_v<S> >= ordinal_v< make_cplx_t<T> >, S, make_cplx_t<T>>; 
        };

        template<typename S, typename T>
        using ordinal_common_t = 
            typename st_ordinal_common_type<std::remove_cvref_t<S>, std::remove_cvref_t<T>>::type;

        template<typename S, typename... Ts>
        struct st_common_type;

        template<typename S>
        struct st_common_type<S>
        {
            using type = S;
        };

        template<typename S, typename T>
        struct st_common_type<S, T>
        {
            using type = ordinal_common_t<S, T>;
        };

        template<typename S, typename T, typename U, typename... Us>
        struct st_common_type<S, T, U, Us...>
        {
            // using type = ordinal_common_t< ordinal_common_t<S, T>, typename st_common_type<T, U, Us...>::type >;
            using type = typename st_common_type<ordinal_common_t<S, T>, U, Us...>::type;
        };
    }

    template<typename S, typename... Ts>
    using common_type_t = 
        typename hidden::st_common_type< std::remove_cvref_t<S>, std::remove_cvref_t<Ts>...>::type;
        
    template<typename... Ts>
    using elevated_common_type_t = 
        typename hidden::st_common_type<double, std::remove_cvref_t<Ts>...>::type;
       
    namespace hidden
    {
        template<typename T, typename A>
        struct st_valid_function
        {
            constexpr static int pCount = parameter_count_v<T, A>;
            constexpr static bool value = pCount > 0 && pCount < MaxInvocableCount;
        };

        template<number_c T, typename A>
        struct st_valid_function<T, A>: std::false_type{ };

        template<typename T, typename A>
        struct st_parameter_size
        {
            constexpr static int pCount = parameter_count_v<T, A>;
            constexpr static int value = 
                (pCount > 0 && pCount < MaxInvocableCount) ? pCount: number_c<T> ? 0 : MaxInvocableCount; 
        };
    }
    // end of namespace hidden

    template<typename FuncType, typename ArgType = float>
    concept numeric_function_c = 
        hidden::st_valid_function<std::remove_cvref_t<FuncType>,
                                  std::remove_cvref_t<ArgType>>::value;

    template<typename... FuncTypes>
    concept at_least_one_function_c = 
        ( numeric_function_c<FuncTypes, std::complex<float>> || ... );

    template<typename... FuncTypes>
    concept number_function_mixed_c = at_least_one_number_c<FuncTypes...> &&
            at_least_one_function_c<FuncTypes...>;

    template<typename T, typename ArgType = std::complex<float>>
    concept number_or_function_c = number_c<T> || numeric_function_c<T, ArgType>;
   
    template<typename Func, typename ArgType = std::complex<float>>
    concept extended_function_c = number_c<std::remove_cvref_t<Func>>
                                 || numeric_function_c<Func, ArgType>;

    template<typename Func, typename ArgType = std::complex<float>>
    concept non_extended_function_c = !extended_function_c<Func, ArgType>;

    template<typename Func, typename ArgType = std::complex<float>>
    inline constexpr int parameter_size_v = hidden::st_parameter_size<Func, ArgType>::value;

    template<typename ArgType = std::complex<float>, typename Func>
    consteval int parameter_size(Func&& f) noexcept
    {
        constexpr int pCount = parameter_count_v<Func, ArgType>;
        return (pCount > 0 && pCount < MaxInvocableCount) ? pCount: 
            (number_c<Func> && std::is_convertible_v< std::remove_cvref_t<Func>, std::remove_cvref_t<ArgType>>) ? 0 : MaxInvocableCount; 
    }

    namespace hidden
    {
        template<typename T> struct st_promote;
        
        template<> struct st_promote<float>
        {
            using type = double;
        };

        template<> struct st_promote<double>
        {

            using type = real_quadruple_t;
        };
        
        template<> struct st_promote<real_quadruple_t>
        {
            using type = real_octuple_t;
        };

        template<> struct st_promote<real_octuple_t>
        {
            using type = real_huge_t;
        };

        template<> struct st_promote<real_huge_t>
        {
            using type = real_super_huge_t;
        };

        template<> struct st_promote<real_super_huge_t>
        {
            using type = non_type<>;
        };

        template<> struct st_promote<std::complex<float>>
        {
            using type = std::complex<double>;
        };

        template<> struct st_promote<std::complex<double>>
        {
            using type = cplx_quadruple_t;
        };

        template<> struct st_promote<cplx_quadruple_t>
        {
            using type = cplx_octuple_t;
        };

        template<> struct st_promote<cplx_octuple_t>
        {
            using type = cplx_huge_t;
        };

        template<> struct st_promote<cplx_huge_t>
        {
            using type = cplx_super_huge_t;
        };

        template<> struct st_promote<cplx_super_huge_t>
        {
            using type = non_type<>;
        };

        template<typename T> struct st_demote; 
        
        template<> struct st_demote<float>
        {
            using type = non_type<>;
        };

        template<> struct st_demote<double>
        {
            using type = float;
        };

        template<> struct st_demote<real_quadruple_t>
        {
            using type = double;
        };

        template<> struct st_demote<real_octuple_t>
        {
            using type = real_quadruple_t;
        };

        template<> struct st_demote<real_huge_t>
        {
            using type = real_octuple_t;
        };

        template<> struct st_demote<real_super_huge_t>
        {
            using type = real_huge_t;
        };

        template<> struct st_demote<std::complex<float>>
        {
            using type = non_type<>;
        };

        template<> struct st_demote<std::complex<double>>
        {
            using type = std::complex<float>;
        };

        template<> struct st_demote<cplx_quadruple_t>
        {
            using type = std::complex<double>;
        };

        template<> struct st_demote<cplx_octuple_t>
        {
            using type = cplx_quadruple_t;
        };

        template<> struct st_demote<cplx_huge_t>
        {
            using type = cplx_octuple_t;
        };

        template<> struct st_demote<cplx_super_huge_t>
        {
            using type = cplx_huge_t;
        };

        template<typename T>
        struct st_promote_type
        {
            using pd_type = typename st_promote<T>::type;
            using type = std::conditional_t< non_type_c<pd_type>, T, pd_type>;
        };

        template<typename T>
        struct st_demote_type
        {
            using pd_type = typename st_demote<T>::type;
            using type = std::conditional_t< non_type_c<pd_type>, T, pd_type>;
        };
    }
    // end of namespace hidden
    
    template<typename T>
    using promote_t = typename hidden::st_promote_type<std::remove_cvref_t<T>>::type;

    template<typename T>
    using demote_t = typename hidden::st_demote_type<std::remove_cvref_t<T>>::type;

    template<primi_floating_c ArgType>
    auto ceil(ArgType arg) noexcept
    {
        return std::ceil(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    auto ceil(const realnum<Prec, Rnd>& arg) noexcept
    {
        realnum<Prec, Rnd> x;
        mpfr_ceil(x.mpfr_ptr(), arg.mpfr_srcptr());
        return x;
    }
    
    template<primi_floating_c ArgType>
    auto floor(ArgType arg) noexcept
    {
        return std::floor(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    auto floor(const realnum<Prec, Rnd>& arg) noexcept
    {
        realnum<Prec, Rnd> x;
        mpfr_floor(x.mpfr_ptr(), arg.mpfr_srcptr());
        return x;
    }

    template<primi_floating_c ArgType>
    auto trunc(ArgType arg) noexcept
    {
        return std::floor(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    auto trunc(const realnum<Prec, Rnd>& arg) noexcept
    {
        realnum<Prec, Rnd> x;
        mpfr_trunc(x.mpfr_ptr(), arg.mpfr_srcptr());
        return x;
    }

    template<primi_floating_c ArgType>
    auto round(ArgType arg) noexcept
    {
        return std::round(arg);
    }

    template<mpfr_prec_t Prec, mpfr_rnd_t Rnd>
    auto round(const realnum<Prec, Rnd>& arg) noexcept
    {
        realnum<Prec, Rnd> x;
        mpfr_round(x.mpfr_ptr(), arg.mpfr_srcptr());
        return x;
    }

    template<primi_floating_c ArgType>
    bool isfinite(ArgType arg) noexcept
    {
        return std::isfinite(arg);
    }

    template<realnum_c ArgType>
    bool isfinite(ArgType arg) noexcept
    {
        return mpfr_number_p(arg);
    }

    template<floating_number_c ArgType>
    bool is_integral_float(ArgType arg) noexcept
    {
        return trunc(arg) == arg;
    }

    template<floating_number_c ArgType>
    bool is_negative_integral_float(ArgType arg) noexcept
    {
        return (trunc(arg) == arg) && (arg < ArgType{0});
    }

    template<integral_number_c ReturnType = intnum, integral_number_c nType>
    inline auto factorial(nType n) noexcept
    {
        intnum x;

        unsigned long nn = [&]
        {
            if constexpr(intnum_c<nType>)
                return hidden::mpz_get_integer<unsigned long>(n.mpz_srcptr());
            else
                return static_cast<unsigned long>(n);
        }();

        mpz_fac_ui(x.mpz_ptr(), nn);

        if constexpr(intnum_c<ReturnType> || intnum_c<nType>)
            return x;
        else
            return hidden::mpz_get_integer<ReturnType>(x.mpz_srcptr());
    }
    
}
// end of namespace gmp

namespace std
{
    // using namespace gmp;
    // using namespace gmp::operators;

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator+(T&& lhs, const std::complex<C>& rhs)
    {
        return std::complex<C>((C)lhs) + rhs;
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator+(const std::complex<C>& lhs, T&& rhs)
    {
        return lhs + std::complex<C>((C)rhs);
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator-(T&& lhs, const std::complex<C>& rhs)
    {
        return std::complex<C>((C)lhs) - rhs;
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator-(const std::complex<C>& lhs, T&& rhs)
    {
        return lhs - std::complex<C>((C)rhs);
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator*(T&& lhs, const std::complex<C>& rhs)
    {
        return std::complex<C>((C)lhs) * rhs;
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator*(const std::complex<C>& lhs, T&& rhs)
    {
        return lhs * std::complex<C>((C)rhs);
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator/(T&& lhs, const std::complex<C>& rhs)
    {
        return std::complex<C>((C)lhs) / rhs;
    }

    template<gmp::primi_int_floating_c T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator/(const std::complex<C>& lhs, T&& rhs)
    {
        return lhs / std::complex<C>((C)rhs);
    }

    template<std::floating_point T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator+(const std::complex<T>& lhs, const std::complex<C>& rhs)
    {
        using ele_t = std::common_type_t<T, C>;

        if constexpr(std::same_as<ele_t, T>)
        {
            return lhs + std::complex<T>{ rhs.real(), rhs.imag() };
        }
        else
        {
            return std::complex<C>{ lhs.real(), lhs.imag() } + rhs;
        }
    }

    template<std::floating_point T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator-(const std::complex<T>& lhs, const std::complex<C>& rhs)
    {
        using ele_t = std::common_type_t<T, C>;

        if constexpr(std::same_as<ele_t, T>)
        {
            return lhs - std::complex<T>{ rhs.real(), rhs.imag() };
        }
        else
        {
            return std::complex<C>{ lhs.real(), lhs.imag() } - rhs;
        }
    }

    template<std::floating_point T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator*(const std::complex<T>& lhs, const std::complex<C>& rhs)
    {
        using ele_t = std::common_type_t<T, C>;

        if constexpr(std::same_as<ele_t, T>)
        {
            return lhs * std::complex<T>{ rhs.real(), rhs.imag() };
        }
        else
        {
            return std::complex<C>{ lhs.real(), lhs.imag() } * rhs;
        }
    }

    template<std::floating_point T, std::floating_point C>
        requires gmp::not_same_c<T, C>
    auto operator/(const std::complex<T>& lhs, const std::complex<C>& rhs)
    {
        using ele_t = std::common_type_t<T, C>;

        if constexpr(std::same_as<ele_t, T>)
        {
            return lhs / std::complex<T>{ rhs.real(), rhs.imag() };
        }
        else
        {
            return std::complex<C>{ lhs.real(), lhs.imag() } / rhs;
        }
    }

}
// end of namespace std

namespace gmp::operators
{
    // capture operation result to shared_ptr
    template<typename ArgType>
    [[nodiscard]] auto result_shared(ArgType&& arg)
        noexcept(nothrow_move_constructible_c<ArgType>)
        requires( std::is_rvalue_reference_v<decltype(arg)> )
    {
        return std::make_shared<
            std::remove_cvref_t<ArgType>>(std::move(arg));
    }

    // capture operation result to unique_ptr
    template<typename ArgType>
    [[nodiscard]] auto result_unique(ArgType&& arg)
        noexcept(nothrow_move_constructible_c<ArgType>)
        requires( std::is_rvalue_reference_v<decltype(arg)> )
    {
        return std::make_unique<
            std::remove_cvref_t<ArgType>>(std::move(arg));
    }

    template<number_c ArgType, number_c... ArgTypes>
    auto common(ArgType&& arg, ArgTypes&&... args) noexcept
    {
        using ele_t = common_type_t<ArgType, ArgTypes...>;
        
        return std::array
            {
                static_cast<ele_t>(std::forward<ArgType>(arg)),
                static_cast<ele_t>(std::forward<ArgTypes>(args))...
            };
    }

    // make arg, args... of common type
    // and form std::array{ arg, args... }
    template<number_c ArgType, number_c... ArgTypes>
    auto make_args(ArgType&& arg, ArgTypes&&... args) noexcept
    {
        return common(std::forward<ArgType>(arg), 
            std::forward<ArgTypes>(args)...);
    }

    template<number_c ArgType, number_c... ArgTypes>
    auto promote(ArgType&& arg, ArgTypes&&... args) noexcept
    {
        using common_t = common_type_t<ArgType, ArgTypes...>;
        using ele_t = promote_t<common_t>;
        
        return std::array
            {
                static_cast<ele_t>(std::forward<ArgType>(arg)),
                static_cast<ele_t>(std::forward<ArgTypes>(args))...
            };
    }

    template<number_c ArgType, std::size_t N>
    auto promote(const std::array<ArgType, N>& args) noexcept
    {
        using ele_t = promote_t<ArgType>;
        
        return [&]<auto... ns>(value_container<ns...>)
        {
            return std::array{ static_cast<ele_t>(args[ns])... };

        }( forward_sequence<N>() );
    }

    template<CastRtnType cast = CastRtnType::ifpsble, 
        number_c ArgType = std::complex<double>, std::size_t N, extended_function_c<ArgType> FuncType>
    auto evaluate(FuncType&& f, const std::array<ArgType, N>& args) noexcept
    {       
        if constexpr(number_c<FuncType>)
        {
            if constexpr(cast == CastRtnType::force)
                return (ArgType)f;
            else if constexpr(cast == CastRtnType::dont) 
                return f;
            else
            {
                if constexpr( std::convertible_to<std::remove_cvref_t<FuncType>, ArgType>)
                    return (ArgType)f;
                else
                    return f;
            }
        }
        else
        {
            if constexpr(cast == CastRtnType::force)
            {
                return [&]<auto ...n>(value_container<n...>)
                {
                    return static_cast<ArgType>( f( get_or_zero<n>(args)... ) );

                }( forward_sequence<parameter_count_v<FuncType, ArgType>>());
            }
            else if constexpr(cast == CastRtnType::dont)
            {
                return [&]<auto ...n>(value_container<n...>)
                {
                    return f( get_or_zero<n>(args)... );

                }( forward_sequence<parameter_count_v<FuncType, ArgType>>());
            }
            else
            {
                auto rtn = [&]<auto ...n>(value_container<n...>)
                    {
                        return f( get_or_zero<n>(args)... );

                    }( forward_sequence<parameter_count_v<FuncType, ArgType>>());

                if constexpr(std::convertible_to<decltype(rtn), ArgType>)
                    return (ArgType)rtn;
                else
                    return rtn;
            }
        }
    }

    template<CastRtnType cast = CastRtnType::ifpsble, 
        number_c ArgType = std::complex<double>, number_c... ArgTypes,
        extended_function_c<ArgType> FuncType>
    auto evaluate(FuncType&& f, const std::tuple<ArgType, ArgTypes...>& args) noexcept
    {       
        using ele_t = common_type_t<ArgType, ArgTypes...>;

        if constexpr(number_c<FuncType>)
        {
            if constexpr(cast == CastRtnType::force)
                return (ele_t)f;
            else if constexpr(cast == CastRtnType::dont) 
                return f;
            else
            {
                if constexpr( std::convertible_to<std::remove_cvref_t<FuncType>, ele_t>)
                    return (ele_t)f;
                else
                    return f;
            }
        }
        else
        {
            if constexpr(cast == CastRtnType::force)
            {
                return [&]<auto ...n>(value_container<n...>)
                {
                    return static_cast<ele_t>( f( get_or_zero<n>(args)... ) );

                }( forward_sequence<parameter_count_v<FuncType, ele_t>>());
            }
            else if constexpr(cast == CastRtnType::dont)
            {
                return [&]<auto ...n>(value_container<n...>)
                {
                    return f( get_or_zero<n>(args)... );

                }( forward_sequence<parameter_count_v<FuncType, ele_t>>());
            }
            else
            {
                auto rtn = [&]<auto ...n>(value_container<n...>)
                    {
                        return f( get_or_zero<n>(args)... );

                    }( forward_sequence<parameter_count_v<FuncType, ele_t>>());

                if constexpr(std::convertible_to<decltype(rtn), ele_t>)
                    return (ele_t)rtn;
                else
                    return rtn;
            }
        }
    }

    template<CastRtnType cast = CastRtnType::ifpsble, 
        number_c ArgType, number_c... ArgTypes, extended_function_c<ArgType> FuncType>
    auto evaluate(FuncType&& f, ArgType&& arg, ArgTypes&&... args) noexcept
    {
        return evaluate<cast>( std::forward<FuncType>(f),
            common( std::forward<ArgType>(arg), std::forward<ArgTypes>(args) ... ) );
    }

    template<number_c ArgType, std::size_t N, extended_function_c<ArgType> FuncType>
    ArgType pevaluate(FuncType&& f, const std::array<ArgType, N>& args) noexcept
    {  
        auto values = [&args]<auto...n>(value_container<n...>)
        {
            using pArgType = promote_t<ArgType>;

            return std::array{ static_cast<pArgType>(get_or_zero<n>(args))... };

        }( forward_sequence<N>());

        return static_cast<ArgType>( evaluate(std::forward<FuncType>(f), values) );
    }

    template<number_c ArgType, number_c... ArgTypes, extended_function_c<ArgType> FuncType>
    ArgType pevaluate(FuncType&& f, ArgType&& arg, ArgTypes&&... args) noexcept
    {  
        return pevaluate(std::forward<FuncType>(f),
            common( std::forward<ArgType>(arg), std::forward<ArgTypes>(args) ...) );
    }

    /////////////////////////////////////////////////
    template<CastRtnType cast = CastRtnType::force, typename T = std::complex<float>,
        numeric_function_c<T> TargetType, number_or_function_c<T> ArgType,
        number_or_function_c<T>... ArgTypes,
        int pCount = max_v< parameter_size_v<ArgType, T>, parameter_size_v<ArgTypes, T>...>>
    auto call_redirect(TargetType&& target, ArgType&& arg, ArgTypes&&... args) noexcept
    {
        // arg and args... are immediate numbers
        if constexpr(pCount < 1) 
        {
            using ele_t = common_type_t<ArgType, ArgTypes...>;

            return evaluate<cast>( target, 
                std::array{ (ele_t)std::forward<ArgType>(arg),
                            (ele_t)std::forward<ArgTypes>(args)... } );
        }
        else // if constexpr(pCount < MaxInvocableCount),
             // not required for ArgTypes are numbers or functions
        {
            return [target = std::forward<TargetType>(target), args_tuple
                    = std::tuple{ std::forward<ArgType>(arg), std::forward<ArgTypes>(args) ...} ]
                    <number_c... PrmTypes>( PrmTypes... prms )
                requires (sizeof...(PrmTypes) == pCount)
            {
                auto arg_prms = std::array{ std::move(prms)... };

                auto args = [=]<auto...i>(value_container<i...>)
                {
                    return std::array{ evaluate<cast>(get<i>(args_tuple), arg_prms) ... };

                }(forward_sequence< (int) sizeof...(ArgTypes) + 1 >());

                return evaluate<cast>(target, args);
            };
        }
    }

    /////////////////////////////////////////////////
    template<CastRtnType cast = CastRtnType::force, typename T = std::complex<float>, 
        numeric_function_c<T> TargetType, number_or_function_c<T> ArgType,
        number_or_function_c<T>... ArgTypes,
        int pCount = max_v< parameter_size_v<ArgType, T>, parameter_size_v<ArgTypes, T>...>>
    auto call_binder(TargetType&& target, ArgType&& arg, ArgTypes&&... args) noexcept
    {
        // arg and args... are immediate numbers
        if constexpr(pCount < 1) 
        {
            using ele_t = common_type_t<ArgType, ArgTypes...>;

            return evaluate<cast>( target, 
                std::array{ (ele_t)std::forward<ArgType>(arg),
                            (ele_t)std::forward<ArgTypes>(args)... } );
        }
        else // if constexpr(pCount < MaxInvocableCount), not required for ArgTypes are numbers or functions
        {
            return [target = std::forward<TargetType>(target), args_tuple
                    = std::tuple{ std::forward<ArgType>(arg), std::forward<ArgTypes>(args) ...} ]
                    <number_c... PrmTypes>( PrmTypes... prms )
                requires (sizeof...(PrmTypes) == pCount)
            {
                auto arg_prms = std::array{ std::move(prms)... };

                auto args = [=]<auto...i>(value_container<i...>)
                {
                    return std::array{ evaluate<cast>(get<i>(args_tuple), arg_prms) ... };

                }(forward_sequence< (int) sizeof...(ArgTypes) + 1 >());

                return evaluate<cast>(target, args);
            };
        }
    }

    template<typename ObjType>
        decltype(auto) wrap(ObjType&& obj) noexcept
    {
        if constexpr(number_c<ObjType>)
            return std::forward<ObjType>(obj);
        else
        {
            return [=](auto... args)
                requires(sizeof...(args) == parameter_size_v<ObjType>)
            {
                return evaluate(obj, args...);
            };
        } 
    }

    ///////////////////////////////////////////////////////////
    
    template<gmp::gmp_non_cplx_c SType, std::floating_point FType>
    auto operator+(const SType& lhs, const std::complex<FType>& rhs) noexcept
    {
        return (FType)lhs + rhs;
    }

    template<std::floating_point FType, gmp::gmp_non_cplx_c SType>
    auto operator+(const std::complex<FType>& lhs, const SType& rhs) noexcept
    {
        return lhs + (FType)rhs;
    }

    template<gmp::gmp_non_cplx_c SType, std::floating_point FType>
    auto operator-(const SType& lhs, const std::complex<FType>& rhs) noexcept
    {
        return (FType)lhs - rhs;
    }

    template<std::floating_point FType, gmp::gmp_non_cplx_c SType>
    auto operator-(const std::complex<FType>& lhs, const SType& rhs) noexcept
    {
        return lhs - (FType)rhs;
    }

    template<gmp::gmp_non_cplx_c SType, std::floating_point FType>
    auto operator*(const SType& lhs, const std::complex<FType>& rhs) noexcept
    {
        return (FType)lhs * rhs;
    }

    template<std::floating_point FType, gmp::gmp_non_cplx_c SType>
    auto operator*(const std::complex<FType>& lhs, const SType& rhs) noexcept
    {
        return lhs * (FType)rhs;
    }

    template<gmp::gmp_non_cplx_c SType, std::floating_point FType>
    auto operator/(const SType& lhs, const std::complex<FType>& rhs) noexcept
    {
        return (FType)lhs / rhs;
    }

    template<std::floating_point FType, gmp::gmp_non_cplx_c SType>
    auto operator/(const std::complex<FType>& lhs, const SType& rhs) noexcept
    {
        return lhs / (FType)rhs;
    }

    ///////////////////////////////////////////////

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator+(ScalarType&& lhs, fType&& func)
    {
        return [lhs = std::forward<ScalarType>(lhs),
                func = std::forward<fType>(func)](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return lhs + gmp::apply(func, values);
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator+(fType&& func, ScalarType&& rhs)
    {
        return [rhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(func, values) + rhs;
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator-(ScalarType&& lhs, fType&& func)
    {
        return [lhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return lhs - gmp::apply(func, values);
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator-(fType&& func, ScalarType&& rhs)
    {
        return [rhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(func, values) - rhs;
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator*(ScalarType&& lhs, fType&& func)
    {
        return [lhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return lhs * gmp::apply(func, values);
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator*(fType&& func, ScalarType&& rhs)
    {
        return [rhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(func, values) * rhs;
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator/(ScalarType&& lhs, fType&& func)
    {
        return [lhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return lhs / gmp::apply(func, values);
        };
    }

    template<scalar_c ScalarType, function_c fType,
            int pCount = args_count_v<fType>>
    auto operator/(fType&& func, ScalarType&& rhs)
    {
        return [rhs, func](auto ... args)
            requires(sizeof...(args) == pCount)
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(func, values) / rhs;
        };
    }

    ///////////////////////////////////////////

    template<function_c lType, function_c rType,
        int lCount = args_count_v<lType>,
        int rCount = args_count_v<rType>>
    auto operator+(lType&& lhs, rType&& rhs)
    {
        return [lhs, rhs](auto ... args)
            requires(sizeof...(args) == std::max(lCount, rCount))
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(lhs, values) + gmp::apply(rhs, values);
        };
    }

    template<function_c lType, function_c rType,
        int lCount = args_count_v<lType>,
        int rCount = args_count_v<rType>>
    auto operator-(lType&& lhs, rType&& rhs)
    {
        return [lhs, rhs](auto ... args)
            requires(sizeof...(args) == std::max(lCount, rCount))
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(lhs, values) - gmp::apply(rhs, values);
        };
    }

    template<function_c lType, function_c rType,
        int lCount = args_count_v<lType>,
        int rCount = args_count_v<rType>>
    auto operator*(lType&& lhs, rType&& rhs)
    {
        return [lhs, rhs](auto ... args)
            requires(sizeof...(args) == std::max(lCount, rCount))
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(lhs, values) * gmp::apply(rhs, values);
        };
    }

    template<function_c lType, function_c rType,
        int lCount = args_count_v<lType>,
        int rCount = args_count_v<rType>>
    auto operator/(lType&& lhs, rType&& rhs)
    {
        return [lhs, rhs](auto ... args)
            requires(sizeof...(args) == std::max(lCount, rCount))
        {
            auto values = std::make_tuple(std::move(args)...);
            return gmp::apply(lhs, values) / gmp::apply(rhs, values);
        };
    }
}
// end of namespace gmp::operators

namespace gmp
{
    enum class DrvStencil { three_point, five_point, seven_point, nine_point };
    enum class DrvPivot { backward, centered, forward };

    enum class DrvTensor { jacobian, inverse_jacobian, metric, inverse_metric,
                           christoffel_1st, christoffel_2nd, riemann, ricci, scalar_curvature,
                           hessian, gradient, laplacian, divergence, curl, normal_derivative };

    template<typename CharType> std::basic_ostream<CharType>& 
        operator<<(std::basic_ostream<CharType>& os, DrvStencil ds)
    {
        switch(ds)
        {
            case DrvStencil::three_point: 
                os << "three_point"; return os;

            case DrvStencil::five_point: 
                os << "five_point"; return os;

            case DrvStencil::seven_point: 
                os << "seven_point"; return os;

            case DrvStencil::nine_point: 
                os << "nine_point"; return os;

            default:
                return os;
        }
    };

    template<typename CharType> std::basic_ostream<CharType>& 
        operator<<(std::basic_ostream<CharType>& os, DrvPivot dp)
    {
        switch(dp)
        {
            case DrvPivot::backward: 
                os << "backward"; return os;

            case DrvPivot::centered: 
                os << "centered"; return os;

            case DrvPivot::forward: 
                os << "forward"; return os;

            default:
                return os;
        }
    };
    
    // derivative operator
    template<auto... flags> struct drv_cmd{ };
    template<typename... Types> struct drv_cmds{ };

    // Gradient - Flux per unit length in the direction of maximum change.
    //
    //               𝑓 ( 𝑝 + Δ𝓁) - 𝑓(𝑝)    
    // ∇𝑓(𝑝) = lim ——————————————————————— 𝐥
    //        Δ𝓁⟶0         ‖Δ𝓁‖            
    //
    // d𝑓 = ∇𝑓 ⋅ d𝐫  
    template<auto... flags> struct grd_cmd{ };

    // lapacian operator
    template<auto... flags> struct lap_cmd{ };

    // Divergence - Flux per unit measure (line/area/volume)
    //
    //                 1      
    // ∇⋅𝐅(𝑝) = lim ——————— ∬ 𝐅 ⋅ d𝑆
    //         Δ𝑆⟶0  Δ𝑆 
    template<auto... flags> struct dvg_cmd{ };

    // Curl - Circulation per unit area
    //
    //                       1   
    // ∇ × 𝐹(𝑝) ⋅ 𝐧  = lim ————— ∮ 𝐅 ⋅ d𝓁
    //                Δ𝐴⟶0 Δ𝐴       
    //
    template<auto... flags> struct crl_cmd{ };

    template<auto... flags> struct jac_cmd{ };
    template<auto... flags> struct mtt_cmd{ };

    // Christoffel Symbols of the First Kind
    // 
    // 𝛤ᵢⱼₖ = (∂ⱼgᵢₖ + ∂ₖgᵢⱼ - ∂ᵢgⱼₖ) / 2
    //
    //  
    //
    //
    // 
    template<auto... flags> struct chr1_cmd{ };
    
    template<auto... flags> struct chr2_cmd{ };

    template<auto... flags> struct chr_cmd{ };

    // Raw Derivative Coefficients, 𝐴ᵏᵢⱼ 
    template<auto... flags> struct rdc_cmd{ };

    // Structure Coefficients, 𝐶ᵏᵢⱼ 
    template<auto... flags> struct stc_cmd{ };
        
    namespace hidden
    {
        template<typename T>
        struct st_is_drv_cmd: std::false_type{ };

        template<auto... flags>
        struct st_is_drv_cmd<drv_cmd<flags...>>: std::true_type{ };

        template<typename T>
        struct st_drv_cmd_flag_count
        { 
            constexpr static int value = 0;
        };

        template<auto... flags>
        struct st_drv_cmd_flag_count<drv_cmd<flags...>>
        {
            constexpr static int value = (int) sizeof...(flags);
        };
    }
    // end of namespace hidden

    template<typename T>
    concept drv_cmd_c = hidden::st_is_drv_cmd<T>::value;

    template<drv_cmd_c T>
    constexpr auto drv_cmd_flags_count_v = hidden::st_drv_cmd_flag_count<T>::value;

    namespace hidden
    {
        template<int N, auto flag, auto... flags>
        constexpr auto get_nth_flag(drv_cmd<flag, flags...>)
        {
            if constexpr(N==0)
                return flag;
            else
            {
                if constexpr( N > 0 && sizeof...(flags) > 0)
                    return get_nth_flag<N-1>(drv_cmd<flags...>{});
                else
                    return -1;
            }
        } 
    }
    // end of namespace hidden

    template<int N, drv_cmd_c DrvCmd>
    constexpr auto drv_cmd_flag = hidden::get_nth_flag<N>(DrvCmd{});

    enum class QdrKind { qdr_legendre, qdr_weighted, qdr_chebyshev1, qdr_chebyshev2,
                         qdr_jacobi, qdr_laguerre, qdr_hermite };
    
    template<typename T>
    concept bound_type_c = std::floating_point<std::remove_cvref_t<T>>
            || realnum_c<T> || complex_c<T>;

    namespace hidden
    {
        template<typename T>
        struct st_is_bound_func
        {
            constexpr static int pCount = parameter_count_v<T, float>;
            constexpr static bool value = pCount > 0 && pCount < MaxInvocableCount;
        };
    }
    // end of namespace hidden

    template<typename T>
    concept bound_func_c = hidden::st_is_bound_func<std::remove_cvref_t<T>>::value;
    
    template<typename T>
    concept intg_bound_c = bound_type_c<T> ||  bound_func_c<T>;

    template<int VarID, QdrKind qdrknd, int Nodes, auto Tolerance, auto MaxItr, 
                                        intg_bound_c LbType, intg_bound_c UbType>
    struct IntCmd
    {
        LbType lbound; UbType ubound;

        IntCmd(LbType lb, UbType ub) noexcept: lbound{ std::move(lb) }, ubound{ std::move(ub) } { }
    };

    namespace hidden
    {
        template<typename T>
        struct st_is_intcmd: std::false_type{ };
        
        template<int VarID, QdrKind QdrKnd, int Nodes, auto Tolerance,
                auto MaxItr, typename LbType, typename UbType>
        struct st_is_intcmd<IntCmd<VarID, QdrKnd, Nodes, Tolerance,
                MaxItr, LbType, UbType>>: std::true_type{ };

    }
    //end of namespace hidden

    template<typename T>
    concept intcmd_c = hidden::st_is_intcmd<std::remove_cvref_t<T>>::value;
    
    template<int... varid, QdrKind... qdrknd, int... nodes, auto... Tolerances,
                auto...MaxItrs, typename... LbTypes, typename... UbTypes>
    constexpr auto get_IntCmd_VarIDs(type_container< IntCmd<varid, qdrknd, nodes,
            Tolerances, MaxItrs, LbTypes, UbTypes>...>) noexcept
    {
        return gmp::value_container<varid...>{};
    }

    template<int... varid, QdrKind... qdrknd, int... nodes, auto... Tolerances,
                auto... MaxItrs, typename... LbTypes, typename... UbTypes>
    constexpr auto get_IntCmd_QdrKnds(type_container< IntCmd<varid, qdrknd, nodes,
                Tolerances, MaxItrs, LbTypes, UbTypes>...>) noexcept
    {
        return gmp::value_container<qdrknd...>{};
    }

    template<int... varid, QdrKind... qdrknd, int... nodes, auto... Tolerances,
                        auto... MaxItrs, typename... LbTypes, typename... UbTypes>
    constexpr auto get_IntCmd_Nodes(type_container< IntCmd<varid, qdrknd, nodes,
            Tolerances, MaxItrs, LbTypes, UbTypes>...>) noexcept
    {
        return gmp::value_container<nodes...>{};
    }

    template<int... varid, QdrKind... qdrknd, int... nodes, auto... Tolerances,
            auto... MaxItrs, typename... LbTypes, typename... UbTypes>
    constexpr auto get_IntCmd_LbTypes(type_container< IntCmd<varid, qdrknd, nodes,
            Tolerances, MaxItrs, LbTypes, UbTypes>...>) noexcept
    {
        return gmp::type_container<LbTypes...>{};
    }

    template<int... varid, QdrKind... qdrknd, int... nodes, auto... Tolerances,
        auto... MaxItrs, typename... LbTypes, typename... UbTypes>
    constexpr auto get_IntCmd_UbTypes(type_container< IntCmd<varid, qdrknd, nodes,
            Tolerances, MaxItrs, LbTypes, UbTypes>...>) noexcept
    {
        return gmp::type_container<UbTypes...>{};
    }   

    namespace hidden
    {
        template<typename T> 
        struct st_intg_bound
        {
            using lbound_type = non_type<>;
            using ubound_type = non_type<>;
        };

        template<int VarID, QdrKind qdrknd, int Nodes, auto Tolerance,
                auto MaxItr, typename LbType, typename UbType>
        struct st_intg_bound<IntCmd<VarID, qdrknd, Nodes, Tolerance, MaxItr, LbType, UbType>>
        {
            using lbound_type = LbType;
            using ubound_type = UbType;
        };

        template<typename T> 
        struct st_intg_bound_terminal: std::false_type{ };

        template<int VarID, QdrKind qdrknd, int Nodes, auto Tolerance,
                auto MaxItr, typename LbType, typename UbType>
        struct st_intg_bound_terminal< IntCmd<VarID, qdrknd, Nodes, Tolerance,
                MaxItr, LbType, UbType> >
        {
            constexpr static bool value = std::same_as<LbType, UbType>;
        };
    }
    // end of namespace hidden

    template<typename T>
    using lower_bound_t = typename hidden::st_intg_bound<std::remove_cvref_t<T>>::lbound_type;

    template<typename T>
    using upper_bound_t = typename hidden::st_intg_bound<std::remove_cvref_t<T>>::ubound_type;

    template<typename T>
    concept cmd_start_c = hidden::st_intg_bound_terminal<std::remove_cvref_t<T>>::value;

    template<int VarID, QdrKind qdrknd = QdrKind::qdr_legendre, int Nodes = 21,
        auto Tolerance = 0.0, auto MaxItr = 50, intg_bound_c LbType, intg_bound_c UbType>
    constexpr IntCmd<VarID, qdrknd, Nodes, Tolerance, MaxItr, LbType, UbType>
    create_intcmd(LbType lbound, UbType ubound) noexcept
    {
        return IntCmd<VarID, qdrknd, Nodes, Tolerance,
                        MaxItr, LbType, UbType>{lbound, ubound};
    };    
      
    namespace operators
    {
        // *****************************
        // itg stands for Integral AXis
        // itg<_z>(z1, z2);
        // _z: positional index for z-axis
        // z1: lower limit for the z-axis of the integration
        // z2: upper limit for the z-axis of the integration
        template<int VarID = 0, int Nodes = 21, auto Tolerance = 0.0,
                    auto MaxItr = 50, QdrKind qdrknd = QdrKind::qdr_legendre, 
                     intg_bound_c LbType, intg_bound_c UbType>
        constexpr IntCmd<VarID, qdrknd, Nodes, Tolerance, MaxItr, LbType, UbType>
        itg(LbType lbound, UbType ubound) noexcept
        {
            return IntCmd<VarID, qdrknd, Nodes, Tolerance,
                        MaxItr, LbType, UbType>{lbound, ubound};
        };

        // // *****************************
        // // iwq stands for Integral Weighted Quadrature
        // // iwq<_z>(z1, z2);
        // // _z: positional index for z-axis
        // // z1: lower limit for the z-axis of the integration
        // // z2: upper limit for the z-axis of the integration
        // template<int VarID = 0, int Splits = 7, int Nodes = 3, QdrKind qdrknd = QdrKind::qdr_weighted, 
        //              intg_bound_c LbType, intg_bound_c UbType>
        // constexpr IntCmd<VarID, qdrknd, Nodes, Splits, LbType, UbType>
        // iwq(LbType lbound, UbType ubound) noexcept
        // {
        //     return IntCmd<VarID, qdrknd, Nodes, Splits, LbType, UbType>{lbound, ubound};
        // };
    }
    // end of namespace operators;

    namespace literals
    {
        using gmp::cplx_float_t;
        using gmp::cplx_double_t;
        using gmp::cplx_quadruple_t;
        using gmp::cplx_octuple_t;
        using gmp::cplx_huge_t;
        using gmp::cplx_super_huge_t;

        using gmp::real_float_t;
        using gmp::real_double_t;
        using gmp::real_quadruple_t;
        using gmp::real_octuple_t;
        using gmp::real_huge_t;
        using gmp::real_super_huge_t;


        using enum DrvStencil; using enum DrvPivot;

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv3b = drv_cmd<three_point, backward, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv3c = drv_cmd<three_point, centered, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv3f = drv_cmd<three_point, forward, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv5b = drv_cmd<five_point, backward, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv5c = drv_cmd<five_point, centered, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv5f = drv_cmd<five_point, forward, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv7b = drv_cmd<seven_point, backward, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv7c = drv_cmd<seven_point, centered, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv7f = drv_cmd<seven_point, forward, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv9b = drv_cmd<nine_point, backward, VarID, Order, DX>{};
        
        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv9c = drv_cmd<nine_point, centered, VarID, Order, DX>{};

        template<auto VarID, auto Order, auto DX>
        inline constexpr auto drv9f = drv_cmd<nine_point, forward, VarID, Order, DX>{};

        ///////////////////////////////////////////////////////////////////////////////

        // template<DrvStencil stknd, DrvPivot drpv, auto DX> 
        // inline constexpr auto jacobian = jac_cmd<stknd, drpv, DX>{};

        // template<DrvStencil stknd, DrvPivot drpv, auto DX> 
        // inline constexpr auto metric_tensor = mtt_cmd<stknd, drpv, DX>{};

        using enum QdrKind;
    }
    // end of namespace literals

    namespace hidden
    {
        template<std::integral EleType>
        EleType fma(EleType a, EleType b, EleType c) noexcept
        {
            return a * b + c;
        }

        template<std::floating_point EleType>
        EleType fma(EleType a, EleType b, EleType c) noexcept
        {
            return std::fma(a, b, c);
        }

        template<std::floating_point EleType>
        std::complex<EleType> fma(std::complex<EleType> a,
                std::complex<EleType> b, std::complex<EleType> c) noexcept
        {
            return a * b + c;
        }

        inline intnum fma(const intnum& a,
            const intnum& b, const intnum& c) noexcept
        {
            intnum x;
            mpz_mul(x.mpz_ptr(), a.mpz_srcptr(), b.mpz_srcptr());
            mpz_add(x.mpz_ptr(), x.mpz_srcptr(), c.mpz_srcptr());
            return x;
        }

        inline ratnum fma(const ratnum& a, 
            const ratnum& b, const ratnum& c) noexcept
        {
            ratnum x;
            mpq_mul(x.mpq_ptr(), a.mpq_srcptr(), b.mpq_srcptr());
            mpq_add(x.mpq_ptr(), x.mpq_srcptr(), c.mpq_srcptr());
            return x;
        }

        template<mpfr_prec_t Prec, mpfr_rnd_t RndMode>
        inline realnum<Prec, RndMode> fma(const realnum<Prec, RndMode>& a,
                const realnum<Prec, RndMode>& b, const realnum<Prec, RndMode>& c) noexcept
        {
            realnum<Prec, RndMode> x;
            mpfr_mul(x.mpfr_ptr(), a.mpfr_srcptr(), b.mpfr_srcptr(), RndMode);
            mpfr_add(x.mpfr_ptr(), x.mpfr_srcptr(), c.mpfr_srcptr(), RndMode);
            return x;
        }

        template<mpfr_prec_t Prec, mpc_rnd_t Rnd>
        cplxnum<Prec, Rnd> fma(const cplxnum<Prec, Rnd>& a, 
            const cplxnum<Prec, Rnd>& b, const cplxnum<Prec, Rnd>& c) noexcept
        {
            cplxnum<Prec, Rnd> x;
            mpc_mul(x.mpc_ptr(), a.mpc_srcptr(), b.mpc_srcptr(), Rnd);
            mpc_add(x.mpc_ptr(), x.mpc_srcptr(), c.mpc_srcptr(), Rnd);
            return x;
        }
    }
    // end of namespace hidden
    
    template<number_c AType, number_c BType, number_c CType>
    auto fma(AType&& a, BType&& b, CType c) noexcept
    {
        using ele_t = common_type_t<AType, BType, CType>;
        
        return hidden::fma( Gmp_Forward(ele_t, a),
                            Gmp_Forward(ele_t, b),
                            Gmp_Forward(ele_t, c) );
    }

    template<typename ExpType>
        requires one_of_c<ExpType, unsigned, unsigned long, unsigned long long>
    inline auto pow(const intnum& op, ExpType ex)
    {
        intnum result;

        mpz_pow_ui(result.mpz_ptr(), op.mpz_srcptr(), (unsigned int)ex);

        return result;
    }

    template<typename ExpType>
        requires one_of_c<ExpType, int, long, long long>
    inline auto pow(const intnum& op, ExpType ex)
    {
        if (ex > 0)
        {
            return ratnum{ pow(op, (unsigned)ex ) };
        }
        else if(ex == 0)
        {
            return ratnum{ }; 
        }
        else // ex < 0
        {          
            return ratnum{ intnum{"1"}, pow(op, (unsigned)-ex ) };
        }
    }

    template<valid_function_c LambdaType>
    std::ostream& operator>>(std::ostream& os, LambdaType&&)
    {
        auto fc = func_cat_v<LambdaType>;

        os << fc;

        if(fc != FuncCat::unknown )
            os <<" taking " << (arity_v<LambdaType>) << " arguments";
        
        return os;
    }

    template<valid_function_c LambdaType>
    std::ostream& operator<(std::ostream& os, LambdaType&&)
    {
        // auto fc = func_cat_v<LambdaType>;

        // // os << fc;

        // if(fc != FuncCat::unknown )
        
        os <<"L" << (arity_v<LambdaType>);

        return os;
    }

    template<typename ArgType>
        requires (!gmp_type_c<ArgType> && !valid_function_c<ArgType>)
    std::ostream& operator>>(std::ostream& os, ArgType&& arg)
    {
        using T = std::remove_cvref_t<ArgType>;
        os <<Gmp_GetTypeName(T); return os;
    }

    template<typename T, typename X>
    auto eval_poly(const std::tuple<PolyMode, std::vector<T>>& fn, X x)
    {
        using ele_t = common_type_t<T, X>;

        auto& [pmode, a] = fn;

        if (a.empty()) return ele_t{ };

        const int N = (int) a.size();
                   
        if (pmode == PolyMode::canonical)
        {    
            // constant coefficient comes first
            // a_0 + a_1 x + a_2 x^2 + a_3 x^3, N = 4
            // a_0 + x (a_1 + x (a_2 + a_3 x)), 
            //                   N-2      N-1 
            ele_t result = static_cast<ele_t>( a.back() ); // N - 1

            for (int i = N - 2; i >= 0; --i)  // i = N-2, ..., 0
            {
                // using Horner's Rule
                // result = a[i] + result * x
                result = fma(x, result, a[i]); 
            }
            
            return result;
        }
        
        // the highest order coefficient comes first
        else //if(pmode == PolyMode::standard)
        {
            // a_0 x^3 + a_1 x^2 + a_2 x + a_3
            // ((a_0 x + a_1) x + a_2) x + a_3
            ele_t result = static_cast<ele_t>( a.front() );

            for (int i = 1; i < N; ++i)
            {
                // result = x * result + a[i]
                result = fma(x, result, a[i]); 
            }

            return result;
        }
    }

    namespace hidden
    {
        /*
            (x+y)^p = x^p (1 + y/x)^p = y^p (1 + x/y)^p

            (n k) = (n, n-k), only when n is non-negative integer
            (n k) * k! = nPr

            1. p = n = 0, 1, 2, ... non-negative integer

            (1+x)^n = sum { k = 0, n } (n k) x^k
                    
                        = (n 0)x^0 + (n 1)x^1 + (n 2)x^2 + ... + (n n)x^n
                        
                                 n          n (n-1)         n (n-1) (n-2)
                        = 1 + --------x + ----------x^2 + ----------------x^3 + ... + 1 x^n
                                 1!            2!                  3!

            2. p = -1, -2, -3, ... negative integer
               n = -p, p = -n

               (1+x)^p = (1+x)^{-n}
                       = sum { k = 0, infinity}
                              
                                  (-n)        (-n)( (-n) - 1))         (-n)( (-n) - 1))( (-n) - 2))
                       = 1 x^0 + ------x^1 + ------------------ x^2 + ------------------------------ x^3 + 
                                   1!             2!                              3!            

                 (-n)( (-n) - 1))( (-n) - 2))               n (n + 1) (n + 2)
                 ------------------------------ = (-1)^3  ---------------------- = (-1)^k (n+k-1 k)
                              3!                                     3!
               
               sum { k = 0, infinity } (-1)^k(n+k-1 k) x^k

            3. p = non-integral real number 
                                 
                                  p             p(p-1)       p (p-1) (p-2)
                (1+x)^p = 1 + ---------x^1 + ----------x^2 + ------------- x^3 + 
                                  1!             2!                 3!
                        = sum { k = 0, k = infinity} (p k) x^k
                        
            4. p complex nummber
        */

        // ArgType p can be any integer, i.e., ... -2, -1, 0, 1, 2, ...
        template<primi_integer_c ArgType, primi_integer_c KType>
        auto binomial(ArgType p, unsigned long k) noexcept
        {
            if constexpr(std::is_signed_v<ArgType>)
            {
                // when p < 0,
                //
                //  (p, k) = (-n, k) = (-1)^k (n + k - 1 k)
                //
                intnum rop; intnum z{p};
                mpz_bin_ui(rop.mpz_ptr(), z.mpz_srcptr(), k);               
                return hidden::mpz_get_integer<ArgType>(rop.mpz_srcptr());
            }
            else
            {
                intnum rop;
                mpz_bin_uiui(rop.mpz_ptr(), (unsigned long)p, k);               
                return hidden::mpz_get_integer<ArgType>(rop.mpz_srcptr());
            }
        }

        // p can be any integer negative, or non-negative
        inline intnum binomial(const intnum& p, unsigned long k)
        {
            intnum rop;
            mpz_bin_ui(rop.mpz_ptr(), p.mpz_srcptr(), k);
            return rop;
        }

        // KType k should always be non-negative integer, i.e., 0, 1, 2, 3 ...
        void binomial_rational(mpq_t result, const mpq_t alpha, unsigned long k)
        {
            mpq_t term, i_q, denom_q;
            mpq_init(term);
            mpq_init(i_q);
            mpq_init(denom_q);
            mpq_set_ui(result, 1, 1); // result = 1

            for (unsigned long i = 0; i < k; ++i)
            {
                mpq_set_ui(i_q, i, 1);         // i_q = i
                mpq_sub(term, alpha, i_q);     // term = alpha - i
                mpq_mul(result, result, term); // result *= term
            }

            // Compute k! as mpq_t
            mpz_t denom_z;
            mpz_init_set_ui(denom_z, 1);
            for (unsigned long i = 2; i <= k; ++i)
                mpz_mul_ui(denom_z, denom_z, i);

            mpq_set_z(denom_q, denom_z);      // denom_q = k!
            mpq_div(result, result, denom_q); // result /= k!
            mpq_canonicalize(result);         // ensure result is in reduced form

            mpz_clear(denom_z);
            mpq_clear(term);
            mpq_clear(i_q);
            mpq_clear(denom_q);
        }
        
        // KType k should always be non-negative integer, i.e., 0, 1, 2, 3 ...
        template<ratnum_c rType>
        rType binomial(rType r, unsigned long n) noexcept
        {
            ratnum x{};

            binomial_rational(x.mpq_ptr(), r.mpq_srcptr(), n);

            return x;
        }

        // template<realnum_c rType>
        // rType binomial(rType r, unsigned long n) noexcept
        // {
        
        template<floating_number_c rType>
        rType binomial(rType r, unsigned long n) noexcept
        {
            auto result = tgamma(r+1) / ( tgamma(n+1) * tgamma(r-n+1) );

            if( isfinite(result) ) return result;

            /*
                        rPn     6 * 5 * 4 * 3
                (6 4) = ---- = -----------------
                         n!     1 * 2 * 3 * 4

                         r  * (r-1) * (r-2) * ... * (r-n+1)    
                (r n) = ------------------------------------
                         1  *   2   *   3   * ... *    n

                    (r-2)    (r - (3 - 1))   (r - (k - 1))
                    ----- = -------------- = -------------
                      3            3               k
            */

            // If not finite, r is likely a negative integer (pole of Gamma)
            // Fallback: use iterative product formula
            result = 1;

            for (unsigned long k = 0; k < n; ++k)
            {
                result *= (r - k) / (k + 1);
            }

            return result;
        }

        template<complex_c rType>
        rType binomial(rType r, unsigned long n) noexcept
        {
            // numerator = r * (r-1) * ... * (r-n+1)cls
            rType num{1};
            using real_t = real_type_t<float, rType>;

            for (unsigned long k = 0; k < n; ++k)
                num *= (r - (rType)k);

            return num / (real_t)factorial(n);
        }

    }
    // end of namespace hidden

    template<typename ReturnType = non_type<>, 
        number_c rType, number_c nType>
    auto binomial(rType&& r, nType n) noexcept
    {
        if constexpr(non_type_c<ReturnType>)
            return hidden::binomial(std::forward<rType>(r), (unsigned long)n);
        else
            return static_cast<ReturnType>(hidden::binomial(std::forward<rType>(r), (unsigned long)n));
    }

    /////////////////////////////////////////////////////////////////////
    template<typename CandidateType = non_type<>, integral_number_c NType>
    auto factorials(NType n) noexcept
    {
        using ele_t = 
            std::conditional_t< same_c<CandidateType, non_type<>>, NType, CandidateType>;

        std::vector<ele_t> fact;
        fact.reserve((int)n + 1); // +1 for 0!
        
        fact.emplace_back(1); NType k = 1;
        
        while(k <= n)
        {
            fact.emplace_back(fact.back()* k); ++k;
        }
        
        return fact;
    }

    // (n, 0), (n, 1), ..., (n, n)
    template<typename CandidateType = non_type<>, integral_number_c NType>
    auto binomials(NType n) noexcept
    {
        using ele_t = 
            std::conditional_t< same_c<CandidateType, non_type<>>, NType, CandidateType>;

        std::vector<ele_t> coeffs;
        
        coeffs.reserve((int)n + 1); // +1 elements for nCr's r = 0,..., n
        // (int)n, the cast is required for n of type real

        if(n == 0)
        {
            coeffs.emplace_back(1); return coeffs;
        }
        else if(n == 1)
        {
            coeffs.emplace_back(n);
            coeffs.emplace_back(n);
            return coeffs;
        }

        /*
            we can actually create only half of the combinations if n is non-negative integers,
            but for simplicity and convenience when consuming them, we just create full combinations.

            NOTE: (n, r) != (n, n-r) for real n
        */
        
        NType k   {1};

        coeffs.emplace_back( 1 );
       
        if( n % NType{2} ) // remainder is not zero, i.e., odd n = 3, 5, 7, 
        {
            NType half_n = (n+1) / 2;

            while(k < half_n) // k = 1, 2, ..., half_n - 1
            {
                // (n, k+1) = (n, k) * (n-k) / (k+1)
                // the above is mathematically correct, but algorithmically WRONG.
                //
                // (n, k)  = (n, k-1) * (n-k+1) / k
                // the above is mathematically correct, ALGORITHMICALLY CORRECT.
                // 

                // prev = prev * (n-k+1) / k; ++k;
                
                coeffs.emplace_back( coeffs.back() * (n-k+1) / k ); ++k;
            }

            while(k != 0) // k = half_n, ... 0
            {
                coeffs.emplace_back( coeffs[(int)k-1]); --k;
            }
        }
        else // even n = 2, 4, 6, 
        {
            NType half_n = n / 2;

            while(k <= half_n) // k = 1, 2, ..., half_n
            {
                // (n, k+1) = (n, k) * (n-k) / (k+1)
                // the above is mathematically correct, but algorithmically WRONG.
                //
                // (n, k)  = (n, k-1) * (n-k+1) / k
                // the above is mathematically correct, ALGORITHMICALLY CORRECT.
                // 

                // prev = prev * (n-k+1) / k; ++k;
                
                coeffs.emplace_back( coeffs.back() * (n-k+1) / k ); ++k;
            }

            while(k != 1) // k = half_n-1, ... 0
            {
                coeffs.emplace_back( coeffs[(int)k-2]); --k;
            }
        }

        return coeffs;
    }

    /*
        Ln^alpha(x) = sum (-1)^k / k! (n+alpha, n-k) x^k
                    = sum C_k x^k
        C_k = (-1)^k / k! (n+alpha, n-k)
        C_k = -(n-k+1)/(k (k+alpha)) C_{k-1}
    */
    template<typename CandidateType = non_type<>,
                        number_c NType, number_c AType>
    auto coefficients_laguerre(NType n, AType alpha, PolyMode pmode) noexcept
    {
        using operators::operator*;
        using operators::operator/;
        using operators::operator+;
        using operators::operator-;

        using common_t = common_type_t<NType, AType, ratnum>;

        using ele_t = std::conditional_t<
            same_c<CandidateType, non_type<>>, common_t, CandidateType>;

        std::vector<ele_t> coeffs;
        
        coeffs.reserve((int)n + 1); 
        if(n == 0)
        {
            coeffs.emplace_back(1); 

            return std::tuple{ pmode, coeffs };
        }
           
        NType k   {1};

        coeffs.emplace_back( gmp::binomial(n + alpha, n) );
       
        while(k <= n ) // k = 1, 2, ..., n
        {
            /*
                coeff_k = coeff_{k-1} * (k - n - 1)/ (k * ( k + alpha) )
            */
            coeffs.emplace_back( coeffs.back() * ( k - n - 1) / (k * (k + alpha)) );
            
            ++k;
        }

        if (pmode == PolyMode::standard)
            std::ranges::reverse(coeffs);

        return std::tuple{ pmode, coeffs };
    }

    template<typename CandidateType = non_type<>, number_c NType>
    auto coefficients_laguerre(NType n, PolyMode pmode) noexcept
    {
        return coefficients_laguerre<CandidateType>(n, NType{0}, pmode);
    }

    template<typename CandidateType = non_type<>, number_c NType>
    auto coefficients_laguerre(NType n) noexcept
    {
        return coefficients_laguerre<CandidateType>(n, NType{0}, PolyMode::canonical);
    }

    template<int M, typename EleType>
    auto derivative_poly(std::tuple<PolyMode, std::vector<EleType>> fn) noexcept
    {
        using operators::operator*;
        using operators::operator/;
        using operators::operator+;
        using operators::operator-;

        auto& [pmode, coeffs] = fn;

        if(coeffs.empty()) return fn;

        if (PolyMode::standard == pmode)
                std::ranges::reverse(coeffs);

        int n = coeffs.size();

        for (int m = 0; m < M; ++m)  
        {
            for(int k = m+1; k < n; ++k)
            {
                coeffs[k] *= k - m;
            }
        }

        // coeffs.erase(coeffs.begin(), std::min(coeffs.begin() + M, coeffs.end()));
        coeffs.erase(coeffs.begin(), coeffs.begin() + std::min<int>(M, n));

        if (PolyMode::standard == pmode)
            std::ranges::reverse(coeffs);       
        
        return fn;
    }
    
    // Householder's method
    // https://en.wikipedia.org/wiki/Householder%27s_method
    template<SolveMethod smethod = SolveMethod::newton, number_c EleType>
    auto fn_over_dfn(const std::tuple<PolyMode, std::vector<EleType>>& fn) noexcept
    {        
        using operators::operator*;
        using operators::operator/;
        using operators::operator+;
        using operators::operator-;
        
        if constexpr(smethod == SolveMethod::newton) // Newton–Raphson
        {
            return [=, dfn = derivative_poly<1>(fn)](auto x)
            {
                auto f  = eval_poly(fn,  x);
                auto fp = eval_poly(dfn, x);
                return f / fp;
            };
        }
        else if constexpr(smethod == SolveMethod::halley) // Halley or Householder 2nd order
        {
            return [=, dfn1 = derivative_poly<1>(fn),
                       dfn2 = derivative_poly<2>(fn)](auto x)
            {
                // Householder's method
                // https://en.wikipedia.org/wiki/Householder%27s_method

                auto f   = eval_poly(fn,   x);
                auto fp  = eval_poly(dfn1, x);
                auto fpp = eval_poly(dfn2, x);

                // Δ = (2 f f') / ( 2 (f')^2 - f f'' )
                return (2 * f * fp) / (2 * fp * fp - f * fpp);
            };
        }
        else if constexpr(smethod == SolveMethod::householder)// Householder (order-3; uses up to f''')
        {
            return [=, dfn1 = derivative_poly<1>(fn),
                        dfn2 = derivative_poly<2>(fn),
                        dfn3 = derivative_poly<3>(fn)](auto x)
            {
                auto f    = eval_poly(fn,   x);
                auto fp   = eval_poly(dfn1, x);
                auto fpp  = eval_poly(dfn2, x);
                auto fppp = eval_poly(dfn3, x);

                // Householder's method
                // https://en.wikipedia.org/wiki/Householder%27s_method

                // Δ = (6 f (f')^2) / ( 6 (f')^3 - 3 f f' f'' + f^2 f''' )
                return (6 * f * fp * fp) / (6 * fp * fp * fp - 3 * f * fp * fpp + f * f * fppp);
            };
        }
    }

    /*
        Pn(x) = sum {k=0, n} a_{n, k} x^k
        returns a_{n, k},

        Pn(x) = 2^n * sum {k=0, n} (n, k) (n + k -1, n) x^k
        a_{n, k} = -(n - k + 2)*( n - k + 1) / (k * (k-1) ) * a_{n,k-2} 
    */
    // template<rational_or_floating_number_c EleType = ratnum,
    //          PolyMode pmode = PolyMode::standard,
    //          integral_number_c NType, integral_number_c FactType>
    // std::vector<EleType>
    //     coefficients_Pn(NType n, const std::vector<FactType>& facts) noexcept
    // {
    //     std::vector<EleType> Pn;
    //     Pn.reserve( (int) n+1 ); // +1 for constant term
        
    //     // computation coefficients as ascending degree order or taylor mode

    //     // Pn(x) = 2^n * sum {k=0, n} (n, k) ((n + k - 1)/2, n) x^k
    //     //       = sum {k=0, n} (n, k) * (n+k, k) ( (x-1)/2 )^k 
    //     // a_{n, k} = -(n - k + 2)*( n - k + 1) / (k * (k-1) ) * a_{n,k-2} 
    //     //          = 2^n * (n, k) * ((n + k - 1)/2, n)
        
    //     // when n=2m, even, k = 0
    //     //  (n, k) ((n + k - 1)/2, n) = (2m, 0) ((2m-1)/2, 2m)
    //     //                            = ( (2m-1) / 2, 2m)   

    //     if constexpr(pmode == PolyMode::canonical)
    //         return Pn;
    //     else
    //     {
    //         return std::ranges::reverse(Pn);
    //     }
    // }
}
// end of namespace gmp

#endif 
// end of file