#ifndef _GMP_OUTPUT_HPP
#define _GMP_OUTPUT_HPP

#include "gmp_base.hpp"

namespace gmp::output
{
    using gmp::operator<<;
    using gmp::operator>>;
    
    template<typename S, typename T>
    std::ostream& operator<<(std::ostream& os, const std::pair<S, T>& p)
    {
        os <<"< ";
        
        if constexpr(ratnum_or_cplxnum_c<S>)
            os << p.first.flat(0);
        else if constexpr(valid_function_c<S>)
            os >> p.first;
        else
            os << p.first;

        os << ", ";

        if constexpr(ratnum_or_cplxnum_c<T>)
            os << p.second.flat(0);
        else if constexpr(valid_function_c<T>)
            os < p.second;
        else
            os << p.second;
            
        os << " >";

        return os;
    }
    
    // Forward declarations
    template<typename T> void print_element(std::ostream& os, const T& value);
    void print_element(std::ostream& os, const char* str);

    template<typename... Ts> void print_element(std::ostream& os, const std::tuple<Ts...>& tup);

    // Print array<T, N> element
    template<typename T, std::size_t N>
    void print_element(std::ostream& os, const std::array<T, N>& arr)
    {
        os << "(";
        for (std::size_t i = 0; i < N; ++i)
        {
            if (i > 0) os << ", ";

            if constexpr(ratnum_or_cplxnum_c<T>)
                print_element(os, arr[i].flat(0));
            else
                print_element(os, arr[i]);
        }
        os << ")";
    }

    // Print vector element
    template<vector_c T>
    void print_element(std::ostream& os, const T& v)
    {
        using ele_t = typename T::value_type;

        os << "[ ";
        for (std::size_t i = 0; i < v.size(); ++i)
        {
            if (i > 0) os << ", ";
            
            if constexpr(ratnum_or_cplxnum_c<ele_t>)
                print_element(os, v[i].flat(0));
            else
                print_element(os, v[i]);
        }
        os << " ]";
    }

    template<typename T>
    void print_element(std::ostream& os, const T& value)
    {
        if constexpr(valid_function_c<T>)
            os < value;
        else
            os << value;
    }

    inline void print_element(std::ostream& os, const char* str)
    {
        os << "\"" << str << "\"";
    }

    template<std::size_t I = 0, typename... Ts>
    void print_tuple_elements(std::ostream& os, const std::tuple<Ts...>& tup)
    {
        if constexpr (I < sizeof...(Ts))
        {
            if constexpr (I > 0) os << ", ";
            
            using ele_t = std::tuple_element_t<I, std::tuple<Ts...>>;

            if constexpr(ratnum_or_cplxnum_c<ele_t>)
                print_element(os, std::get<I>(tup).flat(0));
            else
                print_element(os, std::get<I>(tup));

            print_tuple_elements<I + 1>(os, tup);
        }
    }

    template<typename... Ts>
    void print_element(std::ostream& os, const std::tuple<Ts...>& tup)
    {
        os << "{ ";
        print_tuple_elements(os, tup);
        os << " }";
    }

    // Final operator overload calls print_element
    template<typename... Ts>
    std::ostream& operator<<(std::ostream& os, const std::tuple<Ts...>& tup)
    {
        print_element(os, tup);
        return os;
    }

    template<typename T, std::size_t N>
    std::ostream& operator<<(std::ostream& os, const std::array<T, N>& arr)
    {
        print_element(os, arr);
        return os;
    }

    template<vector_c T>
    std::ostream& operator<<(std::ostream& os, const T& v)
    {
        print_element(os, v); return os;
    }
}

#endif
