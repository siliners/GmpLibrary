﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.08.17
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/    

0. Primary declaration
    template<typename DimType, typename CntrType> class tensor;

    Tensor of values
S1. template<typename EleType, int Dim, std::size_t M> requires (Dim == M) 
        class tensor<value_container<Dim>, std::array<EleType, M>>

    Tensor of values
S2. template<typename EleType, int Rows, int Cols, int... Dims, std::size_t M> 
        requires (Rows * (Cols * ... * Dims) == M)
        class tensor<value_container<Rows, Cols, Dims...>, std::array<EleType, M>>

    Tensor of functions
S3. template<typename EleType, typename... EleTypes>
    class tensor<value_container< (int)sizeof...(EleTypes)+1 >,
            std::tuple<EleType, EleTypes...>>

    Tensor of functions
S4. template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    class tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>

    Tensor of values
S5. template<int Dim, int... Dims, typename EleType> 
        class tensor<value_container<Dim, Dims...>, std::vector<EleType>>

Tensor of values
    I will Merge S1, S2, S5 to a single specialization.

Tensor of functions
    I will Merge S3 and S4 to a single specialization.
    I may change the design in future.

////////////////////////////////////////////////////////////
enum class MtrxKind { full, upper_triangular, lower_triangular, diagonal };

0. Primary declaration
    template<typename DimType, typename CntrType> class tensor;

    Tensor of values
S1. template<MtrxKind mknd = MtrxKind::full, typename EleType, int Dim, std::size_t M> requires (Dim == M) 
        class tensor<value_container<mknd, Dim>, std::array<EleType, M>>

    Tensor of values
S2. template<MtrxKind mknd = MtrxKind::full, typename EleType, int Rows, int Cols, int... Dims, std::size_t M> 
        requires (Rows * (Cols * ... * Dims) == M)
        class tensor<value_container<mknd, Rows, Cols, Dims...>, std::array<EleType, M>>

    Tensor of functions
S3. template<MtrxKind mknd = MtrxKind::full, typename EleType, typename... EleTypes>
    class tensor<value_container<mknd, (int)sizeof...(EleTypes)+1 >,
            std::tuple<EleType, EleTypes...>>

    Tensor of functions
S4. template<MtrxKind mknd = MtrxKind::full, typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    class tensor<value_container<mknd, Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>

    Tensor of values
S5. template<MtrxKind mknd, int Dim, int... Dims, typename EleType> 
        class tensor<value_container<mknd, Dim, Dims...>, std::vector<EleType>>

    //////////////////////////////////////////////////////////////
    
    DEFINITIONS (no ambiguity)

    Primal basis:    { e_i }
    Dual basis:      { e^i } with e^i · e_j = δ^i_j
    Coordinate partial:   ∂_i ≡ ∂/∂u^i  (commuting)
    Directional deriv.:   D_i ≡ (e_i · ∇)   (need not commute)

    RAW DERIVATIVE COEFFICIENTS (what drv_cmd computes)
    A^k_{ij}  :=  e^k · ( ∂_i e_j )
    ⇔  ∂_i e_j  =  A^m_{ij} e_m

    STRUCTURE COEFFICIENTS (stc_cmd)
    C^k_{ij}  :=  e^k · ( ∂_i e_j - ∂_j e_i )
    ⇔  C^k_{ij} = A^k_{ij} - A^k_{ji}
    (equivalently from commutator [e_i,e_j] if using directional derivatives)

    CHRISTOFFEL (Levi–Civita, connection coefficients) — general frame form:
    G^i_{jk} := 1/2 g^{iℓ} ( e_j g_{kℓ} + e_k g_{jℓ} - e_ℓ g_{jk}
                             + c_{jkℓ} + c_{ℓ j k} - c_{kℓ j} )
    where c_{jkℓ} = g_{ℓ m} c^m_{jk}, and c^m_{jk} = coefficients of [e_j,e_k].

    RELATION (library canonical split)
    A^k_{ij} = G^k_{ij} + C^k_{ij}

    TORSION (general)
    T^k_{ij} = G^k_{ij} - G^k_{ji} - C^k_{ij}
    (For Levi–Civita: T^k_{ij} = 0 ⇒ G^k_{ij}-G^k_{ji} = C^k_{ij}.)

    USAGE RULES:
    - If V is the position map R(u) (so e_j = ∂_j R) → coordinate/holonomic:
        * C^k_{ij} = 0, A^k_{ij} = G^k_{ij}.
        * You may compute Γ from metric formula Γ = 1/2 g^{-1}(∂g + ∂g - ∂g).
    - If V is not the position map (or if you normalize R) → anholonomic:
        * drv_cmd → yields A (raw).
        * compute C via antisymmetrized drv_cmd: C = A - A^T.
        * get G as G = A - C.


================================================================

Gradient - Flux per unit length in the direction of maximum change.
    
                  𝑓 ( 𝑝 + Δ𝓁) - 𝑓(𝑝)    
    ∇𝑓(𝑝) = lim ——————————————————————— 𝐥
           Δ𝓁⟶0         ‖Δ𝓁‖            
    
    d𝑓 = ∇𝑓 ⋅ d𝐫  

Divergence - Flux per unit measure (line/area/volume - curve / surface / solid)
    
                    1      
    ∇⋅𝐅(𝑝) = lim ——————— ∬ 𝐅 ⋅ d𝑆
            Δ𝑆⟶0   Δ𝑆 

Curl - Circulation per unit area
    
                           1   
    ∇ × 𝐹(𝑝) ⋅ 𝐧  = lim —————— ∮ 𝐅 ⋅ d𝓁
                   Δ𝐴⟶0  Δ𝐴       
    
============ Ambient Approach vs. Instrinsic Approach ================================

1. Perspective

    Ambient Approach - Views the surface from the outside, in 3D space.
    Intrinsic Approach - Views the surface from the inside, using its own geometry.

    Ambient space (mathematics)
    https://en.wikipedia.org/wiki/Ambient_space_(mathematics)

2. Input

    Ambient Approach - Requires both the 3D vector field 𝐅 and the surface normal 𝐧.
    Intrinsic Approach - Requires the vector field's components (𝐅ᵘ, 𝐅ᵛ) and the
    metric tensor's determinant (g) in surface coordinates.
    
3. Calculation

    Ambient Approach - First computes a 3D curl, then takes a dot product.
    Intrinsic Approach - Directly computes a curl-like operations using partial derivatives
    with respect to the surface parameters.

4. Applicability

    Ambient Approach - Works when the surface is embedded in a higher-dimensional spaces.
    Intrinsic Approach - Can be generalized to any 2D manifold, even if it cannot be easily
    embedded in 3D space.

====================== Metric Tensor ===================================

∇ⱼVᵏ = 𝐞ᵏ⋅ ∂ⱼ(Vⁱ𝐞ᵢ)

Finding the Components

We start with the relationship.

    𝐅 = 𝐅ᵤ 𝐫ᵤ + 𝐅ᵥ 𝐫ᵥ          (1)

1. Dot Product with 𝐫ᵤ: Take the dot product of both sides of Equation (1) with 𝐫ᵤ:

   𝐅 ⋅ 𝐫ᵤ = (𝐅ᵤ 𝐫ᵤ + 𝐅ᵥ 𝐫ᵥ) ⋅ 𝐫ᵤ

Using the distributive property of the dot product:

    𝐅 ⋅ 𝐫ᵤ = 𝐅ᵤ (𝐫ᵤ ⋅ 𝐫ᵤ) + 𝐅ᵥ (𝐫ᵥ ⋅ 𝐫ᵤ)

We can express the dot products in terms of the metric tensor components,
gᵢⱼ = 𝐫ᵢ ⋅ 𝐫ⱼ

    𝐅 ⋅ 𝐫ᵤ = 𝐅ᵤ gᵤᵤ + 𝐅ᵥ gᵥᵤ    (2)

2. Dot Product with 𝐫ᵥ: Take the dot product of both sides of Equation (1) with 𝐫ᵥ:

   𝐅 ⋅ 𝐫ᵥ = (𝐅ᵤ 𝐫ᵤ + 𝐅ᵥ 𝐫ᵥ) ⋅ 𝐫ᵥ

Using the distributive property of the dot product:

    𝐅 ⋅ 𝐫ᵥ = 𝐅ᵤ (𝐫ᵤ ⋅ 𝐫ᵥ) + 𝐅ᵥ (𝐫ᵥ ⋅ 𝐫ᵥ)

We can express the dot products in terms of the metric tensor components,
gᵢⱼ = 𝐫ᵢ ⋅ 𝐫ⱼ

    𝐅 ⋅ 𝐫ᵥ = 𝐅ᵤ gᵤᵥ + 𝐅ᵥ gᵥᵥ    (3)

Now we have a system of two linear equations, (2) and (3), with two unknowns,
𝐅ᵤ and 𝐅ᵥ:

    | 𝐅 ⋅ 𝐫ᵤ |   | gᵤᵤ  gᵤᵥ | 𝐅ᵤ   
    |       | = |          |                (4)
    | 𝐅 ⋅ 𝐫ᵥ |   | gᵥᵤ  gᵥᵥ | 𝐅ᵥ

    | 𝐅ᵤ |    | gᵤᵤ  gᵤᵥ |⁻¹  | 𝐅 ⋅ 𝐫ᵤ |
    |    | =  |          |  ⋅  |       |
    | 𝐅ᵥ |    | gᵥᵤ  gᵥᵥ |    | 𝐅 ⋅ 𝐫ᵥ |

This system can be solved using standard linear algebra methods, such as Cramer's Rule
or matrix inversion.

By solving this system, we can find the expressions for 𝐅ᵤ and 𝐅ᵥ. This process is essential
for converting a vector field from a Cartesian representation (in terms of ̂x, ̂y, ̂z ) to a
representation in terms of the surface basis vectors (𝐫ᵤ, 𝐫ᵥ), which is required for calculating
intrinsic properties like surface divergence and curl.

In the argument above, the vector field 𝐅 and the surface 𝐫 are originally represented
with respect to the ambient coordinate system, such as Cartesian Coordinate system.
For example, 𝐅 = Fx(u, v) ̂x + Fy(u, v)̂y + Fz(u, v) ̂z, and if the surface is an ellipsoidal surface,

    𝐫 = 𝑎 sin(𝑢) cos(𝑣) ̂x + 𝑏 sin(𝑢) sin(𝑣) ̂y + 𝑐 cos(𝑣) ̂z ?

The vector field 𝐅 and the surface 𝐫 are initially defined with respect to the ambient
Cartesian coordinate system. To compute the intrinsic divergence or curl on the
ellipsoidal surface, you must first convert the ambient vector field to a representation
that uses the surface's intrinsic coordinate system. This is a crucial, non-trivial step.

Step-by-Step Conversion

1.  Define the Surface Parametrization:
    The surface 𝐫 is a function of the parameters 𝑢 and 𝑣:

    𝐫 = 𝑎 sin(𝑢) cos(𝑣) ̂x + 𝑏 sin(𝑢) sin(𝑣) ̂y + 𝑐 cos(𝑣) ̂z   (4)


2.  Calculate the Surface Basis Vectors:
    These vectors form a local basis at every point on the surface. They are found by taking
    partial derivatives of r with respect to the parameters 𝑢 and 𝑣.
          
          ∂𝐫
    𝐫ᵤ = ———— = 𝑎 cos(𝑢) cos(𝑣) ̂x + 𝑏 cos(𝑢) sin(𝑣) ̂y - 𝑐 sin(𝑣) ̂z   (5)
          ∂𝑢 

          ∂𝐫
    𝐫ᵥ = ———— = -𝑎 sin(𝑢) sin(𝑣) ̂x + 𝑏 sin(𝑢) cos(𝑣) ̂y + 0 ̂z   (6)
          ∂𝑣 

3.  Express the Ambient Vector Field in Terms of u and v:
    The original vector field F is given in Cartesian components. You must substitute the expressions
    for x, y, and z from your surface parametrization (Equation 4) into the
    ambient vector field's components (Fx, Fy, Fz).

        𝐅(𝑢, 𝑣) = Fx(𝑢, 𝑣) ̂x + Fy(𝑢, 𝑣) ̂y + Fz(𝑢, 𝑣) ̂z          (7)

    For instance, if Fx was originally a function of x,y,z, it now becomes a function of u,v.

4.  Solve for Intrinsic Components (Fᵤ, Fᵥ):
    This is the step we discussed in the previous response. We have
    a vector 𝐅 (now expressed in terms of 𝑢 and 𝑣) and the two basis vectors 𝐫ᵤ and 𝐫ᵥ.

    We must solve the system of equations derived from the dot products to find the components
    Fᵤ and Fᵥ such that 𝐅= Fᵤ 𝐫ᵤ + Fᵥ 𝐫ᵥ.

    4-1. First, calculate the metric tensor components: 
            
        gᵤᵤ = 𝐫ᵤ ⋅ 𝐫ᵤ, gᵤᵥ = 𝐫ᵤ ⋅ 𝐫ᵥ, gᵥᵤ = 𝐫ᵥ ⋅ 𝐫ᵤ,  gᵥᵥ = 𝐫ᵥ ⋅ 𝐫ᵥ

    4-2. Then, calculate the dot products: 𝐅 ⋅ 𝐫ᵤ and 𝐅 ⋅ 𝐫ᵥ

    4-3. Solve the system:

        𝐅 ⋅ 𝐫ᵤ = Fᵤgᵤᵤ + Fᵥgᵥᵤ      (8)
        𝐅 ⋅ 𝐫ᵥ = Fᵤgᵤᵥ + Fᵥgᵥᵥ      (9)
​
This is the core of the conversion process. Once you have the components Fu and Fv,
you can apply the intrinsic divergence and curl formulas that we discussed previously.
Without this step, the concept of surface divergence or curl is not well-defined.

====================================================================================

If there's an intrinsic divergence and curl, there must also be an intrinsic gradient.
This concept is a fundamental part of the extension of vector calculus to manifolds
and is crucial for understanding how to perform calculus on curved surfaces.

What is the Intrinsic Gradient?

The intrinsic gradient of a scalar function f(u,v) on a surface measures the direction
and magnitude of the steepest ascent of that function, but restricted to the surface itself.
The resulting gradient vector, ∇ₛ𝑓, will always lie in the tangent plane of the surface at that point.

Conceptual Difference: The standard 3D gradient, ∇𝑓, points in the direction of steepest ascent
in the ambient 3D space. The intrinsic gradient, ∇ₛ𝑓, finds the direction of steepest ascent
by only considering paths that lie on the surface.

How to Compute It

The formula for the intrinsic gradient uses the same building blocks as the intrinsic divergence
and curl: the surface's basis vectors and the metric tensor. The gradient vector is a linear combination
of the basis vectors, with coefficients determined by the derivatives of the scalar function 𝑓.

The general formula is:

               ∂𝑓
    ∇ₛ𝑓 = 𝑔ⁱʲ ————— 𝐫ⱼ
               ∂𝑥ⁱ

where 𝑔ⁱʲ is the inverse of the metric tensor and 𝑥ⁱ represents the surface coordinates (𝑢 and 𝑣).

In the two-dimensional case of a surface, this expands to:

               ∂𝑓             ∂𝑓             ∂𝑓             ∂𝑓
    ∇ₛ𝑓 = 𝑔ᵘᵘ ————— 𝐫ᵤ + 𝑔ᵘᵛ ————— 𝐫ᵤ + 𝑔ᵛᵘ ————— 𝐫ᵥ + 𝑔ᵛᵛ ————— 𝐫ᵥ
               ∂𝑢             ∂𝑣             ∂𝑢             ∂𝑣  

        
           𝑔ᵥᵥ ∂𝑓/∂𝑢 - 𝑔ᵤᵥ ∂𝑓/∂𝑣          𝑔ᵤᵤ ∂𝑓/∂𝑣 - 𝑔ᵥᵤ ∂𝑓/∂𝑢      
    ∇ₛ𝑓 =  ———————————————————————— 𝐫ᵤ + ———————————————————————— 𝐫ᵥ 
                     |𝑔|                            |𝑔| 

where ∣𝑔∣ is the determinant of the metric tensor.

Just like with divergence and curl, this formula ensures that the
resulting gradient vector lives entirely within the surface's tangent plane.

There's a conceptual misunderstanding here. An "intrinsic gradient" is inherently
a property of a manifold (like a 2D surface or a 1D curve) embedded within a higher-dimensional space.
The term "intrinsic" refers to properties that are defined purely by the geometry
of the manifold itself, without reference to the ambient space.

Manifold: The Intuitive Explanation

A manifold is a space that, when you zoom in on any point, looks like a familiar flat, Euclidean space.
It's a generalization of curves and surfaces to higher dimensions.

Imagine you're an ant living on the surface of a sphere. To you, your world seems flat.
You can move forward, backward, left, or right, just like on a flat piece of paper.
You have no idea that your "paper" is actually curved. Only by traveling a great distance
would you realize your space is curved and finite.

A manifold is just like that sphere. Locally, it's flat and Euclidean.
Globally, it can be curved, twisted, and have a complex, non-Euclidean shape.
A 1D manifold is a curve, like a circle. A 2D manifold is a surface, like a sphere or a torus.
The concept extends to 3D and higher dimensions.

Manifold: The Mathematical Explanation

Mathematically, a manifold is a topological space that is locally Euclidean.
This means that for every point on the manifold, there exists a neighborhood around that point
that is homeomorphic to an open subset of Euclidean space (ℝⁿ).

Let's break that down:

1. Topological Space: This is a very general space where we can define properties
   like continuity and convergence, but not necessarily distance or angles.

2. Locally Euclidean: This is the key property. It means that for a point p on a manifold M,
   you can find a small neighborhood U around p and a continuous,
   one-to-one mapping (a homeomorphism) ϕ that maps U to an open set V in ℝⁿ.

3. Homeomorphism (ϕ): This is a mapping that is continuous, has a continuous inverse,
   and preserves the topological structure. It's like stretching and deforming a piece
   of rubber—it doesn't tear or create new holes. The pair (U, ϕ) is called a coordinate chart or an atlas.

The number n is the dimension of the manifold. For a 2D manifold like a sphere, n=2 because any local patch
on the sphere can be mapped to a 2D plane (ℝ²).

*/

#ifndef _GMP_TENSOR_TYPES_HPP
#define _GMP_TENSOR_TYPES_HPP

#include <gmp/gmp_solver.hpp>

#ifndef GMP_MAX_STATIC_TENSOR
#define GMP_MAX_STATIC_TENSOR (3*3*3+1)
#endif

namespace gmp
{
    // // 4 * 4 * 4 * 4 + 1 = 16 x 16 + 1 = 256 + 1
    // inline constexpr int MaxStaticTensor = 4 * 4 * 4 * 4 + 1; 

    // 3 * 3 * 3 + 1 = 27 + 1 = 28
    inline constexpr int MaxStaticTensor = GMP_MAX_STATIC_TENSOR; 

    template<typename DimType, typename CntrType> class tensor;

    namespace hidden
    {
        template<typename T> struct st_tensor: std::false_type { };
        
        template<auto Dim, typename CntrType> struct
        st_tensor<tensor<value_container<Dim>, CntrType>>: std::true_type{ };

        template<auto Rows, auto Cols, auto... Dims, typename CntrType> struct
        st_tensor<tensor<value_container<Rows, Cols, Dims...>, CntrType>>: std::true_type{ };

        template<typename T> struct st_vctr: std::false_type { };
        
        template<auto Dim, typename CntrType> struct
        st_vctr<tensor<value_container<Dim>, CntrType>>: std::true_type{ };

        template<typename T> struct st_fvctr: std::false_type { };
        
        template<auto Dim, tuple_c CntrType> struct
        st_fvctr<tensor<value_container<Dim>, CntrType>>: std::true_type{ };

        ///////////////////////////////////////

        template<typename T> struct st_fmtrx: std::false_type { };
        
        template<auto Rows, auto Cols, tuple_c CntrType> struct
        st_fmtrx<tensor<value_container<Rows, Cols>, CntrType>>: std::true_type{ };

        ///////////////////////////////////////

        template<typename T> struct st_nvctr: std::false_type { };
        
        template<auto Dim, std_array_or_vector_c CntrType> struct
        st_nvctr<tensor<value_container<Dim>, CntrType>>: std::true_type{ };

        template<typename T> struct st_n2vctr: std::false_type { };
        
        template<std_array_or_vector_c CntrType> struct
        st_n2vctr<tensor<value_container<2>, CntrType>>: std::true_type{ };

        template<typename T> struct st_n3vctr: std::false_type { };
        
        template<std_array_or_vector_c CntrType> struct
        st_n3vctr<tensor<value_container<3>, CntrType>>: std::true_type{ };

        template<typename T> struct st_vctr_array: std::false_type { };
        
        template<auto Dim, std_array_c CntrType> struct
        st_vctr_array<tensor<value_container<Dim>, CntrType>>: std::true_type{ };

        template<typename T> struct st_vctr_vctr: std::false_type { };
        
        template<auto Dim, vector_c CntrType> struct
        st_vctr_vctr<tensor<value_container<Dim>, CntrType>>: std::true_type{ };

        template<typename T> struct st_vctr_tuple: std::false_type { };
        
        template<auto Dim, tuple_c CntrType> struct
        st_vctr_tuple<tensor<value_container<Dim>, CntrType>>: std::true_type{ };
        
        template<typename T> struct st_mtrx: std::false_type { };
        
        template<auto Dim1, auto Dim2, typename CntrType> struct
        st_mtrx<tensor<value_container<Dim1, Dim2>, CntrType>>: std::true_type{ };

        template<typename S, typename T>
            struct st_same_dim: std::false_type { };

        template<auto dim, typename S, typename T>
            struct st_same_dim<tensor<value_container<dim>, S>,
            tensor<value_container<dim>, T>>: std::true_type { };

        template<auto dim1, auto dim2, auto... dims,
                    typename S, typename T>
            struct st_same_dim<tensor<value_container<dim1, dim2, dims...>, S>,
            tensor<value_container<dim1, dim2, dims...>, T>>: std::true_type { };

        template<typename T>
        struct st_func_tensor: std::false_type { };

        template<auto Dim, auto... Dims, tuple_c T>
        struct st_func_tensor<tensor< value_container<Dim, Dims...>, T > >
            : std::true_type{ };

         template<typename T>
        struct st_ntensor: std::false_type { };

        template<auto Dim, auto... Dims, std_array_or_vector_c T>
        struct st_ntensor<tensor< value_container<Dim, Dims...>, T > >
            : std::true_type{ };

        template<typename T>
        struct st_square_mtrx : std::false_type { };

        template<auto Rows, typename CntrType>
        struct st_square_mtrx<tensor<value_container<Rows, Rows>, CntrType>>
            : std::true_type { };
    }
    // end of namespace hidden

    template<typename T>
    concept tensor_c = gmp::hidden::st_tensor<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept square_matrix_c = 
        gmp::hidden::st_square_mtrx<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept func_tensor_c = 
        gmp::hidden::st_func_tensor<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept fmtrx_c = 
        gmp::hidden::st_fmtrx<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept ntensor_c = 
        gmp::hidden::st_ntensor<std::remove_cvref_t<T>>::value;
    
    template<typename S, typename T>
    concept same_dim_c = gmp::hidden::st_same_dim<
        std::remove_cvref_t<S>, std::remove_cvref_t<T>>::value;

    template<typename T>
    concept vctr_c = gmp::hidden::st_vctr<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept nvctr_c = gmp::hidden::st_nvctr<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept n2vctr_c = gmp::hidden::st_n2vctr<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept n3vctr_c = gmp::hidden::st_n3vctr<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept vctr_array_c = gmp::hidden::st_vctr_array<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept vctr_vctr_c = gmp::hidden::st_vctr_vctr<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept vctr_tuple_c = gmp::hidden::st_vctr_tuple<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept fvctr_c = gmp::hidden::st_fvctr<std::remove_cvref_t<T>>::value;

    template<typename T>
    concept mtrx_c = gmp::hidden::st_mtrx<std::remove_cvref_t<T>>::value;

    template<typename EleType, int Dim, std::size_t M> requires (Dim == M)
        class tensor<value_container<Dim>, std::array<EleType, M>>
    {
        public:
            using base_type = std::array<EleType, M>;
            using value_type = EleType;
            
            using dims_cntr = value_container<Dim>;
            using index_mplrs = multiplier_t<dims_cntr>;

            constexpr static int dimension = Dim;
            constexpr static int rank = 1;

        protected:
            base_type m_data;

        public:

            tensor() noexcept: m_data{} {}

            template<typename ArgType, typename...ArgTypes>
                requires all_numbers_c<ArgType, ArgTypes...>
            tensor(ArgType&& arg, ArgTypes&&... args) noexcept: 
                m_data{ (EleType)std::forward<ArgType>(arg),
                        (EleType)std::forward<ArgTypes>(args)...} { }

            template<typename ArgType, std::size_t N>
                    requires (same_c<ArgType, EleType> && Dim == (int)N)
            tensor(const std::array<ArgType, N>& ar) noexcept:
                    m_data{ ar } { }

            template<typename ArgType, std::size_t N>
                    requires (same_c<ArgType, EleType> && Dim == (int)N)
            tensor(std::array<ArgType, N>&& ar) noexcept:
                    m_data { std::move(ar) } { }

            const auto& data() const noexcept
            {
                return this->m_data;
            }

            auto& data() noexcept
            {
                return this->m_data;
            }

            tensor(const tensor& t): m_data{ t.m_data } { }

            tensor(tensor&& t): m_data{ std::move(t.m_data) } { }

            tensor& operator=(const tensor& t) noexcept
            {
                if(this != std::addressof(t))
                {
                    this->m_data = t.m_data;
                }

                return *this;
            }

            tensor& operator=(tensor&& t) noexcept
            {
                if(this != std::addressof(t))
                {
                    this->m_data = std::move(t.m_data);
                }

                return *this;
            }

            const auto& operator[](int i) const noexcept
            {
                return this->m_data[i];
            }

            auto& operator[](int i) noexcept
            {
                return this->m_data[i];
            }

            template<int idx> requires(idx < dimension)
            auto& get() noexcept
            {
                return std::get<idx>(this->m_data);
            }

            template<int idx> requires(idx < dimension)
            const auto& get() const noexcept
            {
                return std::get<idx>(this->m_data);
            }

            auto mag() const noexcept
            {
                return [&]<auto...n>(value_container<n...>)
                {
                    return gmp::hypot( this->m_data[n] ... );

                }(forward_sequence<Dim>());
            }

            auto mag2() const noexcept
            {
                return [&]<auto...n>(value_container<n...>)
                {
                    return ( (this->m_data[n] * this->m_data[n]) + ... );

                }(forward_sequence<Dim>());
            }

            tensor unit() const noexcept
                requires (rank == 1 && Dim < 4 )
            {
                auto m = this->mag();

                return [&]<auto...n>(value_container<n...>)->tensor
                {
                    return { this->m_data[n]/m ...};

                }(forward_sequence<Dim>());
            }
    };

    template<typename EleType, int Rows, int Cols, int... Dims, std::size_t M>
        requires (Rows * (Cols * ... * Dims) == M)
        class tensor<value_container<Rows, Cols, Dims...>, std::array<EleType, M>> 
    {
        public:
            using base_type = std::array<EleType, M>;
            using value_type = EleType;

            using dims_cntr = value_container<Rows, Cols, Dims...>;
            using index_mplrs = multiplier_t<dims_cntr>;

            constexpr static int dimension = Rows * ( Cols * ... * Dims ) ;
            constexpr static int rank = 2 + sizeof...(Dims);

        protected:
            base_type m_data; // std::array<EleType, M>, HAS-A method

        public:

            tensor() noexcept: m_data{} { }

            template<typename ArgType, typename...ArgTypes>
                    requires all_numbers_c<ArgType, ArgTypes...>
            tensor(ArgType&& arg, ArgTypes&&... args) noexcept:
                m_data{ (EleType)std::forward<ArgType>(arg),
                        (EleType)std::forward<ArgTypes>(args) ...} { }

            const auto& data() const noexcept
            {
                return this->m_data;
            }

            auto& data() noexcept
            {
                return this->m_data;
            }

            tensor(const tensor& t): m_data{ t.m_data } { }

            auto& cast_ref() noexcept
            {
                return gmp::cast_ref(dims_cntr{},
                        static_cast<base_type&>(m_data));
            }

            const auto& cast_ref() const noexcept
            {
                return gmp::cast_ref(dims_cntr(), 
                    static_cast<const base_type&>(m_data));
            }

            template<int id, int... ids>
                requires valid_index_c<value_container<id, ids...>, dims_cntr>
            EleType& get() noexcept
            {
                constexpr auto idx = 
                    index_dot_product(value_container<id, ids...>{}, index_mplrs{});
                    
                return this->m_data[idx];
            }

            template<int id, int... ids>
                requires valid_index_c<value_container<id, ids...>, dims_cntr>
            const EleType& get() const noexcept
            {
                constexpr auto idx = 
                    index_dot_product(value_container<id, ids...>{}, index_mplrs{});
                    
                return this->m_data[idx];
            }

            EleType& operator[](auto id, auto... ids) noexcept
                requires (sizeof...(ids) + 1 == rank )
            {
                auto idx = [=]<auto n, auto... ns>
                    (value_container<n, ns...>)
                    {
                        return ( (id * n) + ... + (ids * ns) );

                    }(index_mplrs{});

                assert(idx < dimension);

                return this->m_data[idx];
            }

            const EleType& operator[](auto id, auto... ids) const noexcept
                requires (sizeof...(ids) + 1 == rank )
            {
                auto idx = [=]<auto n, auto... ns>
                    (value_container<n, ns...>)
                    {
                        return ( (id * n) + ... + (ids * ns) );

                    }(index_mplrs{});

                assert(idx < dimension);

                return this->m_data[idx];
            }

            tensor& operator=(const tensor& t) noexcept
            {
                if(this != std::addressof(t))
                {
                    this->m_data = t.m_data;
                }

                return *this;
            }

            tensor& operator=(tensor&& t) noexcept
            {
                if(this != std::addressof(t))
                {
                    this->m_data = std::move(t.m_data);
                }

                return *this;
            }

            auto transpose() const noexcept
                requires(rank == 2)
            {
                tensor<value_container<Cols, Rows>, std::array<EleType, M>> A;
                
                auto& m = this->cast_ref();
                auto& a = A.cast_ref();

                for(int i = 0; i < Cols; ++i)
                {
                    for(int j = 0; j < Rows; ++j)
                        a[i][j] = m[j][i];
                }
            
                return A;
            }
            
            auto det() const noexcept
                requires square_matrix_c<tensor>
            {
                using namespace gmp::literals;
                using namespace gmp::calculus;

                using gmp::calculus::operator*;
                using gmp::calculus::operator+;
                using gmp::calculus::operator-;
                using gmp::calculus::operator/;
                
                if constexpr(Rows == 1)
                    return std::get<0>(this->m_data);
                else if constexpr(Rows == 2)
                {
                    auto& m = this->cast_ref();

                    return m[0][0] * m[1][1]
                        - m[0][1] * m[1][0];
                }
                else if constexpr(Rows == 3)
                {
                    auto& m = this->cast_ref();

                    return  m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                          - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                          + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
                }
                else
                {
                    static_assert(Rows < 4, "Not Yet Implemented");
                }
            }

            template<auto row, auto col>
            auto minor() const noexcept
                requires(rank == 2 && row < Rows && col < Cols)
            {
                constexpr auto NRows = Rows - 1;
                constexpr auto NCols = Cols - 1; 

                tensor<value_container<NRows, NCols>, std::vector<EleType>> A;
                
                auto& m = this->cast_ref();
                auto& a = A.cast_ref();

                for(int i = 0; i < NRows; ++i)
                {
                    for(int j = 0; j < NCols; ++j)
                    {
                        auto ii = (i < row) ? i : i + 1;
                        auto jj = (j < col) ? j : j + 1;

                        a[i][j] = m[ii][jj];
                    }
                }

                return A;
            }

            template<auto row, auto col>
            auto cofactor() const noexcept
                requires(rank == 2 && Rows == Cols && row < Rows && col < Cols)
            {
                auto det = minor<row, col>().det();

                return (row + col) % 2 ? - det : det;  
            }

            auto inverse() const noexcept requires(rank == 2 && Rows == Cols);

            template<auto i, auto j>
            auto inverse() const noexcept
                requires (rank == 2 && Rows == Cols && i < Rows && j < Rows);
    };

    template<typename EleType, typename... EleTypes>
    class tensor<value_container<(int)sizeof...(EleTypes)+1>,
            std::tuple<EleType, EleTypes...>>
    {
        public:
            using base_type = std::tuple<EleType, EleTypes...>;
            using value_type = type_container<EleType, EleTypes...>;

            using args_count = value_container<parameter_size_v<EleType>,
                                parameter_size_v<EleTypes>...>;

            constexpr static int max_arg_count = maximum_values(args_count{});

            using dims_cntr = value_container<(int)sizeof...(EleTypes)+1>;
            using index_mplrs = multiplier_t<dims_cntr>;

            constexpr static int dimension = (int)sizeof...(EleTypes)+1;
            constexpr static int rank = 1;

        protected:
            base_type m_data;

        public:
                    
            template<typename ArgType, typename...ArgTypes>
                    requires at_least_one_function_c<ArgType, ArgTypes...>
            tensor(ArgType&& arg, ArgTypes&&... args) noexcept:
                m_data{ std::forward<ArgType>(arg), std::forward<ArgTypes>(args)... } { }

            template<typename ArgType, typename...ArgTypes>
                    requires at_least_one_function_c<ArgType, ArgTypes...>
            tensor(std::tuple<ArgType, ArgTypes...>&& t) noexcept:
                        m_data{ std::move(t) } { }

            template<typename ArgType, typename...ArgTypes>
                    requires at_least_one_function_c<ArgType, ArgTypes...>
            tensor(const std::tuple<ArgType, ArgTypes...>& t) noexcept:
                        m_data{ t } { }

            const auto& data() const noexcept
            {
                return this->m_data;
            }

            tensor(const tensor& t): m_data{ t.m_data } { }

            constexpr auto param_count() const noexcept
            {
                return args_count{};
            }

            template<int idx> requires(idx < dimension)
            const auto& get() const noexcept
            {
                return std::get<idx>(this->m_data);
            }

            template<CastRtnType cmode = CastRtnType::dont,
                number_c ArgType, number_c... ArgTypes>
            auto evaluate(ArgType&& arg, ArgTypes&&... args) const noexcept;

            template<CastRtnType cmode = CastRtnType::dont,
                number_c ArgType, std::size_t N>
            auto evaluate(const std::array<ArgType, N>& args) const noexcept;

            auto mag() const noexcept
            {
                return [&]<auto...n>(value_container<n...>)
                {
                    namespace gmm = gmp::math;

                    return gmm::hypot( std::get<n>(this->m_data) ... );

                }(forward_sequence<dimension>());
            }

            auto mag2() const noexcept
            {
                return [&]<auto...n>(value_container<n...>)
                {
                    return ( ( std::get<n>(this->m_data) * std::get<n>(this->m_data) ) + ... );

                }(forward_sequence<dimension>());
            }

            auto unit() const noexcept
                requires (rank == 1 && dimension < 4);
    };

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    class tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>
    {
        public:
            using base_type = std::tuple<EleType, EleTypes...>;
            using value_type = type_container<EleType, EleTypes...>;

            using args_count = value_container<parameter_size_v<EleType>,
                                parameter_size_v<EleTypes>...>;

            constexpr static int max_arg_count = maximum_values(args_count{});

            using dims_cntr = value_container<Rows, Cols, Dims...>;
            using index_mplrs = multiplier_t<dims_cntr>;

            constexpr static int dimension = Rows * (Cols * ... * Dims);
            constexpr static int rank = 2 + sizeof...(Dims);

        protected:
            base_type m_data;
        public:
        
            template<typename ArgType, typename...ArgTypes>
                    requires at_least_one_function_c<ArgType, ArgTypes...>
            tensor(ArgType&& arg, ArgTypes&&... args) noexcept:
                m_data{ std::forward<ArgType>(arg),
                        std::forward<ArgTypes>(args) ... }{ }

            template<typename ArgType, typename...ArgTypes>
                    requires at_least_one_function_c<ArgType, ArgTypes...>
            tensor(std::tuple<ArgType, ArgTypes...>&& t) noexcept:
                        m_data{ std::move(t) } { }

            template<typename ArgType, typename...ArgTypes>
                    requires at_least_one_function_c<ArgType, ArgTypes...>
            tensor(const std::tuple<ArgType, ArgTypes...>& t) noexcept:
                        m_data{ t } { }

            const auto& data() const noexcept
            {
                return this->m_data;
            }

            tensor(const tensor& t): m_data{ t.m_data } { }

            template<int idx> requires (idx < dimension)
            const auto& get() const noexcept
            {
                return std::get<idx>(this->m_data);
            }

            template<int id, int... ids>
                requires valid_index_c<value_container<id, ids...>, dims_cntr>
            const auto& get() const noexcept
            {
                constexpr auto idx = index_dot_product(
                    value_container<id, ids...>{}, index_mplrs{});

                return std::get<idx>(this->m_data);
            }

            template<auto row, auto col>
                requires (dimension == 2 && row < Rows && col < Cols)
            const auto& get(value_container<row, col>) const noexcept
            {
                constexpr auto idx = index_dot_product(
                    value_container<row, col>{}, index_mplrs{});

                return std::get<idx>(this->m_data);
            }

            template<CastRtnType cmode = CastRtnType::dont,
                number_c ArgType, number_c... ArgTypes>
            auto evaluate(ArgType&& arg, ArgTypes&&... args) const noexcept;

            template<CastRtnType cmode = CastRtnType::dont,
                number_c ArgType, std::size_t N>
            auto evaluate(const std::array<ArgType, N>& args) const noexcept;
            
            auto transpose() const noexcept
                requires(rank == 2);

            auto inverse() const noexcept
                requires(rank == 2);

            template<auto i, auto j>
            auto inverse() const noexcept
                requires (rank == 2 && Rows == Cols && i < Rows && j < Cols);
            
            /////////////////////////////////////
            template<auto row_idx> requires
                (sizeof...(Dims) == 0 && row_idx < Rows)
            auto get_row() const noexcept;

            template<auto col_idx> requires
                (sizeof...(Dims) == 0 && col_idx < Cols)
            auto get_col() const noexcept;

            auto get_rows() const noexcept
                requires ( sizeof...(Dims) == 0);

            template<auto row_begin, auto row_end>
                requires ( sizeof...(Dims) == 0
                && row_begin < Rows && row_end <= Rows)
            auto get_rows() const noexcept;

            auto get_cols() const noexcept
                requires ( sizeof...(Dims) == 0);

            template<auto col_begin, auto col_end>
                requires ( sizeof...(Dims) == 0
                && col_begin < Cols && col_end <= Cols)
            auto get_cols() const noexcept;

            /////////////////////////////////

            template<auto row_idx> requires
                (sizeof...(Dims) == 0 && row_idx < Rows)
            auto row_vector() const noexcept;

            template<auto col_idx> requires
                (sizeof...(Dims) == 0 && col_idx < Cols)
            auto col_vector() const noexcept;

            auto row_vectors() const noexcept
                requires ( sizeof...(Dims) == 0);

            template<auto row_begin, auto row_end>
                requires ( sizeof...(Dims) == 0
                && row_begin < Rows && row_end <= Rows)
            auto row_vectors() const noexcept;

            auto col_vectors() const noexcept
                requires ( sizeof...(Dims) == 0);

            template<auto col_begin, auto col_end>
                requires ( sizeof...(Dims) == 0
                && col_begin < Cols && col_end <= Cols)
            auto col_vectors() const noexcept;

            auto det() const noexcept
                requires(sizeof...(Dims) == 0 && Rows == Cols);

            template<auto row, auto col>
            auto minor() const noexcept
                requires(rank == 2 && row < Rows && col < Cols);

            template<auto row, auto col>
            auto cofactor() const noexcept
                requires(rank == 2 && Rows == Cols && row < Rows && col < Cols);

    };
    
    template<int Dim, int... Dims, typename EleType>
        class tensor<value_container<Dim, Dims...>, std::vector<EleType>> 
    {
        public:
            using base_type = std::vector<EleType>;
            using value_type = EleType;

            using dims_cntr = value_container<Dim, Dims...>;
            using index_mplrs = multiplier_t<dims_cntr>;

            constexpr static int dimension = (Dim * ... * Dims);
            constexpr static int rank = 1 + sizeof...(Dims);

        protected:
            base_type m_data;

        public:
        
            tensor() noexcept: m_data((Dim * ... * Dims)){  }

            template<typename ArgType, typename...ArgTypes>
                requires all_numbers_c<ArgType, ArgTypes...>
            tensor(ArgType&& arg, ArgTypes&&... args) noexcept: 
                m_data{ (EleType)std::forward<ArgType>(arg),
                                    (EleType)std::forward<ArgTypes>(args)...} { }

            decltype(auto) data() const noexcept
            {
                return static_cast<const base_type&>(this->m_data);
            }

            decltype(auto) data() noexcept
            {
                return static_cast<base_type&>(this->m_data);
            }

            tensor(const tensor& t) noexcept: m_data{ t.m_data } { }

            tensor& operator=(const tensor& t) noexcept
            {
                if(this != std::addressof(t))
                {
                    this->m_data = t.m_data;
                }

                return *this;
            }

            tensor& operator=(tensor&& t) noexcept
            {
                if(this != std::addressof(t))
                {
                    this->m_data = std::move(t.m_data);
                }

                return *this;
            }

            tensor(tensor&& t) noexcept: 
                m_data{ std::move(t.m_data) } { }

            template<int id, int... ids>
                requires valid_index_c<value_container<id, ids...>, dims_cntr>
            EleType& get() noexcept
            {
                constexpr auto idx = index_dot_product(
                    value_container<id, ids...>{}, index_mplrs{});
                    
                return this->m_data[idx];
            }

            template<int id, int... ids>
                requires valid_index_c<value_container<id, ids...>, dims_cntr>
            const EleType& get() const noexcept
            {
                constexpr auto idx = index_dot_product(
                    value_container<id, ids...>{}, index_mplrs{});
                    
                return m_data[idx];
            }

            auto& operator[](auto id, auto... ids) noexcept
                requires (sizeof...(ids) + 1 == rank )
            {
                auto idx = [&]<auto n, auto... ns>
                        (value_container<n, ns...>)
                    {
                        return ( (id * n) + ... + (ids * ns) );

                    }(index_mplrs{});

                assert(idx < dimension);

                return this->m_data[idx];
            }

            const auto& operator[](auto id, auto... ids) const noexcept
                requires (sizeof...(ids) + 1 == rank )
            {
                auto idx = [&]<auto n, auto... ns>
                    (value_container<n, ns...>)
                    {
                        return ( (id * n) + ... + (ids * ns) );

                    }(index_mplrs{});

                assert(idx < dimension);

                return this->m_data[idx];
            }

            auto& cast_ref() noexcept
            {
                return gmp::cast_ref(dims_cntr{},
                        static_cast<base_type&>(m_data)); 
            }

            auto& cast_ref() const noexcept
            {
                return gmp::cast_ref(dims_cntr{},
                        static_cast<const base_type&>(m_data)); 
            }

            auto transpose() const noexcept
                requires(rank == 2)
            {
                constexpr auto Rows = gmp::get<0>(dims_cntr{});
                constexpr auto Cols = gmp::get<1>(dims_cntr{});

                tensor<value_container<Cols, Rows>, std::vector<EleType>> A;
                
                auto& m = this->cast_ref();
                auto& a = A.cast_ref();

                for(int i = 0; i < Cols; ++i)
                {
                    for(int j = 0; j < Rows; ++j)
                        a[i][j] = m[j][i];
                }
            
                return A;
            }

            auto det() const noexcept
                requires square_matrix_c<tensor>
            {
                using namespace gmp::literals;
                using namespace gmp::calculus;

                using gmp::calculus::operator*;
                using gmp::calculus::operator+;
                using gmp::calculus::operator-;
                using gmp::calculus::operator/;
                
                if constexpr(Dim == 1)
                    return std::get<0>(this->m_data);
                else if constexpr(Dim == 2)
                {
                    auto& m = this->cast_ref();

                    return m[0][0] * m[1][1]
                         - m[0][1] * m[1][0];
                }
                else if constexpr(Dim == 3)
                {
                    auto& m = this->cast_ref();

                    return m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                            - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                            + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
                }
                else
                {   
                    static_assert(Dim < 4, "Not Yet Implemented");
                }
            }

            template<auto row, auto col>
            auto minor() const noexcept
                requires(rank == 2 && row < gmp::get<0>(dims_cntr{})
                                   && col < gmp::get<1>(dims_cntr{}))
            {
                constexpr auto Rows = gmp::get<0>(dims_cntr{});
                constexpr auto Cols = gmp::get<1>(dims_cntr{});

                constexpr auto NRows = Rows - 1;
                constexpr auto NCols = Cols - 1; 

                tensor<value_container<NRows, NCols>, std::vector<EleType>> A;
                
                auto& m = this->cast_ref();
                auto& a = A.cast_ref();

                for(int i = 0; i < NRows; ++i)
                {
                    for(int j = 0; j < NCols; ++j)
                    {
                        auto ii = (i < row) ? i : i + 1;
                        auto jj = (j < col) ? j : j + 1;

                        a[i][j] = m[ii][jj];
                    }
                }

                return A;
            }

            template<auto row, auto col>
            auto cofactor() const noexcept
                requires(rank == 2 && Dim == gmp::get<1>(dims_cntr{}) 
                                   && row < Dim && col << Dim)
            {
                auto det = minor<row, col>().det();

                return (row + col) % 2 ? -det: det;
            }

            auto mag() const noexcept requires(rank == 1)
            {
                if constexpr(Dim < 4 )
                {
                    return [&]<auto...n>(value_container<n...>)
                    {
                        return gmp::hypot( this->m_data[n] ... );

                    }(forward_sequence<Dim>());
                }
                else
                {
                    // Stable L2 norm for Dim >= 4 
                    // (scaled to avoid overflow/underflow)

                    //
                    // |a| = √ aᵢ² = |a_max| √ (aᵢ/a_max)²
                    //
                    
                    namespace gmm = gmp::math;

                    EleType amax = EleType{0};
                    
                    for (int i = 0; i < Dim; ++i) 
                    {
                        auto ai = gmm::abs(this->m_data[i]);
                        if (ai > amax) amax = ai;
                    }
                    
                    if (amax == EleType{0}) return EleType{0};

                    EleType s = EleType{0};
                    
                    for (int i = 0; i < Dim; ++i) 
                    {
                        auto t = this->m_data[i] / amax;
                        s += t * t;
                    }
                    
                    return amax * gmm::sqrt(s);

                    // // Sum of squares for Dim >= 4
                    // EleType s = EleType{0};
                    
                    // for (int i = 0; i < Dim; ++i)
                    //     s += this->m_data[i] * this->m_data[i];

                    // return gmp::sqrt(s);
                }
            }

            auto mag2() const noexcept requires(rank == 1)
            {
                if constexpr(Dim < 4)
                {
                    return [&]<auto...n>(value_container<n...>)
                    {
                        return ( (this->m_data[n] * this->m_data[n]) + ... );

                    }(forward_sequence<Dim>());
                }
                else
                {
                    // Sum of squares for Dim >= 4
                    EleType s = EleType{0};
                    for (int i = 0; i < Dim; ++i)
                        s += this->m_data[i] * this->m_data[i];
                    return s;
                }
            }

            tensor unit() const noexcept
                requires( rank == 1 && Dim < 4)
            {
                auto m = this->mag();

                return [&]<auto...n>(value_container<n...>) -> tensor
                {
                    return { this->m_data[n]/m ...  };

                }(forward_sequence<Dim>());
            }

            auto inverse() const noexcept
                requires(rank == 2);

            template<auto i, auto j>
                requires (rank == 2 && i < Dim && j < Dim)
            auto inverse() const noexcept;

    };
    // end of class tensor<value_container<Dim, Dims...>, std::vector<EleType>> 
    
    template<int N, int...Ns, std_array_or_vector_c CntrType>
    std::ostream& operator<<(std::ostream& os,
            const tensor<value_container<N, Ns...>, CntrType>& M) noexcept
    {
        using output::operator<<;
        using output::operator>>;

        using TensorType = tensor<value_container<N, Ns...>, CntrType>;
        
        if constexpr(TensorType::rank == 1)
        {
            os << M.data(); return os;
        }
        else if constexpr(TensorType::rank == 2)
        {
            os <<"\n{ \n  ";

            int iEnd = get<0>(value_container<N, Ns...>{});
            int jEnd = get<1>(value_container<N, Ns...>{});

            for(int i = 0; i < iEnd; ++i)
            {
                for(int j = 0 ; j < jEnd; ++j)
                {
                    os << M[i, j];

                    if( j+1 < jEnd ) os << ", ";
                }

                if( i+1 < iEnd) os << std::endl << "  ";
            }

            os << "\n}" << std::endl ; return os;
        }
        else if constexpr(TensorType::rank == 3)
        {
            os <<"\n  ";

            int iEnd = get<0>(value_container<N, Ns...>{});
            int jEnd = get<1>(value_container<N, Ns...>{});
            int kEnd = get<2>(value_container<N, Ns...>{});

            for(int i = 0; i < iEnd ; ++i)
            {
                os << "--"<< i <<"-------------\n  ";

                for(int j = 0 ; j < jEnd ; ++j)
                {
                    for(int k = 0 ; k < kEnd; ++k)
                    {
                        os << M[i, j, k];

                        if( k+1 < kEnd ) os << ", ";
                    }

                    if( j+1 < jEnd) os << std::endl << "  ";   
                }

                if( i+1 < iEnd) os << std::endl << "  ";   
            }

            os << std::endl; return os;
        }
        else if constexpr(TensorType::rank == 4)
        {
            os <<"\n  ";

            int iEnd = get<0>(value_container<N, Ns...>{});
            int jEnd = get<1>(value_container<N, Ns...>{});
            int kEnd = get<2>(value_container<N, Ns...>{});
            int lEnd = get<3>(value_container<N, Ns...>{});

            for(int i = 0; i < iEnd ; ++i)
            {
                os << "===="<< i <<"==================\n\n  ";

                for(int j = 0 ; j < jEnd ; ++j)
                {
                    os << "---------"<< j <<"---------------\n  ";
                    for(int k = 0 ; k < kEnd; ++k)
                    {
                        for(int l = 0 ; l < lEnd; ++l)
                        {
                            os << M[i, j, k, l];

                            if( l+1 < lEnd ) os << ", ";
                        }

                        if( k+1 < kEnd) os << std::endl <<"  ";   
                    }

                    os << std::endl <<"  ";
                }

                if( i+1 < iEnd) os << "\n  ";
            }

            os << std::endl; return os;
        }
    }

    template<int N, int...Ns, tuple_c CntrType>
    std::ostream& operator<<(std::ostream& os,
            const tensor<value_container<N, Ns...>, CntrType>& M) noexcept
    {
        using output::operator<<;
        using output::operator>>;
        
        using TensorType = tensor<value_container<N, Ns...>, CntrType>;

        if constexpr(TensorType::rank == 1)
        {
           os <<"{ ";

            [&]<auto...n>(value_container<n...>)
            {
                using args = typename TensorType::args_count;

                auto item = [&]<auto i>(value_container<i>)
                {
                    constexpr int cnt = get<i>(args{});

                    if constexpr (cnt == 0)
                        os << M.template get<i>();
                    else
                        os << "<  " << cnt << "  >";

                    if constexpr(i + 1 < TensorType::dimension)
                        os <<", ";
                };

                ( item(value_container<n>{}), ... );

            }(forward_sequence<TensorType::dimension>());

            os <<" }"; return os;
        }
        else if constexpr(TensorType::rank == 2)
        {
            os << "\n{ \n  ";

            constexpr int iEnd = get<0>(value_container<N, Ns...>{});
            using args = typename TensorType::args_count;

            [&]<auto...ii>(value_container<ii...>)
            {
                constexpr int jEnd = get<1>(value_container<N, Ns...>{});

                auto print_rows = [&]<auto i>(value_container<i>)
                {
                    auto item=[&]<auto i1, auto j1>(value_container<i1, j1>)
                    {
                        constexpr int idx = i1 * jEnd + j1;
                        constexpr int cnt = get<idx>(args{});
                        
                        if constexpr(cnt == 0 )
                            os << M.template get<i1, j1>();
                        else
                            os << "<  " << cnt <<"  >";

                        if constexpr(j1 + 1 < jEnd)
                            os <<", ";
                        else
                        {
                            if constexpr(i1 + 1 < iEnd)
                               os <<"\n  ";
                            else 
                                os <<"\n";
                        }
                    };

                    [&]<auto ...j>(value_container<j...>)
                    {
                        ( item(value_container<i, j>{}), ...);

                    }( forward_sequence<jEnd>() );
                };

                ( print_rows(value_container<ii>{}), ... );


            }(forward_sequence<iEnd>());

            os <<" }"; return os;
        }
        else if constexpr(TensorType::rank == 3)
        {
            constexpr int iEnd = get<0>(value_container<N, Ns...>{});
            using args = typename TensorType::args_count;
            
            os <<"\n  ";

            [&]<auto...ii>(value_container<ii...>)
            {
                auto visit_i = [&]<auto i>(value_container<i>)
                {
                    os << "------"<< i <<"------------------------\n  ";
                    
                    constexpr int jEnd = get<1>(value_container<N, Ns...>{});

                    [&]<auto...jj>(value_container<jj...>)
                    {
                        auto visit_ij = [&]<auto j>(value_container<j>)
                        {
                            constexpr int kEnd = get<2>(value_container<N, Ns...>{});

                            [&]<auto...kk>(value_container<kk...>)
                            {
                                using index_mplrs = typename TensorType::index_mplrs;
                                using args = typename TensorType::args_count;

                                auto item = [&]<auto k>(value_container<k>)
                                {
                                    constexpr int idx = index_dot_product(
                                            value_container<i, j, k>{}, index_mplrs{} );
                                    
                                    constexpr int cnt = get<idx>(args{});

                                    if constexpr(cnt == 0)
                                            os << M.template get<idx>();
                                    else
                                            os << "<  " << cnt <<"  >";

                                    if constexpr(k + 1 < kEnd)
                                        os <<", ";
                                    else
                                        os << "\n  ";
                                };

                                ( item(value_container<kk>{}), ... );

                            }(forward_sequence<kEnd>());
                        };

                        ( visit_ij(value_container<jj>{}), ...);

                    }(forward_sequence<jEnd>());

                };

                ( visit_i(value_container<ii>{}), ... );

            }(forward_sequence<iEnd>());

            return os;
        }
        else if constexpr(TensorType::rank == 4)
        {
            constexpr int iEnd = get<0>(value_container<N, Ns...>{});
            
            [&]<auto...i>(value_container<i...>)
            {
                constexpr int jEnd = get<1>(value_container<N, Ns...>{});

                auto sel_i = [&]<auto ii>(value_container<ii>)
                {
                    os << "\n  ====" << ii << "===============================\n  ";

                    [&]<auto...j>(value_container<j...>)
                    {
                        constexpr int kEnd = get<2>(value_container<N, Ns...>{});

                        auto sel_j = [&]<auto jj>(value_container<jj>)
                        {
                            os << "\n  --------" << jj << "-------------------------\n  ";

                            [&]<auto...k>(value_container<k...>)
                            {
                                constexpr int lEnd = get<3>(value_container<N, Ns...>{});

                                auto sel_k = [&]<auto kk>(value_container<kk>)
                                {
                                    [&]<auto...l>(value_container<l...>)
                                    {
                                        using index_mplrs = typename TensorType::index_mplrs;
                                        using args = typename TensorType::args_count;

                                        auto sel_l = [&]<auto ll>(value_container<ll>)
                                        {
                                            constexpr int idx =  index_dot_product(
                                                value_container<ii, jj, kk, ll>{}, index_mplrs{});

                                            constexpr int cnt = get<idx>( args{} );

                                            if constexpr(cnt == 0)
                                                os << M.template get<idx>();
                                            else
                                                os << "<  " << cnt <<"  >";

                                            if constexpr(ll + 1 < lEnd)
                                                os <<", ";
                                            else
                                                os <<"\n  ";
                                        };

                                        ( sel_l(value_container<l>{}), ...);

                                    }(forward_sequence<lEnd>());

                                };

                                ( sel_k(value_container<k>{}), ... );

                            }(forward_sequence<kEnd>());
                        };

                        ( sel_j(value_container<j>{}), ...);

                    }( forward_sequence<jEnd>() );
                };

                ( sel_i(value_container<i>{}), ...);

            }( forward_sequence<iEnd>() );

            return os;
        }
    }

    namespace operators
    {
        template<number_or_function_c ArgType, number_or_function_c...ArgTypes>
        auto make_tensor(ArgType&& arg, ArgTypes&&... args) noexcept
        {
            if constexpr(all_numbers_c<ArgType, ArgTypes...>)
            {
                using EleType = common_type_t<ArgType, ArgTypes...>;
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = std::conditional_t< (int)N < MaxStaticTensor, 
                    tensor<value_container<(int)N>, std::array<EleType, N>>, 
                        tensor<value_container<(int)N>, std::vector<EleType>>>;
                        
                return tensor_t{ (EleType)std::forward<ArgType>(arg), (EleType)std::forward<ArgTypes>(args)... };
            }
            else
            {
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = tensor<value_container<(int)N>, 
                        std::tuple<std::remove_cvref_t<ArgType>, std::remove_cvref_t<ArgTypes>...>>;

                return tensor_t{ std::forward<ArgType>(arg),
                                 std::forward<ArgTypes>(args)... };
            }
        }

        template<number_or_function_c ArgType, number_or_function_c...ArgTypes>
        [[nodiscard]] auto unique_tensor(ArgType&& arg, ArgTypes&&... args)  noexcept
        {
            if constexpr(all_numbers_c<ArgType, ArgTypes...>)
            {
                using EleType = common_type_t<ArgType, ArgTypes...>;
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = std::conditional_t< (int)N < MaxStaticTensor, 
                    tensor<value_container<(int)N>, std::array<EleType, N>>, 
                        tensor<value_container<(int)N>, std::vector<EleType>>>;
                            
                return std::make_unique<tensor_t>(
                        (EleType)std::forward<ArgType>(arg), (EleType)std::forward<ArgTypes>(args)... );
            }
            else
            {
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = tensor<value_container<(int)N>, 
                        std::tuple<std::remove_cvref_t<ArgType>, std::remove_cvref_t<ArgTypes>...>>;

                return std::make_unique<tensor_t>(std::forward<ArgType>(arg),
                    std::forward<ArgTypes>(args)... );
            }
        }

        template<number_or_function_c ArgType, number_or_function_c...ArgTypes>
        [[nodiscard]] auto shared_tensor(ArgType&& arg, ArgTypes&&... args)  noexcept
        {
            if constexpr(all_numbers_c<ArgType, ArgTypes...>)
            {
                using EleType = common_type_t<ArgType, ArgTypes...>;
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = std::conditional_t< (int)N < MaxStaticTensor, 
                    tensor<value_container<(int)N>, std::array<EleType, N>>, 
                        tensor<value_container<(int)N>, std::vector<EleType>>>;
                            
                return std::make_shared<tensor_t>(
                        (EleType)std::forward<ArgType>(arg), (EleType)std::forward<ArgTypes>(args)... );
            }
            else
            {
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = tensor<value_container<(int)N>, 
                        std::tuple<std::remove_cvref_t<ArgType>, std::remove_cvref_t<ArgTypes>...>>;

                return std::make_shared<tensor_t>(std::forward<ArgType>(arg),
                    std::forward<ArgTypes>(args)... );
            }
        }

        template<int Dim, int... Dims, number_or_function_c ArgType,
                                    number_or_function_c...ArgTypes>
            requires ( (Dim * ... * Dims) == (int)sizeof...(ArgTypes) + 1)
        auto make_tensor(ArgType&& arg, ArgTypes&&... args) noexcept
        {
            if constexpr(all_numbers_c<ArgType, ArgTypes...>)
            {
                using EleType = common_type_t<ArgType, ArgTypes...>;
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = std::conditional_t< (int)N < MaxStaticTensor, 
                    tensor<value_container<Dim, Dims...>, std::array<EleType, N>>, 
                        tensor<value_container<Dim, Dims...>, std::vector<EleType>>>;

                return tensor_t{ (EleType)std::forward<ArgType>(arg), (EleType)std::forward<ArgTypes>(args)... };
            }
            else
            {
                using tensor_t = tensor<value_container<Dim, Dims...>, 
                        std::tuple<std::remove_cvref_t<ArgType>, std::remove_cvref_t<ArgTypes>...>>;

                return tensor_t{ std::forward<ArgType>(arg), std::forward<ArgTypes>(args)... };
            }
        }

        template<int Dim, int... Dims, number_or_function_c ArgType,
                                    number_or_function_c...ArgTypes>
            requires ( (Dim * ... * Dims) == (int)sizeof...(ArgTypes) + 1)
        [[nodiscard]] auto unique_tensor(ArgType&& arg, ArgTypes&&... args) noexcept
        {
            if constexpr(all_numbers_c<ArgType, ArgTypes...>)
            {
                using EleType = common_type_t<ArgType, ArgTypes...>;
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = std::conditional_t< (int)N < MaxStaticTensor, 
                    tensor<value_container<Dim, Dims...>, std::array<EleType, N>>, 
                        tensor<value_container<Dim, Dims...>, std::vector<EleType>>>;

                return std::make_unique<tensor_t>((EleType)std::forward<ArgType>(arg),
                    (EleType)std::forward<ArgTypes>(args)... );
            }
            else
            {
                using tensor_t = tensor<value_container<Dim, Dims...>, 
                        std::tuple<std::remove_cvref_t<ArgType>, std::remove_cvref_t<ArgTypes>...>>;

                return std::make_unique<tensor_t>(
                    std::forward<ArgType>(arg), std::forward<ArgTypes>(args)... );
            }
        }

        template<int Dim, int... Dims, number_or_function_c ArgType,
                                    number_or_function_c...ArgTypes>
            requires ( (Dim * ... * Dims) == (int)sizeof...(ArgTypes) + 1)
        [[nodiscard]] auto shared_tensor(ArgType&& arg, ArgTypes&&... args) noexcept
        {
            if constexpr(all_numbers_c<ArgType, ArgTypes...>)
            {
                using EleType = common_type_t<ArgType, ArgTypes...>;
                constexpr std::size_t N = sizeof...(ArgTypes) + 1;

                using tensor_t = std::conditional_t< (int)N < MaxStaticTensor, 
                    tensor<value_container<Dim, Dims...>, std::array<EleType, N>>, 
                        tensor<value_container<Dim, Dims...>, std::vector<EleType>>>;

                return std::make_shared<tensor_t>((EleType)std::forward<ArgType>(arg),
                    (EleType)std::forward<ArgTypes>(args)... );
            }
            else
            {
                using tensor_t = tensor<value_container<Dim, Dims...>, 
                        std::tuple<std::remove_cvref_t<ArgType>, std::remove_cvref_t<ArgTypes>...>>;

                return std::make_shared<tensor_t>(
                    std::forward<ArgType>(arg), std::forward<ArgTypes>(args)... );
            }
        }

        template<int Dim, int... Dims, number_or_function_c ArgType,
                                    number_or_function_c...ArgTypes>
            requires ( (Dim * ... * Dims) == (int)sizeof...(ArgTypes) + 1)
        auto make_tensor(value_container<Dim, Dims...>,
                ArgType&& arg, ArgTypes&&... args) noexcept
        {
            return make_tensor<Dim, Dims...>
                ( std::forward<ArgType>(arg), std::forward<ArgTypes>(args)... );
        }

        template<typename EleType, int Dim, int... Dims>
        auto make_tensor() noexcept
        {
            constexpr std::size_t N = (Dim * ... * Dims);

            using tensor_t = std::conditional_t<(int)N < MaxStaticTensor, 
                tensor<value_container<Dim, Dims...>, std::array<EleType, N>>, 
                    tensor<value_container<Dim, Dims...>, std::vector<EleType>>>;

            return tensor_t{ };
        }

        template<typename EleType, std::size_t N>
        auto make_tensor(const std::array<EleType, N>& ar) noexcept
        {
            using tensor_t = std::conditional_t<(int)N < MaxStaticTensor, 
                tensor<value_container<(int)N>, std::array<EleType, N>>, 
                    tensor<value_container<(int)N>, std::vector<EleType>>>;
            return tensor_t{ ar };
        }

        template<typename EleType, std::size_t N>
        auto make_tensor(std::array<EleType, N>&& ar) noexcept
        {
            using tensor_t = std::conditional_t<(int)N < MaxStaticTensor, 
                tensor<value_container<(int)N>, std::array<EleType, N>>, 
                    tensor<value_container<(int)N>, std::vector<EleType>>>;
            return tensor_t{ std::move(ar) };
        }

        template<int Dim, int... Dims, typename EleType, std::size_t N>
            requires ( (Dim * ... * Dims) == (int)N)
        auto make_tensor(const std::array<EleType, N>& ar) noexcept
        {
            using tensor_t = std::conditional_t<(int)N < MaxStaticTensor, 
                tensor<value_container<Dim, Dims...>, std::array<EleType, N>>, 
                    tensor<value_container<Dim, Dims...>, std::vector<EleType>>>;
            return tensor_t{ ar };
        }

        template<int Dim, int... Dims, typename EleType, std::size_t N>
            requires ( (Dim * ... * Dims) == (int)N)
        auto make_tensor(std::array<EleType, N>&& ar) noexcept
        {
            using tensor_t = std::conditional_t<(int)N < MaxStaticTensor, 
                tensor<value_container<Dim, Dims...>, std::array<EleType, N>>, 
                    tensor<value_container<Dim, Dims...>, std::vector<EleType>>>;

            return tensor_t{ std::move(ar) };
        }
    }
    // end of namespace operators

    template<typename EleType, typename... EleTypes>
        template<CastRtnType cmode, number_c ArgType, number_c... ArgTypes>
    auto tensor<value_container<(int)sizeof...(EleTypes)+1>, 
        std::tuple<EleType, EleTypes...>>::
        evaluate(ArgType&& arg, ArgTypes&&... args) const noexcept
    {
        return [&]<auto... n>(value_container<n...>)
        {
            using namespace operators;

            return make_tensor( value_container<(int)sizeof...(EleTypes)+1>{}, 
                operators::evaluate<cmode>( this->get<n>(), arg, args... ) ... );

        }(forward_sequence<dimension>());
    }

    template<typename EleType, typename... EleTypes>
        template<CastRtnType cmode, number_c ArgType, std::size_t N>
    auto tensor<value_container<(int)sizeof...(EleTypes)+1>, 
        std::tuple<EleType, EleTypes...>>::
        evaluate(const std::array<ArgType, N>& args) const noexcept
    {
        return [&]<auto... n>(value_container<n...>)
        {
            using namespace operators;

            return make_tensor(value_container<(int)sizeof...(EleTypes)+1>{},  
                operators::evaluate<cmode>( this->get<n>(), args )... );

        }(forward_sequence<dimension>());
    }
       
    template<typename EleType, typename... EleTypes,
        int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<CastRtnType cmode, number_c ArgType, number_c... ArgTypes>
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::
    evaluate(ArgType&& arg, ArgTypes&&... args) const noexcept
    {
        return [&]<auto... n>(value_container<n...>)
        {
            using namespace operators;

            return make_tensor(value_container<Rows, Cols, Dims...>{},  
                operators::evaluate<cmode>(this->get<n>(), arg, args...) ... );

        }(forward_sequence<dimension>());
    }

    template<typename EleType, typename... EleTypes,
        int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<CastRtnType cmode, number_c ArgType, std::size_t N>
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::
        evaluate(const std::array<ArgType, N>& args) const noexcept
    {
        return [&]<auto... n>(value_container<n...>)
        {
            using namespace operators;

            return make_tensor(value_container<Rows, Cols, Dims...>{}, 
                    operators::evaluate<cmode>(this->get<n>(), args)...);

        }(forward_sequence<dimension>());
    }

    namespace operators
    {
        template<CastRtnType cmode = CastRtnType::dont, 
                func_tensor_c TensorType, number_c ArgType, std::size_t N>
        auto evaluate(TensorType&& tsr, std::array<ArgType, N> const& args) noexcept
        {
            return tsr.template evaluate<cmode>(args);
        }

        template<CastRtnType cmode = CastRtnType::dont, 
                func_tensor_c TensorType, number_c ArgType, number_c... ArgTypes>
        auto evaluate(TensorType&& tsr, ArgType&& arg, ArgTypes&&... args) noexcept
        {
            return tsr.template evaluate<cmode>(std::forward<ArgType>(arg),
                std::forward<ArgTypes>(args)... );
        }

        
    }

    //////////////////////////////////////////////////////////////////
    template<typename EleType, typename... EleTypes>
    auto tensor<value_container<(int)sizeof...(EleTypes)+1>,
            std::tuple<EleType, EleTypes...>>::unit() const noexcept
            requires (rank == 1 && dimension < 4)
    {
        auto m = this->mag();

        return [&]<auto...n>(value_container<n...>)
        {
            return make_tensor(std::get<n>(this->m_data) / m ... );

        }(forward_sequence<dimension>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    auto tensor<value_container<Rows, Cols, Dims...>, 
        std::tuple<EleType, EleTypes...>>::transpose() const noexcept
                 requires(rank == 2)
    {
        return [&]<auto...i>(value_container<i...>)
        {
            // for Intel icx-cl compiler
            using namespace operators;

            return make_tensor<Cols, Rows>
                ( this->get<i % Rows, i / Rows>() ... );

        }(forward_sequence<Rows * Cols>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto row_idx> requires
        (sizeof...(Dims) == 0 && row_idx < Rows)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::get_row() const noexcept
    {
        return [&]<auto... j>(value_container<j...>)
        {
            return make_tensor( this->template get<row_idx, j>() ... );

        }(forward_sequence<Cols>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto col_idx> requires
        (sizeof...(Dims) == 0 && col_idx < Cols)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::get_col() const noexcept
    {
        return [&]<auto... i>(value_container<i...>)
        {
            return make_tensor( this->template get<i, col_idx>() ... );

        }(forward_sequence<Rows>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::get_rows() const noexcept
                 requires (sizeof...(Dims) == 0)
    {
        return [&]<auto... i>(value_container<i...>)
        {
            return std::tuple{ this->row_vector<i>()... };

        }(forward_sequence<Rows>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::get_cols() const noexcept
                 requires (sizeof...(Dims) == 0)
    {
        return [&]<auto... j>(value_container<j...>)
        {
            return std::tuple{ this->col_vector<j>()... };

        }(forward_sequence<Cols>());
    }
    
    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto row_begin, auto row_end>
                requires ( sizeof...(Dims) == 0
                && row_begin < Rows && row_end <= Rows)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::get_rows() const noexcept
    {
        return [&]<auto... i>(value_container<i...>)
        {
            return std::tuple{ this->row_vector<i>()... };

        }(forward_sequence<row_begin, row_end>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto col_begin, auto col_end>
                requires ( sizeof...(Dims) == 0
                && col_begin < Cols && col_end <= Cols)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::get_cols() const noexcept
    {
        return [&]<auto... j>(value_container<j...>)
        {
            return std::tuple{ this->col_vector<j>()... };

        }(forward_sequence<col_begin, col_end>());
    }

    /////////////////////////////////////////////////////////////
    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto row_idx> requires
        (sizeof...(Dims) == 0 && row_idx < Rows)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::row_vector() const noexcept
    {
        return [&]<auto... j>(value_container<j...>)
        {
            return make_tensor( value_container<1, Cols>{},
                                this->template get<row_idx, j>() ... );

        }(forward_sequence<Cols>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto col_idx> requires
        (sizeof...(Dims) == 0 && col_idx < Cols)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::col_vector() const noexcept
    {
        return [&]<auto... i>(value_container<i...>)
        {
            return make_tensor(value_container<Rows, 1>{},
                    this->template get<i, col_idx>() ... );

        }(forward_sequence<Rows>());
    }

    template<typename EleType, typename... EleTypes,
        int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    auto tensor<value_container<Rows, Cols, Dims...>, 
        std::tuple<EleType, EleTypes...>>::row_vectors() const noexcept
              requires (sizeof...(Dims) == 0)
    {
        return [&]<auto... i>(value_container<i...>)
        {
            return std::tuple{ this->row_vector<i>()... };

        }(forward_sequence<Rows>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::col_vectors() const noexcept
                 requires (sizeof...(Dims) == 0)
    {
        return [&]<auto... j>(value_container<j...>)
        {
            return std::tuple{ this->col_vector<j>()... };

        }(forward_sequence<Cols>());
    }
    
    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto row_begin, auto row_end>
                requires ( sizeof...(Dims) == 0
                && row_begin < Rows && row_end <= Rows)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::row_vectors() const noexcept
    {
        return [&]<auto... i>(value_container<i...>)
        {
            return std::tuple{ this->row_vector<i>()... };

        }(forward_sequence<row_begin, row_end>());
    }

    template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
    template<auto col_begin, auto col_end>
                requires ( sizeof...(Dims) == 0
                && col_begin < Cols && col_end <= Cols)
    auto tensor<value_container<Rows, Cols, Dims...>, 
                 std::tuple<EleType, EleTypes...>>::col_vectors() const noexcept
    {
        return [&]<auto... j>(value_container<j...>)
        {
            return std::tuple{ this->col_vector<j>()... };

        }(forward_sequence<col_begin, col_end>());
    }

    ///////////////////////////////////////////////////////////////

    namespace hidden
    {
        template<BinOpr opr, func_tensor_c TensorType, number_or_function_c ScalarType>
        auto tensor_binary_operation(TensorType&& tsr, ScalarType&& scr) noexcept
        {
            if constexpr(opr == BinOpr::mul)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (tsr.template get<n>() * scr)... ) ;

                }(forward_sequence<TT::dimension>());
            }
            else if constexpr(opr == BinOpr::add)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (tsr.template get<n>() + scr)... ) ;

                }(forward_sequence<TT::dimension>());
            }
            else if constexpr(opr == BinOpr::sub)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (tsr.template get<n>() - scr)... ) ;

                }(forward_sequence<TT::dimension>());
            }
            else if constexpr(opr == BinOpr::div)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (tsr.template get<n>() / scr)... ) ;

                }(forward_sequence<TT::dimension>());
            }
        }

        template<BinOpr opr, number_or_function_c ScalarType, func_tensor_c TensorType>
        auto tensor_binary_operation(ScalarType&& scr, TensorType&& tsr) noexcept
        {
            if constexpr(opr == BinOpr::mul)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (scr * tsr.template get<n>()) ... ) ;

                }(forward_sequence<TT::dimension>());
            }
            else if constexpr(opr == BinOpr::add)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (scr + tsr.template get<n>()) ... ) ;

                }(forward_sequence<TT::dimension>());
            }
            else if constexpr(opr == BinOpr::sub)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (scr - tsr.template get<n>()) ... ) ;

                }(forward_sequence<TT::dimension>());
            }
            else if constexpr(opr == BinOpr::div)
            {
                using TT = std::remove_cvref_t<TensorType>;

                return [&]<auto...n>(value_container<n...>)
                {
                    return make_tensor(typename TT::dims_cntr{}, (scr / tsr.template get<n>()) ... ) ;

                }(forward_sequence<TT::dimension>());
            }
        }
    
        template<BinOpr opr, ntensor_c TensorType, number_c ScalarType>
        decltype(auto) tensor_binary_operation(TensorType&& tsr, ScalarType&& scr) noexcept
        {
            using TType = std::remove_cvref_t<TensorType>;
            using EType = typename TType::value_type;

            using SType = std::remove_cvref_t<ScalarType>;
           
            if constexpr( same_c<EType, SType> &&
                    std::is_rvalue_reference_v<decltype(tsr)> )
            {
                auto& t = tsr.data();

                if constexpr(opr == BinOpr::add)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] += scr;

                    return std::move(tsr);
                }
                else if constexpr(opr == BinOpr::mul)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] *= scr;

                    return std::move(tsr);
                }
                else if constexpr(opr == BinOpr::sub)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] -= scr;

                    return std::move(tsr);
                }
                else if constexpr(opr == BinOpr::div)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] /= scr;

                    return std::move(tsr);
                }
            }
            else
            {
                if constexpr(opr == BinOpr::mul)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (tsr.template get<n>() * scr) ...);

                    }( forward_sequence<TType::dimension>() );
                }
                else if constexpr(opr == BinOpr::add)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (tsr.template get<n>() + scr) ...);

                    }( forward_sequence<TType::dimension>() );
                }
                else if constexpr(opr == BinOpr::sub)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (tsr.template get<n>() - scr) ...);

                    }( forward_sequence<TType::dimension>() );
                }
                else if constexpr(opr == BinOpr::div)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (tsr.template get<n>() / scr) ...);

                    }( forward_sequence<TType::dimension>() );
                }
            }
        }

        template<BinOpr opr, number_c ScalarType, ntensor_c TensorType>
        decltype(auto) tensor_binary_operation(ScalarType&& scr, TensorType&& tsr) noexcept
        {
            using TType = std::remove_cvref_t<TensorType>;
            using EType = typename TType::value_type;

            using SType = std::remove_cvref_t<ScalarType>;
           
            if constexpr( same_c<EType, SType> &&
                    std::is_rvalue_reference_v<decltype(tsr)> )
            {
                auto& t = tsr.data();

                if constexpr(opr == BinOpr::add)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] = t[n] + scr;

                    return std::move(tsr);
                }
                else if constexpr(opr == BinOpr::mul)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] = t[n] * scr;

                    return std::move(tsr);
                }
                else if constexpr(opr == BinOpr::sub)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] = t[n] - scr;

                    return std::move(tsr);
                }
                else if constexpr(opr == BinOpr::div)
                {
                    for(int n = 0; n < TType::dimension; ++n)
                        t[n] = t[n] / scr;

                    return std::move(tsr);
                }
            }
            else
            {
                if constexpr(opr == BinOpr::mul)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (scr * tsr.template get<n>()) ...);

                    }( forward_sequence<TType::dimension>() );
                }
                else if constexpr(opr == BinOpr::add)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (scr + tsr.template get<n>()) ...);

                    }( forward_sequence<TType::dimension>() );
                }
                else if constexpr(opr == BinOpr::sub)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (scr - tsr.template get<n>()) ...);

                    }( forward_sequence<TType::dimension>() );
                }
                else if constexpr(opr == BinOpr::div)
                {
                    [&]<auto...n>(value_container<n...>)
                    {
                        return make_tensor(typename TType::dims_cntr{},
                                (scr / tsr.template get<n>()) ...);

                    }( forward_sequence<TType::dimension>() );
                }
            }
        }
    }
    // end of namespace hidden

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator*(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::mul>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator*(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::mul>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator+(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::add>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator+(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::add>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator-(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::sub>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator-(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::sub>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator/(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::div>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<func_tensor_c TensorType, number_or_function_c ScalarType>
    auto operator/(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::div>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    ///////////////////////////////////////////////////////
    template<ntensor_c TensorType, number_c ScalarType>
    auto operator*(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::mul>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator*(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::mul>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator/(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::div>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator/(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::div>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator+(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::add>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator+(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::add>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator-(TensorType&& tsr, ScalarType&& scr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::sub>
            (std::forward<TensorType>(tsr), std::forward<ScalarType>(scr) );
    }

    template<ntensor_c TensorType, number_c ScalarType>
    auto operator-(ScalarType&& scr, TensorType&& tsr) noexcept
    {
        return hidden::tensor_binary_operation<BinOpr::sub>
            (std::forward<ScalarType>(scr), std::forward<TensorType>(tsr) );
    }

    //////////////////////////////////////////////////////////

    // dot product
    // template<auto Dim, tuple_c CntrType1, array_tuple_vector_c CntrType2>
    // auto operator*(const tensor<value_container<Dim>, CntrType1>& L, 
    //                const tensor<value_container<Dim>, CntrType2>& R ) noexcept
    // {
    //     return [&]<auto...k>(value_container<k...>)
    //     {
    //         return ( (L.template get<k>() * R.template get<k>() ) + ... );

    //     }(forward_sequence<Dim>());
    // }

    // cross product
    template<auto Dim, tuple_c CntrType1,
        tuple_c CntrType2> requires (Dim == 3)
    auto operator%(const tensor<value_container<Dim>, CntrType1>& L, 
                   const tensor<value_container<Dim>, CntrType2>& R ) noexcept
    {
        auto& [ x1, y1, z1] = L.data();
        auto& [ x2, y2, z2] = R.data();

        return make_tensor( wrap(y1 * z2 - z1 * y2),
                            wrap(z1 * x2 - x1 * z2),
                            wrap(x1 * y2 - y1 * x2) );
    }

    // cross product
    template<auto Dim, std_array_or_vector_c CntrType1,
        std_array_or_vector_c CntrType2> requires (Dim == 3)
    auto operator%(const tensor<value_container<Dim>, CntrType1>& L, 
                   const tensor<value_container<Dim>, CntrType2>& R ) noexcept
    {
        auto& x1 = L[0]; auto& y1 = L[1]; auto& z1 = L[2];
        auto& x2 = R[0]; auto& y2 = R[1]; auto& z2 = R[2];

        return make_tensor( wrap(y1 * z2 - z1 * y2),
                            wrap(z1 * x2 - x1 * z2),
                            wrap(x1 * y2 - y1 * x2) );
    }

    // cross product
    template<auto Dim, tuple_c CntrType1,
        tuple_c CntrType2> requires (Dim == 2)
    auto operator%(const tensor<value_container<Dim>, CntrType1>& L, 
                   const tensor<value_container<Dim>, CntrType2>& R ) noexcept
    {
        auto& [ x1, y1 ] = L.data();
        auto& [ x2, y2 ] = R.data();

        return wrap(x1 * y2 - y1 * x2);
    }

    // cross product
    template<auto Dim, std_array_or_vector_c CntrType1,
        std_array_or_vector_c CntrType2> requires (Dim == 2)
    auto operator%(const tensor<value_container<Dim>, CntrType1>& L, 
                   const tensor<value_container<Dim>, CntrType2>& R ) noexcept
    {
        auto& x1 = L[0]; auto& y1 = L[1];
        auto& x2 = R[0]; auto& y2 = R[1];

        return x1 * y2 - y1 * x2;
    }
    
    // template<auto VarID, auto Order, auto DX>
    // inline constexpr auto drv7f = drv_cmd<seven_point, forward, VarID, Order, DX>{};
    template<DrvStencil drstn, DrvPivot drpv, auto VarID, auto Order, auto DX,
             auto Dim, auto... Dims, tuple_c CntrType>
    auto operator*(drv_cmd<drstn, drpv, VarID, Order, DX> dv,
        const tensor<value_container<Dim, Dims...>, CntrType>& tsr) noexcept
    {
        using TType = tensor<value_container<Dim, Dims...>, CntrType>;

        return [&]<auto... n>(value_container<n...>)
        {
            using namespace literals;
            using namespace calculus;

            return make_tensor(value_container<Dim, Dims...>{},
                    dv * std::get<n>(tsr.data()) ... );

        }( forward_sequence<TType::dimension>());
    }

    template<auto StencilKnd, auto PivotKnd, auto VarID, auto Order, auto DX,
            drv_cmd_c... DrvCmds, auto Dim, auto... Dims, tuple_c CntrType>
    auto operator* (drv_cmds< 
                drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>, DrvCmds...>,
                const tensor<value_container<Dim, Dims...>, CntrType>& tsr)
    {          
        using TType = tensor<value_container<Dim, Dims...>, CntrType>;

        if constexpr(sizeof... (DrvCmds) == 0)
            return drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>{} * tsr;
        else
        {
            return drv_cmds<DrvCmds...>{} *
                     ( drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>{} * tsr );
        }
    }

    template<auto TimeID, DrvStencil stknd, DrvPivot drpv, auto DX, numeric_function_c<std::complex<float>> FType>
    auto operator*(grd_cmd<TimeID, stknd, drpv, DX>, FType&& f) noexcept
    {
        if constexpr(TimeID == -1)
        {
            constexpr int pCount = parameter_size_v<FType, std::complex<float>>;

            return [&]<auto ...VarID>(value_container<VarID...>)
            {
                using namespace literals;
                using namespace calculus;

                return make_tensor( drv_cmd<stknd, drpv, VarID, 1, DX>{} * f ... );

            }(forward_sequence<pCount>());  
        }
        else if constexpr(TimeID == 0)
        {
            constexpr int pCount = parameter_size_v<FType, std::complex<float>>;

            return [&]<auto ...VarID>(value_container<VarID...>)
            {
                using namespace literals;
                using namespace calculus;

                return make_tensor( drv_cmd<stknd, drpv, VarID, 1, DX>{} * f ... );

            }(forward_sequence<1, pCount>());  
        }
        else
        {
            return [&]<auto ...VarID>(value_container<VarID...>)
            {
                using namespace literals;
                using namespace calculus;

                return make_tensor( drv_cmd<stknd, drpv, VarID, 1, DX>{} * f ... );

            }(forward_sequence<TimeID>());
        }
    }

    template<DrvStencil stknd, DrvPivot drpv, auto DX, numeric_function_c<std::complex<float>> FType>
    auto operator*(lap_cmd<stknd, drpv, DX>, FType&& f) noexcept
    {
        constexpr int pCount = parameter_size_v<FType, std::complex<float>>;

        return [&]<auto ...VarID>(value_container<VarID...>)
        {
            using namespace literals;
            using namespace calculus;

            return make_tensor( drv_cmd<stknd, drpv, VarID, 2, DX>{} * f ... );

        }(forward_sequence<pCount>());  
    }

    // template<DrvStencil stknd, DrvPivot drpv, auto DX, numeric_function_c<std::complex<float>> FType>
    // auto operator*(dvg_cmd<stknd, drpv, DX>, FType&& f) noexcept
    // {
    //     constexpr int pCount = parameter_size_v<FType, std::complex<float>>;

    //     return [&]<auto ...VarID>(value_container<VarID...>)
    //     {
    //         using namespace literals;
    //         using namespace calculus;

    //         return make_tensor( drv_cmd<stknd, drpv, VarID, 2, DX>{} * f ... );

    //     }(forward_sequence<pCount>());  
    // }

    // template<auto Dim, std_array_or_vector_c CntrType1, tuple_c CntrType2>
    // auto operator*(const tensor<value_container<Dim>, CntrType1>& L, 
    //                const tensor<value_container<Dim>, CntrType2>& R ) noexcept
    // {
    //     return [=]<auto...k>(value_container<k...>)
    //     {
    //         return ( (L.template get<k>() * R.template get<k>() ) + ... );

    //     }(forward_sequence<Dim>());
    // }
}
// end of namespace gmp


/*

1. Geodesic equation. (The Big Bang Equation)

     d²𝑥ᵏ         d𝑥ⁱ  d𝑥ʲ
    ————— + 𝛤ᵏᵢⱼ ———— ———— = 0  ... (1)
      d𝜏²          d𝜏  d𝜏  

    The derivation of the Geodesic equation is straightforward
    if learned Calculus of variation, which, in the current session we will not deal with
    
    Geodesics in general relativity
    https://en.wikipedia.org/wiki/Geodesics_in_general_relativity

    Deriving the geodesic equation via an action
    https://en.wikipedia.org/wiki/Geodesics_in_general_relativity

    010- Stress Energy Tensor 1, Metric Tensor gᵢⱼ unit, temporal - spatial derivative equivalence
    https://www.youtube.com/watch?v=qyUkfBsikPI
    (Oct 7, 2024)

    I've sensed it for several months ago, but could not prove it mathematically.

    The geodesic equation is the dynamic cancellation of curvature
     — making the motion appear straight in curved space.

            1
    𝛤ᵏᵢⱼ = ——— gⁿᵏ( ∂ᵢgₙⱼ + ∂ⱼgₙᵢ - ∂ₙgᵢⱼ) ... (2)
            2

            ∂𝐞ⱼ
         = ————— ⋅ 𝐞ᵏ
            ∂𝑥ⁱ


               ∂𝐫           ∂𝐫           ∂𝐫
         𝐞ᵢ = ————— , 𝐞ⱼ = ————— , 𝐞ₖ = —————
               ∂𝑥ⁱ          ∂𝑥ʲ          ∂𝑥ᵏ 
               
        
                𝐞ⱼ × eₖ              eₖ × eᵢ             𝐞ᵢ × 𝐞ⱼ 
         𝐞ⁱ = ———————————— , 𝐞ʲ = —————————————, 𝐞ᵏ = ————————————
              𝐞ᵢ × 𝐞ⱼ ⋅ eₖ          𝐞ᵢ × 𝐞ⱼ ⋅ eₖ         𝐞ᵢ × 𝐞ⱼ ⋅ eₖ    

    where gᵢⱼ = gⱼᵢ always holds for metric tensor gᵢⱼ is symmetric. (Really?)

             ∂𝐫    ∂𝐫
       gᵢⱼ = ——— ⋅ ——— = 𝐞ᵢ ⋅ 𝐞ⱼ 
             ∂𝑥ⁱ   ∂𝑥ʲ

       gⁱʲ = 𝐞ⁱ ⋅ 𝐞ʲ why? by SYMMETRIC principle.   

2. Understanding torsion

   The Frenet–Serret formulas are:
   https://en.wikipedia.org/wiki/Frenet%E2%80%93Serret_formulas

   𝐵 = 𝑇 × 𝑁 ... (3) 

    d𝑇
   ———— = 𝜅 𝑁 ... (4)
    d𝑠

    d𝑁
    ——— = -𝜅 𝑇 + 𝜏 𝐵  ... (5)
    d𝑠

    d𝐵
   ———— = -𝜏 𝑁 ... (6)       
    d𝑠

                                                  
    NOTE: for any vector V, whose |V| = constant, 
                                                  
     dV
    ———— ⋅ V = 0, i.e., dV/ds is normal to V
     d𝑠

    From eq (6)

    d𝐵
   ———— ⋅ 𝑁 = -𝜏 𝑁 ⋅ 𝑁  
    d𝑠

           d𝐵
    𝜏 = - ———— ⋅ 𝑁 ... (7)
           d𝑠

    If 𝜏 is zero,
        
        either d𝐵 = 0,
        or |-dB/ds| cos θ = 0, i.e., θ = ± 𝜋/2, perpendicular to 𝑁

    from eq (5)

     d𝑁
    ———— = -𝜅 𝑇 .... (8), 
     d𝑠

    that is, motion on T-N plane, or osculating plane

3. In Differential Geometry / Physics (Cartan Torsion)

    Torsion measures how much parallel transport fails to be path-independent in a manifold
    with affine connection.

    ∘ Without torsion: a parallelogram closes
    ∘ With torsion: it doesn't

    Torsion, in terms of Christoffel symbols, 
    
    𝑇ᵏᵢⱼ = 𝛤ᵏᵢⱼ - 𝛤ᵏⱼᵢ ... (9)

    d𝐁
    ——— = -𝜏 𝐍
    d𝑠

    d𝐍
    ——— = -𝜅 𝐓 + 𝜏 𝐁
    d𝑠
    
    ∘ If 𝑇ᵏᵢⱼ = 0, the connection is symmetric.
    ∘ General Relativity assumes zero torsion (Levi-Civita connection)
    ∘ Theories like Einstein-Cartan include non-zero torsion, allowing for spin-torsion coupling.

    Geometric Intuition
    ∘ Curvature: how space bends
    ∘ Torsion: how space twists during parallel transport

    If we apply the concept torsion = zero, from Frenet–Serret formula, to
    curvy surface, it means "the motion on the curvy surface, but not off the surface" ?

    Intuition:

    If you imagine walking on a sphere (e.g., Earth), zero torsion means
    your feet stay on the surface, following the curve (e.g., great circle).
    The direction changes due to curvature, but there's no out-of-plane twisting.

*/

#endif 
// end of file _GMP_TENSOR_TYPES_HPP
