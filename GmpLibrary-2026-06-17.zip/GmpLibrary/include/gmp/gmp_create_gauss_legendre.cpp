﻿#include <iostream> // For input/output operations (e.g., std::cout, std::cerr)
#include <fstream>  // For file stream operations (e.g., std::ifstream)
#include <string>   // For string manipulation (e.g., std::string, std::getline)
#include <vector>   // For dynamic arrays (e.g., std::vector)
#include <sstream>  // For string stream operations (e.g., std::stringstream)
#include <algorithm> // For std::remove, std::isspace
#include <cstring>

/**
 * @brief Trims leading and trailing whitespace from a string.
 * @param s The string to trim.
 */
void trim(std::string &s) 
{
    // Trim leading whitespace
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char ch) {
        return !std::isspace(ch);
    }));
    
    // Trim trailing whitespace
    s.erase(std::find_if(s.rbegin(), s.rend(), [](unsigned char ch) 
    {
        return !std::isspace(ch);
    }).base(), s.end());
}

/**
 * @brief Reads Legendre polynomial data from a specified file.
 * The file format expects:
 * - An integer on the first line, indicating 'n' (number of data points for the group).
 * - 'n' subsequent lines, each containing a quoted string, potentially followed by a comma.
 * This process repeats until the end of the file.
 * @param filename The path to the file to read.
 * @return A vector of vectors of strings, where each inner vector represents a group of data points.
 */
std::vector<std::vector<std::string>> read_legendre_data(const std::string& filename) {
    // Vector to store all groups of strings
    std::vector<std::vector<std::string>> all_groups;
    // Input file stream object
    std::ifstream file(filename);

    // Check if the file was opened successfully
    if (!file.is_open()) {
        std::cerr << "Error: Could not open file " << filename << std::endl;
        return all_groups; // Return an empty vector if file opening fails
    }

    std::string line;
    std::size_t group_size;

    // Loop through the file, reading group sizes and then the corresponding data lines
    while (std::getline(file, line)) {
        // Use a stringstream to parse the group size from the line
        std::stringstream ss(line);
        if (!(ss >> group_size)) {
            // If parsing fails, it might be an empty line or malformed, skip it.
            // Or, if it's the end of a previous group's data lines, it might be an empty line.
            // For robustness, we can check if the line is empty after trimming.
            trim(line); // Trim to check if it's truly empty
            if (line.empty()) {
                continue; // Skip empty lines
            }
            std::cerr << "Warning: Failed to parse group size from line: '" << line << "' in " << filename << std::endl;
            // Depending on desired error handling, you might want to break or throw here.
            // For now, we'll continue, which might lead to further parsing issues if the file is truly malformed.
            break; // Exit loop if a non-empty line cannot be parsed as a size
        }

        // Create a vector to hold strings for the current group
        std::vector<std::string> current_group;
        // Read 'group_size' number of lines for the current group
        for (std::size_t i = 0; i < group_size; ++i) 
        {
            if (std::getline(file, line)) 
            {
                // Clean the string: remove leading/trailing whitespace, quotes, and trailing commas
                trim(line); // Trim whitespace first

                // Remove leading quote if present
                if (!line.empty() && line.front() == '"') {
                    line.erase(0, 1);
                }
                // Remove trailing quote if present
                if (!line.empty() && line.back() == '"') {
                    line.pop_back();
                }
                // Remove trailing comma if present (after quote removal)
                if (!line.empty() && line.back() == ',') {
                    line.pop_back();
                }

                current_group.push_back(line); // Add the cleaned string to the current group
            } else {
                std::cerr << "Error: Unexpected end of file while reading group data for size " << group_size
                          << " in " << filename << ". Read " << i << " out of " << group_size << " lines." << std::endl;
                // Clear current_group and break to avoid adding incomplete data
                current_group.clear();
                break; // Exit inner loop
            }
        }
        
        // Only add the group if it's complete (i.e., not cleared due to error)
        if (current_group.size() == group_size) {
            all_groups.push_back(current_group); // Add the complete group to the main vector
        } else {
            // If the group was incomplete, break the outer loop as well, as file format is broken
            break;
        }
    }

    file.close(); // Close the file
    return all_groups; // Return the parsed data
}

int main(int argc, char* argv[])
{
    // Define the filenames
    const std::string abscissae_filename = "gauss_legendre_nodes_384.txt";
    const std::string weights_filename   = "gauss_legendre_weights_384.txt";

    // Read data from the abscissae file
    // std::cout << "Reading data from " << abscissae_filename << "..." << std::endl;
    std::vector<std::vector<std::string>> abscissae_data = read_legendre_data(abscissae_filename);
  
    // Read data from the weights file
    // std::cout << "\nReading data from " << weights_filename << "..." << std::endl;
    std::vector<std::vector<std::string>> weights_data = read_legendre_data(weights_filename);
    
    auto endl = "\n";
    auto endL = "\n\n";

    std::cout <<"/*" << endl;
    std::cout <<"    Author: Chang Hee Kim (Thomas Kim)" << endl;
    std::cout <<"    First Edit: June 15, 2025" << endL;

    std::cout <<"    License: Creative Commons Attribution 4.0 International (CC BY 4.0) "<< endL;

    std::cout <<"    You are free to: "<< endl;
    std::cout <<"        - Share - copy and redistribute the material in any medium or format "<< endl;
    std::cout <<"        - Adapt - remix, transform, and build upon the material for any purpose, even commercially. "<< endL;

    std::cout <<    "Under the following terms: "<< endl;
    std::cout <<"        - Attribution - You must give appropriate credit, provide a link to the license,  "<< endl;
    std::cout <<"        and indicate if changes were made. You may do so in any reasonable manner,  "<< endl;
    std::cout <<"        but not in any way that suggests the licensor endorses you or your use. "<< endL;

    std::cout <<"    License details: https://creativecommons.org/licenses/by/4.0/ "<< endl;
    std::cout <<"*/" << endL;

    std::cout << "#ifndef _GMP_GAUSS_LEGENDRE_HPP"<< endl;
    std::cout << "#define _GMP_GAUSS_LEGENDRE_HPP"<< endL;
    
    std::cout << "#include \"gmp_base.hpp\""<< endL;
    std::cout << "namespace gmp::calculus::hidden" << endl;
    std::cout << "{" << endl;

    //////////////////////////////////////////////////////////////////////////
    std::cout << "    // *******************************************"<< endl;
    std::cout << "    // Returns (abscissa, weight) pairs"<< endl;
    std::cout << "    //        for Gauss-Legendure Quadrature algorithm,"<< endl;
    std::cout << "    //        for data types std::float_point and std::complex numbers"<< endl;
    std::cout << "    //  "<< endl;
    std::cout << "    template<int N, std_real_cplx_c ValueType,"<< endl;
    std::cout << "        typename PairType = std::pair<ValueType, ValueType>," << endl;
    std::cout << "        typename ReturnType = std::array<PairType, (std::size_t)N>> requires ( N > 0 && N < 65 ) "<< endl;
    std::cout << "    constexpr ReturnType gauss_legendre_weights_nodes() noexcept" << endl;
    std::cout << "    {" << endl;
        
    int prec = 23;
    if(abscissae_data.size() == weights_data.size())
    {
        for(int group = 0; group < abscissae_data.size(); ++group)
        {

            if( abscissae_data[group].size() == weights_data[group].size())
            {
                if(group == 0)
                    std::cout <<"        if constexpr( N == " << (group+1) <<" )\n"
                            "            return ReturnType{";
                else 
                    std::cout <<"        else if constexpr( N == " << (group+1) <<" )\n"
                                "            return ReturnType{";

                auto& abscissae = abscissae_data[group];
                auto& weights = weights_data[group];

                for(int k = 0; k < abscissae.size(); ++k)
                {
                    if (k == 0)
                        std::cout << " PairType( (ValueType)";
                    else
                        std::cout << "                               PairType( (ValueType)";

                    std::cout << abscissae[k].substr(0, prec) 
                        << ", (ValueType)" << weights[k].substr(0, prec);

                    if(k + 1 != abscissae.size()) 
                        std::cout <<" ), " << endl;
                }

                std::cout <<" ) };" << endL;
            }
        }
    }

    std::cout << "    }" << endl;
    std::cout << "    // end of function gauss_legendre_weights_nodes()" << endl;
    std::cout << "    // for std::floating_point and std::complex types" << endL;
        
    std::cout << "    // *******************************************"<< endl;
    std::cout << "    // Returns (abscissa, weight) pairs"<< endl;
    std::cout << "    //        for Gauss-Legendure Quadrature algorithm,"<< endl;
    std::cout << "    //        for data types GMP real and complex numbers"<< endl;
    std::cout << "    //  "<< endl;
    std::cout << "    template<int N, gmp_real_cplx_c ValueType,"<< endl;
    std::cout << "        typename PairType = std::pair<ValueType, ValueType>," << endl;
    std::cout << "        typename ReturnType = std::array<PairType, (std::size_t)N>> requires ( N > 0 && N < 65 ) "<< endl;
    std::cout << "    constexpr ReturnType gauss_legendre_weights_nodes() noexcept" << endl;
    std::cout << "    {" << endl;
  
    if(argc == 2)
        prec = std::stoi(argv[1]);
    else
        prec = 350;
        
    if(abscissae_data.size() == weights_data.size())
    {
        for(int group = 0; group < abscissae_data.size(); ++group)
        {

            if( abscissae_data[group].size() == weights_data[group].size())
            {
                if(group == 0)
                    std::cout <<"        if constexpr( N == " << (group+1) <<" )\n"
                            "            return ReturnType{";
                else 
                    std::cout <<"        else if constexpr( N == " << (group+1) <<" )\n"
                                "            return ReturnType{";

                auto& abscissae = abscissae_data[group];
                auto& weights = weights_data[group];

                for(int k = 0; k < abscissae.size(); ++k)
                {
                    if (k == 0)
                        std::cout << " PairType( ValueType{ \"";
                    else
                        std::cout << "                               PairType( ValueType{ \"";

                    std::cout << abscissae[k].substr(0, prec) 
                        << "\" }, ValueType{ \"" << weights[k].substr(0, prec) <<"\" }";

                    if(k + 1 != abscissae.size()) 
                        std::cout <<" ), " << endl;
                }

                std::cout <<" ) };" << endL;
            }
        }
    }

    std::cout << "    }" << endl;
    std::cout << "    // end of function gauss_legendre_weights_nodes()" << endl;;
    std::cout << "    // for GMP realnum, cplxnum types" << endL;

    //////////////////////////////////////////////////////////////////////

    std::cout << "}" << std::endl;
    std::cout << "// end of namespace gmp::calculus::hidden" << std::endl << std::endl;

    std::cout << "#endif"<< endl;
    std::cout << "// end of file _GMP_GAUSS_LEGENDRE_HPP"<< endL;

    return 0; // Indicate successful execution
}