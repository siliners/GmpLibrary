/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.07.6
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/  
*/

#ifndef _GMP_STD_CPLX_HPP
#define _GMP_STD_CPLX_HPP

#include "gmp_base.hpp"

namespace gmp::binary_operations
{
    template<std::floating_point EleType, typename ScalarType>
    requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator + 
        (const std::complex<EleType>& c, ScalarType s)
    {
        using T = std::common_type_t<EleType, ScalarType>;

        return { (EleType) ((T)c.real() + (T)s), c.imag() };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator + 
        (ScalarType s, const std::complex<EleType>& c)
    {
        using T = std::common_type_t<EleType, ScalarType>;
        return { (EleType)((T) c.real() + (T)s), c.imag() };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator - 
        (const std::complex<EleType>& c, ScalarType s)
    {
        using T = std::common_type_t<EleType, ScalarType>;
        return { (EleType) ((T)c.real() - (T)s), c.imag() };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator - 
        (ScalarType s, const std::complex<EleType>& c)
    {
        using T = std::common_type_t<EleType, ScalarType>;
        return { (EleType) ((T)s - (T)c.real()), -c.imag() };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator * 
        (const std::complex<EleType>& c, ScalarType s)
    {
        using T = std::common_type_t<EleType, ScalarType>;
        return { (EleType) ((T)c.real() * (T)s), (EleType) c.imag() * s };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator * 
        (ScalarType s, const std::complex<EleType>& c)
    {
        using T = std::common_type_t<EleType, ScalarType>;
        return { (EleType) ((T)s * (T)c.real()), (EleType) s * c.imag() };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator / 
        (const std::complex<EleType>& c, ScalarType s)
    {
        using T = std::common_type_t<EleType, ScalarType>;
        return { (EleType) ((T)c.real() / (T)s), (EleType) ((T)c.imag() / (T)s) };
    }

    template<std::floating_point EleType, typename ScalarType>
        requires (!std::same_as<EleType, ScalarType>)
    std::complex<EleType> operator / 
        (ScalarType s, const std::complex<EleType>& c)
    {
        using T = std::common_type_t<EleType, ScalarType>;

        T denom = (T)c.real() * (T)c.real() + (T)c.imag() * (T)c.imag();
        
        return 
            {
                (EleType)(((T)s * (T)c.real()) / denom),
                (EleType)((-(T)s * (T)c.imag()) / denom)
            };
    }
}

#endif
// end of file name _STD_CPLX_EXTENSIONS_HPP