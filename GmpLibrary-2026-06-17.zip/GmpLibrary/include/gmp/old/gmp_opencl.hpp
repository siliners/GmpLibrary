﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.02.04
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/

    OpenCL™, OpenGL®, and Vulkan® Compatibility Pack
    https://apps.microsoft.com/detail/9nqpsl29bfff?ocid=msfe_edumktg_apps_oo_edu&hl=en-us&gl=KR

    Intel® CPU Runtimes for OpenCL™ Applications
    https://www.intel.com/content/www/us/en/developer/tools/opencl-cpu-runtime/overview.html

    OpenCL API Specification
    https://registry.khronos.org/OpenCL/specs/3.0-unified/html/OpenCL_API.html

    OpenCL C Language Specification
    https://registry.khronos.org/OpenCL/specs/3.0-unified/html/OpenCL_C.html

    OpenCL SPIR-V Environment Specification 
    https://registry.khronos.org/OpenCL/specs/3.0-unified/html/OpenCL_Env.html

    OpenCL 3.0 Reference Pages
    https://registry.khronos.org/OpenCL/sdk/3.0/docs/man/html/
    
    Getting started with OpenCL on Microsoft Windows
    https://github.com/KhronosGroup/OpenCL-Guide/blob/main/chapters/getting_started_windows.md


    cl /std:c++latest /EHsc /MD /nologo ocl.cpp /Fe: m.exe
    icx-cl -Qstd=c++23 /EHsc /nologo ocl.cpp -o i.exe
    clang++ -std=c++23 ocl.cpp -lgmp -lmpfr -lmpc -lopencl -ltbb12 -ltbbmalloc -o c.exe
        g++ -std=c++23 ocl.cpp -lgmp -lmpfr -lmpc -lopencl -ltbb12 -ltbbmalloc -o g.exe

*/

#ifndef GMP_OPENCL_HPP
#define GMP_OPENCL_HPP

#ifndef CL_TARGET_OPENCL_VERSION
    #define CL_TARGET_OPENCL_VERSION 300
#endif 

#include <cl/opencl.h>

#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <memory>

#if defined(_MSVC_LANG) || defined(__INTEL_LLVM_COMPILER)
    #pragma comment(lib, "opencl.lib")
#endif

namespace opencl
{
    namespace hidden
    {
        template<typename... Types>
        struct st_is_std_string: std::false_type { };

        template<typename... Types>
        struct st_is_std_string<std::basic_string<Types...>>: std::true_type { };

        template<>
        struct st_is_std_string<const char*>: std::true_type { };
    }
    // end of namespace hidden

    template<typename T>
    concept string_c = 
        hidden::st_is_std_string< std::remove_cvref_t<T>>::value;

    // OpenCL 3.0 Reference Pages
    // https://registry.khronos.org/OpenCL/sdk/3.0/docs/man/html/

    template<typename CharType = char>
    auto create_character_buffer(size_t character_count /* null terminating count is automatically adjusted */)
    {
        // +1 is for null terminating character
        // the reason we have to fill the buffer with zero
        // is that some system functions does not append terminating null character
        // especially Windows Win32 APIs
        return std::unique_ptr<CharType[]>( new CharType[character_count + 1]
            { /* we have to initialize with null characters */ } );
    }

    template<typename = void>
    std::string get_platform_info(cl_platform_id platform,
            cl_platform_info param_name)
    {
        size_t parameter_value_size;

        // STEP 1 - retrieve parameter_value_size
        auto error_num = 
            clGetPlatformInfo(platform, param_name, 0, NULL, &parameter_value_size);

        if(error_num != CL_SUCCESS || parameter_value_size == 0)
        {
            std::cout << "Failed to call clGetPlatformInfo() in STEP 1";
            return {};
        }

        // we allocated parameter_value_size characters
        // if the parameter_value_size is big enough, it works with no problem.
        // std::string is implemented using Small String Optimization technique.
        // if the string is big, the internal memory is dynamically allocated
        // otherwise, std::string does not dynamically allocate memory, instead use STACK memory
        // std::string platform_info('c', parameter_value_size);

        /*
            Small String Optimized (SSO) string class
            https://www.ibm.com/support/pages/small-string-optimized-sso-string-class
        */

        auto platform_info = create_character_buffer(parameter_value_size);

        error_num = clGetPlatformInfo(platform, param_name, parameter_value_size, platform_info.get(), NULL);

        return error_num == CL_SUCCESS ? std::string{ platform_info.get() } : std::string{};
    }

    std::vector<cl_device_id>
    get_device_ids(cl_platform_id platform, cl_device_type device_type)
    {
        cl_uint count;
        clGetDeviceIDs(platform, device_type, 0, NULL, &count);
        
        if(count == 0 ) {};
        
        std::vector<cl_device_id> devices(count);

        clGetDeviceIDs(platform, device_type, count, &devices.front(), NULL);
        return devices;
    }

    template<typename = void>
    auto enumerate_devices()
    {
        using ele_t = std::tuple<cl_platform_id, cl_device_id>;
        std::vector<ele_t> device_ids;

        cl_uint available_number_of_platforms;
        auto err_num = clGetPlatformIDs(0, NULL, &available_number_of_platforms);

        if(err_num != CL_SUCCESS || available_number_of_platforms == 0)
            { return device_ids; }

        std::vector<cl_platform_id> platforms(available_number_of_platforms);

        clGetPlatformIDs(available_number_of_platforms, platforms.data(), NULL);

        for(auto& platform: platforms)
        {
            auto devices = 
                get_device_ids(platform, CL_DEVICE_TYPE_GPU 
                    | CL_DEVICE_TYPE_CPU | CL_DEVICE_TYPE_ACCELERATOR);

            for(auto& device: devices)
            { 	
                device_ids.emplace_back(platform, device);
            }
        }

        return device_ids;
    }

    template<typename = void>
    std::string platform_info(cl_platform_id platform)
    {
        std::ostringstream oss;

        oss << "\tPlatform ID: " << platform << "\n";
        oss << "\tPlatform Vendor: " << get_platform_info(platform, CL_PLATFORM_VENDOR) << "\n";
        oss << "\tPlatform Name: " << get_platform_info(platform, CL_PLATFORM_NAME) << "\n";
        oss << "\tPlatform Profile: " << get_platform_info(platform, CL_PLATFORM_PROFILE) << "\n";
        oss << "\tPlatform Version: " << get_platform_info(platform, CL_PLATFORM_VERSION) 
                                       << "\n";
        auto extensions = 
            get_platform_info(platform, CL_PLATFORM_EXTENSIONS);

        std::ostringstream ext;
        for(auto c: extensions)
        {
            if(c == ' ') ext << "\n\t";
            else ext << c;
        }

        oss << "\n\tPlatform Extensions:\n\t" << ext.str();

        return oss.str();
    }

    template<typename = void>
    std::string device_info(cl_device_id device)
    {
        std::ostringstream oss;

        cl_uint vendor_id;
        clGetDeviceInfo(device, CL_DEVICE_VENDOR_ID, sizeof(vendor_id), &vendor_id, nullptr);
        oss << "\tVendor ID: " << vendor_id << "\n";

        cl_device_type dtype;
        clGetDeviceInfo(device, CL_DEVICE_TYPE, sizeof(dtype), &dtype, nullptr);

        oss <<"\tType: ";

        switch(dtype)
        {
            case CL_DEVICE_TYPE_CPU: oss <<"CPU" << "\n"; break;
            case CL_DEVICE_TYPE_GPU: oss <<"GPU" << "\n"; break;
            case CL_DEVICE_TYPE_ACCELERATOR: oss <<"ACCELERATOR" << "\n"; break;
            default:
            oss <<"Unknown" << "\n";
        }

        std::size_t bsize;
        clGetDeviceInfo(device, CL_DEVICE_NAME, 0, nullptr, &bsize);
        std::unique_ptr<char[]> device_name(new char[bsize+1]{});

        clGetDeviceInfo(device, CL_DEVICE_NAME, bsize, device_name.get(), nullptr);
        oss << "\tDevice Name: " << device_name.get() << "\n";

        clGetDeviceInfo(device, CL_DEVICE_VERSION, 0, nullptr, &bsize);
        std::unique_ptr<char[]> device_version(new char[bsize+1]{});

        clGetDeviceInfo(device, CL_DEVICE_VERSION, bsize, device_version.get(), nullptr);
        oss << "\tDevice Version: " 
            << device_version.get() << "\n\n";

        cl_uint max_compute_units;
        clGetDeviceInfo(device, CL_DEVICE_MAX_COMPUTE_UNITS,
                sizeof(max_compute_units), &max_compute_units, nullptr);
        oss << "\tDEVICE_MAX_COMPUTE_UNITS: " << max_compute_units << "\n";

        cl_uint max_work_item_dimensions;
        clGetDeviceInfo(device, CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS,
                sizeof(max_work_item_dimensions), &max_work_item_dimensions, nullptr);
        oss << "\tCL_DEVICE_MAX_WORK_ITEM_DIMENSIONS: " << max_work_item_dimensions << "\n";

        std::unique_ptr<std::size_t[]> 
            work_item_sizes(new std::size_t[max_work_item_dimensions]{});

        clGetDeviceInfo(device, CL_DEVICE_MAX_WORK_ITEM_SIZES,
                sizeof(std::size_t) * max_work_item_dimensions,
                    work_item_sizes.get(), nullptr);

        oss << "\tCL_DEVICE_MAX_WORK_ITEM_SIZES: [";

        for(cl_uint i = 0; i < max_work_item_dimensions-1; ++i)
            oss << work_item_sizes[i] << ", ";

        oss << work_item_sizes[max_work_item_dimensions-1] << "]" << "\n";

        std::size_t max_work_group_size;

        clGetDeviceInfo(device, CL_DEVICE_MAX_WORK_GROUP_SIZE,
            sizeof(max_work_group_size), &max_work_group_size, nullptr);

        oss << "\tCL_DEVICE_MAX_WORK_GROUP_SIZE: " 
            << max_work_group_size << "\n\n";

        cl_uint global_mem_cacheline_size;
        clGetDeviceInfo(device, CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE,
                sizeof(cl_uint), &global_mem_cacheline_size, nullptr);
        oss << "\tCL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE: " 
            << global_mem_cacheline_size << "\n";

        cl_ulong global_mem_cache_size;
        clGetDeviceInfo(device, CL_DEVICE_GLOBAL_MEM_CACHE_SIZE,
                sizeof(cl_ulong), &global_mem_cache_size, nullptr);
        oss << "\tCL_DEVICE_GLOBAL_MEM_CACHE_SIZE: " 
            << global_mem_cache_size << "\n";

        cl_ulong global_mem_size;
        clGetDeviceInfo(device, CL_DEVICE_GLOBAL_MEM_SIZE,
                sizeof(cl_ulong), &global_mem_size, nullptr);
        oss << "\tCL_DEVICE_GLOBAL_MEM_SIZE: " 
            << global_mem_size << "\n";

        cl_ulong local_mem_size;
        clGetDeviceInfo(device, CL_DEVICE_LOCAL_MEM_SIZE, sizeof(cl_ulong), &local_mem_size, nullptr);
        oss << "\tCL_DEVICE_LOCAL_MEM_SIZE: " 
            << local_mem_size << "\n\n";

        cl_uint native_vector_width_float;
        clGetDeviceInfo(device, CL_DEVICE_NATIVE_VECTOR_WIDTH_FLOAT,
            sizeof(native_vector_width_float), &native_vector_width_float, nullptr);

        oss << "\tCL_DEVICE_NATIVE_VECTOR_WIDTH_FLOAT: " 
            << native_vector_width_float << "\n";

        cl_uint preferred_vector_width_float;
        clGetDeviceInfo(device, CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT,
            sizeof(preferred_vector_width_float), &preferred_vector_width_float, nullptr);

        oss << "\tCL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT: " 
            << preferred_vector_width_float << "\n";

        cl_uint native_vector_width_double;
        clGetDeviceInfo(device, CL_DEVICE_NATIVE_VECTOR_WIDTH_DOUBLE,
            sizeof(native_vector_width_double), &native_vector_width_double, nullptr);

        oss << "\tCL_DEVICE_NATIVE_VECTOR_WIDTH_DOUBLE: " 
            << native_vector_width_double << "\n";

        cl_uint preferred_vector_width_double;
        clGetDeviceInfo(device, CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE,
            sizeof(preferred_vector_width_double), &preferred_vector_width_double, nullptr);

        oss << "\tCL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE: " 
            << preferred_vector_width_double << "\n\n";

        return oss.str();
    }
    

    template<typename = void>
    void display_devices()
    {
        auto platform_devices = enumerate_devices();
        
        for(int index = 0; 
                auto& [ platform, device ]: platform_devices)
        {
            std::cout << "Device : " << index << std::endl;
            std::cout << platform_info(platform) << std::endl << std::endl;
            std::cout << device_info(device) << std::endl;
            
            ++index;
        }
    }
    
    template<typename = void>
    bool is_fp64_supported(cl_device_id device)
    {
        cl_uint width;
        clGetDeviceInfo(device, CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE,
                sizeof(width), &width, nullptr);
        
        /*
            If double precision is not supported,
            CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE must return 0.
        */
        return width != 0;
    }

    std::string get_file_extension(std::string filename)
    {
        auto pos = filename.find_last_of('.');
        
        if(pos == std::string::npos) return "";
        return filename.substr(pos+1);
    }

    template<typename = void>
    std::string read_file(const std::string& filename) 
    {
        std::ifstream file{filename, std::ios::in};

        if (!file.is_open()) 
        {
            throw std::runtime_error("Failed to open file: " + filename);
        }

        std::string content{ std::istreambuf_iterator<char>(file),
                             std::istreambuf_iterator<char>() };
        
        if(content.size() > 4)
        {
            // UTF-8
            if( content[0] == (char)0xEF && content[1] == (char)0xBB && content[2] == (char)0xBF)
            {
                return content.substr(3, content.size()-3);
            }
            // UTF-16(BE)
            else if(content[0] == (char)0xFE && content[1] == (char)0xFF) 
            {
                return content.substr(2, content.size()-2);
            }
            // UTF-16(LE)
            else if(content[0] == (char)0xFF && content[1] == (char)0xFE) 
            {
                return content.substr(2, content.size()-2);
            }
            // UTF-32(BE)
            else if(content[0] == (char)0    && content[1] == (char)0 &&
                    content[2] == (char)0xFE && content[3] == (char)0xFF) 
            {
                return content.substr(4, content.size()-4);
            }
            // UTF-32(LE)
            else if(content[0] == (char)0    && content[1] == (char)0 &&
                    content[2] == (char)0xFF && content[3] == (char)0xFE) 
            {
                    return content.substr(4, content.size()-4);
            }
            // UTF-7
            else if(content[0] == (char)0x2B && content[1] == (char)0x2F &&
                    content[2] == (char)0x76) 
            {
                    return content.substr(3, content.size()-3);
            }
        }

        return content;
    }

    template<typename = void>
    auto group_header_source_files(const std::vector<std::string>& filenames)
    {
        using pair_t = std::pair<int, std::string>;

        auto comp = [](const pair_t& a, const pair_t& b)
            { return a.second < b.second; };

        auto comp_idx = [](const pair_t& a, const pair_t& b)
            { return a.first < b.first; };

        std::set<pair_t, decltype(comp)> headers{ comp };
        std::set<pair_t, decltype(comp)> sources{ comp };

        int index_header = 0;
        int index_source = 0;

        for(auto& filename: filenames)
        {
            if(get_file_extension(filename) == std::string{"clh"})
            {
                headers.insert(pair_t{index_header, filename});
                ++index_header; continue;
            }
            else
            {
                sources.insert(pair_t{index_source, filename});
                ++index_source; continue;
            }
        }

        std::vector<pair_t> hdrs;
        std::vector<std::string> header_files;

        if(!headers.empty())
        {
            for(auto& h: headers) hdrs.push_back(h);
            std::sort(hdrs.begin(), hdrs.end(), comp_idx);
            
            for(auto& h: hdrs) 
                header_files.emplace_back(h.second);
        }
        
        std::vector<pair_t> srcs;
        std::vector<std::string> source_files;

        if(!sources.empty())
        {
            for(auto& s: sources) srcs.push_back(s);
            std::sort(srcs.begin(), srcs.end(), comp_idx);

            for(auto& s: srcs)
                source_files.emplace_back(s.second);
        }

        return std::tuple{header_files, source_files};
    }
    
    class context;
    class kernel;
    class command_queue;
    class program;

    template<typename, std::size_t> 
    class mem;

    class context
    {
        private:
            cl_context cl_obj{};

        public:
            context(){ }

        bool create()
        {
            cl_int errNum;
            cl_uint numPlatforms;
            cl_platform_id firstPlatformId;
            
            // First, select an OpenCL platform to run on.  For this example, we
            // simply choose the first available platform.  Normally, you would
            // query for all available platforms and select the most appropriate one.
            errNum = clGetPlatformIDs(1, &firstPlatformId, &numPlatforms);
            if (errNum != CL_SUCCESS || numPlatforms <= 0)
            {
                std::cout << "Failed to find any OpenCL platforms." << std::endl;
                return false;
            }

            // Next, create an OpenCL context on the platform.  Attempt to
            // create a GPU-based context, and if that fails, try to create
            // a CPU-based context.
            cl_context_properties contextProperties[] =
            {
                CL_CONTEXT_PLATFORM,
                (cl_context_properties)firstPlatformId,
                0
            };

            this->cl_obj = clCreateContextFromType(contextProperties, CL_DEVICE_TYPE_GPU,
                                            NULL, NULL, &errNum);
            if (errNum != CL_SUCCESS)
            {
                std::cout << "Could not create GPU context, trying CPU..." << std::endl;
                this->cl_obj = clCreateContextFromType(contextProperties, CL_DEVICE_TYPE_CPU,
                                                NULL, NULL, &errNum);
                if (errNum != CL_SUCCESS)
                {
                    std::cout << "Failed to create an OpenCL GPU or CPU context." << std::endl;
                    return false;
                }
            }

            return true;
        }

        bool create(cl_device_type device_type)
        {
            cl_int errNum;
            cl_uint numPlatforms;
            cl_platform_id firstPlatformId;
            
            // First, select an OpenCL platform to run on.  For this example, we
            // simply choose the first available platform.  Normally, you would
            // query for all available platforms and select the most appropriate one.
            errNum = clGetPlatformIDs(1, &firstPlatformId, &numPlatforms);
            if (errNum != CL_SUCCESS || numPlatforms <= 0)
            {
                std::cout << "Failed to find any OpenCL platforms." << std::endl;
                return false;
            }

            // Next, create an OpenCL context on the platform.  Attempt to
            // create a GPU-based context, and if that fails, try to create
            // a CPU-based context.
            cl_context_properties contextProperties[] =
            {
                CL_CONTEXT_PLATFORM,
                (cl_context_properties)firstPlatformId,
                0
            };

            this->cl_obj = clCreateContextFromType(contextProperties, device_type,
                                            NULL, NULL, &errNum);
            if (errNum != CL_SUCCESS)
            {
                std::cout << "Failed to create an OpenCL GPU or CPU context." << std::endl;
                return false;
            }

            return true;
        }

        bool create(std::string device_name,
                cl_device_type device_type = CL_DEVICE_TYPE_GPU)
        {
            cl_int errNum;
            cl_uint numPlatforms;
            
            errNum = clGetPlatformIDs(0, NULL, &numPlatforms);
            if(errNum != CL_SUCCESS)
            {
                std::cout << "Failed to select device [" 
                    << device_name <<"]" << std::endl;

                return false;
            }

            std::unique_ptr<cl_platform_id[]> 
                platforms(new cl_platform_id[numPlatforms]);

            errNum = clGetPlatformIDs(numPlatforms, platforms.get(), nullptr);

            cl_platform_id platform = NULL;
            for(int i=0; i <(int)numPlatforms; ++i)
            {  
                auto vendor = 
                    get_platform_info(platforms[i], CL_PLATFORM_VENDOR);

                auto pos = vendor.find(device_name);
                if(pos != std::string::npos)
                {
                    platform = platforms[i]; break;
                }
            }

            if(platform == NULL)
            {
                std::cout <<"Failed to find platform " << std::endl;
                return false;
            }

            cl_uint deviceCount = 0;

            clGetDeviceIDs(platform, device_type, 0, nullptr, &deviceCount);
            
            if(deviceCount == 0)
            {
                std::cout << "Device count is zero" << std::endl;
                return false;
            }

            std::vector<cl_device_id> devices(deviceCount);
            clGetDeviceIDs(platform, device_type, deviceCount, devices.data(), nullptr);

            cl_device_id device_id = devices.front();

            this->cl_obj = clCreateContext(nullptr, 1, &device_id,
                    nullptr, nullptr, &errNum);

            if(errNum != CL_SUCCESS)
            {
                std::cout << "Failed to create device" << std::endl;
                return false;
            }
                
            return true;
        }

        const cl_context object() const 
            { return this->cl_obj; }

        cl_context& object()
            { return this->cl_obj; }

        operator bool() const
        {   return this->cl_obj != nullptr; }

        std::string display_info() const
        {
            cl_int errNum;
            std::size_t device_count = 0;

            errNum = clGetContextInfo(this->cl_obj,
                CL_CONTEXT_NUM_DEVICES, sizeof(device_count), &device_count, NULL);

            if(errNum != CL_SUCCESS)
            {
                return "Failed getting device count";
            }

            // std::cout << "device count = " << device_count << std::endl;

            std::unique_ptr<cl_device_id[]> 
                devices(new cl_device_id[device_count]{});
            
            std::size_t count;

            errNum = clGetContextInfo(this->cl_obj, 
                CL_CONTEXT_DEVICES, sizeof(cl_device_id) * device_count, devices.get(), &count);

            if(errNum != CL_SUCCESS)
            {
                return "Failed to fill devices";
            }

            std::ostringstream oss;

            for(size_t i = 0; i < device_count; ++i)
            {
                std::size_t len;
                clGetDeviceInfo(devices[i], CL_DEVICE_NAME, NULL, NULL, &len);
              
                std::unique_ptr<char[]> device_name(new char[len+1]{});
                clGetDeviceInfo(devices[i], CL_DEVICE_NAME, len, device_name.get(), &len);

                oss << "Device " << i <<" Name: " << device_name <<"\n";

                cl_device_type device_type;
                clGetDeviceInfo(devices[i], CL_DEVICE_TYPE, sizeof(device_type), &device_type, NULL);
                oss <<"Device " << i << " Type: ";

                switch(device_type)
                {
                    case CL_DEVICE_TYPE_CPU: 
                        oss << "CPU\n"; break;

                    case CL_DEVICE_TYPE_GPU:
                        oss << "GPU\n"; break;

                    case CL_DEVICE_TYPE_ACCELERATOR:
                        oss << "Accelerator\n"; break;

                    default: oss << "Default Device\n";
                }

                oss << "Device " << i <<" Type double supported: ";
                
                if(is_fp64_supported(devices[i]))
                    oss << "true" << "\n";
                else
                    oss << "false" << "\n";

                cl_uint max_compute_units;
                clGetDeviceInfo(devices[i], CL_DEVICE_MAX_COMPUTE_UNITS,
                      sizeof(max_compute_units), &max_compute_units, NULL);
                
                oss << "Device " << i <<" Max Compute Units: " 
                    << max_compute_units <<"\n";

                std::size_t max_work_group_size;
                clGetDeviceInfo(devices[i], CL_DEVICE_MAX_WORK_GROUP_SIZE,
                      sizeof(max_work_group_size), &max_work_group_size, NULL);
                
                oss << "Device " << i <<" Max Work Group Size: " 
                    << max_work_group_size <<"\n";

                cl_uint max_work_item_dimensions;
                clGetDeviceInfo(devices[i], CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS,
                      sizeof(max_work_item_dimensions), &max_work_item_dimensions, NULL);
                
                oss << "Device " << i <<" Max Work Item Dimensions: " 
                    << max_work_item_dimensions <<"\n";

                std::unique_ptr<std::size_t[]> 
                    max_work_item_sizes(new std::size_t[max_work_item_dimensions]{});

                clGetDeviceInfo(devices[i], CL_DEVICE_MAX_WORK_ITEM_SIZES,
                      sizeof(std::size_t) * max_work_item_dimensions,
                            max_work_item_sizes.get(), NULL);
                
                oss << "Device " << i <<" Max Work Item Sizes: [";
                for(int i=0; i < (int)max_work_item_dimensions; ++i)
                {
                    oss << max_work_item_sizes[i];

                    if(i != (int)max_work_item_dimensions-1)
                        oss << ", ";
                    else
                        oss <<"]\n";
                }
                                               
                cl_ulong global_mem_size;
                clGetDeviceInfo(devices[i], CL_DEVICE_GLOBAL_MEM_SIZE,
                      sizeof(global_mem_size), &global_mem_size, NULL);
                
                oss << "Device " << i <<" Global Memory Size: " 
                    << global_mem_size <<" bytes\n";

                cl_ulong local_mem_size;
                clGetDeviceInfo(devices[i], CL_DEVICE_LOCAL_MEM_SIZE,
                      sizeof(local_mem_size), &local_mem_size, NULL);
                
                oss << "Device " << i <<" Local Memory Size : " 
                    << local_mem_size <<" bytes\n";
            }

            return oss.str();
        }

        context(const context& ctx): cl_obj{ctx.cl_obj}
        {
            clRetainContext(this->cl_obj);
        }

        context(context&& ctx): cl_obj{ ctx.cl_obj }
        {  ctx.reset(); }

        context& operator=(const context& ctx)
        {
            if(this != std::addressof(ctx))
            {
                this->cleanup();
                this->cl_obj = ctx.cl_obj;
                clRetainContext(this->cl_obj);
            }

            return *this;
        }
        context& operator=(context&& ctx)
        {
            if(this != std::addressof(ctx))
            {
                this->cleanup();
                this->cl_obj = ctx.cl_obj;
                ctx.reset();
            }

            return *this;
        }
        
        void reset() { cl_obj = nullptr; }
        void cleanup() 
            { 
                if(this->cl_obj)
                    clReleaseContext(this->cl_obj);

                this->reset();
            }

        ~context() 
        { 
            cleanup(); 
        }
    };
    // end of class context

    class command_queue
    {
        private:
            cl_command_queue cl_obj{};

        public:
            command_queue(){ }

        const cl_command_queue object() const 
            { return this->cl_obj; }

        cl_command_queue& object()
            { return this->cl_obj; }

        operator bool() const
        {   return this->cl_obj != nullptr; }

        bool enqueue_nd_range_kernel(const kernel& knl)
        {
            
        }

        command_queue(const command_queue&) = delete;
        command_queue(command_queue&&) = delete;
        command_queue& operator=(const command_queue&) = delete;
        command_queue& operator=(command_queue&&) = delete;

        bool create_with_properties(const context& context,
            cl_device_id* device, const cl_queue_properties* properties)
        {
            /*
                    Provided by CL_VERSION_2_0
                cl_command_queue clCreateCommandQueueWithProperties(
                    cl_context context,
                    cl_device_id device,
                    const cl_queue_properties* properties,
                    cl_int* errcode_ret);
            */

            cl_int errNum;
            size_t deviceBufferSize = -1;

            // First get the size of the devices buffer
            errNum = clGetContextInfo(context.object(), CL_CONTEXT_DEVICES, 0, NULL, &deviceBufferSize);
            if (errNum != CL_SUCCESS)
            {
                std::cout << "Failed call to clGetContextInfo(...,GL_CONTEXT_DEVICES,...)";
                return false;
            }

            if (deviceBufferSize <= 0)
            {
                std::cout << "No devices available.";
                return false;
            }

            // Allocate memory for the devices buffer
            // cl_device_id *devices;
            
            std::unique_ptr<cl_device_id[]> 
                    devices( new cl_device_id[deviceBufferSize / sizeof(cl_device_id)]{ } );

            errNum = clGetContextInfo(context.object(),
                CL_CONTEXT_DEVICES, deviceBufferSize, devices.get(), NULL);

            if (errNum != CL_SUCCESS)
            {
                std::cout << "Failed to get device IDs";
                return false;
            }

            // In this example, we just choose the first available device.  In a
            // real program, you would likely use all available devices or choose
            // the highest performance device based on OpenCL device queries
            this->cl_obj = clCreateCommandQueueWithProperties(context.object(),
                devices[0], properties, &errNum);
            
            if (errNum != CL_SUCCESS)
            {
                std::cout << "Failed to create commandQueue for device 0";
                return false;
            }

            *device = devices[0];

            return true;
        }

        void reset() { cl_obj = nullptr; }
        void cleanup() 
            { 
                if(this->cl_obj)
                    clReleaseCommandQueue(this->cl_obj);

                this->reset();
            }

        ~command_queue() { cleanup(); }
    };
    // end of class command_queue
   
    class program
    {
        private:
            cl_program cl_obj{};

        public:
            program(){ }

        const cl_program object() const 
            { return this->cl_obj; }

        cl_program& object()
            { return this->cl_obj; }

        operator bool() const
        {   return this->cl_obj != nullptr; }

        template<string_c... FileTypes>
        bool create(const context& ctx, cl_device_id device,
                    const char* option, FileTypes... filenames)
        {
            cl_int errNum;

            auto contents = [fnames = std::forward_as_tuple(filenames...)]
                    <int... ns> (std::integer_sequence<int, ns...>) -> std::vector<std::string>
                {
                    return { read_file(std::get<ns>(fnames))... };

                }( std::make_integer_sequence<int, sizeof...(filenames)> { });

            std::vector<const char*> str_contents;

            for(const auto& c: contents)
                str_contents.emplace_back(c.c_str());

            this->cl_obj = clCreateProgramWithSource(ctx.object(), (cl_uint)str_contents.size(),
                                                (const char**)str_contents.data(),
                                                NULL, &errNum);
            if (errNum != CL_SUCCESS)
            {
                std::cout << "Failed to create CL program from source." << std::endl;
                return false;
            }

            errNum = clBuildProgram(this->cl_obj, 1, &device, option, NULL, NULL);
            if (errNum != CL_SUCCESS)
            {
                // Determine the reason for the error
                char buildLog[16384];
                clGetProgramBuildInfo(this->cl_obj, device, CL_PROGRAM_BUILD_LOG,
                                    sizeof(buildLog), buildLog, NULL);

                std::cout << "Error in kernel: " << std::endl;
                std::cout << buildLog;
                
                cleanup(); 
                
                return false;
            }

            return true;
        }

        program(const program&) = delete;
        program(program&&) = delete;
        program& operator=(const program&) = delete;
        program& operator=(program&&) = delete;

        void reset() { cl_obj = nullptr; }
        void cleanup() 
            { 
                if(this->cl_obj)
                    clReleaseProgram(this->cl_obj);

                this->reset();
            }

        ~program() { cleanup(); }
    };
    // end of class program

    class kernel
    {
        private:
            cl_kernel cl_obj{};

        public:
            kernel(){ }

        const cl_kernel object() const 
            { return this->cl_obj; }

        cl_kernel& object()
            { return this->cl_obj; }

        operator bool() const
        {   return this->cl_obj != nullptr; }

        kernel(const kernel&) = delete;
        kernel(kernel&&) = delete;
        kernel& operator=(const kernel&) = delete;
        kernel& operator=(kernel&&) = delete;

        bool create(const program& prog, const char* kernel_name)
        {
            cl_int errNum;
            this->cl_obj = 
                clCreateKernel(prog.object(), kernel_name, &errNum);

            if(errNum != CL_SUCCESS)
            {
                std::cout << "failed to create kernel " << kernel_name << std::endl;
                return false;
            }

            return true;
        }

        void reset() { cl_obj = nullptr; }
        void cleanup() 
            { 
                if(this->cl_obj)
                    clReleaseKernel(this->cl_obj);

                this->reset();
            }

        ~kernel() { cleanup(); }
    };
    // end of class kernel

    // Helper function to convert OpenCL error codes to strings
    const char* getOpenCLErrorString(cl_int error_code) 
    {
        switch (error_code) 
        {
            case CL_SUCCESS: return "CL_SUCCESS";
            case CL_DEVICE_NOT_FOUND: return "CL_DEVICE_NOT_FOUND";
            case CL_DEVICE_NOT_AVAILABLE: return "CL_DEVICE_NOT_AVAILABLE";
            case CL_COMPILER_NOT_AVAILABLE: return "CL_COMPILER_NOT_AVAILABLE";
            case CL_MEM_OBJECT_ALLOCATION_FAILURE: return "CL_MEM_OBJECT_ALLOCATION_FAILURE";
            case CL_OUT_OF_RESOURCES: return "CL_OUT_OF_RESOURCES";
            case CL_OUT_OF_HOST_MEMORY: return "CL_OUT_OF_HOST_MEMORY";
            case CL_PROFILING_INFO_NOT_AVAILABLE: return "CL_PROFILING_INFO_NOT_AVAILABLE";
            case CL_MEM_COPY_OVERLAP: return "CL_MEM_COPY_OVERLAP";
            case CL_IMAGE_FORMAT_MISMATCH: return "CL_IMAGE_FORMAT_MISMATCH";
            case CL_IMAGE_FORMAT_NOT_SUPPORTED: return "CL_IMAGE_FORMAT_NOT_SUPPORTED";
            case CL_BUILD_PROGRAM_FAILURE: return "CL_BUILD_PROGRAM_FAILURE";
            case CL_MAP_FAILURE: return "CL_MAP_FAILURE";
            case CL_MISALIGNED_SUB_BUFFER_OFFSET: return "CL_MISALIGNED_SUB_BUFFER_OFFSET";
            case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST: return "CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST";
            case CL_COMPILE_PROGRAM_FAILURE: return "CL_COMPILE_PROGRAM_FAILURE";
            case CL_LINKER_NOT_AVAILABLE: return "CL_LINKER_NOT_AVAILABLE";
            case CL_LINK_PROGRAM_FAILURE: return "CL_LINK_PROGRAM_FAILURE";
            case CL_DEVICE_PARTITION_FAILED: return "CL_DEVICE_PARTITION_FAILED";
            case CL_KERNEL_ARG_INFO_NOT_AVAILABLE: return "CL_KERNEL_ARG_INFO_NOT_AVAILABLE";
            default: return "Unknown error code";
        }
    }
    
    template<typename Type, std::size_t Count = 1>
    class mem
    {
        private:
            cl_mem cl_obj{};

        public:
            mem(){ }

            mem(const context& ctx, Type(&arg)[Count])
            {
                if(!create(ctx, arg))
                    throw std::runtime_error("Falled");
            }

            mem(const context& ctx)
            {
                if(!create(ctx))
                    throw std::runtime_error("Falled");
            }

        const cl_mem object() const 
            { return this->cl_obj; }

        cl_mem& object()
            { return this->cl_obj; }

        operator bool() const
        {   return this->cl_obj != nullptr; }

        mem(const mem&) = delete;
        mem(mem&&) = delete;
        mem& operator=(const mem&) = delete;
        mem& operator=(mem&&) = delete;

        bool create(const context& ctx)
        {
            cl_int errNum;

            this->cl_obj = clCreateBuffer(ctx.object(), CL_MEM_READ_WRITE,
                            sizeof(Type) * Count, NULL, &errNum);
            
            if(errNum != CL_SUCCESS)
            {
                std::cout << "failed to create mem" << std::endl;
                std::cout << "Error: " << getOpenCLErrorString(errNum) << std::endl;
                return false;
            }
            else 
                return true;
        }

        bool create(const context& ctx, Type* arg)
        {
            cl_int errNum;

            if constexpr(std::is_const_v<Type>)
            {
                this->cl_obj = 
                    clCreateBuffer(ctx.object(), CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                        sizeof(Type) * Count, (void*)arg, &errNum);
            }
            else
            {
                this->cl_obj = 
                    clCreateBuffer(ctx.object(), CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR,
                        sizeof(Type) * Count, (void*)arg, &errNum);
            }

            if(errNum != CL_SUCCESS)
            {
                std::cout << "failed to create mem" << std::endl;
                std::cout << "Error: " << getOpenCLErrorString(errNum) << std::endl;
                return false;
            }
            else 
                return true;
        }

        void reset() 
        { 
            cl_obj = nullptr; 
        }
        void cleanup() 
            { 
                for(int i = 0; i < Count; ++i)
                {
                    if(cl_obj != nullptr)
                        clReleaseMemObject(cl_obj); 

                    cl_obj = nullptr;
                }
            }

        ~mem() { cleanup(); }
    };
    // end of class mem

    namespace hidden
    {
        template<typename T>
        struct st_is_mem: std::false_type {};

        template<typename Type, std::size_t Count>
        struct st_is_mem<mem<Type, Count>>: std::true_type {};
    }
    // end of namespace hidden

    template<typename T>
    concept mem_c = hidden::st_is_mem<std::remove_cvref_t<T>>::value;

    bool set_kernel_args(const kernel& knl, mem_c auto&... args)
    {
        auto set_arg = [&knl, values = std::forward_as_tuple(args...)]<cl_uint n>
            (std::integer_sequence<cl_uint, n>) -> cl_int
            {
                return clSetKernelArg(knl.object(), n, sizeof(cl_mem), &std::get<n>(values).object());
            };

        return [&set_arg]<cl_uint... ns>
            (std::integer_sequence<cl_uint, ns...>)
        {
            return (set_arg(std::integer_sequence<cl_uint, ns>{}) | ... );

        }( std::make_integer_sequence<cl_uint, sizeof...(args)>{} );
    }
}

#endif
// end of file