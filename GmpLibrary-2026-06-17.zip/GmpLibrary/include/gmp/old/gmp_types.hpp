/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.01.07
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/
*/

#ifndef _GMP_TYPES_HPP
#define _GMP_TYPES_HPP

#if defined(_MSVC_LANG) || defined(__INTEL_LLVM_COMPILER)

    #if defined(_DEBUG) || defined(DEBUG)
        #pragma message("DEBUG BUILD, liked with mpir_d, mpfr_d")
        #pragma comment(lib, "mpir_d.lib")
        #pragma comment(lib, "mpfr_d.lib")
        #pragma comment(lib, "mpc_d.lib")
    #else
        #pragma message("NODEBUG BUILD, liked with mpir, mpfr")
        #pragma comment(lib, "mpir.lib")
        #pragma comment(lib, "mpfr.lib")
        #pragma comment(lib, "mpc.lib")
    #endif

#endif

#include <tbb/tbb.h>
#include <gmpxx.h>
#include <mpreal.h>
#include <mpc.h>

#include <iostream>
#include <cmath>
#include <complex>
#include <concepts>

/*
    In any languages, be it a natural language such as English or Korean,
    or computer programming language such as C++, name clashes are serious problems.

    NEVER ever declare or define PRETTY names in the Global Namespace!!!
    If you keep this in mind, you can create millions of lines of C++ code without name clashes!!
*/

namespace gmp
{
    // type container
    template<typename... Types> struct type_container{ };

    // value container
    template<auto... Values> struct value_container{ };

    template<typename Type, typename... Types>
    concept type_in_types_c = (std::same_as<Type, Types> || ...);

    template<std::floating_point ArgType, std::integral ReturnType = int>
    consteval ReturnType floor(ArgType v)
    {
        return (ReturnType)v;   
    }

    template<std::floating_point ArgType, std::integral ReturnType = int>
    consteval ReturnType ceil(ArgType v)
    {
        if ( (ReturnType)(v * 10) - ((ReturnType)v * 10))
            return (ReturnType)(v) + 1;
        else
            return (ReturnType)v;
    }

    // nontype floating-point template argument v
    template<std::floating_point auto v, std::integral ReturnType = int>
    constexpr ReturnType flr()
    {
        return (ReturnType)v;   
    }

    // nontype floating-point template argument v
    template<std::floating_point auto v, std::integral ReturnType = int>
    constexpr ReturnType cel()
    {
        if constexpr ( (ReturnType)(v * 10) - ((ReturnType)v * 10))
            return (ReturnType)(v) + 1;
        else
            return (ReturnType)v;
    }
}
// end of namespace gmp

namespace mpfr
{
    /*
        2^10 = Q = 1024 ≈ 1000 = 10^3

        2^10 = Q ≈ 10^3

        2^(binary digits) = Q ≈ 10^(decimal digits)

        bits = binary digits = 10
        digits = decimal digits = 3

        2^bits = Q ≈ 10^digits 

        log2 (2^bits) = log2(Q)

        bits = log2(Q)

        bits/log2(Q) = 1 .... Eq. (1)

       =========================
        10^digits = Q 
        log10(10^digits) = log10 (Q)

        digits = log10(Q)

        digits/log10(Q) = 1 .... Eq. (2)

        =========================
        16^hexits = Q 
        log16(16^hexits) = log16 (Q)

        hexits = log16(Q)

        hexits/log16(Q) = 1 .... Eq. (3)

        =============================

        Eq. (1) = Eq. (2) = 1

        bits/log2(Q) = digits/log10(Q)

        bits = digits * log2(Q) / log10(Q)

                            logₙ(Q)
                logₘ(n) = —————————— identity
                            logₘ(Q)   
    
                log2(Q) / log10(Q) = log2(10)

        // digits to bits
        bits = digits * log2(10)

        =============================
        digits/log10(Q) = bits/log2(Q)

        digits = bits * log10(Q) / log2(Q)

                log10(Q) / log2(Q) = log10 (2)

        // bits to digits
        digits = bits * log10(2)
        
    */
    template<std::integral ArgType>
    consteval mp_prec_t digits_2_bits(ArgType d)
    {
        // digits to bits
        // bits = digits * log2(10)

        constexpr double LOG2_10 = 3.3219280948873624;

        return (mp_prec_t)gmp::ceil( d * LOG2_10 );
    }

    template<typename ArgType = mp_prec_t>
    consteval int bits_2_digits(ArgType b)
    {
        // bits to digits
        // digits = bits * log10(2)
        
        constexpr double LOG10_2 = 0.30102999566398119;

        return (int)gmp::floor(b * LOG10_2);
    }


    template<typename Type>
    concept cplx_arg_c = gmp::type_in_types_c< std::decay_t<std::remove_cvref_t<Type>>, 
        int, unsigned int, long, unsigned long, long long, unsigned long long,
        float, double, long double, char*>;

    template<typename Type>
    concept mpreal_c = std::same_as<std::remove_cvref_t<Type>, mpfr::mpreal>;

    // returns decimal precision
    inline auto get_default_precision()
    {
        return mpfr::bits2digits( mpreal::get_default_prec());
    }

    // provide decimal digits or precision as argument
    // returns previous decimal precision
    template<typename DecimalType>
    auto set_default_precision(DecimalType digits)
    {
        auto prev_precision = get_default_precision();
        mpreal::set_default_prec( mpfr::digits2bits(digits) );

        return prev_precision;
    }

    //////////////////////////////////////////////////////////////
    
    class complex
    {
        private:
            mpfr::mpreal m_real;
            mpfr::mpreal m_imag;

        public:
            complex(): m_real{ 0 }, m_imag{ 0 } {  }

            template<mpreal_c ArgTypeReal>
            complex(ArgTypeReal&& r): m_real{ std::forward<ArgTypeReal>(r) }, m_imag{ 0 } {  }

            template<mpreal_c ArgTypeReal, mpreal_c ArgTypeImag>
            complex(ArgTypeReal&& r, ArgTypeImag&& c): 
                m_real{ std::forward<ArgTypeReal>(r) }, m_imag{ std::forward<ArgTypeImag>(c) } {  }

            template<cplx_arg_c ArgType>
            complex(ArgType&& r): m_real{ r }, m_imag{ 0 } {  }

            template<cplx_arg_c ArgTypeReal, cplx_arg_c ArgTypeImag> 
            complex(ArgTypeReal&& r, ArgTypeImag&& c): m_real{ r }, m_imag{ c } {  }

            complex(const mpc_t& z1)
            {
                // std::cout << "copy from mpc" << std::endl;
                this->m_real = z1->re;
                this->m_imag = z1->im;
            }

            complex(mpc_t&& z1)
            {
                // std::cout << "move from mpc" << std::endl;
                
                this->m_real = std::move(z1->re);
                this->m_imag = std::move(z1->im);
            }

            ////////// more constructors will follow //////////////////////////////

            // copy constructor
            complex(const complex& z): m_real{ z.m_real }, m_imag{ z.m_imag } { }

            // move constructor
            complex(complex&& z): m_real{ std::move(z.m_real) },
                                  m_imag{ std::move(z.m_imag) } 
                                  { }


            // we will implement move constructor in the later sessions

            // copy assignment operator
            complex& operator=(const complex& z)
            {
                if(this != std::addressof(z))
                {
                    this->m_real = z.m_real;
                    this->m_imag = z.m_imag;
                }

                return *this;
            }

            // move assignment operator
            complex& operator=(complex&& z)
            {
                if( this != std::addressof(z))
                {
                    this->m_real = std::move(z.m_real);
                    this->m_imag = std::move(z.m_imag);
                }

                return *this;
            }

            ///////////// more assignment operators //////////////////

            complex& operator+=(const complex& z)
            {
                this->m_real += z.m_real;
                this->m_imag += z.m_imag;

                return *this;
            }

            complex& operator-=(const complex& z)
            {
                this->m_real -= z.m_real;
                this->m_imag -= z.m_imag;
                
                return *this;
            }

            complex& operator*=(const complex& z)
            {
                auto [ a, b ] = *this;
                auto [ c, d ] = z;

                /*
                    (a + b i) * (c + d i)
                    = a*c + a * d i + b * c i - b * d
                    = {a*c - b*d} + { a*d + b*c} i 
                */
               this->m_real = a * c - b * d;
               this->m_imag = a * d + b * c;
                
                return *this;
            }

            // returns magnitude squared
            auto norm() const
            {
                return this->m_real * this->m_real + this->m_imag * this->m_imag;
            }

            // conjugate of *this
            auto conj() const
            {
                return complex{ this->m_real, -this->m_imag };
            }

            complex& operator/=(const complex& z)
            {
                auto [ a, b ] = *this;
                auto [ c, d ] = z;

                /*
                    (a + b i)
                    —————————
                    (c + d i)

                       (a + b i)   (c - d i) 
                    = —————————— * —————————— 
                       (c + d i)   (c - d i) 

                       {a * c + b * d } + { b * c - a * d } i
                    = ———————————————————————————————————————
                                c*c + d * d
                */

               auto ns = (c*c + d * d);

               this->m_real = (a * c  + b * d) / ns;
               this->m_imag = (b * c - a * d ) / ns;
                
                return *this;
            }

            auto real() const
            {
                return this->m_real;
            }

            auto imag() const
            {
                return this->m_imag;
            }
    };
    // end of class complex

    inline std::ostream&
        operator<<(std::ostream& os, const mpfr::complex& z)
        {
            os <<"(" << z.real() <<"," << z.imag() << ")" ;
            return os;
        }

    namespace hidden
    {
        // int  mpc_sqrt        (mpc_ptr, mpc_srcptr, mpc_rnd_t)
        // int  mpc_exp         (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_log         (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_log10       (mpc_ptr, mpc_srcptr, mpc_rnd_t);

        // int  mpc_sin         (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_cos         (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_tan         (mpc_ptr, mpc_srcptr, mpc_rnd_t);

        // int  mpc_sinh        (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_cosh        (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_tanh        (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_asin        (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_acos        (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_atan        (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_asinh       (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_acosh       (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_atanh       (mpc_ptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_proj        (mpc_ptr, mpc_srcptr, mpc_rnd_t);

        template<typename FuncType>
        concept mpc_ptr_mpc_srcptr_mpc_rnd_c =
            std::same_as<std::remove_cvref_t<FuncType>, int(mpc_ptr, mpc_srcptr, mpc_rnd_t)>;
            
        template<mpc_ptr_mpc_srcptr_mpc_rnd_c FuncType>
        mpfr::complex special_func_cz1(mpfr::complex const& cz, FuncType& mpc_func)
        {
            mpc_t z, result;

            auto mpfr_prec = mpfr::mpreal::get_default_prec();
            auto mpfr_rnd  = mpfr::mpreal::get_default_rnd();

            auto mpc_rnd = MPC_RND(mpfr_rnd, mpfr_rnd);

            // step 1. initialize z and result
            mpc_init2(z, mpfr_prec);
            mpc_init2(result, mpfr_prec);

            // step 2. set values for z = cz
            mpc_set_fr_fr(z, cz.real().mpfr_srcptr(),
                             cz.imag().mpfr_srcptr(), mpc_rnd);

            // step 3. compute the square root or mpc_func of z ( = cz)
            mpc_func(result, z, mpc_rnd);

            // step 4. declare mpfr_t real_part, imag_part
            mpfr_t real_part, imag_part;

            // step 5. initialize real_part, imag_part
            mpfr_init2(real_part, mpfr_prec);
            mpfr_init2(imag_part, mpfr_prec);

            // step 6. extract real and imag parts of result

            mpc_real(real_part, result, mpfr_rnd);
            mpc_imag(imag_part, result, mpfr_rnd);

            // step 7. create mpreals with real_part and imag_part
            // we move the internal memory of real_part and imag_part.
            mpfr::mpreal r_part(real_part, true);
            mpfr::mpreal i_part(imag_part, true);

            mpc_clear(z);
            mpc_clear(result);

            // we should not clear real_part and imag_part
            // for these memories are recyled in mpreal r_part and i_part
            // mpfr_clear(real_part)
            // mpfr_clear(imag_part)
            // should be disabled, because the memories for
            // real_part and imag_part are recycled in r_part and i_part

            return { std::move(r_part), std::move(i_part) };
        }

        // int  mpc_pow       (mpc_ptr, mpc_srcptr, mpc_srcptr, mpc_rnd_t)
        // int  mpc_add       (mpc_ptr, mpc_srcptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_sub       (mpc_ptr, mpc_srcptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_mul       (mpc_ptr, mpc_srcptr, mpc_srcptr, mpc_rnd_t);
        // int  mpc_div       (mpc_ptr, mpc_srcptr, mpc_srcptr, mpc_rnd_t);

        template<typename Type>
        concept mpc_ptr_mpc_srcptr_mpc_srcptr_mpc_rnd_c = 
            std::same_as<std::remove_cvref_t<Type>, int (mpc_ptr, mpc_srcptr, mpc_srcptr, mpc_rnd_t)>;
        
        template<mpc_ptr_mpc_srcptr_mpc_srcptr_mpc_rnd_c FuncType>
        mpfr::complex special_func_cz2(mpfr::complex const& cz1, mpfr::complex const& cz2, FuncType& mpc_func)
        {
            mpc_t z1, z2, result;

            auto mpfr_prec = mpfr::mpreal::get_default_prec();
            auto mpfr_rnd  = mpfr::mpreal::get_default_rnd();

            auto mpc_rnd = MPC_RND(mpfr_rnd, mpfr_rnd);

            // step 1. initialize z and result
            mpc_init2(z1, mpfr_prec);
            mpc_init2(z2, mpfr_prec);
            mpc_init2(result, mpfr_prec);

            // step 2. set values for z1 = cz1, z2 = cz2
            mpc_set_fr_fr(z1, cz1.real().mpfr_srcptr(),
                              cz1.imag().mpfr_srcptr(), mpc_rnd);
            mpc_set_fr_fr(z2, cz2.real().mpfr_srcptr(),
                              cz2.imag().mpfr_srcptr(), mpc_rnd);

            // step 3. compute the mpc_pow or mpc_func of z1, z2
            mpc_func(result, z1, z2, mpc_rnd);
            
            mpc_clear(z1);
            mpc_clear(z2);

            return { std::move(result) };
        }
    
        // int  mpc_add_fr    (mpc_ptr, mpc_srcptr, mpfr_srcptr, mpc_rnd_t)
        // int  mpc_sub_fr    (mpc_ptr, mpc_srcptr, mpfr_srcptr, mpc_rnd_t)
        // int  mpc_mul_fr    (mpc_ptr, mpc_srcptr, mpfr_srcptr, mpc_rnd_t)
        // int  mpc_div_fr    (mpc_ptr, mpc_srcptr, mpfr_srcptr, mpc_rnd_t)
        // int  mpc_pow_fr    (mpc_ptr, mpc_srcptr, mpfr_srcptr, mpc_rnd_t)

        template<typename Type>
        concept mpc_ptr_mpc_srcptr_mpfr_srcptr_mpc_rnd_c =
            std::same_as<std::remove_cvref_t<Type>, int (mpc_ptr, mpc_srcptr, mpfr_srcptr, mpc_rnd_t)>;

        template<mpc_ptr_mpc_srcptr_mpfr_srcptr_mpc_rnd_c FuncType>
        mpfr::complex special_func_cz1_mpfr_cf1(const mpfr::complex& cz1, const mpfr_t& cf1, FuncType& mpc_func)
        {
            // Initialize variables
            mpc_t base, result;
            // mpfr_t exponent; = cf1

            auto mpfr_prec = mpfr::mpreal::get_default_prec();
            auto mpfr_rnd = mpfr::mpreal::get_default_rnd();

            auto mpc_rnd = MPC_RND(mpfr_rnd, mpfr_rnd);
            
            // Initialize complex and real variables
            mpc_init2(base, mpfr_prec);    
            mpc_init2(result, mpfr_prec);  
            
            // Set the base complex number (e.g., base = cz1.real() + cz1.imag())
            mpc_set_fr_fr(base, cz1.real().mpfr_srcptr(), cz1.imag().mpfr_srcptr(), mpc_rnd);

            // Compute the power: result = base ^ exponent
            mpc_func(result, base, cf1, mpc_rnd);
            
            // Free memory
            mpc_clear(base);           // Clear the complex base
            // mpc_clear(result);         

            return { std::move(result) };
        }

        // int  mpc_fr_sub    (mpc_ptr, mpfr_srcptr, mpc_srcptr, mpc_rnd_t)
        // int  mpc_fr_div    (mpc_ptr, mpfr_srcptr, mpc_srcptr, mpc_rnd_t)

        template<typename Type>
        concept mpc_ptr_mpfr_srcptr_mpc_srcptr_mpc_rnd_c =
            std::same_as<std::remove_cvref_t<Type>, int (mpc_ptr, mpfr_srcptr, mpc_srcptr, mpc_rnd_t)>;

        template<mpc_ptr_mpfr_srcptr_mpc_srcptr_mpc_rnd_c FuncType>
        mpfr::complex special_func_mpfr_cf1_cz1(const mpfr_t& cf1, const mpfr::complex& cz1, FuncType& mpc_func)
        {
            // Initialize variables
            mpc_t z, result;
            
            auto mpfr_prec = mpfr::mpreal::get_default_prec();
            auto mpfr_rnd = mpfr::mpreal::get_default_rnd();

            auto mpc_rnd = MPC_RND(mpfr_rnd, mpfr_rnd);
            
            // Initialize complex and real variables
            mpc_init2(z, mpfr_prec);    
            mpc_init2(result, mpfr_prec);  
            
            // Set the base complex number (e.g., base = cz1.real() + cz1.imag())
            mpc_set_fr_fr(z, cz1.real().mpfr_srcptr(), cz1.imag().mpfr_srcptr(), mpc_rnd);

            // int  mpc_fr_sub (mpc_ptr, mpfr_srcptr, mpc_srcptr, mpc_rnd_t);
            mpc_func(result, cf1, z, mpc_rnd);
            
            // Free memory
            mpc_clear(z);           // Clear the complex base
            
            return { std::move(result) };
        }

        // int  mpc_add_si    (mpc_ptr, mpc_srcptr, long int, mpc_rnd_t);
        // int  mpc_mul_si    (mpc_ptr, mpc_srcptr, long int, mpc_rnd_t);
        // int  mpc_div_2si   (mpc_ptr, mpc_srcptr, long int, mpc_rnd_t);
        // int  mpc_mul_2si   (mpc_ptr, mpc_srcptr, long int, mpc_rnd_t);

        template<typename Type>
        concept mpc_ptr_mpc_srcptr_long_int_mpc_rnd_c =
            std::same_as<std::remove_cvref_t<Type>, int (mpc_ptr, mpc_srcptr, long int, mpc_rnd_t)>;

        template<mpc_ptr_mpc_srcptr_long_int_mpc_rnd_c FuncType>
        mpfr::complex special_func_cz1_si(const mpfr::complex& cz1, long int si, FuncType& mpc_func)
        {
            mpc_t z, result;

            auto mpfr_prec = mpfr::mpreal::get_default_prec();
            auto mpfr_rnd = mpfr::mpreal::get_default_rnd();

            auto mpc_rnd = MPC_RND(mpfr_rnd, mpfr_rnd);

            mpc_init2(z, mpfr_prec);    
            mpc_init2(result, mpfr_prec);  

            mpc_set_fr_fr(z, cz1.real().mpfr_srcptr(), cz1.imag().mpfr_srcptr(), mpc_rnd);

            // int mpc_add_si (mpc_ptr, mpc_srcptr, long int, mpc_rnd_t);
            mpc_func(result, z, si, mpc_rnd);

            // Free memory
            mpc_clear(z);  

            return { std::move(result) };
        }

        // int  mpc_add_ui    (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);
        // int  mpc_sub_ui    (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);
        // int  mpc_mul_ui    (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);
        // int  mpc_div_ui    (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);
        // int  mpc_div_2ui   (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);
        // int  mpc_mul_2ui   (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);

        template<typename Type>
        concept mpc_ptr_mpc_srcptr_unsigned_long_int_mpc_rnd_c =
            std::same_as<std::remove_cvref_t<Type>, int (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t)>;
        
        template<mpc_ptr_mpc_srcptr_unsigned_long_int_mpc_rnd_c FuncType>
        mpfr::complex special_func_cz1_ui(const mpfr::complex& cz1, unsigned long int ui, FuncType& mpc_func)
        {
            mpc_t z, result;

            auto mpfr_prec = mpfr::mpreal::get_default_prec();
            auto mpfr_rnd = mpfr::mpreal::get_default_rnd();

            auto mpc_rnd = MPC_RND(mpfr_rnd, mpfr_rnd);

            mpc_init2(z, mpfr_prec);    
            mpc_init2(result, mpfr_prec);  

            mpc_set_fr_fr(z, cz1.real().mpfr_srcptr(), cz1.imag().mpfr_srcptr(), mpc_rnd);

            //int  mpc_add_ui    (mpc_ptr, mpc_srcptr, unsigned long int, mpc_rnd_t);
            mpc_func(result, z, ui, mpc_rnd);

            // Free memory
            mpc_clear(z);  

            return { std::move(result) };
        }
    }
    // end of namespace hidden

    inline mpfr::complex sqrt(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_sqrt);
    }

    inline mpfr::complex sin(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_sin);
    }

    inline mpfr::complex cos(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_cos);
    }

    inline mpfr::complex tan(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_tan);
    }

    inline mpfr::complex exp(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_exp);
    }

    inline mpfr::complex log(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_log);
    }

    inline mpfr::complex log10(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_log10);
    }

    inline mpfr::complex sinh(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_sinh);
    }

    inline mpfr::complex cosh(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_cosh);
    }

    inline mpfr::complex tanh(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_tanh);
    }

    inline mpfr::complex asin(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_asin);
    }

    inline mpfr::complex acos(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_acos);
    }
      
    inline mpfr::complex atan(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_atan);
    }

    inline mpfr::complex asinh(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_asinh);
    }

    inline mpfr::complex acosh(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_acosh);
    }

    inline mpfr::complex atanh(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_atanh);
    }

    inline mpfr::complex proj(mpfr::complex const& cz)
    {
        return hidden::special_func_cz1(cz, mpc_proj);
    }

    inline mpfr::complex pow(mpfr::complex const& cz1, mpfr::complex const& cz2)
    {
        return hidden::special_func_cz2(cz1, cz2, mpc_pow);
    }

    inline mpfr::complex pow(const mpfr::complex& cz1, const mpfr_t& cf1)
    {
        return hidden::special_func_cz1_mpfr_cf1(cz1, cf1, mpc_pow_fr);
    }

    inline mpfr::complex operator+ (const mpfr::complex& cz1, const mpfr::complex& cz2)
    {
        return hidden::special_func_cz2(cz1, cz2, mpc_add);
    }

    inline mpfr::complex operator+ (const mpfr::complex& cz1, const mpfr_t& cf1)
    {
        return hidden::special_func_cz1_mpfr_cf1(cz1, cf1, mpc_add_fr);
    }

    inline mpfr::complex operator+ (const mpfr_t& cf1, const mpfr::complex& cz1)
    {
        return hidden::special_func_cz1_mpfr_cf1(cz1, cf1, mpc_add_fr);
    }

    inline mpfr::complex operator+ (const mpfr::complex& cz1, long int si)
    {
        return hidden::special_func_cz1_si(cz1, si, mpc_add_si);
    }

    inline mpfr::complex operator+ (const mpfr::complex& cz1, unsigned long int ui)
    {
        return hidden::special_func_cz1_ui(cz1, ui, mpc_add_ui);
    }

    inline mpfr::complex operator+ (long int si, const mpfr::complex& cz1)
    {
        return hidden::special_func_cz1_si(cz1, si, mpc_add_si);
    }

    inline mpfr::complex operator- (const mpfr::complex& cz1, const mpfr::complex& cz2)
    {
        return hidden::special_func_cz2(cz1, cz2, mpc_sub);
    }

    inline mpfr::complex operator- (const mpfr::complex& cz1, const mpfr_t& cf1)
    {
        return hidden::special_func_cz1_mpfr_cf1(cz1, cf1, mpc_sub_fr);
    }

    inline mpfr::complex operator- (const mpfr_t& cf1, const mpfr::complex& cz1)
    {
        return hidden::special_func_mpfr_cf1_cz1(cf1, cz1, mpc_fr_sub);
    }

    inline mpfr::complex operator- (const mpfr::complex& cz1, unsigned long int ui)
    {
        return hidden::special_func_cz1_ui(cz1, ui, mpc_sub_ui);
    }

    inline mpfr::complex operator* (const mpfr::complex& cz1, const mpfr::complex& cz2)
    {
        return hidden::special_func_cz2(cz1, cz2, mpc_mul);
    }

    inline mpfr::complex operator* (const mpfr::complex& cz1, const mpfr_t& cf1)
    {
        return hidden::special_func_cz1_mpfr_cf1(cz1, cf1, mpc_mul_fr);
    }

    inline mpfr::complex operator* (const mpfr::complex& cz1, long int si)
    {
        return hidden::special_func_cz1_si(cz1, si, mpc_mul_si);
    }

    inline mpfr::complex operator* (long int si, const mpfr::complex& cz1)
    {
        return hidden::special_func_cz1_si(cz1, si, mpc_mul_si);
    }

    inline mpfr::complex operator* (const mpfr::complex& cz1, unsigned long int ui)
    {
        return hidden::special_func_cz1_ui(cz1, ui, mpc_mul_ui);
    }
    
    // returns cz1 x 2ˢⁱ
    inline mpfr::complex operator& (const mpfr::complex& cz1, long int si)
    {
        return hidden::special_func_cz1_si(cz1, si, mpc_mul_2si);
    }

    // returns cz1 x 2ᵘⁱ
    inline mpfr::complex operator& (const mpfr::complex& cz1, unsigned long int ui)
    {
        return hidden::special_func_cz1_ui(cz1, ui, mpc_mul_2ui);
    }
    
    inline mpfr::complex operator/ (mpfr::complex const& cz1, mpfr::complex const& cz2)
    {
        return hidden::special_func_cz2(cz1, cz2, mpc_div);
    }

    inline mpfr::complex operator/ (mpfr::complex const& cz1, const mpfr_t& cf1)
    {
        return hidden::special_func_cz1_mpfr_cf1(cz1, cf1, mpc_div_fr);
    }

    inline mpfr::complex operator/ (const mpfr_t& cf1, mpfr::complex const& cz1)
    {
        return hidden::special_func_mpfr_cf1_cz1(cf1, cz1, mpc_fr_div);
    }

    // returns cz1 / 2ˢⁱ
    inline mpfr::complex operator| (const mpfr::complex& cz1, long int si)
    {
        return hidden::special_func_cz1_si(cz1, si, mpc_div_2si);
    }

    // returns cz1 / 2ᵘⁱ
    inline mpfr::complex operator| (const mpfr::complex& cz1, unsigned long int ui)
    {
        return hidden::special_func_cz1_ui(cz1, ui, mpc_div_2ui);
    }

    inline mpfr::complex operator/ (const mpfr::complex& cz1, unsigned long int ui)
    {
        return hidden::special_func_cz1_ui(cz1, ui, mpc_div_ui);
    }
}
// end of namespace mpfr
#endif
// end of file 