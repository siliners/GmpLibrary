﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: July 24, 2025
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/

    GmpLibrary (The version at the time of filming video)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2025-07-20.zip

    GmpLibrary (Update version)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary.zip

    Reflection for C++26
    https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2025/p2996r12.html

    005- Coordinate Transformation, Jacobian Matrix, Numerical Integral
    https://www.youtube.com/watch?v=E23gnaOYf7g&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt

    004- Legendre Polynomial and Gaussian Quadrature, Numerical Integration 1
    https://www.youtube.com/watch?v=IQ-GURoM6j8&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt&index=2

    003- C++ GMP, Derivatives, 도함수, 미분법
    https://www.youtube.com/watch?v=IZhZ3Jin2A8&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt&index=3

    002- C++ GMP Data value display methods
    https://www.youtube.com/watch?v=gb_j5LBHcL0&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt&index=4

    001- (SETUP) C++ GMP, Complex Analysis, Initialization, Literals, Memory Leak Check
    https://www.youtube.com/watch?v=PCwbjWyNONk&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt&index=5

    079 - Newton Method, Five-Point Stencil, Gaussian Quadrature 
    https://www.youtube.com/watch?v=F-sgGk2w3Vk&list=PL1_C6uWTeBDF7kjfRMCmHIq1FncthhBpQ&index=79 (Published on 2020. 10. 7.)

    156- Numerical Integration 3 - Adaptive Gaussian Quadrature - General Idea and Benchmarking (Published on 2022. 12. 8.)
    https://www.youtube.com/watch?v=aK0AkEfmB4o&list=PL1_C6uWTeBDEjwkxjppnQ0TmMS272eNRx&index=159

    157- Numerical Integration 4 - Multiple Integrals 1 - Double Integrals 1 - Fundamentals
    https://www.youtube.com/watch?v=OhGJNB-uYBg&list=PL1_C6uWTeBDEjwkxjppnQ0TmMS272eNRx&index=160 (Published on 2022. 12. 9.)

    159- Numerical Integration 6 - Multiple Integrals 3 - Double Integrals (Completed)
    https://www.youtube.com/watch?v=1wUA0x7EQ8s&list=PL1_C6uWTeBDEjwkxjppnQ0TmMS272eNRx&index=162 (Published on 2022. 12. 9.)

    cl gmm-math.cpp /Fe: m.exe /std:c++latest /EHsc /nologo

    Memory Leak Test
    cl gmm-math.cpp /Fe: m.exe /std:c++latest /MDd /EHsc /nologo

    icx-cl gmm-math.cpp -o i.exe -Qstd=c++23 /EHsc /nologo

    clang++ gmm-math.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12

    g++ gmm-math.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12

    GEN_LAGUERRE_RULE
    Generalized Gauss-Laguerre Quadrature Rules
    https://people.math.sc.edu/burkardt/cpp_src/gen_laguerre_rule/gen_laguerre_rule.html
*/

#include <gmp/gmp_solver.hpp>

namespace high_precision
{
    using namespace gmp::precision_super_huge;
    using namespace gmp::calculus::hidden;

    void solve_nodes_weights()
    {
        std::cout.precision(385);

        []<auto ... n>(gmp::value_container<n...>)
        {
            auto roots = []<auto N>(gmp::value_container<N>)
            { 
                std::cout <<"N = " << N << std::endl;

                auto weights_nodes = 
                    get_gauss_legendre_weights_nodes<N, gmp::real_extreme_t>();

                for(auto& [x, w] : weights_nodes)
                {
                    std::cout << "x = " << x << endl;
                    std::cout << "w = " << w << endL;
                }
            };

            ( roots( gmp::value_container<n>() ), ...);

        }( gmp::forward_sequence<1, 1, 65>() );
    }

    void compute_nodes()
    {
        std::cout.precision(384);

        []<auto ... n>(gmp::value_container<n...>)
        {
            auto roots = []<auto N>(gmp::value_container<N>)
            { 
                std::cout << N << std::endl;

                auto weights_nodes = 
                    get_gauss_legendre_weights_nodes<N, gmp::real_extreme_t>();

                for(auto& [x, w] : weights_nodes)
                {
                    std::cout << "    "<< x << endl;
                }
            };

            ( roots( gmp::value_container<n>() ), ...);

        }( gmp::forward_sequence<1, 1, 65>() );
    }

    void compute_weights()
    {
        std::cout.precision(384);

        []<auto ... n>(gmp::value_container<n...>)
        {
            auto roots = []<auto N>(gmp::value_container<N>)
            { 
                std::cout << N << std::endl;

                auto weights_nodes = 
                    get_gauss_legendre_weights_nodes<N, gmp::real_extreme_t>();

                for(auto& [x, w] : weights_nodes)
                {
                    std::cout << "    "<< w << endl;
                }
            };

            ( roots( gmp::value_container<n>() ), ...);

        }( gmp::forward_sequence<1, 1, 65>() );
    }
}
// end of namespace high_precision

int main()
{
    using namespace high_precision;

    // solve_nodes_weights();
    // compute_nodes();
    compute_weights();
}