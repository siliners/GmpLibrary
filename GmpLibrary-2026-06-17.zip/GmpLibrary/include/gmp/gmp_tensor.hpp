﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.08.17
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/    
*/

#ifndef _GMP_TENSOR_HPP
#define _GMP_TENSOR_HPP

#include <gmp/gmp_tensor_types.hpp>

///////////// vector implementation//////////

namespace gmp
{
  using namespace operators;
  using namespace output;
  
  template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
        requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
  auto tensor<value_container<Rows, Cols, Dims...>, 
              std::tuple<EleType, EleTypes...>>::det() const noexcept
              requires(sizeof...(Dims) == 0 && Rows == Cols)
  {
      using namespace gmp::literals;
      using namespace gmp::calculus;

      using gmp::calculus::operator*;
      using gmp::calculus::operator+;
      using gmp::calculus::operator-;
      using gmp::calculus::operator/;
      
      if constexpr(Rows == 1)
          return std::get<0>(this->m_data);
      else if constexpr(Rows < 4)
      {     
          return [*this](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {
            auto A = this->evaluate(args...);
            return A.det();
          };
      }
      else
      {
          static_assert(Rows < 4, "Not Yet Implemented");
      }
  };

  template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
      requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
  template<auto row, auto col>
  auto tensor<value_container<Rows, Cols, Dims...>, 
      std::tuple<EleType, EleTypes...>>::minor() const noexcept
              requires(rank == 2 && row < Rows && col < Cols)
  {
      constexpr auto NRows = Rows - 1;
      constexpr auto NCols = Cols - 1;

      return [&]<auto...n>(value_container<n...>)
      {
          // for Intel icx-cl compiler
          using namespace operators;

          auto m_ij = [&]<auto i, auto j>(value_container<i, j>)
          {
              constexpr auto ii = (i < row) ? i : i + 1;
              constexpr auto jj = (j < col) ? j : j + 1;

              return this->template get<ii, jj>();
          };

          return make_tensor<NRows, NCols>
              (  m_ij( value_container<n / NCols, n % NCols>{}) ...  );

      }(forward_sequence<NRows * NCols>());
  }

  template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
      requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
  template<auto row, auto col>
  auto tensor<value_container<Rows, Cols, Dims...>, 
      std::tuple<EleType, EleTypes...>>::cofactor() const noexcept
              requires(rank == 2 && Rows == Cols && row < Rows && col < Cols)
  {
      auto det = minor<row, col>().det();

      if constexpr((row + col) % 2)
        return -1 * det;
      else
        return det;
  }

  template<auto i, auto j, mtrx_c MatrixType>
  auto minor(MatrixType&& m)
  {
    return m.template minor<i, j>();
  }

  template<auto i, auto j, mtrx_c MatrixType>
  auto cofactor(MatrixType&& m)
  {
    return m.template cofactor<i, j>();
  }
  
  template<typename EleType, int Rows, int Cols, int... Dims, std::size_t M>
        requires (Rows * (Cols * ... * Dims) == M)
    auto tensor<value_container<Rows, Cols, Dims...>, std::array<EleType, M>>::
            inverse() const noexcept requires(rank == 2 && Rows == Cols)
  {
      using namespace gmp::literals;
      using namespace gmp::calculus;

      using gmp::calculus::operator*;
      using gmp::calculus::operator+;
      using gmp::calculus::operator-;
      using gmp::calculus::operator/;

      if constexpr(Rows == 2 && Rows == Cols)
      {
          auto& [m11, m12,
                  m21, m22] = this->m_data;

          // determinant is already implemented
          auto det = this->det();

          // inverse = (1/det) * adj(A) where adj(A) = transpose(cofactor(A))
          return make_tensor<Rows, Cols>(
              ( m22 ) / det,   (-m12) / det,
              (-m21) / det,    ( m11 ) / det
          );

      }
      else if constexpr(Rows == 3 && Rows == Cols)
      {
          auto& [m11, m12, m13,
          m21, m22, m23,
          m31, m32, m33] = this->m_data;

          // determinant is already implemented
          auto det = this->det();

          // Cofactors (C_ij)
          auto C11 =  m22*m33 - m23*m32;
          auto C12 =  m23*m31 - m21*m33;  // -(m21*m33 - m23*m31)
          auto C13 =  m21*m32 - m22*m31;

          auto C21 =  m13*m32 - m12*m33;  // -(m12*m33 - m13*m32)
          auto C22 =  m11*m33 - m13*m31;
          auto C23 =  m12*m31 - m11*m32;  // -(m11*m32 - m12*m31)

          auto C31 =  m12*m23 - m13*m22;
          auto C32 =  m13*m21 - m11*m23;  // -(m11*m23 - m13*m21)
          auto C33 =  m11*m22 - m12*m21;

          // inverse = (1/det) * adj(A) = (1/det) * transpose(Cofactor)
          return make_tensor<Rows, Cols>(
              C11/det, C21/det, C31/det,
              C12/det, C22/det, C32/det,
              C13/det, C23/det, C33/det
          );
      }
      else
      {
          static_assert(Rows == Cols && Rows < 3, "Not yet implemented");
      }
  }
  
  template<int Dim, int... Dims, typename EleType>
    auto tensor<value_container<Dim, Dims...>, std::vector<EleType>>::
            inverse() const noexcept requires(rank == 2)
  {
      using namespace gmp::literals;
      using namespace gmp::calculus;

      using gmp::calculus::operator*;
      using gmp::calculus::operator+;
      using gmp::calculus::operator-;
      using gmp::calculus::operator/;

      constexpr auto Rows = gmp::get<0>(value_container<Dim, Dims...>{});
      constexpr auto Cols = gmp::get<1>(value_container<Dim, Dims...>{});

      if constexpr(Rows == 2 && Rows == Cols)
      {
          auto& [m11, m12,
                m21, m22] = this->m_data;

          // determinant is already implemented
          auto det = this->det();

          // inverse = (1/det) * adj(A) where adj(A) = transpose(cofactor(A))
          return make_tensor<Rows, Cols>(
              ( m22 ) / det,   (-m12) / det,
              (-m21) / det,    ( m11 ) / det
          );

      }
      else if constexpr(Rows == 3 && Rows == Cols)
      {
          auto& [m11, m12, m13,
          m21, m22, m23,
          m31, m32, m33] = this->m_data;

          // determinant is already implemented
          auto det = this->det();

          // Cofactors (C_ij)
          auto C11 =  m22*m33 - m23*m32;
          auto C12 =  m23*m31 - m21*m33;  // -(m21*m33 - m23*m31)
          auto C13 =  m21*m32 - m22*m31;

          auto C21 =  m13*m32 - m12*m33;  // -(m12*m33 - m13*m32)
          auto C22 =  m11*m33 - m13*m31;
          auto C23 =  m12*m31 - m11*m32;  // -(m11*m32 - m12*m31)

          auto C31 =  m12*m23 - m13*m22;
          auto C32 =  m13*m21 - m11*m23;  // -(m11*m23 - m13*m21)
          auto C33 =  m11*m22 - m12*m21;

          // inverse = (1/det) * adj(A) = (1/det) * transpose(Cofactor)
          return make_tensor<Rows, Cols>(
              C11/det, C21/det, C31/det,
              C12/det, C22/det, C32/det,
              C13/det, C23/det, C33/det
          );
      }
      else
      {
          static_assert(Rows == Cols && Rows < 3, "Not yet implemented");
      }
  }

  
  template<typename EleType, typename... EleTypes, int Rows, int Cols, int...Dims>
      requires (Rows * (Cols * ... * Dims) == (int)sizeof...(EleTypes) + 1)
  auto tensor<value_container<Rows, Cols, Dims...>, 
      std::tuple<EleType, EleTypes...>>::inverse() const noexcept
                requires(rank == 2)
  {
      using namespace gmp::literals;
      using namespace gmp::calculus;

      using gmp::calculus::operator*;
      using gmp::calculus::operator+;
      using gmp::calculus::operator-;
      using gmp::calculus::operator/;

      if constexpr(Rows == 2 && Rows == Cols)
      {
          auto& [m11, m12,
                  m21, m22] = this->m_data;

          // determinant is already implemented

          auto dt = this->det();

          // inverse = (1/det) * adj(A) where adj(A) = transpose(cofactor(A))
          return make_tensor<Rows, Cols>(  m22 / dt,       (-1 * m12) / dt,
                                          (-1 * m21) / dt,       m11 / dt   );

      }
      else if constexpr(Rows == 3 && Rows == Cols)
      {
          using namespace gmp::operators;

          auto& [ m11, m12, m13,
                  m21, m22, m23,
                  m31, m32, m33 ] = this->m_data;

          // determinant is already implemented
          auto dt = this->det();

          // Cofactors (C_ij)

          auto C11 = [dt, m22, m33, m23, m32](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m22, args...) * gmp::evaluate(m33, args...)
                     - gmp::evaluate(m23, args...) * gmp::evaluate(m32, args...) ) / gmp::evaluate(dt, args...);
          };

          // -(m21*m33 - m23*m31) = m23*m31 - m21*m33
          auto C12 = [dt, m23, m31, m21, m33](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m23, args...) * gmp::evaluate(m31, args...)
                     - gmp::evaluate(m21, args...) * gmp::evaluate(m33, args...) ) / gmp::evaluate(dt, args...);
          };

          // m21*m32 - m22*m31;
          auto C13 = [dt, m21, m32, m22, m31](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m21, args...) * gmp::evaluate(m32, args...)
                     - gmp::evaluate(m22, args...) * gmp::evaluate(m31, args...) ) / gmp::evaluate(dt, args...);
          };

          // -(m12*m33 - m13*m32) = m13*m32 - m12*m33;
          auto C21 = [dt, m12, m33, m13, m32](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m13, args...) * gmp::evaluate(m32, args...)
                     - gmp::evaluate(m12, args...) * gmp::evaluate(m33, args...) ) / gmp::evaluate(dt, args...);
          };

          //  m11*m33 - m13*m31;
          auto C22 = [dt, m11, m33, m13, m31](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m11, args...) * gmp::evaluate(m33, args...)
                     - gmp::evaluate(m13, args...) * gmp::evaluate(m31, args...) ) / gmp::evaluate(dt, args...);
          };

          // -(m11*m32 - m12*m31) = m12*m31 - m11*m32
          auto C23 = [dt, m11, m32, m12, m31](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m12, args...) * gmp::evaluate(m31, args...)
                     - gmp::evaluate(m11, args...) * gmp::evaluate(m32, args...) ) / gmp::evaluate(dt, args...);
          };

          // m12*m23 - m13*m22
          auto C31 = [dt, m12, m23, m13, m22](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m12, args...) * gmp::evaluate(m23, args...)
                     - gmp::evaluate(m13, args...) * gmp::evaluate(m22, args...) ) / gmp::evaluate(dt, args...);
          };

          // -(m11*m23 - m13*m21) = m13*m21 - m11*m23
          auto C32 = [dt, m11, m23, m13, m21](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m13, args...) * gmp::evaluate(m21, args...)
                     - gmp::evaluate(m11, args...) * gmp::evaluate(m23, args...) ) / gmp::evaluate(dt, args...);
          };

          // m11*m22 - m12*m21;
          auto C33 = [dt, m11, m22, m12, m21](auto... args)
            requires (sizeof...(args) == max_arg_count)
          {  
              return ( gmp::evaluate(m11, args...) * gmp::evaluate(m22, args...)
                     - gmp::evaluate(m12, args...) * gmp::evaluate(m21, args...) ) / gmp::evaluate(dt, args...);
          };

          // inverse = (1/det) * adj(A) = (1/det) * transpose(Cofactor)
          return make_tensor<Rows, Cols>(C11, C21, C31,
                                         C12, C22, C32,
                                         C13, C23, C33 );
      }
      else
      {
          static_assert(Rows == Cols && Rows < 3, "Not yet implemented");
      }
  }

  
  namespace operators
  {
    namespace hidden
    {
      
      template<BinOpr opr, std_array_c LeftType, std_array_c RightType>
        requires same_size_c<LeftType, RightType>
      decltype(auto) binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
      {
        using L = decltype(lhs); 
        using LType = std::remove_cvref_t<L>;

        using R = decltype(rhs);
        using RType = std::remove_cvref_t<R>;

        if constexpr(same_c<LType, RType>)
        {
          if constexpr(opr == BinOpr::add)
            {
              if constexpr(std::is_rvalue_reference_v<L>)
              {
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) lhs[k] += rhs[k];
                
                return std::move(lhs);
              }
              else if constexpr(std::is_rvalue_reference_v<R>)
              {
                constexpr int N = std::tuple_size_v<RType>;
                for(int k = 0; k < N; ++k) rhs[k] += lhs[k];
                
                return std::move(rhs);
              }
              else
              {
                auto x = lhs;
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) x[k] += rhs[k];
                return x;
              }
            }
            else if constexpr(opr == BinOpr::mul)
            {
              if constexpr(std::is_rvalue_reference_v<L>)
              {
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) lhs[k] *= rhs[k];
                
                return std::move(lhs);
              }
              else if constexpr(std::is_rvalue_reference_v<R>)
              {
                constexpr int N = std::tuple_size_v<RType>;
                for(int k = 0; k < N; ++k) rhs[k] *= lhs[k];
                
                return std::move(rhs);
              }
              else
              {
                auto x = lhs;
                
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) x[k] *= rhs[k];

                return x;
              }
            }
            else if constexpr(opr == BinOpr::sub)
            {
              if constexpr(std::is_rvalue_reference_v<L>)
              {
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) lhs[k] -= rhs[k];
                
                return std::move(lhs);
              }
              else if constexpr(std::is_rvalue_reference_v<R>)
              {
                constexpr int N = std::tuple_size_v<RType>;
                
                for(int k = 0; k < N; ++k)
                  rhs[k] = lhs[k] - rhs[k];
                
                return std::move(rhs);
              }
              else
              {
                auto x = lhs;
                
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) x[k] -= rhs[k];

                return x;
              }
            }
            else if constexpr(opr == BinOpr::div)
            {
              if constexpr(std::is_rvalue_reference_v<L>)
              {
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) lhs[k] /= rhs[k];
                
                return std::move(lhs);
              }
              else if constexpr(std::is_rvalue_reference_v<R>)
              {
                constexpr int N = std::tuple_size_v<RType>;

                for(int k = 0; k < N; ++k)
                  rhs[k] = lhs[k]/ rhs[k];
                
                return std::move(rhs);
              }
              else
              {
                auto x = lhs;
                
                constexpr int N = std::tuple_size_v<LType>;
                for(int k = 0; k < N; ++k) x[k] /= rhs[k];

                return x;
              }
            }
        }
        else
        {
            if constexpr(opr == BinOpr::add)
            {
                constexpr int N = std::tuple_size_v<LType>;

                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return std::array{ (lhs[n] + rhs[n])... };

                }(std::make_index_sequence<N>{});
            }
            else if constexpr(opr == BinOpr::mul)
            {
                constexpr int N = std::tuple_size_v<LType>;

                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return std::array{ (lhs[n] * rhs[n])... };

                }(std::make_index_sequence<N>{});
            }
            else if constexpr(opr == BinOpr::sub)
            {
                constexpr int N = std::tuple_size_v<LType>;

                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return std::array{ (lhs[n] - rhs[n])... };

                }(std::make_index_sequence<N>{});
            }
            else if constexpr(opr == BinOpr::div)
            {
                constexpr int N = std::tuple_size_v<LType>;

                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return std::array{ (lhs[n] / rhs[n])... };

                }(std::make_index_sequence<N>{});
            }
        }
      }

      template<BinOpr opr, vector_c LeftType, vector_c RightType>
      decltype(auto) binary_operation(LeftType&& lhs, RightType&& rhs) noexcept
      {
        using L = decltype(lhs); 
        using LType = std::remove_cvref_t<L>;
        using LValue = typename LType::value_type;

        int N = lhs.size();
        
        using R = decltype(rhs);
        using RType = std::remove_cvref_t<R>;
        using RValue = typename RType::value_type;

        int RN = rhs.size();

        assert(N != 0 && N == RN);

        if constexpr(same_c<LType, RType>)
        {
          if constexpr(opr == BinOpr::add)
          {
            if constexpr(std::is_rvalue_reference_v<L>)
            {
              for(int k = 0; k < N; ++k) lhs[k] += rhs[k];
              return std::move(lhs);
            }
            else if constexpr(std::is_rvalue_reference_v<R>)
            {
              for(int k = 0; k < N; ++k) rhs[k] += lhs[k];
              return std::move(rhs);
            }
            else
            {
              auto x = lhs;
              for(int k = 0; k < N; ++k) x[k] += rhs[k];
              return x;
            }
          }
          else if constexpr(opr == BinOpr::mul)
          {
            if constexpr(std::is_rvalue_reference_v<L>)
            {
              for(int k = 0; k < N; ++k) lhs[k] *= rhs[k];
              return std::move(lhs);
            }
            else if constexpr(std::is_rvalue_reference_v<R>)
            {
              for(int k = 0; k < N; ++k) rhs[k] *= lhs[k];
              return std::move(rhs);
            }
            else
            {
              auto x = lhs;
              
              for(int k = 0; k < N; ++k) x[k] *= rhs[k];

              return x;
            }
          }
          else if constexpr(opr == BinOpr::sub)
          {
            if constexpr(std::is_rvalue_reference_v<L>)
            {
              for(int k = 0; k < N; ++k) lhs[k] -= rhs[k];
              return std::move(lhs);
            }
            else if constexpr(std::is_rvalue_reference_v<R>)
            {
              for(int k = 0; k < N; ++k)
                rhs[k] = lhs[k] - rhs[k];
              
              return std::move(rhs);
            }
            else
            {
              auto x = lhs;
              for(int k = 0; k < N; ++k) x[k] -= rhs[k];
              return x;
            }
          }
          else if constexpr(opr == BinOpr::div)
        {
          if constexpr(std::is_rvalue_reference_v<L>)
          {
            for(int k = 0; k < N; ++k) lhs[k] /= rhs[k];       
            return std::move(lhs);
          }
          else if constexpr(std::is_rvalue_reference_v<R>)
          {
            for(int k = 0; k < N; ++k) rhs[k] = lhs[k] / rhs[k];

            return std::move(rhs);
          }
          else
          {
            auto x = lhs;
            for(int k = 0; k < N; ++k) x[k] /= rhs[k];
            return x;
          }
        }
        }
        else
        {
          using ele_t = common_type_t<LType, RType>;
          
          std::vector<ele_t> rnt;
          rnt.reserve(N);

          for(int k =0; k < N; ++k)
          {
            if constexpr(opr == BinOpr::add)
              rnt.emplace_back(static_cast<ele_t>(lhs[k]) + 
                              static_cast<ele_t>(rhs[k]));
            else if constexpr(opr == BinOpr::mul)
              rnt.emplace_back(static_cast<ele_t>(lhs[k]) * 
                              static_cast<ele_t>(rhs[k]));
            else if constexpr(opr == BinOpr::sub)
              rnt.emplace_back(static_cast<ele_t>(lhs[k]) - 
                              static_cast<ele_t>(rhs[k]));
            else if constexpr(opr == BinOpr::div)
              rnt.emplace_back(static_cast<ele_t>(lhs[k]) /
                              static_cast<ele_t>(rhs[k]));
          }
        }
      }
    
      template<BinOpr opr, tuple_c LeftType, tuple_c RightType>
        requires same_size_c<LeftType, RightType>
      decltype(auto) binary_operation(const LeftType& lhs, const RightType& rhs) noexcept
      {
        using L = decltype(lhs); 
        using LType = std::remove_cvref_t<L>;

        using R = decltype(rhs);
        using RType = std::remove_cvref_t<R>;
        
        if constexpr(opr == BinOpr::add)
        {
            constexpr int N = std::tuple_size_v<LType>;

            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return std::tuple{ (lhs[n] + rhs[n])... };

            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::mul)
        {
            constexpr int N = std::tuple_size_v<LType>;

            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return std::tuple{ (lhs[n] * rhs[n])... };

            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::sub)
        {
            constexpr int N = std::tuple_size_v<LType>;

            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return std::tuple{ (lhs[n] - rhs[n])... };

            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::div)
        {
            constexpr int N = std::tuple_size_v<LType>;

            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return std::tuple{ (lhs[n] / rhs[n])... };

            }(std::make_index_sequence<N>{});
        }
      }
    
      template<BinOpr opr, nvctr_c LType, nvctr_c RType>
        requires same_dim_c<LType, RType>
      decltype(auto) binary_operation(LType&& lhs, RType&& rhs) noexcept
      {
        using L = decltype(lhs);     
        using R = decltype(rhs);

        auto& ls = lhs.data();
        auto& rs = rhs.data();

        constexpr int N = std::remove_cvref_t<LType>::dimension;

        if constexpr(same_c<LType, RType>)
        {
          if constexpr(opr == BinOpr::add)
          {
            if constexpr(std::is_rvalue_reference_v<L>)
            {
              for(int k = 0; k < N; ++k) ls[k] += rs[k];
              
              return std::move(lhs);
            }
            else if constexpr(std::is_rvalue_reference_v<R>)
            {
              for(int k = 0; k < N; ++k) rs[k] += ls[k];
              return std::move(rhs);
            }
            else
            {
              auto xx = lhs; auto& x = xx.data();

              for(int k = 0; k < N; ++k) x[k] += rs[k];
              
              return xx;
            }
          }
          else if constexpr(opr == BinOpr::dot)
          {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return ( (ls[n] * rs[n]) + ... );

            }(std::make_index_sequence<N>{});
          }
          else if constexpr(opr == BinOpr::cross)
          {
            if constexpr(N == 2)
                {
                  auto& x1 = lhs[0]; auto& y1 = lhs[1];
                  auto& x2 = rhs[0]; auto& y2 = rhs[1];

                  return make_tensor(0, 0, x1 * y2 - y1 * x2 );
                }
                else if constexpr(N == 3)
                {
                  auto& x1 = lhs[0]; auto& y1 = lhs[1]; auto& z1 = lhs[2];
                  auto& x2 = rhs[0]; auto& y2 = rhs[1]; auto& z2 = rhs[2];

                  return make_tensor(y1 * z2 - z1 * y2,
                                      z1 * x2 - x1 * z2,
                                      x1 * y2 - y1 * x2 );
                }
                else
                {
                  static_assert(N == 2 || N == 3, "cross product is defined for 2 or 3D");
                }
          }
          else if constexpr(opr == BinOpr::mul)
          {
            if constexpr(std::is_rvalue_reference_v<L>)
            {
              for(int k = 0; k < N; ++k) ls[k] *= rs[k];
              return std::move(lhs);
            }
            else if constexpr(std::is_rvalue_reference_v<R>)
            {
              for(int k = 0; k < N; ++k) rs[k] *= ls[k];
              return std::move(rhs);
            }
            else
            {
              auto xx = lhs; auto&& x = xx.data();
                            
              for(int k = 0; k < N; ++k) x[k] *= rhs[k];

              return xx;
            }
          }
          else if constexpr(opr == BinOpr::sub)
          {
            if constexpr(std::is_rvalue_reference_v<L>)
            {
              for(int k = 0; k < N; ++k) ls[k] -= rs[k];
              return std::move(lhs);
            }
            else if constexpr(std::is_rvalue_reference_v<R>)
            {
              for(int k = 0; k < N; ++k)
                rs[k] = ls[k] - rs[k];
              
              return std::move(rhs);
            }
            else
            {
              auto xx = lhs; auto& x = xx.data();
              
              for(int k = 0; k < N; ++k) x[k] -= rs[k];

              return xx;
            }
          }
          else if constexpr(opr == BinOpr::div)
            {
              if constexpr(std::is_rvalue_reference_v<L>)
              {
                for(int k = 0; k < N; ++k) ls[k] /= rs[k];
                
                return std::move(lhs);
              }
              else if constexpr(std::is_rvalue_reference_v<R>)
              {
                for(int k = 0; k < N; ++k)
                  rs[k] = ls[k]/ rs[k];
                
                return std::move(rhs);
              }
              else
              {
                auto xx = lhs; auto& x = xx.data();
                
                for(int k = 0; k < N; ++k) x[k] /= rs[k];

                return xx;
              }
            }
        }
        else
        {
            if constexpr(opr == BinOpr::add)
            {
                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return make_tensor( (ls[n] + rs[n])... );

                }(std::make_index_sequence<N>{});
            }
            else if constexpr(opr == BinOpr::dot)
            {
                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return ( (ls[n] * rs[n]) + ... );

                }(std::make_index_sequence<N>{});
            }
            else if constexpr(opr == BinOpr::cross)
            {
                if constexpr(N == 2)
                {
                  auto& x1 = lhs[0]; auto& y1 = lhs[1];
                  auto& x2 = rhs[0]; auto& y2 = rhs[1];

                  return make_tensor(0, 0, x1 * y2 - y1 * x2 );
                }
                else if constexpr(N == 3)
                {
                  auto& x1 = lhs[0]; auto& y1 = lhs[1]; auto& z1 = lhs[2];
                  auto& x2 = rhs[0]; auto& y2 = rhs[1]; auto& z2 = rhs[2];

                  return make_tensor(y1 * z2 - z1 * y2,
                                      z1 * x2 - x1 * z2,
                                      x1 * y2 - y1 * x2 );
                }
                else
                {
                  static_assert(N == 2 || N == 3, "cross product is defined for 2 or 3D");
                }
            }
            else if constexpr(opr == BinOpr::sub)
            {
                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                  {
                    return make_tensor( (ls[n] - rs[n])... );

                  }(std::make_index_sequence<N>{});
            }
            else if constexpr(opr == BinOpr::div)
            {
                return [&]<std::size_t ... n>(std::index_sequence<n...>)
                {
                  return make_tensor( (ls[n] / rs[n])... );

                }(std::make_index_sequence<N>{});
            }
        }
      }

      template<BinOpr opr, fvctr_c LType, fvctr_c RType>
        requires same_dim_c<LType, RType>
      decltype(auto) binary_operation(const LType& lhs, const RType& rhs) noexcept
      {
        auto& ls = lhs.data();
        auto& rs = rhs.data();

        constexpr int N = std::remove_cvref_t<LType>::dimension;

        if constexpr(opr == BinOpr::add)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return make_tensor( (std::get<n>(ls) + std::get<n>(rs))... );
              
            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::dot)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return ( (std::get<n>(ls) * std::get<n>(rs)) + ... );

            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::cross)
        {
            if constexpr(N == 2)
            {
              auto&[x1, y1] = ls;
              auto&[x2, y2] = rs;

              return make_tensor(0, 0, x1 * y2 - y1 * x2 );
            }
            else if constexpr(N == 3)
            {
              auto&[x1, y1, z1] = ls;
              auto&[x2, y2, z2] = rs;

              return make_tensor(y1 * z2 - z1 * y2,
                                    z1 * x2 - x1 * z2,
                                    x1 * y2 - y1 * x2 );
            }
            else
            {
              static_assert(N == 2 || N == 3, "cross product is defined for 2 or 3D");
            }
        }
        else if constexpr(opr == BinOpr::sub)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
              {
                return make_tensor( (std::get<n>(ls) - std::get<n>(rs))... );

              }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::div)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return make_tensor( (std::get<n>(ls) / std::get<n>(rs))... );

            }(std::make_index_sequence<N>{});
        }
      }
      
      template<BinOpr opr, nvctr_c LType, number_c RType>
        decltype(auto) binary_operation(LType&& lhs, RType&& rhs) noexcept
      {
        using L = decltype(lhs);
        using LeftType = std::remove_cvref_t<LType>;
        using LvType = LeftType::value_type;
        using dimsn = typename LeftType::dims_cntr;

        using R = decltype(rhs);
        using RightType = std::remove_cvref_t<RType>;
        using RvType = RightType;

        auto& ls = lhs.data();
        // auto& rs = rhs.data();

        constexpr int N = LeftType::dimension;
        
        if constexpr(same_c<LvType, RvType> && 
                    std::is_rvalue_reference_v<L>)
        {
            [&]<auto...n>(value_container<n...>)
            {
              if constexpr(opr == BinOpr::add)
                ( (void)(ls[n] += rhs), ... );
              else if constexpr(opr == BinOpr::sub)
                ( (void)(ls[n] -= rhs), ... );
              else if constexpr(opr == BinOpr::mul)
                ( (void)(ls[n] *= rhs), ... );
              else if constexpr(opr == BinOpr::div)
                ( (void)(ls[n] /= rhs), ... );

            }( forward_sequence<N>() );

            return std::move(lhs);
        }
        else
        {
          if constexpr(opr == BinOpr::add)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (ls[n] + rhs) ... );

            }(forward_sequence<N>());
          }
          else if constexpr(opr == BinOpr::sub)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (ls[n] - rhs) ... );

            }(forward_sequence<N>());
          }
          else if constexpr(opr == BinOpr::mul)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (ls[n] * rhs) ... );

            }(forward_sequence<N>());
          }
          else if constexpr(opr == BinOpr::div)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (ls[n] / rhs) ... );

            }(forward_sequence<N>());
          }
        }
      }

      template<BinOpr opr, number_c LType, nvctr_c RType>
        decltype(auto) binary_operation(LType&& lhs, RType&& rhs) noexcept
      {
        using L = decltype(lhs);
        using LeftType = std::remove_cvref_t<LType>;
        using LvType = LeftType;
        
        using R = decltype(rhs);
        using RightType = std::remove_cvref_t<RType>;
        using RvType = typename RightType::value_type;
        using dimsn = typename RightType::dims_cntr;
        
        // auto& ls = lhs.data();
        auto& rs = rhs.data();

        constexpr int N = RightType::dimension;
        
        if constexpr(all_same_c<LvType, RvType> && 
                     std::is_rvalue_reference_v<R>)
        {
            [&]<auto...n>(value_container<n...>)
            {
              if constexpr(opr == BinOpr::add)
                ( (void)(rs[n] += lhs), ... );
              else if constexpr(opr == BinOpr::sub)
                ( (void)(rs[n] = lhs - rs[n]), ... );
              else if constexpr(opr == BinOpr::mul)
                ( (void)(rs[n] *= lhs), ... );
              else if constexpr(opr == BinOpr::div)
                ( (void)(rs[n] = lhs / rs[n]), ... );

            }( forward_sequence<N>() );
                      
            return std::move(rhs);
        }
        else
        {
          if constexpr(opr == BinOpr::add)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (lhs + rs[n]) ... );

            }(forward_sequence<N>());
          }
          else if constexpr(opr == BinOpr::sub)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (lhs - rs[n]) ... );

            }(forward_sequence<N>());
          }
          else if constexpr(opr == BinOpr::mul)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (lhs * rs[n]) ... );

            }(forward_sequence<N>());
          }
          else if constexpr(opr == BinOpr::div)
          {
            return [&]<auto...n>(value_container<n...>)
            {
              return make_tensor(dimsn{}, (lhs / rs[n]) ... );

            }(forward_sequence<N>());
          }
        }
      }

      template<BinOpr opr, fvctr_c LType, nvctr_c RType>
        requires same_dim_c<LType, RType>
      decltype(auto) binary_operation(const LType& lhs, const RType& rhs) noexcept
      {
        auto& ls = lhs.data();
        auto& rs = rhs.data();

        constexpr int N = std::remove_cvref_t<LType>::dimension;

        if constexpr(opr == BinOpr::add)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return make_tensor( (std::get<n>(ls) + std::get<n>(rs))... );
              
            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::dot)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return ( (std::get<n>(ls) * std::get<n>(rs)) + ... );

            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::cross)
        {
            if constexpr(N == 2)
            {
              auto&[x1, y1] = ls;
              auto&[x2, y2] = rs;

              return make_tensor(0, 0, x1 * y2 - y1 * x2 );
            }
            else if constexpr(N == 3)
            {
              auto&[x1, y1, z1] = ls;
              auto&[x2, y2, z2] = rs;

              return make_tensor(y1 * z2 - z1 * y2,
                                    z1 * x2 - x1 * z2,
                                    x1 * y2 - y1 * x2 );
            }
            else
            {
              static_assert(N == 2 || N == 3, "cross product is defined for 2 or 3D");
            }
        }
        else if constexpr(opr == BinOpr::sub)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
              {
                return make_tensor( (std::get<n>(ls) - std::get<n>(rs))... );

              }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::div)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return make_tensor( (std::get<n>(ls) / std::get<n>(rs))... );

            }(std::make_index_sequence<N>{});
        }
      }

      template<BinOpr opr, nvctr_c LType, fvctr_c RType>
        requires same_dim_c<LType, RType>
      decltype(auto) binary_operation(const LType& lhs, const RType& rhs) noexcept
      {
        auto& ls = lhs.data();
        auto& rs = rhs.data();

        constexpr int N = std::remove_cvref_t<LType>::dimension;

        if constexpr(opr == BinOpr::add)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return make_tensor( (std::get<n>(ls) + std::get<n>(rs))... );
              
            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::dot)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return ( (std::get<n>(ls) * std::get<n>(rs)) + ... );

            }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::cross)
        {
            if constexpr(N == 2)
            {
              auto&[x1, y1] = ls;
              auto&[x2, y2] = rs;

              return make_tensor(0, 0, x1 * y2 - y1 * x2 );
            }
            else if constexpr(N == 3)
            {
              auto&[x1, y1, z1] = ls;
              auto&[x2, y2, z2] = rs;

              return make_tensor(y1 * z2 - z1 * y2,
                                    z1 * x2 - x1 * z2,
                                    x1 * y2 - y1 * x2 );
            }
            else
            {
              static_assert(N == 2 || N == 3, "cross product is defined for 2 or 3D");
            }
        }
        else if constexpr(opr == BinOpr::sub)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
              {
                return make_tensor( (std::get<n>(ls) - std::get<n>(rs))... );

              }(std::make_index_sequence<N>{});
        }
        else if constexpr(opr == BinOpr::div)
        {
            return [&]<std::size_t ... n>(std::index_sequence<n...>)
            {
              return make_tensor( (std::get<n>(ls) / std::get<n>(rs))... );

            }(std::make_index_sequence<N>{});
        }
      }

    }
    // end of namespace hidden

    template<nvctr_c LType, number_c RType>
    decltype(auto) operator+(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::add>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    template<number_c LType, nvctr_c RType>
    decltype(auto) operator+(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::add>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    template<nvctr_c LType, number_c RType>
    decltype(auto) operator-(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::sub>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    template<number_c LType, nvctr_c RType>
    decltype(auto) operator-(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::sub>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    // template<nvctr_c LType, nvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator-(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::sub>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<nvctr_c LType, nvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator*(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::dot>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<nvctr_c LType, nvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator%(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::cross>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // /////////////////////////////////////////////
    // template<fvctr_c LType, fvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator+(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::add>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<fvctr_c LType, fvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator-(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::sub>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<fvctr_c LType, fvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator*(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::dot>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<fvctr_c LType, fvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator%(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::cross>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    /////////////////////////////////////////////////////////////

    /////////////////////////////////////////////
    template<vctr_c LType, vctr_c RType>
      requires same_dim_c<LType, RType>
    decltype(auto) operator+(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::add>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    template<vctr_c LType, vctr_c RType>
      requires same_dim_c<LType, RType>
    decltype(auto) operator-(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::sub>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    template<vctr_c LType, vctr_c RType>
      requires same_dim_c<LType, RType>
    decltype(auto) operator*(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::dot>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    template<vctr_c LType, vctr_c RType>
      requires same_dim_c<LType, RType>
    decltype(auto) operator%(LType&& lhs, RType&& rhs)
    {
        return hidden::binary_operation<BinOpr::cross>(
          std::forward<LType>(lhs), std::forward<RType>(rhs));
    }

    // template<nvctr_c LType, nvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator-(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::sub>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<nvctr_c LType, nvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator*(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::dot>(
    //       std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<nvctr_c LType, nvctr_c RType>
    //   requires same_dim_c<LType, RType>
    // decltype(auto) operator%(LType&& lhs, RType&& rhs)
    // {
    //     return hidden::binary_operation<BinOpr::cross>(
    //        std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<int N, vctr_c LType, vctr_c RType>
    // decltype(auto) operator-(LType&& lhs, RType&& rhs)
    // {
    //   return hidden::binary_operation<BinOpr::sub>
    //       (std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<int N, vctr_c LType, vctr_c RType>
    // decltype(auto) operator*(LType&& lhs, RType&& rhs)
    // {
    //   return hidden::binary_operation<BinOpr::mul>
    //       (std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    // template<int N, vctr_c LType, vctr_c RType>
    // decltype(auto) operator/(LType&& lhs, RType&& rhs)
    // {
    //   return hidden::binary_operation<BinOpr::div>
    //       (std::forward<LType>(lhs), std::forward<RType>(rhs));
    // }

    namespace hidden
    {
      template<auto Rows, auto Cols, auto i, auto j, typename... vs >
      constexpr auto transpose_indices(type_container<vs...>) noexcept
      {
        if constexpr(j == Cols)
          return transpose_indices<Rows, Cols, i + 1, 0>(type_container<vs...>{});
        else
        {
          if constexpr(i == Rows)
            return type_container<vs...>{};
          else
            return transpose_indices<Rows, Cols, i, j + 1>
                    (type_container<vs..., value_container<j, i>>{});
        }
      }

      template<auto Rows, auto Cols>
      constexpr auto transpose_indices() noexcept
      {
        return transpose_indices<Rows, Cols, 0, 0>(type_container<>{});
      }

      template<auto Rows, auto Cols, typename CntrType,
        auto...jj, auto...ii>
      auto transpose(const tensor<value_container<Rows, Cols>, CntrType>& M,
                     type_container<value_container<jj, ii>...>) noexcept
      {
        using MType = tensor<value_container<Rows, Cols>, CntrType>;

        using M_dims = value_container<Rows, Cols>;
        using T_dims = value_container<Cols, Rows>;
      
        return make_tensor(T_dims{}, M.template get<jj * Cols + ii>()... );
      }

      template<auto Rows, auto Cols, auto i, auto j, typename... vs >
      constexpr auto make_metric_indices(type_container<vs...>) noexcept
      {
        if constexpr(i + 1 == Rows)
        {
          if constexpr(j + 1 < Cols)
            return make_metric_indices<Rows, Cols, i, j + 1>
              ( type_container<vs..., value_container<i, j>>{} );
          else
            return type_container<vs..., value_container<i, j> >{};
        }
        else 
        {
          if constexpr(j + 1 < Cols)
            return make_metric_indices<Rows, Cols, i, j + 1>
              ( type_container<vs..., value_container<i, j>>{} );
          else
            return make_metric_indices<Rows, Cols, i + 1, 0>
              ( type_container<vs..., value_container<i, j>>{} );  
        }
      }

      template<auto Rows, auto Cols>
      constexpr auto make_metric_indices() noexcept
      {
        return make_metric_indices<Rows, Cols, 0, 0>(type_container<>{});
      }

      template<DrvStencil stknd, DrvPivot drpv, auto DX,
          auto N, tuple_c CntrType, auto Rows, auto Cols, auto...ii, auto...jj>
      auto make_metric_tensor(mtt_cmd<stknd, drpv, DX> mt,
                     const tensor<value_container<N>, CntrType>& V,
                     value_container<Rows, Cols>, type_container<value_container<ii, jj>...>) noexcept
      {
          using TType = tensor<value_container<N>, CntrType>;

          auto drv_mn = [&]<auto i, auto j, auto k>(value_container<i, j, k>)
            {
              return [vk = V.template get<k>()](auto... args)
                            requires (sizeof...(args) == TType::max_arg_count)
                    {
                      using namespace gmp::literals;
                      using namespace gmp::calculus;

                      using gmp::calculus::operator*;
                      using gmp::calculus::operator+;
                      using gmp::calculus::operator-;
                      using gmp::calculus::operator/;

                      auto d_ik = drv_cmd<stknd, drpv, i, 1, DX>{} * vk;
                      auto d_jk = drv_cmd<stknd, drpv, j, 1, DX>{} * vk;

                      return evaluate(d_ik, args...) * evaluate(d_jk, args...);
                    };
            };

          auto g_ij = [&]<auto i, auto j>(value_container<i, j>)
            {
              return [&]<auto...k>(value_container<k...>)
              {
                return ( drv_mn(value_container<i, j, k>{} ) + ...);

              }( forward_sequence<N>() );

              // return [gg](auto... args)
              //       requires(sizeof...(args) == TType::max_arg_count)
              //   {
              //     return evaluate(gg, args...);
              //   };
            };

          return make_tensor(value_container<Rows, Cols>{},
                             wrap(g_ij(value_container<ii, jj>{}))... );
      }

      //////////////////////////////////////////////////////////////////////////
      template<DrvStencil stknd, DrvPivot drpv, auto DX,
              auto N, tuple_c CntrType, auto Rows, auto Cols, auto...ii, auto...jj>
      auto make_jacobian(jac_cmd<stknd, drpv, DX>, 
            const tensor<value_container<N>, CntrType>& V,
            value_container<Rows, Cols>, type_container<value_container<ii, jj>...>) noexcept
      {
          auto drv_mn = [&]<auto i, auto j>(value_container<i, j>)
          {

            return [vi = V.template get<i>()](auto... args)
              requires (sizeof...(args) == Cols)
            {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              auto d_ij = drv_cmd<stknd, drpv, j, 1, DX>{} * vi;

              return evaluate(d_ij, args...);
            };
          };

          return make_tensor(value_container<Rows, Cols>{},
            drv_mn(value_container<ii, jj>{})... );
      }
    }
    // end of namespace hidden

    template<auto Rows, auto Cols, typename CntrType>
    auto transpose(const tensor<value_container<Rows, Cols>, CntrType>& M) noexcept
    {
        // auto ti = hidden::transpose_indices<Rows, Cols>();
        // std::cout <<"ti = " >> ti << std::endl;

        return hidden::transpose(M, hidden::transpose_indices<Cols, Rows>());
    }

    // Jacobian matrix
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(jac_cmd<stknd, drpv, DX> jc, const tensor<value_container<N>, CntrType>& V) noexcept
    {
      using VType = tensor<value_container<N>, CntrType>;
      constexpr auto arg_max = maximum_values(typename VType::args_count{});

      return hidden::make_jacobian(jc, V, value_container<(int)N, (int)arg_max>{},
                                             hidden::make_metric_indices<(int)N, (int)arg_max>());
    }

    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto make_metric_tensor(mtt_cmd<stknd, drpv, DX> mt,
                            const tensor<value_container<N>, CntrType>& V) noexcept
    {
        using VType = tensor<value_container<N>, CntrType>;
        constexpr auto arg_max = maximum_values(typename VType::args_count{});

        return hidden::make_metric_tensor(mt, V, value_container<arg_max, arg_max>{},
                                             hidden::make_metric_indices<arg_max, arg_max>());
    }

    // metric tensor
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(mtt_cmd<stknd, drpv, DX> mt, const tensor<value_container<N>, CntrType>& V) noexcept
    {
      return make_metric_tensor(mt, V);
    }

    //
    // christoffel 2nd
    //
    // 𝛤ᵏᵢⱼ = gᵐᵏ 𝛤ₘᵢⱼ
    //      = gᵐᵏ (1/2)(∂ᵢgₘⱼ + ∂ⱼgₘᵢ - ∂ₘgᵢⱼ) 
    //      = ∂ᵢ𝐞ⱼ ⋅ 𝐞ᵏ
    // 
    // 𝛤ᵏᵢⱼ 𝐞ₖ = ∇ᵢ𝐞ⱼ (By definition of connection)
    //        
    //         ∂𝐞ⱼ
    // 𝛤ᵏᵢⱼ = ———— ⋅ 𝐞ᵏ 
    //         ∂ᵢ
    //
    //  𝐞ⁱ ⋅ 𝐞ⱼ = 𝛿ⁱⱼ
    //
    //  ∂ⱼ𝐞ₖ = 𝛤ⁱⱼₖ 𝐞ᵢ  (Coordinate partial derivative of the basis)
    //    The above equality holds only when 𝐞ₖ is a coordinate basis (holonomic system)
    // 
    //  ∇ᵢ𝐞ⱼ = 𝛤ᵏᵢⱼ 𝐞ₖ (Definition of connection) 
    //
    //  ∂ⱼ𝐞ₖ = 𝛤ⁱⱼₖ 𝐞ᵢ + 𝐶ⱼₖⁱ𝐞ᵢ
    //    where 𝐶ⱼₖⁱ are the structure coefficients (non-zero for non-holonomic bases)
    //
    //  ∇ᵢeⱼ = ∂ᵢeⱼ iff the basis is coordinate (holonomic).
    //
    // Coordinate basis (holonomic)
    //  ∂ᵢ𝐞ⱼ = 𝛤ᵏᵢⱼ 𝐞ₖ
    //    and the structure coefficients vanish, 𝐶ᵏᵢⱼ = 0
    //
    // Non-coordinate basis (anholonomic)
    //  The basis vectors fail to commute
    //    [𝐞ᵢ , 𝐞ⱼ ] = 𝐶ᵏᵢⱼ 𝐞ₖ
    //
    // so the partial derivative picks up an extra piece
    //
    //  ∂ᵢ𝐞ⱼ = 𝛤ᵏᵢⱼ 𝐞ₖ + 𝐶ᵏᵢⱼ 𝐞ₖ
    //
    // Covariant derivative keeps only the connection part
    // 
    //    ∇ᵢ𝐞ⱼ = 𝛤ᵏᵢⱼ 𝐞ₖ
    // 
    //  Extraction using reciprocal basis
    //    
    //   𝐞ᵏ ⋅ ∇ᵢ𝐞ⱼ = 𝐞ᵏ ⋅ 𝛤ᵏᵢⱼ 𝐞ₖ = 𝛤ᵏᵢⱼ 𝐞ᵏ ⋅ 𝐞ₖ = 𝛤ᵏᵢⱼ
    //   
    //    𝛤ᵏᵢⱼ = 𝐞ᵏ ⋅ ∇ᵢ𝐞ⱼ,  𝐶ᵏᵢⱼ = 𝐞ᵏ ⋅ [ 𝐞ᵢ, 𝐞ⱼ ]
    //
    //  So in short
    //
    //    ∂ᵢ𝐞ⱼ = ∇ᵢ𝐞ⱼ + 𝐶ᵏᵢⱼ𝐞ₖ
    //        
    //  is the generic decomposition, valid for any basis - holonomic or anholonomic
    //    
    //  If the basis is holonomic (coordinate basis), then 𝐶ᵏᵢⱼ = 0, so it reduces to
    //
    //    ∂ᵢ𝐞ⱼ = ∇ᵢ𝐞ⱼ .
    //  
    //  If the basis is anholonomic, then 𝐶ᵏᵢⱼ ≠ 0, and the difference between the raw partial derivative
    //  and the covariant derivative of the basis is exactly captured by those structure coefficients
    // 
    //  𝛤ᵏᵢⱼ = 𝐞ᵏ ⋅ ∇ᵢ𝐞ⱼ = 𝐞ᵏ ⋅ ∂ᵢ𝐞ⱼ, only works, when
    //     { 𝐞ⱼ } is a coordinate basis (holonomic vectors)
    //     { 𝐞ᵏ } is the reciprocal dual basis, satisfying 𝐞ᵏ ⋅ 𝐞ⱼ = δᵏⱼ 
    //      
    //  If the basis is non-coordinate (anholonomic), then 
    //    ∂ᵢ 𝐞ⱼ = 𝛤ᵏᵢⱼ 𝐞ₖ + 𝐶ᵏᵢⱼ 𝐞ₖ 
    //
    //  so 
    //    𝐞ᵏ ⋅  ∂ᵢ 𝐞ⱼ = 𝐞ᵏ ⋅ 𝛤ᵏᵢⱼ 𝐞ₖ + 𝐞ᵏ ⋅ 𝐶ᵏᵢⱼ 𝐞ₖ 
    //                = 𝛤ᵏᵢⱼ 𝐞ᵏ ⋅ 𝐞ₖ + 𝐶ᵏᵢⱼ 𝐞ᵏ ⋅ 𝐞ₖ 
    //
    //    𝐞ᵏ ⋅  ∂ᵢ 𝐞ⱼ = 𝛤ᵏᵢⱼ + 𝐶ᵏᵢⱼ
    //  
    //  Want me to illustrate the difference with polar coordinates
    //  (holonomic, works cleanly) vs.
    //      a non-coordinate frame (like orthonormal polar unit vectors)?
    // 
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(chr2_cmd<stknd, drpv, DX> ch, const tensor<value_container<N>, CntrType>& V) noexcept
    {
       using TType = tensor<value_container<N>, CntrType>;

       if constexpr(N == 3)
       {
          if constexpr(TType::max_arg_count == 3)
          {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              auto e1 =  drv_cmd<stknd, drpv, 0, 1, DX>{} * V;
              auto e2 =  drv_cmd<stknd, drpv, 1, 1, DX>{} * V;
              auto e3 =  drv_cmd<stknd, drpv, 2, 1, DX>{} * V;

              auto dV = e1 % e2 * e3;

              auto d1 = e2 % e3 / dV;
              auto d2 = e3 % e1 / dV;
              auto d3 = e1 % e2 / dV;

              return [e = std::tuple{e1, e2, e3}, d = std::tuple{d1, d2, d3}]
                    <auto k, auto i, auto j>(value_container<k, i, j>)
                {
                    //         ∂𝐞ⱼ 
                    // 𝛤ᵏᵢⱼ = ———— ⋅ 𝐞ᵏ
                    //         ∂𝑥ⁱ

                    auto e_j = std::get<j>(e);
                    auto d_k = std::get<k>(d);

                    return (drv_cmd<stknd, drpv, i, 1, DX>{} * e_j) * d_k; 
                    
                };
          }
          else if constexpr(TType::max_arg_count == 2)
          {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              auto e1 =  drv_cmd<stknd, drpv, 0, 1, DX>{} * V;
              auto e2 =  drv_cmd<stknd, drpv, 1, 1, DX>{} * V;
              auto e12 =  e1 % e2;
              auto e3 = e12 / e12.mag();
              
              auto dV = e1 % e2 * e3;

              auto d1 = e2 % e3 / dV;
              auto d2 = e3 % e1 / dV;
              auto d3 = e1 % e2 / dV;

              return [e = std::tuple{e1, e2, e3}, d = std::tuple{d1, d2, d3}]
                    <auto k, auto i, auto j>(value_container<k, i, j>)
                {
                    //         ∂𝐞ⱼ 
                    // 𝛤ᵏᵢⱼ = ———— ⋅ 𝐞ᵏ = ∂ᵢ𝐞ⱼ ⋅ 𝐞ᵏ
                    //         ∂𝑥ⁱ
                    //
                    // 𝛤ᵏᵢⱼ = ∂ᵢ𝐞ⱼ ⋅ 𝐞ᵏ

                    auto e_j = std::get<j>(e);
                    auto d_k = std::get<k>(d);

                    return (drv_cmd<stknd, drpv, i, 1, DX>{} * e_j) * d_k; 
                    
                };
          }
          else if constexpr(TType::max_arg_count == 1)
          {
            static_assert(TType::max_arg_count >= 2, "not yet implemented");
          }
        }
    }

    // Christoffel symbols in terms of basis vectors are
    //
    //  𝛤ᵏᵢⱼ = (1/2) gᵏᵐ ( ∂ᵢgⱼₘ + ∂ⱼgᵢₘ - ∂ₘgᵢⱼ )
    //  𝛤ᵏᵢⱼ = (1/2) (𝐞ᵏ ⋅ 𝐞ᵐ)( ∂ᵢ(𝐞ⱼ⋅𝐞ₘ) + ∂ⱼ(𝐞ᵢ⋅𝐞ₘ) - ∂ₘ(𝐞ᵢ⋅𝐞ⱼ) )
    //
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(chr_cmd<stknd, drpv, DX> ch, const tensor<value_container<N>, CntrType>& V) noexcept
    {
       using TType = tensor<value_container<N>, CntrType>;

       if constexpr(N == 3)
       {
          if constexpr(TType::max_arg_count == 3)
          {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              auto e1 =  drv_cmd<stknd, drpv, 0, 1, DX>{} * V;
              auto e2 =  drv_cmd<stknd, drpv, 1, 1, DX>{} * V;
              auto e3 =  drv_cmd<stknd, drpv, 2, 1, DX>{} * V;

              auto dV = e1 % e2 * e3;

              auto d1 = e2 % e3 / dV;
              auto d2 = e3 % e1 / dV;
              auto d3 = e1 % e2 / dV;

              return [e = std::tuple{e1, e2, e3}, d = std::tuple{d1, d2, d3}]
                    <auto k, auto i, auto j>(value_container<k, i, j>)
                {
                  using namespace gmp::literals;
                  using namespace gmp::calculus;

                  using gmp::calculus::operator*;
                  using gmp::calculus::operator+;
                  using gmp::calculus::operator-;
                  using gmp::calculus::operator/;

                  using operators::operator*;
                  using operators::operator+;
                  using operators::operator-;
                  using operators::operator/;
                  
                    // 𝛤ᵏᵢⱼ = (1/2) (𝐞ᵏ ⋅ 𝐞ᵐ){ ∂ᵢ(𝐞ⱼ⋅𝐞ₘ) + ∂ⱼ(𝐞ᵢ⋅𝐞ₘ) - ∂ₘ(𝐞ᵢ⋅𝐞ⱼ) }
                    // 
                    //      = (1/2) (𝐞ᵏ ⋅ 𝐞⁰){ ∂ᵢ(𝐞ⱼ⋅𝐞₀) + ∂ⱼ(𝐞ᵢ⋅𝐞₀) - ∂₀(𝐞ᵢ⋅𝐞ⱼ) }
                    //      + (1/2) (𝐞ᵏ ⋅ 𝐞¹){ ∂ᵢ(𝐞ⱼ⋅𝐞₁) + ∂ⱼ(𝐞ᵢ⋅𝐞₁) - ∂₁(𝐞ᵢ⋅𝐞ⱼ) }
                    //      + (1/2) (𝐞ᵏ ⋅ 𝐞²){ ∂ᵢ(𝐞ⱼ⋅𝐞₂) + ∂ⱼ(𝐞ᵢ⋅𝐞₂) - ∂₂(𝐞ᵢ⋅𝐞ⱼ) }

                    //      = (1/2) (𝐝ᵏ ⋅ 𝐝⁰){ ∂ᵢ(𝐞ⱼ⋅𝐞₀) + ∂ⱼ(𝐞ᵢ⋅𝐞₀) - ∂₀(𝐞ᵢ⋅𝐞ⱼ) }
                    //      + (1/2) (𝐝ᵏ ⋅ 𝐝¹){ ∂ᵢ(𝐞ⱼ⋅𝐞₁) + ∂ⱼ(𝐞ᵢ⋅𝐞₁) - ∂₁(𝐞ᵢ⋅𝐞ⱼ) }
                    //      + (1/2) (𝐝ᵏ ⋅ 𝐝²){ ∂ᵢ(𝐞ⱼ⋅𝐞₂) + ∂ⱼ(𝐞ᵢ⋅𝐞₂) - ∂₂(𝐞ᵢ⋅𝐞ⱼ) }

                    auto d_k = std::get<k>(d);
                    auto [d_0, d_1, d_2] = d; auto [e_0, e_1, e_2] = e;

                    auto e_i = std::get<i>(e);  auto e_j = std::get<j>(e);
                  
                    auto r_0 = (d_k * d_0) * ( drv_cmd<stknd, drpv, i, 1, DX>{} * (e_j * e_0)
                                             + drv_cmd<stknd, drpv, j, 1, DX>{} * (e_i * e_0)
                                             - drv_cmd<stknd, drpv, 0, 1, DX>{} * (e_i * e_j) );

                    auto r_1 = (d_k * d_1) * ( drv_cmd<stknd, drpv, i, 1, DX>{} * (e_j * e_1)
                                             + drv_cmd<stknd, drpv, j, 1, DX>{} * (e_i * e_1)
                                             - drv_cmd<stknd, drpv, 1, 1, DX>{} * (e_i * e_j) );

                    auto r_2 = (d_k * d_2) * ( drv_cmd<stknd, drpv, i, 1, DX>{} * (e_j * e_2)
                                             + drv_cmd<stknd, drpv, j, 1, DX>{} * (e_i * e_2)
                                             - drv_cmd<stknd, drpv, 2, 1, DX>{} * (e_i * e_j) );

                    return (r_0 + r_1 + r_2)/2;
                    
                };
          }
          else if constexpr(TType::max_arg_count == 2)
          {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              auto e1 =  drv_cmd<stknd, drpv, 0, 1, DX>{} * V;
              auto e2 =  drv_cmd<stknd, drpv, 1, 1, DX>{} * V;
              auto e12 =  e1 % e2;
              auto e3 = e12 / e12.mag();
              
              auto dV = e1 % e2 * e3;

              auto d1 = e2 % e3 / dV;
              auto d2 = e3 % e1 / dV;
              auto d3 = e1 % e2 / dV;

              return [e = std::tuple{e1, e2, e3}, d = std::tuple{d1, d2, d3}]
                    <auto k, auto i, auto j>(value_container<k, i, j>)
                {
                    //         ∂𝐞ⱼ 
                    // 𝛤ᵏᵢⱼ = ———— ⋅ 𝐞ᵏ
                    //         ∂𝑥ⁱ

                    auto e_j = std::get<j>(e); auto d_k = std::get<k>(d);

                    return (drv_cmd<stknd, drpv, i, 1, DX>{} * e_j) * d_k; 
                    
                };
          }
          else if constexpr(TType::max_arg_count == 1)
          {
            static_assert(TType::max_arg_count >= 2, "not yet implemented");
          }
        }
    }

    //
    // [𝐞ᵢ, 𝐞ⱼ] = (∂ᵢ𝐞ⱼ - ∂ⱼ𝐞ᵢ) = 𝐶ᵏᵢⱼ𝐞ₖ
    //
    // 𝐶ᵏᵢⱼ = 𝐞ᵏ ⋅ (∂ᵢ𝐞ⱼ - ∂ⱼ𝐞ᵢ)
    // 
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(stc_cmd<stknd, drpv, DX> ch, const tensor<value_container<N>, CntrType>& V) noexcept
    {
       using TType = tensor<value_container<N>, CntrType>;

       if constexpr(N == 3)
       {
          if constexpr(TType::max_arg_count == 3)
          {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              using operators::operator*;
              using operators::operator+;
              using operators::operator-;
              using operators::operator/;

              auto e1 =  drv_cmd<stknd, drpv, 0, 1, DX>{} * V;
              auto e2 =  drv_cmd<stknd, drpv, 1, 1, DX>{} * V;
              auto e3 =  drv_cmd<stknd, drpv, 2, 1, DX>{} * V;

              auto dV = e1 % e2 * e3;

              auto d1 = e2 % e3 / dV;
              auto d2 = e3 % e1 / dV;
              auto d3 = e1 % e2 / dV;

              return [e = std::tuple{e1, e2, e3}, d = std::tuple{d1, d2, d3}]
                    <auto k, auto i, auto j>(value_container<k, i, j>)
                {
                    auto e_i = std::get<i>(e);
                    auto e_j = std::get<j>(e);
                    auto d_k = std::get<k>(d);

                    return (drv_cmd<stknd, drpv, i, 1, DX>{} * e_j
                            - drv_cmd<stknd, drpv, j, 1, DX>{} * e_i) * d_k;
                };
          }
          else if constexpr(TType::max_arg_count == 2)
          {
              using namespace gmp::literals;
              using namespace gmp::calculus;

              using gmp::calculus::operator*;
              using gmp::calculus::operator+;
              using gmp::calculus::operator-;
              using gmp::calculus::operator/;

              auto e1 =  drv_cmd<stknd, drpv, 0, 1, DX>{} * V;
              auto e2 =  drv_cmd<stknd, drpv, 1, 1, DX>{} * V;
              auto e12 =  e1 % e2;
              auto e3 = e12 / e12.mag();
              
              auto dV = e1 % e2 * e3;

              auto d1 = e2 % e3 / dV;
              auto d2 = e3 % e1 / dV;
              auto d3 = e1 % e2 / dV;

              return [e = std::tuple{e1, e2, e3}, d = std::tuple{d1, d2, d3}]
                    <auto k, auto i, auto j>(value_container<k, i, j>)
                {
                    auto e_i = std::get<i>(e);
                    auto e_j = std::get<j>(e);
                    auto d_k = std::get<k>(d);

                    return (drv_cmd<stknd, drpv, i, 1, DX>{} * e_j
                            - drv_cmd<stknd, drpv, j, 1, DX>{} * e_i) * d_k;
                };
          }
          else if constexpr(TType::max_arg_count == 1)
          {
            static_assert(TType::max_arg_count >= 2, "not yet implemented");
          }
        }
    }

    // Divergence - Flux per unit measure (line / area / volume)
    //
    //               ∬ 𝐅⋅𝑛𝑑𝑆
    // ∇⋅𝐅(𝑝) = lim —————————— 
    //          Δ𝑆→0    Δ𝑆
    //
    //  How to compute the divergence of a vector field that is tangent to a surface.
    //  This is a sophisticated concepts from differential geometry, not standard Vector
    //  Calculus. The key to compute this is to work with the basis vectors of the surface itself,
    //  rather than the arbitrary basis vectors of the ambient space.
    //  
    //  The Conceptual Steps to Compute Surface Divergence
    //
    //  1. Define the Surface Basis Vectors: The surface is parameterized by 𝑢 and 𝑣, with the
    //    
    //  position vector 𝐫(𝑢, 𝑣) = < 𝑥(𝑢, 𝑣), 𝑦(𝑢, 𝑣), 𝑧(𝑢, 𝑣) >. The basis vectors for this surface
    //  are found by taking the partial derivatives of the position vector with respect to the parameters 𝑢 and 𝑣.
    //
    //        ∂𝐫        ∂𝑥   ∂𝑦   ∂𝑧   
    //  𝐫ᵤ = ————— = < ———, ———, ——— >
    //        ∂𝑢       ∂𝑢   ∂𝑢   ∂𝑢
    // 
    //        ∂𝐫       ∂𝑥   ∂𝑦   ∂𝑧   
    //  𝐫ᵥ = ————— = < ———, ———, ——— >
    //        ∂𝑣       ∂𝑣   ∂𝑣   ∂𝑣 
    //
    //  2. Define the Vector Field Components: The vector field 𝐅 must be expressed
    //  in terms of the surface basis vectors. So, we need to find the components 𝐅ᵤ and 𝐅ᵥ such that  
    //
    //    𝐅 = 𝐅ᵤ 𝐫ᵤ + 𝐅ᵥ 𝐫ᵥ
    //
    //  This can be a complex step, as you may have to project the components of 𝐅 onto the 
    //  surface's tangent plane.
    //
    //  Compute the Metric Tensor: The surface dirvergence formula requires the metric tensor,
    //  which meatures distances and areas on the curved surface. The components of the metric
    //  tensor, gᵢⱼ, are the dot products of the basis vectors. 
    // 
    //  3. Compute the Metric Tensor: The surface divergence formula requires the metric tensor,
    //  which meastures distances and areas on the curved surface. The components of the metric
    //  tensor, gᵢⱼ, are the dot products of the basis vectors.
    //
    //  gᵤᵤ = 𝐫ᵤ ⋅ 𝐫ᵤ
    //  gᵤᵥ = gᵥᵤ = 𝐫ᵤ ⋅ 𝐫ᵥ
    //  gᵥᵥ = 𝐫ᵥ ⋅ 𝐫ᵥ
    // 
    //  The determinant of the metric tensor, g = det(gᵢⱼ), is used to calculate the area element.
    //  
    //  4. Apply the Surface Divergence Formula: Finally, the intrinsic divergence of a vector field
    //  
    //  𝐅 on a surface is given by the formula:
    //
    //            1      ∂               ∂
    //  ∇ₛ ⋅ 𝐅 = ————— [ ———( √|g| 𝐅ᵤ) + ———( √|g| 𝐅ᵥ) ]  (Divergence on Surface)
    //          √|g|     ∂𝑢              ∂𝑣  
    //
    //
    //                  1      ∂                ∂
    //  (∇ₛ × 𝐅) ⋅ 𝐧 = ————— [ ———( √|g| 𝐅𝑣) - ———( √|g| 𝐅ᵤ) ]  (Curl on Surface)
    //                 √|g|    ∂𝑢              ∂𝑣  
    //
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(dvg_cmd<stknd, drpv, DX> dg, const tensor<value_container<N>, CntrType>& F) noexcept
       requires (all_the_same_values(typename tensor<value_container<N>, CntrType>::args_count{}))
    {
      using TType = tensor<value_container<N>, CntrType>;
      constexpr int pCount = gmp::get<0>(typename TType::args_count{});

      if constexpr(N == pCount)
      {
        return [&]<auto ... VarId>(value_container<VarId...>)
        {
          using namespace literals;
          using namespace calculus;

          using calculus::operator*;
          using calculus::operator+;

          return ( (drv_cmd<stknd, drpv, VarId, 1, DX>{} * F.template get<VarId>()) + ... );  

        }(forward_sequence<N>());
      }
      else
      {
        static_assert(N == pCount, "Not yet implemented");
      }
    }

    // Curl - Circulation per unit area
    //
    //                       1   
    // ∇ × 𝐹(𝑝) ⋅ 𝐧  = lim ————— ∮ 𝐅 ⋅ d𝓁
    //                 Δ𝐴⟶0 Δ𝐴       
    //
    template<DrvStencil stknd, DrvPivot drpv, auto DX, auto N, tuple_c CntrType>
    auto operator*(crl_cmd<stknd, drpv, DX> cr, const tensor<value_container<N>, CntrType>& F) noexcept
      requires (N < 4 && all_the_same_values(typename tensor<value_container<N>, CntrType>::args_count{}))
    {
      using TType = tensor<value_container<N>, CntrType>;
      constexpr int pCount = gmp::get<0>(typename TType::args_count{});

      if constexpr(N == pCount)
      {
          using namespace literals;
          using namespace calculus;

          using calculus::operator*;
          using calculus::operator+;
          using calculus::operator-;

          if constexpr(N == 2)
          {
            constexpr auto dx = drv_cmd<stknd, drpv, 0, 1, DX>{};
            constexpr auto dy = drv_cmd<stknd, drpv, 1, 1, DX>{};

            auto& [Fx, Fy] = F.m_data();

            return make_tensor(0, 0, dx * Fx - dy * Fy);
          }
          else if constexpr(N == 3)
          {
            constexpr auto dx = drv_cmd<stknd, drpv, 0, 1, DX>{};
            constexpr auto dy = drv_cmd<stknd, drpv, 1, 1, DX>{};
            constexpr auto dz = drv_cmd<stknd, drpv, 2, 1, DX>{};

            auto& [Fx, Fy, Fz] = F.data();

            return make_tensor(dy * Fz - dz * Fy, dz * Fx - dx * Fz, dx * Fy - dy * Fx);
          }
          else
          {
            static_assert(N<4, "Not yet implemented");
          }
      }
      else
      {
        if constexpr(N == 3 && pCount == 2)
        {
          // static_assert(N == pCount, "Not yet implemented");

          //                 1       ∂                ∂
          //  (∇ × 𝐅) ⋅ 𝐧 = ————— [ ———( √ |g| 𝐅ᵛ) - ————( √ |g| 𝐅ᵘ) ]
          //               √ |g|     ∂𝑢               ∂𝑣      
          //
          // 𝐅 = ( 𝑥(𝑢, 𝑣), 𝑦(𝑢, 𝑣), 𝑧(𝑢, 𝑣) )
          //
          //        ∂𝐅         ∂𝐅
          //  𝐅ᵤ = ————, 𝐅ᵥ = ————
          //        ∂𝑢         ∂𝑣
          //
          //      |𝐅ᵤ × 𝐅ᵥ|
          // 𝐧 = ——————————, 
          //       𝐅ᵤ × 𝐅ᵥ
          //
        }
        else 
        {
          static_assert(N == pCount, "Not yet implemented");
        }
        
      }
    }
   
    namespace hidden
    {
      template<auto Rows, auto K, tuple_c CntrType1, auto Cols,
        tuple_c CntrType2, auto... ii, auto... jj>
      auto tensor_binary_mul(const tensor<value_container<Rows, K>, CntrType1>& M,
                     const tensor<value_container<K, Cols>, CntrType2>& N, 
                    type_container< value_container<ii, jj> ... > ) noexcept
      {
        using MType = tensor<value_container<Rows, K>, CntrType1>;
        using NType = tensor<value_container<K, Cols>, CntrType2>;

        auto P_ij = [&]<auto i, auto j>(value_container<i, j>)
        {        
           auto ij = [&]<auto...kk>(value_container<kk...>)
              {
                return ( ( M.template get<i, kk>() * N.template get<kk, j>() ) + ... );

              }(forward_sequence<K>());

          return [ij](auto... args)
              requires(sizeof...(args) == maximum<MType::max_arg_count, NType::max_arg_count>())
            {
              return evaluate(ij, args...);
            };
        };
        
        return make_tensor(value_container<Rows, Cols>{},
                           P_ij( value_container<ii, jj>{} )... );
      }
    }
    // end of namespace hidden
    
    template<auto Rows, auto K, tuple_c CntrType1, auto Cols, tuple_c CntrType2>
    auto operator*(const tensor<value_container<Rows, K>, CntrType1>& M,
                   const tensor<value_container<K, Cols>, CntrType2>& N) noexcept
    {
        // P = M x N

        return hidden::tensor_binary_mul(M, N,
              hidden::make_metric_indices<Rows, Cols>());
    }

    template<auto Rows, auto K, std_array_or_vector_c CntrType1,
             auto Cols, std_array_or_vector_c CntrType2>
    auto operator*(const tensor<value_container<Rows, K>, CntrType1>& M,
                   const tensor<value_container<K, Cols>, CntrType2>& N) noexcept
    {
      
        // P = M x N

        using MType = tensor<value_container<Rows, K>, CntrType1>;
        using NType = tensor<value_container<K, Cols>, CntrType2>;
        using T = common_type_t<double, typename MType::value_type, typename NType::value_type>;

        auto P = make_tensor<T, Rows, Cols>();
        using PType = decltype(P); 

        auto& m = M.cast_ref();
        auto& n = N.cast_ref();
        auto& p = P.cast_ref();

        T s{};

        for(int i = 0; i < Rows; ++i)
        {
          for(int j = 0; j < Cols; ++j)
          {
              s = 0;
              
              for(int k = 0; k < K; ++k)
                  s += m[i][k] * n[k][j];

              p[i][j] = s;
          }
        }

        return P;
    }

    template<auto Dim, auto... Dims, tuple_c CntrType1, tuple_c CntrType2>
    auto operator+(const tensor<value_container<Dim, Dims...>, CntrType1>& M,
                   const tensor<value_container<Dim, Dims...>, CntrType2>& N) noexcept
    {
        using TType = tensor<value_container<Dim, Dims...>, CntrType1>;

        return [&]<auto ... n>(value_container<n...>)
        {
          using namespace gmp::literals;
          using namespace gmp::calculus;

          using gmp::calculus::operator*;
          using gmp::calculus::operator+;
          using gmp::calculus::operator-;
          using gmp::calculus::operator/;

          return make_tensor(typename TType::dims_cntr{},
                             (M.template get<n>() + N.template get<n>()) ... );

        }(forward_sequence<TType::dimension>());
    }

    template<auto Dim, auto... Dims, tuple_c CntrType1, tuple_c CntrType2>
    auto operator-(const tensor<value_container<Dim, Dims...>, CntrType1>& M,
                   const tensor<value_container<Dim, Dims...>, CntrType2>& N) noexcept
    {
        using TType = tensor<value_container<Dim, Dims...>, CntrType1>;

        return [&]<auto ... n>(value_container<n...>)
        {
          using namespace gmp::literals;
          using namespace gmp::calculus;

          using gmp::calculus::operator*;
          using gmp::calculus::operator+;
          using gmp::calculus::operator-;
          using gmp::calculus::operator/;

          return make_tensor(typename TType::dims_cntr{},
                             (M.template get<n>() - N.template get<n>()) ... );

        }(forward_sequence<TType::dimension>());
    }

    template<CastRtnType cmode = CastRtnType::dont,
            typename FType, typename ArgType, typename... ArgTypes>
    auto eval(FType&& f, ArgType&& arg, ArgTypes&& ... args)
    {
      return evaluate<cmode>(std::forward<FType>(f),
            std::forward<ArgType>(arg), std::forward<ArgTypes>(args)...);
    }
  }
  // end of namespace gmp::operators
}
// end of namespace gmp

#endif 
// end of file _GMP_TENSOR_HPP
