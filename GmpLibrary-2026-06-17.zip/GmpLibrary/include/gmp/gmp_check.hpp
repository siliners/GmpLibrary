/*
	Author: Chang Hee Kim (Thomas Kim)
	
	First Created: Nov. 5, 2017
	Second Edit: Nov. 7, 2017
	Third Edit: Jan. 15, 2025
	License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/

	Version: 1.3

    clang++ -std=c++23 sanity.cpp -lmpfr -lmpc -ltbb12 -o c.exe
    g++ -std=c++23 sanity.cpp -lmpfr -lmpc -ltbb12 -o g.exe
*/

#ifndef GMP_CHECK_HPP
#define GMP_CHECK_HPP

#ifndef NOMINMAX
	#define NOMINMAX
#endif

#include <iostream>
#include <sstream>
#include <string>

#ifdef UNICODE
	#define STDSTRING std::wstring
	#define STRSTREAM std::wostringstream
	#define UNISTR(txt)		L##txt	
	#define UNITXT(txt)		UNISTR(#txt)
	#define STDCOUT	std::wcout
#else
	#define STDSTRING std::string
	#define STRSTREAM std::ostringstream
	#define UNISTR(txt)		txt
	#define UNITXT(txt)		UNISTR(#txt)
	#define STDCOUT	std::cout
#endif

#if !defined(_WINDOWS) && !defined(_AFXDLL)

	#ifdef _DEBUG
		// order of #define 
		// and #include should be preserved
		#define _CRTDBG_MAP_ALLOC
		#include <cstdlib>
		#include <crtdbg.h>
		
		#ifndef new
			#define new new(_NORMAL_BLOCK, __FILE__, __LINE__)
		#endif
		
		class CMemLeakCheck
		{
		protected:
			STDSTRING m_filename;
			STDSTRING m_varname;
			int m_lineno;
			size_t m_total;

		public:
			CMemLeakCheck(const STDSTRING& filename=UNISTR(""),
				int lineno=0, const STDSTRING& varname=UNISTR("")) :
				m_filename(filename), m_lineno(lineno), m_varname(varname), m_total(0)
			{
				// does not work
				Reset(); 
			}

			void Reset() {
				
				_CrtMemState mem_state;
				_CrtMemCheckpoint(&mem_state);
				this->m_total = mem_state.lSizes[_NORMAL_BLOCK];
			}
			
			size_t Difference() {
				
				_CrtMemState mem_state;
				_CrtMemCheckpoint(&mem_state);

				return mem_state.lSizes[_NORMAL_BLOCK] - this->m_total;
			}
			
			STDSTRING Message(int lineno = 0, bool from_destructor=false)
			{
				size_t bytes = Difference();
				
				STRSTREAM stm;
				
				if (bytes > 0)
				{
					stm << UNISTR("File: ") << m_filename << UNISTR("\nAt line: ") << (lineno ? lineno : m_lineno)
						<< UNISTR(", Checkpoint: ") << m_varname << UNISTR(", ") << bytes
						<< (from_destructor ? UNISTR(" bytes LEAKED.") : UNISTR(" bytes ALIVE."));
				}
				else
				{
					stm << UNISTR("Memory State CLEAN.");
				}

				return stm.str();
			}

			void Report(int lineno = 0, bool from_destructor=false)
			{
				STDCOUT << UNISTR("\n") << Message(lineno, from_destructor) << UNISTR("\n");
			}

			~CMemLeakCheck()
			{
				if (Difference() > 0) { Report(0, true); }
			}
		};


		#define MemLeakCheckReport(varname)	varname.Report(__LINE__)
		#define MemLeakCheckMessage(varname) varname.Message(__LINE__)

	#endif // end of debugging


#else	// MFC Console or MFC Window

	#ifdef _DEBUG

		#ifndef new 
		#define new DEBUG_NEW
		#endif
	
		class CMemLeakCheck
		{
		protected:
			CString m_filename;
			CString m_varname;
			int m_lineno;
			size_t m_total;

			CMemoryState mem_state;

		public:
			CMemLeakCheck(const CString& filename= UNISTR(""),
				int lineno=0, const CString& varname= UNISTR("")) :
				m_filename(filename), m_lineno(lineno), m_varname(varname), m_total(0)
			{
				// this does not work
				// Reset();
			}

			void Reset() 
			{ 
				mem_state.Checkpoint();
				this->m_total = mem_state.m_lSizes[_NORMAL_BLOCK];
			}

			size_t Difference() 
			{
				mem_state.Checkpoint();
				return (mem_state.m_lSizes[_NORMAL_BLOCK]) - this->m_total;
			}

		#ifdef _CONSOLE
			STDSTRING 
		#else
			CString
		#endif
				Message(int lineno=0, bool from_destructor=false)
			{
				size_t bytes = Difference();

				STRSTREAM stm;

				if (bytes > 0)
				{

					stm << UNISTR("File: ") << m_filename.GetString() << UNISTR("\nAt line: ") << (lineno ? lineno : m_lineno)
						<< UNISTR(", Checkpoint: ") << m_varname.GetString() << UNISTR(", ") << bytes <<
						(from_destructor ? UNISTR(" bytes LEAKED.") : UNISTR(" bytes are ALIVE."));
				}
				else
				{
					stm << UNISTR("Memory Clean.");
				}
				
				#ifdef _CONSOLE
				
					return stm.str();
				
				#else
				
					return CString(stm.str().c_str());
				#endif
			}

			void Report(int lineno = 0, bool from_destructor=false)
			{
				#ifdef _CONSOLE
					STDCOUT <<std::endl<<Message(lineno, from_destructor) << std::endl;

				#else
					CString msg = Message(lineno, from_destructor);
					AfxMessageBox(msg);
				#endif
			}

			~CMemLeakCheck()
			{
				if (Difference()  > 0) { Report(0, true); }
			}
		};

		#define MemLeakCheckReport(varname)	varname.Report(__LINE__)
		#define MemLeakCheckMessage(varname) varname.Message(__LINE__)
		
		//#define MemLeakCheckReport(varname) AfxMessageBox(_T("MemLeakCheckReport is not supported in MFC Windows App"))
		//#define MemLeakCheckMessage(varname) AfxMessageBox(_T("MemLeakCheckMessage is not supported in MFC Windows App"))
		
	#endif // end of debugging
#endif // 

#if defined(_MSVC_LANG) && defined(_DEBUG) 

	#ifdef UNICODE
		#define Gmp_MemLeakCheck(varname)	CMemLeakCheck varname(__FILEW__, __LINE__, UNITXT(varname)) ; varname.Reset()
	#else
		#define Gmp_MemLeakCheck(varname)	CMemLeakCheck varname(__FILE__, __LINE__, UNITXT(varname)) ; varname.Reset()
	#endif

	#define Gmp_MemLeakCheckReport(varname)	varname.Report(__LINE__)
	#define Gmp_MemLeakCheckMessage(varname) varname.Message(__LINE__)
#else	
	// non debugging mode
	#define Gmp_MemLeakCheck(varname)
	#define Gmp_MemLeakCheckReport(varname)
	#define Gmp_MemLeakCheckMessage(varname)
#endif

#endif // end of file