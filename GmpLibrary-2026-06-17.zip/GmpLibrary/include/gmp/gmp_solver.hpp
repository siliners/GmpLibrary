﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.01.27
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/    
*/

#ifndef _GMP_SOLVER_HPP
#define _GMP_SOLVER_HPP

#ifndef GMP_GAUSS_QUADRATURE_SUPER_HUGE
#define GMP_GAUSS_QUADRATURE_SUPER_HUGE TRUE
#endif

#ifndef GMP_CACHE_WEIGHTS_AND_NODES
#define GMP_CACHE_WEIGHTS_AND_NODES TRUE
#endif

#ifndef GMP_CACHE_TOLERANCE
#define GMP_CACHE_TOLERANCE TRUE
#endif 

#ifndef GMP_GAUSS_LAGUERRE_QUADRATURE_SEED
#define GMP_GAUSS_LAGUERRE_QUADRATURE_SEED TRUE
#endif 

#include "gmp_base.hpp"
#include "gmp_math.hpp"

#if GMP_GAUSS_QUADRATURE_SUPER_HUGE==TRUE
    #include "gmp_gauss_legendre_350.hpp"
#else
    #include "gmp_gauss_legendre_71.hpp"
#endif

#if GMP_GAUSS_LAGUERRE_QUADRATURE_SEED == TRUE
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_0.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_1.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_2.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_3.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_4.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_5.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_6.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_7.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_8.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_9.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_10.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_11.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_12.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_13.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_14.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_15.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_16.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_17.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_18.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_19.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_20.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_21.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_22.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_23.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_24.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_25.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_26.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_27.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_28.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_29.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_30.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_31.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_32.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_33.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_34.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_35.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_36.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_37.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_38.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_39.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_40.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_41.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_42.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_43.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_44.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_45.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_46.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_47.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_48.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_49.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_50.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_51.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_52.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_53.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_54.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_55.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_56.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_57.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_58.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_59.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_60.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_61.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_62.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_63.hpp>
    #include <gmp/quadratures/seeds/gmp_gauss_laguerre_quadrature_seed_64.hpp>
#endif

#include "gmp_output_base.hpp"

namespace gmp
{
    // Finite Difference Coefficients Calculator
    // https://web.media.mit.edu/~crtaylor/calculator.html
    
    namespace calculus
    {
        using namespace gmp::operators;
        using namespace gmp::literals;
        
        namespace hidden
        {   
            auto power = []<typename Type>(Type x, auto n)
            {
                if constexpr(gmp_type_c<Type>)
                    return gmp::pow(x, n);
                else
                    return std::pow(x,n);
            };

            // 3-point stencil derivatives: backward, centered, forward
            template<auto VarID, auto Order, typename DxType, 
                    typename ArgType, std::size_t N, typename FuncType>
                requires (Order == 1 || Order == 2)
            ArgType derv_3pt_stc_backward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID];
                auto& xx = args[VarID];
                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[] = {
                    (xx = x - 2*h, (ArgType)std::apply(f, args)),
                    (xx = x - 1*h, (ArgType)std::apply(f, args)),
                    (xx = x       , (ArgType)std::apply(f, args))
                };

                if constexpr(Order == 1)
                    return (3*fh[2] - 4*fh[1] + fh[0]) / (2*h);
                else
                    return (2*fh[2] - 5*fh[1] + 4*fh[0]) / (h*h);
            }

            template<auto VarID, auto Order, typename DxType, 
                    typename ArgType, std::size_t N, typename FuncType>
                requires (Order == 1 || Order == 2)
            ArgType derv_3pt_stc_centered(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID];
                auto& xx = args[VarID];
                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[] = {
                    (xx = x - h, (ArgType)std::apply(f, args)),
                    (xx = x    , (ArgType)std::apply(f, args)),
                    (xx = x + h, (ArgType)std::apply(f, args))
                };

                if constexpr(Order == 1)
                    return (fh[2] - fh[0]) / (2*h);
                else
                    return (fh[0] - 2*fh[1] + fh[2]) / (h*h);
            }

            template<auto VarID, auto Order, typename DxType, 
                    typename ArgType, std::size_t N, typename FuncType>
                requires (Order == 1 || Order == 2)
            ArgType derv_3pt_stc_forward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;
                
                auto x = args[VarID];
                auto& xx = args[VarID];
                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[] = {
                    (xx = x      , (ArgType)std::apply(f, args)),
                    (xx = x + h  , (ArgType)std::apply(f, args)),
                    (xx = x + 2*h, (ArgType)std::apply(f, args))
                };

                if constexpr(Order == 1)
                    return (-3*fh[0] + 4*fh[1] - fh[2]) / (2*h);
                else
                    return (2*fh[0] - 5*fh[1] + 4*fh[2]) / (h*h);
            }

            //////////////////////////////// 5-pt stencil ///////////////
            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 5 )
            ArgType derv_5pt_stc_backward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;
                
                ArgType fh[]
                    {
                        (xx = x - 4 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x - 3 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x - 2 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x - 1 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x        , (ArgType)std::apply(f, args))  // 4
                    };

                if constexpr( Order == 1)
                {
                    return (3*fh[0] - 16*fh[1] + 36*fh[2] - 48*fh[3] + 25*fh[4])/(12*h);
                }
                else if constexpr( Order == 2)
                {
                    return (11*fh[0]-56*fh[1]+114*fh[2]-104*fh[3]+35*fh[4])/(12*h*h);
                }
                else if constexpr( Order == 3)
                {
                    return (3*fh[0]-14*fh[1]+24*fh[2]-18*fh[3]+5*fh[4])/(2*power(h, 3));
                }
                else if constexpr( Order == 4)
                {
                    auto hh = h * h;
                    return (fh[0] - 4*fh[1] + 6*fh[2] - 4*fh[3] + fh[4])/power(h, 4);
                }
            }

            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 5 )
            ArgType derv_5pt_stc_centered(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;
                
                ArgType fh[]
                    {
                        (xx = x - 2 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x - 1 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x + 0 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x + 1 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x + 2 * h, (ArgType)std::apply(f, args))  // 4
                    };

                if constexpr( Order == 1 )
                {
                    return (fh[0] - 8 * fh[1] + 8 * fh[3] - fh[4])/(12 * h); 
                }
                else if constexpr( Order == 2 )
                {
                    return (-fh[0] + 16*fh[1] - 30 * fh[2] + 16 * fh[3] - fh[4])/(12 * h * h);
                }
                else if constexpr( Order == 3 )
                {
                    return (-fh[0] + 2*fh[1] + 0*fh[2] - 2*fh[3] + fh[4])/(2*power(h,3));
                }
                else if constexpr( Order == 4 )
                {
                    return (fh[0] - 4*fh[1] + 6*fh[2] - 4*fh[3] + fh[4])/power(h, 4);
                }
            }

            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 5 )
            ArgType derv_5pt_stc_forward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;
                
                ArgType fh[]
                    {
                        (xx = x        , (ArgType)std::apply(f, args)), // 0
                        (xx = x + 1 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x + 2 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x + 3 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x + 4 * h, (ArgType)std::apply(f, args))  // 4
                    };

                if constexpr( Order == 1)
                {
                    return (-25*fh[0] + 48*fh[1] - 36*fh[2] + 16*fh[3] - 3*fh[4])/(12*h);
                }
                else if constexpr( Order == 2)
                {
                    return (35*fh[0] - 104*fh[1] + 114*fh[2] - 56*fh[3] + 11*fh[4])/(12*h*h);
                }
                else if constexpr( Order == 3)
                {
                    return (-5*fh[0] + 18*fh[1] - 24*fh[2] + 14*fh[3] - 3*fh[4])/(2*power(h, 3));
                }
                else if constexpr( Order == 4)
                {
                    return (fh[0] - 4*fh[1] + 6*fh[2] - 4*fh[3] + fh[4])/power(h, 4);
                }
            }

            /////////////////////////////////////////////////////////
            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 7 )
            ArgType derv_7pt_stc_backward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[]
                    {
                        (xx = x - 6 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x - 5 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x - 4 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x - 3 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x - 2 * h, (ArgType)std::apply(f, args)), // 4
                        (xx = x - 1 * h, (ArgType)std::apply(f, args)), // 5
                        (xx = x        , (ArgType)std::apply(f, args))  // 6
                    };
                
                if constexpr( Order == 1)
                {
                    return (10*fh[0] - 72*fh[1] + 225*fh[2] - 400*fh[3] + 450*fh[4] - 360*fh[5] + 147*fh[6])/(60*h);
                }
                else if constexpr(Order == 2)
                {
                    return (137*fh[0] - 972*fh[1] + 2970*fh[2] - 5080*fh[3] + 5265*fh[4] - 3132*fh[5] + 812*fh[6])/(180*h*h);
                }
                else if constexpr(Order == 3)
                {
                    return (15*fh[0] - 104*fh[1] + 307*fh[2] - 496*fh[3] + 461*fh[4] - 232*fh[5] + 49*fh[6])/(8*power(h, 3));
                }
                else if constexpr(Order == 4)
                {
                    return (17*fh[0] - 114*fh[1] + 321*fh[2] - 484*fh[3] + 411*fh[4] - 186*fh[5] + 35*fh[6])/(6*power(h, 4));
                }
                else if constexpr(Order == 5)
                {
                    return (5*fh[0] - 32*fh[1] + 85*fh[2] - 120*fh[3] + 95*fh[4] - 40*fh[5] + 7*fh[6])/(2*power(h, 5));
                }
                else if constexpr(Order == 6)
                {
                    return (fh[0] - 6*fh[1] + 15*fh[2] - 20*fh[3] + 15*fh[4] - 6*fh[5] + fh[6])/power(h, 6);
                }
            }

            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 7 )
            ArgType derv_7pt_stc_centered(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = static_cast<ele_t>(dx);

                ArgType fh[]
                    {
                        (xx = x - 3 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x - 2 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x - 1 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x       ,  (ArgType)std::apply(f, args)), // 3
                        (xx = x + 1 * h, (ArgType)std::apply(f, args)), // 4
                        (xx = x + 2 * h, (ArgType)std::apply(f, args)), // 5
                        (xx = x + 3 * h, (ArgType)std::apply(f, args))  // 6
                    };
                    
                if constexpr(Order == 1)
                {
                    return (-fh[0] + 9 * fh[1] - 45 * fh[2] + 45 * fh[4] - 9 * fh[5] + fh[6])/(60 * h);
                }
                else if constexpr(Order == 2)
                {
                    return (2*fh[0] - 27*fh[1] + 270*fh[2] - 490*fh[3] + 270*fh[4] - 27*fh[5] + 2*fh[6])/(180*h*h); 
                }
                else if constexpr(Order == 3)
                {
                    return (fh[0] - 8*fh[1] + 13*fh[2] + -13*fh[4] + 8*fh[5] - fh[6])/(8*power(h, 3));
                }
                else if constexpr(Order == 4)
                {
                    return (-fh[0] + 12*fh[1] - 39*fh[2] + 56*fh[3] - 39*fh[4] + 12*fh[5] - fh[6])/(6*power(h, 4));
                }
                else if constexpr(Order == 5)
                {
                    return (-fh[0] + 4*fh[1] - 5*fh[2] + 5*fh[4] - 4*fh[5] + fh[6])/(2*power(h, 5));
                }
                else if constexpr(Order == 6)
                {
                    return (fh[0] - 6*f[1] + 15*fh[2] - 20*fh[3] + 15*fh[4] - 6*fh[5] + fh[6])/power(h, 6);
                }
            }

            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 7 )
            ArgType derv_7pt_stc_forward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;
                
                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[]
                    {
                        (xx = x        , (ArgType)std::apply(f, args)), // 0
                        (xx = x +     h, (ArgType)std::apply(f, args)), // 1
                        (xx = x + 2 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x + 3 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x + 4 * h, (ArgType)std::apply(f, args)), // 4
                        (xx = x + 5 * h, (ArgType)std::apply(f, args)), // 5
                        (xx = x + 6 * h, (ArgType)std::apply(f, args))  // 6
                    };
                    
                if constexpr(Order == 1)
                {
                    return (-fh[0] + 9 * fh[1] - 45 * fh[2] + 45 * fh[4] - 9 * fh[5] + fh[6])/(60 * h);
                }
                else if constexpr(Order == 2)
                {
                    return (2*fh[0] - 27*fh[1] + 270*fh[2] - 490*fh[3] + 270*fh[4] - 27*fh[5] + 2*fh[6])/(180*h*h); 
                }
                else if constexpr(Order == 3)
                {
                    return (fh[0] - 8*fh[1] + 13*fh[2] + -13*fh[4] + 8*fh[5] - fh[6])/(8*power(h, 3));
                }
                else if constexpr(Order == 4)
                {
                    return (-fh[0] + 12*fh[1] - 39*fh[2] + 56*fh[3] - 39*fh[4] + 12*fh[5] - fh[6])/(6*power(h, 4));
                }
                else if constexpr(Order == 5)
                {
                    return (-fh[0] + 4*fh[1] - 5*fh[2] + 5*fh[4] - 4*fh[5] + fh[6])/(2*power(h, 5));
                }
                else if constexpr(Order == 6)
                {
                    return (fh[0] - 6*fh[1] + 15*fh[2] - 20*fh[3] + 15*fh[4] - 6*fh[5] + fh[6])/power(h, 6);
                }
            }

            /////////////////////////////////////////////////////////
            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 9 )
            ArgType derv_9pt_stc_backward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[]
                    {   
                        (xx = x - 8 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x - 7 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x - 6 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x - 5 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x - 4 * h, (ArgType)std::apply(f, args)), // 4
                        (xx = x - 3 * h, (ArgType)std::apply(f, args)), // 5
                        (xx = x - 2 * h, (ArgType)std::apply(f, args)), // 6
                        (xx = x - 1 * h, (ArgType)std::apply(f, args)), // 7
                        (xx = x - 0 * h, (ArgType)std::apply(f, args))  // 8
                    };

                /* ---------- 9-pt LEFT (backward) stencil ---------- */
                if constexpr (Order == 1)
                {
                    return ( -2283 * fh[0] +  6720 * fh[1] +
                            -11760 * fh[2] + 15680 * fh[3] +
                            -14700 * fh[4] +  9408 * fh[5] +
                             -3920 * fh[6] +   960 * fh[7] +
                              -105 * fh[8] ) / ( 840 * h );
                }
                else if constexpr (Order == 2)
                {
                    return (  29531 * fh[0] - 138528 * fh[1] +
                            312984 * fh[2]  - 448672 * fh[3] +
                            435330 * fh[4]  - 284256 * fh[5] +
                            120008 * fh[6]  - 29664 * fh[7] +
                              3267 * fh[8] ) / ( 5040 * power(h,2) );
                }
                else if constexpr (Order == 3)
                {
                    return (  -2403 * fh[0] +  13960 * fh[1] +
                             -36706 * fh[2] +  57384 * fh[3] +
                             -58280 * fh[4] +  39128 * fh[5] +
                             -16830 * fh[6] +   4216 * fh[7] +
                               -469 * fh[8] ) / ( 240 * power(h,3) );
                }
                else if constexpr (Order == 4)
                {
                    return ( 3207 * fh[0]  - 21056 * fh[1] +
                            61156 * fh[2]  - 102912 * fh[3] +
                            109930 * fh[4] - 76352 * fh[5] +
                            33636 * fh[6]  - 8576 * fh[7] +
                            967 * fh[8] ) / ( 240 * power(h,4) );
                }
                else if constexpr (Order == 5)
                {
                    return ( -81 * fh[0]  + 575 * fh[1] +
                            -1790 * fh[2] + 3195 * fh[3] +
                            -3580 * fh[4] + 2581 * fh[5] +
                            -1170 * fh[6] +  305 * fh[7] +
                            -35 * fh[8] ) / ( 6 * power(h,5) );
                }
                else if constexpr (Order == 6)
                {
                    return ( 39 * fh[0]  - 292 * fh[1] +
                            956 * fh[2]  - 1788 * fh[3] +
                            2090 * fh[4] - 1564 * fh[5] +
                            732 * fh[6]  - 196 * fh[7] +
                            23 * fh[8] ) / ( 4 * power(h,6) );
                }
                else if constexpr (Order == 7)
                {
                    return ( -9 * fh[0]   + 70 * fh[1] +
                             -238 * fh[2] + 462 * fh[3] +
                            -560 * fh[4]  + 434 * fh[5] +
                            -210 * fh[6]  + 58 * fh[7] +
                            -7 * fh[8] ) / ( 2 * power(h,7) );
                }
                else if constexpr (Order == 8)
                {
                    return ( 1 * fh[0] - 8 * fh[1] +
                            28 * fh[2] - 56 * fh[3] +
                            70 * fh[4] - 56 * fh[5] +
                            28 * fh[6] - 8 * fh[7] +
                            1 * fh[8] ) / ( power(h,8) );
                }
            }

            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                requires ( Order > 0 && Order < 9 )
            ArgType derv_9pt_stc_centered(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[]
                    {
                        (xx = x - 4 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x - 3 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x - 2 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x - 1 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x       ,  (ArgType)std::apply(f, args)), // 4
                        (xx = x + 1 * h, (ArgType)std::apply(f, args)), // 5
                        (xx = x + 2 * h, (ArgType)std::apply(f, args)), // 6
                        (xx = x + 3 * h, (ArgType)std::apply(f, args)), // 7
                        (xx = x + 4 * h, (ArgType)std::apply(f, args))  // 8
                    };
                    
                if constexpr(Order == 1)
                {
                    return (3*fh[0] - 32*fh[1] + 168*fh[2] - 672*fh[3] + 672*fh[5] - 168*fh[6] + 32*fh[7] - 3*fh[8])/(840*h);
                }
                else if constexpr(Order == 2)
                {
                    return (-9*fh[0]+128*fh[1]-1008*fh[2]+8064*fh[3]-14350*fh[4]+8064*fh[5]-1008*fh[6]+128*fh[7]-9*fh[8])/(5040*h*h);
                }
                else if constexpr(Order == 3)
                {
                    return (-7*fh[0] + 72*fh[1] - 338*fh[2] + 488*fh[3] - 488*fh[5] + 338*fh[6] - 72*fh[7] + 7*fh[8])/(240*power(h, 3));
                }
                else if constexpr(Order == 4)
                {
                    return (7*fh[0]-96*fh[1]+676*fh[2]-1952*fh[3]+2730*fh[4]-1952*fh[5]+676*fh[6]-96*fh[7]+7*fh[8])/(240*power(h, 4));
                }
                else if constexpr(Order == 5)
                {
                    return (fh[0] - 9*fh[1] + 26*fh[2] - 29*fh[3] + 29*fh[5] - 26*fh[6] + 9*fh[7] - fh[8])/(6*power(h, 5));
                }
                else if constexpr(Order == 6)
                {
                    return (fh[0]+12*fh[1]-52*fh[2]+116*fh[3]-150*fh[4]+116*fh[5]-52*fh[6]+12*fh[7]-1*fh[8])/(4*power(h, 6));
                }
                else if constexpr(Order == 7)
                {
                    return (-fh[0] + 6*fh[1] - 14*fh[2] + 14*fh[3] - 14*fh[5] + 14*fh[6] - 6*fh[7] + fh[8])/(2*power(h, 7));
                }
                else if constexpr(Order == 8)
                {
                    return (fh[0] - 8*fh[1] + 28*fh[2] - 56*fh[3] + 70*fh[4] - 56*fh[5] + 28*fh[6] - 8*fh[7] + fh[8])/power(h, 8);
                }
            }
        
            template<auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
                 requires ( Order > 0 && Order < 9 )
            ArgType derv_9pt_stc_forward(FuncType&& f, DxType dx, std::array<ArgType, N> args) noexcept
            {
                using namespace gmp::operators;
                using gmp::operators::operator*;
                using gmp::operators::operator+;
                using gmp::operators::operator-;
                using gmp::operators::operator/;

                auto x = args[VarID]; 
                auto& xx = args[VarID];

                using ele_t = real_type_t<DxType, ArgType>;

                ele_t h = dx;

                ArgType fh[]
                    {   
                        (xx = x + 0 * h, (ArgType)std::apply(f, args)), // 0
                        (xx = x + 1 * h, (ArgType)std::apply(f, args)), // 1
                        (xx = x + 2 * h, (ArgType)std::apply(f, args)), // 2
                        (xx = x + 3 * h, (ArgType)std::apply(f, args)), // 3
                        (xx = x + 4 * h, (ArgType)std::apply(f, args)), // 4
                        (xx = x + 5 * h, (ArgType)std::apply(f, args)), // 5
                        (xx = x + 6 * h, (ArgType)std::apply(f, args)), // 6
                        (xx = x + 7 * h, (ArgType)std::apply(f, args)), // 7
                        (xx = x + 8 * h, (ArgType)std::apply(f, args))  // 8
                    };

                /* ---------- 9-pt RIGHT (forward) stencil ---------- */
                if constexpr (Order == 1)
                {
                    return ( 105 * fh[0]   - 960 * fh[1] +
                             3920 * fh[2]  - 9408 * fh[3] +
                             14700 * fh[4] - 15680 * fh[5] +
                             11760 * fh[6] - 6720 * fh[7] +
                             2283 * fh[8] ) / ( 840 * h );
                }
                else if constexpr (Order == 2)
                {
                    return ( 3267 * fh[0]   - 29664 * fh[1] +
                             120008 * fh[2] - 284256 * fh[3] +
                             435330 * fh[4] - 448672 * fh[5] +
                             312984 * fh[6] - 138528 * fh[7] +
                             29531 * fh[8] ) / ( 5040 * power(h,2) );
                }
                else if constexpr (Order == 3)
                {
                    return ( 469 * fh[0]   - 4216 * fh[1] +
                             16830 * fh[2] - 39128 * fh[3] +
                             58280 * fh[4] - 57384 * fh[5] +
                             36706 * fh[6] - 13960 * fh[7] +
                             2403 * fh[8] ) / ( 240 * power(h,3) );
                }
                else if constexpr (Order == 4)
                {
                    return ( 967 * fh[0]    - 8576 * fh[1] +
                             33636 * fh[2]  - 76352 * fh[3] +
                             109930 * fh[4] - 102912 * fh[5] +
                             61156 * fh[6]  - 21056 * fh[7] +
                             3207 * fh[8] ) / ( 240 * power(h,4) );
                }
                else if constexpr (Order == 5)
                {
                    return ( 35 * fh[0]   - 305 * fh[1] +
                             1170 * fh[2] - 2581 * fh[3] +
                             3580 * fh[4] - 3195 * fh[5] +
                             1790 * fh[6] - 575 * fh[7] +
                             81 * fh[8] ) / ( 6 * power(h,5) );
                }
                else if constexpr (Order == 6)
                {
                    return ( 23 * fh[0]   - 196 * fh[1] +
                             732 * fh[2]  - 1564 * fh[3] +
                             2090 * fh[4] - 1788 * fh[5] +
                             956 * fh[6]  - 292 * fh[7] +
                             39 * fh[8] ) / ( 4 * power(h,6) );
                }
                else if constexpr (Order == 7)
                {
                    return ( 7 * fh[0]  - 58 * fh[1] +
                             210 * fh[2] - 434 * fh[3] +
                             560 * fh[4] - 462 * fh[5] +
                             238 * fh[6] - 70 * fh[7] +
                             9 * fh[8] ) / (   2 * power(h,7) );
                }
                else if constexpr (Order == 8)
                {
                    return ( 1 * fh[0]  - 8 * fh[1] +
                             28 * fh[2] - 56 * fh[3] +
                             70 * fh[4] - 56 * fh[5] +
                             28 * fh[6] - 8 * fh[7] +
                             1 * fh[8] ) / ( power(h,8) );
                }
            }

            template<DrvStencil stencil, DrvPivot pivot, auto VarID, auto Order, typename DxType, 
                typename ArgType, std::size_t N, typename FuncType>
            ArgType derivative_stencil(FuncType&& f, DxType dx,
                        const std::array<ArgType, N>& args) noexcept
            {
                if constexpr     (stencil == DrvStencil::three_point && pivot == DrvPivot::backward)
                    return hidden::derv_3pt_stc_backward<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::three_point && pivot == DrvPivot::centered)
                    return hidden::derv_3pt_stc_centered<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::three_point && pivot == DrvPivot::forward)
                    return hidden::derv_3pt_stc_forward<VarID, Order>(f, dx, args);
                    
                else if constexpr(stencil == DrvStencil::five_point && pivot == DrvPivot::backward)
                    return hidden::derv_5pt_stc_backward<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::five_point && pivot == DrvPivot::centered)
                    return hidden::derv_5pt_stc_centered<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::five_point && pivot == DrvPivot::forward)
                    return hidden::derv_5pt_stc_forward<VarID, Order>(f, dx, args);

                else if constexpr(stencil == DrvStencil::seven_point && pivot == DrvPivot::backward)
                        return hidden::derv_7pt_stc_backward<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::seven_point && pivot == DrvPivot::centered)
                    return hidden::derv_7pt_stc_centered<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::seven_point && pivot == DrvPivot::forward)
                    return hidden::derv_7pt_stc_forward<VarID, Order>(f, dx, args);

                else if constexpr(stencil == DrvStencil::nine_point && pivot == DrvPivot::backward)
                    return hidden::derv_9pt_stc_backward<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::nine_point && pivot == DrvPivot::centered)
                    return hidden::derv_9pt_stc_centered<VarID, Order>(f, dx, args);
                else if constexpr(stencil == DrvStencil::nine_point && pivot == DrvPivot::forward)
                    return hidden::derv_9pt_stc_forward<VarID, Order>(f, dx, args);
            }
        }
        // end of namespace hidden
           
        /////////////////////////////////////////////////////////////////////

        /*    
            f(x, y, z): enum {_x, _y, _z}

            ∫ {x₁, x₂} f(x) dx
                    -> intg<_x>{x1, x2} * f(x)
            
            ∫ {x₁, x₂} ∫ {y₁, y₂} f(x, y) dy dx -> 
                    -> intg<_x>{x1, x2} * intg<_y>{x1, x2} * f(x, y)

            ∫ {x₁, x₂} ∫ {y₁, y₂} ∫ {z₁, z₂} f(x, y, z) dz dy dx -> 
                    -> intg<_x>{x1, x2} * intg<_y>{y1, y2} * intg<_z>{z1, z2} * f(x, y, z)

            ===================================================
            
            ∫ {x₁₁, x₁₂} f(x₁) dx
                    -> intg<_x>{x11, x12} * f(x1);
            
            ∫ {x₁₁, x₁₂} ∫ {x₂₁, x₂₂} f(x₁, x₂) dx₂ dx₁

                    -> intg<_x1>{x11, x12} * intg<_x2>{ x21, x22 } * f(x1, x2);

            ∫ {x₁₁, x₁₂} ∫ {x₂₁, x₂₂} ∫ {x₃₁, x₃₂} f(x₁, x₂, x₃) dx₃ dx₂ dx₁ 
            
                    -> intg<_x1>{x11, x12} * intg<_x2>{x21, x22} * intg<_x3>{x31, x32} * f(x1, x2, x3);

        ===================================================
            
            ∫ {x₁₁, x₁₂} f(x₁) dx
                    -> intg<_x>{x11, x12} * f(x1);
            
            ∫ {x₁₁, x₁₂} ∫ {x₂₁(x₁), x₂₂(x₁) } f(x₁, x₂) dx₂ dx₁

                    -> intg<_x1>{ x11, x12 } * 
                       intg<_x2>{ x21(x1), x22(x1) } * f(x1, x2);

            ∫ {x₁₁, x₁₂} ∫ {x₂₁(x₁), x₂₂(x₁)} ∫ {x₃₁(x₁, x₂), x₃₂(x₁, x₂)} f(x₁, x₂, x₃) dx₃ dx₂ dx₁ 
            
                    -> intg<_x1>{ x11, x12 } * 
                       intg<_x2>{ x21(x1), x22(x1) } * 
                       intg<_x3>{ x31(x1, x2), x32(x1, x2) } * f(x1, x2, x3);
        */

        // Legendre-Pn(x)
        namespace hidden
        {
            
            // Legendre-Pₙ(x) by the closed-form binomial expression
            auto Pn(unsigned n, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;

                if (n == 0) return T{1};
                if (n == 1) return x;

                T sum{0};
                const T two_pow_n = gmp::pow(T{2}, n);          // 2ⁿ  (gmp::pow_ui for mpz/mpf/mpfr)

                for (unsigned k = 0; k <= n / 2; ++k)
                {
                    const T   sign   = (k & 1) ? T{-1} : T{1};     // (–1)ᵏ
                    const auto c1    = gmp::binomial(n, k);        // C(n, k)
                    const auto c2    = gmp::binomial(2 * n - 2 * k, n);   // C(2n–2k, n)
                    const T   coeff  = sign * T(c1 * c2) / two_pow_n;

                    sum += coeff * gmp::pow(x, n - 2 * k);      // xⁿ⁻²ᵏ
                }

                return sum;
            }

            // derivative  Pₙ′(x)  via term-wise differentiation of the closed-form series
            auto dPn(unsigned n, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;
                if (n == 0) return T{0};          // P₀′(x) = 0
                if (n == 1) return T{1};          // P₁(x)=x  ⇒  P₁′(x)=1

                T sum{0};
                const T two_pow_n = gmp::pow(T{2}, n);   // 2ⁿ

                for (unsigned k = 0; k <= n / 2; ++k)
                {
                    const unsigned pow = n - 2 * k;         // exponent before differentiation
                    if (pow == 0) continue;                 // term vanishes after differentiation

                    const T sign  = (k & 1) ? T{-1} : T{1};     // (–1)ᵏ
                    const auto c1 = gmp::binomial(n, k);        // C(n, k)
                    const auto c2 = gmp::binomial(2 * n - 2 * k, n); // C(2n−2k, n)

                    const T coeff = sign * T(c1 * c2) * T(pow) / two_pow_n; // (n−2k)⋯/2ⁿ
                    sum += coeff * gmp::pow(x, pow - 1);   // xⁿ⁻²ᵏ⁻¹
                }

                return sum;
            }

            /*
                Xₙ₊₁ = Xₙ - Pn(x) / Pn'(x), Newton Method 이용 Pn(x) = 0, x 값을 찾기 위해서
                
                Xₙ₊₁ -= Pn(x) / Pn'(x)
            */

            // ---------- Newton correction  Δ = Pₙ(x) / Pₙ′(x)  (Legendre) ---------
            // • single forward recurrence ⇒ no binomial-coefficient cost
            // • O(n) arithmetic, O(1) extra memory
            //
            // Usage:
            //     for (…) { x -= Pn_over_dPn(x,n); }
            //
            // ------------------------------------------------------------------------
            auto Pn_over_dPn(unsigned n, auto x)  // Pn(x) / Pn'(x)
            {
                using T = std::remove_cvref_t<decltype(x)>;

                if (n == 0) return T{0};        // P₀′ = 0  ⇒  no Newton step

                // P₀(x) = 1, P₁(x) = x
                T Pkm1 = T{1};                  // P_{k-1}
                T Pk   = x;                     // P_k

                for (unsigned k = 1; k < n; ++k)
                {
                    // P_{k+1}(x) = [(2k+1)x P_k − k P_{k-1}] / (k+1)
                    T Pk1 = ((T(2*k + 1) * x * Pk) - T(k) * Pkm1) / T(k + 1);
                    Pkm1 = Pk;
                    Pk   = Pk1;
                }

                const T&  Pn   = (n == 1) ? x : Pk;   // Pₙ(x)
                const T&  Pn_1 = (n == 1) ? T{1} : Pkm1; // Pₙ₋₁(x)

                // Identity:  Pₙ′(x) = n/(1−x²) · (Pₙ₋₁(x) − x Pₙ(x))
                // ⇒  Δ = Pₙ / Pₙ′ = (1−x²) Pₙ / [ n (Pₙ₋₁ − x Pₙ) ]
                return (T{1} - x * x) * Pn / (T(n) * (Pn_1 - x * Pn));
            }

            auto compute_weight_Pn(unsigned n, auto xk)
            {
                using T = std::remove_cvref_t<decltype(xk)>;
                
                // Gauss–Legendre weight formula:
                // w_k = 2 / [ (1 − x_k²) · (P_n′(x_k))² ]

                const T dPn_xk = dPn(n, xk);
                const T one_minus_xk2 = T{1} - xk * xk;

                return T{2} / (one_minus_xk2 * dPn_xk * dPn_xk);
            }

                // 004- Legendre Polynomial and Gaussian Quadrature, Numerical Integration 1
                // https://www.youtube.com/watch?v=IQ-GURoM6j8&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt&index=2

            auto compute_node_Pn(unsigned n, auto x) 
            {
                using ArgType = std::remove_cvref_t<decltype(x)>;
                using T = real_type_t<ArgType, float>;

#if GMP_CACHE_TOLERANCE == TRUE
                static 
#endif          
                const T tolerance = []
                    {
                        if constexpr(std::same_as<T, gmp::real_quadruple_t>)
                        {
                            auto tlr = T::constant_epsilon() * 1e6;                  
                            return tlr;
                        }
                        else if constexpr(std::same_as<T, gmp::real_octuple_t>)
                        {
                            auto tlr = T::constant_epsilon() * 1e10;
                            
                            return tlr;
                        }
                        else if constexpr(std::same_as<T, gmp::real_huge_t>)
                        {
                            auto tlr = T::constant_epsilon() * 1e20;
                            
                            return tlr;
                        }
                        else if constexpr(std::same_as<T, gmp::real_super_huge_t>)
                        {
                            auto tlr = T::constant_epsilon() * 1e20;
                            
                            return tlr;
                        }
                        else if constexpr(std::same_as<T, gmp::real_extreme_t>)
                        {
                            auto tlr = T::constant_epsilon() * 1e30;
                            
                            return tlr;
                        }
                    }();

                unsigned count = 0;
             
                while ( gmp::abs( Pn(n, x) ) > tolerance && count < 20 )
                {
                    x -= Pn_over_dPn(n, x); ++count;
                }

                if(count >= 20 )
                std::cout <<"cout = " << count << std::endl;
               
                return x;
            };
          
            ////////////////////////////////////////////////////

            // PairType = std::pair<ArgType, ArgType>
            // returns container< std::pair< weight, node > >
            template<int N, typename ArgType, typename PairType = std::pair<ArgType, ArgType>>
            auto get_gauss_legendre_weights_nodes() noexcept
            {
                if constexpr(std::floating_point<ArgType>)
                {
                    return gauss_legendre_weights_nodes<N, ArgType>();
                }
                else 
                {
                    auto wn = gauss_legendre_weights_nodes<N, real_super_huge_t>();
                    
                    std::vector<PairType> weights_nodes;
                    weights_nodes.reserve(N);

                    for(int k = 0; k < N; ++k)
                    {
                        auto [xk, wk] = wn[k];

                        auto x = compute_node_Pn(N, ArgType{ xk } );

                        weights_nodes.emplace_back(x, compute_weight_Pn(N, x));
                    }
                    return weights_nodes;
                }
            }
           
            ///////////////////////////////////////////////////////////////////////////////////////

            template<std::size_t WeightCount, typename FuncType, typename ArgType>
            ArgType gaussian_legendre_quadrature(FuncType&& f, std::array<ArgType, 2> range)
            {

#if GMP_CACHE_WEIGHTS_AND_NODES==TRUE
                static 
#endif
                const auto weights_nodes = 
                    gauss_legendre_weights_nodes<(int)WeightCount, ArgType>();
                
                auto [x1, x2] = range;

                auto a = (x2 - x1) / 2;
                auto b = (x2 + x1) / 2;

                ArgType I{};
               
                for(auto& [t, w]: weights_nodes)
                {
                    auto x = a * t + b;
                    
                    I += w * f(x);
                }

                I *= a; return I;
            }
             
            ////////////////////////////////////////////////////////////////////////////////

            template<std::size_t WeightCount, auto Tolerance,
                    auto MaxItr, typename FuncType, typename ArgType>
            ArgType adaptive_gaussian_quadrature(FuncType&& f,
                std::array<ArgType, 2> range, ArgType prev = {}, int level = 1)
            {

#if GMP_CACHE_TOLERANCE==TRUE
                static
#endif          
                const auto tolerance = gmp::abs( (ArgType)Tolerance );

                auto& [a, b] = range;

                auto c = ( a + b ) / 2; // the center point between [a, b]

                auto s1 = (prev == ArgType{}) ? 
                    gaussian_legendre_quadrature<WeightCount>(f, std::array{a, b}) : prev;

                auto left_sub_range  = 
                    gaussian_legendre_quadrature<WeightCount>(f, std::array{a, c} ); // [a, c]
                
                auto right_sub_range =
                    gaussian_legendre_quadrature<WeightCount>(f, std::array{c, b} ); // [c, b]

                // [a, b] = [a, c] + [c, b]
                auto s2 = left_sub_range + right_sub_range;
                auto diff = gmp::abs(s1 - s2);

                if(level >= MaxItr || diff <= tolerance)
                    return s2;
                else
                    return adaptive_gaussian_quadrature<WeightCount, Tolerance, MaxItr>
                                            (f, std::array{a, c}, left_sub_range,  level + 1) 
                         + adaptive_gaussian_quadrature<WeightCount, Tolerance, MaxItr>
                                            (f, std::array{c, b}, right_sub_range, level + 1);                 
            }
           
            template<QdrKind qdrknd, std::size_t WeightCount, auto Tolerance,
                auto MaxItr, typename FuncType, typename BndType>
            auto gaussian_quadrature(FuncType&& f, std::array<BndType, 2> range)
            {
                if constexpr(qdrknd == QdrKind::qdr_legendre)
                {
                    if constexpr(Tolerance == (decltype(Tolerance))0)
                    {
                        return gaussian_legendre_quadrature<WeightCount>
                            ( std::forward<FuncType>(f), range);
                    }
                    else 
                    {
                        return adaptive_gaussian_quadrature<WeightCount, Tolerance, MaxItr>
                            ( std::forward<FuncType>(f), range );
                    }
                }
                else
                {
                    static_assert(qdrknd == QdrKind::qdr_legendre, "Not yet programmed");
                }
            }

            //////////////////////////////////////////////////////////////////////////////////

            template<int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance, auto MaxItr,
                intg_bound_c LbType, intg_bound_c UbType, non_pointer_c... ArgTypes>
            auto evaluate_bound(const IntCmd<VarID, Qdrknd, Nodes, Tolerance, MaxItr, LbType, UbType>& cmd,
                    ArgTypes&&... args)
            {
                using BoundType = std::common_type_t< std::remove_cvref_t<ArgTypes>... >;

                auto lbound = [lf = cmd.lbound, params = std::array{ args...}]
                {
                    return evaluate<CastRtnType::ifpsble, BoundType>(lf, params);
                }();
                
                auto ubound = [uf = cmd.ubound, params = std::array{ args... }] 
                {
                    return evaluate<CastRtnType::ifpsble, BoundType>(uf, params);
                }();

                return std::array<BoundType, 2>{lbound, ubound};
            }

            template<int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance, auto MaxItr,
                intg_bound_c LbType, intg_bound_c UbType, std_array_tuple_c ArgType>
            auto evaluate_bound(const IntCmd<VarID, Qdrknd, Nodes, Tolerance, MaxItr, 
                        LbType, UbType>& cmd, ArgType args)
            {
                using BoundType = element_type_t<ArgType>;

                auto lbound = [lf = cmd.lbound, &args] -> BoundType
                    {
                        if constexpr(number_c<LbType>)
                            return (BoundType)lf;
                        else
                        {
                            return [&]<typename T, T ...n>(std::integer_sequence<T, n...>)
                            {
                                return (BoundType)lf( std::get<n>(args) ... );

                            }( std::make_integer_sequence<int, parameter_count_v<LbType, BoundType>>{});
                       }
                    }();
                    
                    auto ubound = [uf = cmd.ubound, args] -> BoundType
                    {
                        if constexpr(number_c<UbType>)
                            return (BoundType)uf;
                        else 
                        {
                            return [&]<typename T, T ...n>(std::integer_sequence<T, n...>)
                            {
                                return (BoundType)uf( std::get<n>(args) ... );

                            }( std::make_integer_sequence<int, parameter_count_v<UbType, BoundType>>{});
                        }
                    }();

                return std::array<BoundType, 2>{lbound, ubound};
            }
              
            /////////////////////////// DO NOT DELETE/////////////////////////////////////////////
            /////////////////////////// DO NOT DELETE/////////////////////////////////////////////
            /////////////////////////// DO NOT DELETE/////////////////////////////////////////////
            //
            // template<int VarID, QdrKind Qdrknd, int Nodes, int Splits, bound_type_c BndType, typename FuncType>
            // auto compute_integral(IntCmd<VarID, Qdrknd, Nodes, Splits, BndType, BndType> cmd, FuncType&& f)
            // {
            //     if constexpr(Splits == 1)
            //     {
            //         auto [lbound, ubound] = cmd;

            //         return gaussian_quadrature<VarID, Qdrknd, Nodes>(f, std::array{lbound, ubound});
            //     }
            //     else
            //     {
            //         auto [lbound, ubound] = cmd;
            //         BndType L = ubound - lbound;
            //         BndType dx = L / Splits;

            //         std::vector<BndType> cumulative_weights(Splits);
            //         BndType sum_weights{};

            //         for (int k = 0; k < Splits; ++k)
            //         {
            //             auto x0 = lbound + dx * k;
            //             auto x1 = lbound + dx * (k + 1);
            //             auto fx0 = f(x0);
            //             auto fx1 = f(x1);

            //             auto weight = gmp::abs((x1 - x0) / (fx1 - fx0));
            //             sum_weights += weight;
            //             cumulative_weights[k] = sum_weights;
            //         }

            //         std::vector<BndType> x_values(Splits + 1);
            //         x_values[0] = lbound;

            //         for (int k = 1; k <= Splits; ++k)
            //             x_values[k] = lbound + L * cumulative_weights[k - 1] / sum_weights;

            //         using intg_type = IntCmd<VarID, Qdrknd, Nodes, Splits, BndType, BndType>;
                    
            //         tbb::combinable<BndType> local_sum;
                    
            //         tbb::parallel_for(0, Splits, [&](int k) 
            //         {
            //             auto itv = std::array{ x_values[k], x_values[k + 1] };

            //             local_sum.local() += gaussian_quadrature<VarID, Qdrknd, Nodes>
            //                                 ( f, std::array{x_values[k], x_values[k + 1]} );
            //         });

            //         return local_sum.combine(std::plus<>());
            //     }
            // }
            
            
            //
            // ∫ {x₁, x₂} f(x) dx
            //                  -> iax<_x>(x1, x2) | f ;
            //                  -> f | iax<_x>(x1, x2) ;
            template<int pCount, int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance,
                auto MaxItr, bound_type_c BndType, typename FuncType>
            auto bind_integral(std::tuple< IntCmd<VarID, Qdrknd, Nodes, Tolerance,
                    MaxItr, BndType, BndType> > cmds, FuncType&& f)
            {
                if constexpr( pCount == 0 ) // function f is constant
                {
                    auto [lbound, ubound] = std::get<0>(cmds);
                    return f * (ubound - lbound);
                }
                else
                {
                    auto [lbound, ubound] = std::get<0>(cmds);
                    return gaussian_quadrature<Qdrknd, Nodes, Tolerance, MaxItr>(f, std::array{lbound, ubound});
                }
            }
            
            //
            // ∫ {x₁, x₂} ∫ {y₁, y₂} f(x, y) dy dx
            //          -> iax<_x>(x1, x2) * iax<_y>(y1, y2) | f ;
            //          -> f | iax<_y>(y1, y2) * iax<_x>(x1, x2) ;
            template<int pCount, int VarID0, QdrKind Qdrknd0, int Nodes0, auto Tolerance0, auto MaxItr0, bound_type_c BndType, 
                                 int VarID1, QdrKind Qdrknd1, int Nodes1, auto Tolerance1, auto MaxItr1, intg_bound_c LbType1, intg_bound_c UbType1, typename FuncType>
            auto bind_integral(std::tuple< IntCmd<VarID0, Qdrknd0, Nodes0, Tolerance0, MaxItr0, BndType, BndType>,
                                           IntCmd<VarID1, Qdrknd1, Nodes1, Tolerance1, MaxItr1, LbType1, UbType1>> cmds, FuncType&& f)
            {
                std::array<BndType, 2> args{ };

                auto ff = [&](BndType v)
                {
                    args[VarID0] = v;

                    auto ff =[&](BndType v)
                    {    
                        args[VarID1] = v;

                        return evaluate(f, args);
                    };

                    auto [lbound, ubound] = evaluate_bound( std::get<1>(cmds), args[VarID0] );

                    return gaussian_quadrature<Qdrknd1, Nodes1, Tolerance1, MaxItr1>(ff, std::array{lbound, ubound} );
                };

                auto [ lbound, ubound ] = std::get<0>(cmds);

                return gaussian_quadrature<Qdrknd0, Nodes0, Tolerance0, MaxItr0>(ff, std::array{ lbound, ubound } );
            }
            
            //
            // ∫ {x₁, x₂} ∫ {y₁, y₂} ∫ {z₁, z₂} f(x, y, z) dz dy dx 
            //      -> iax<_x>(x1, x2) * iax<_y>(y1, y2) * iax<_z>(z1, z2) | f
            //      -> f | iax<_z>(z1, z2) * iax<_y>(y1, y2) * iax<_x>(x1, x2) ;
            template<int pCount, int VarID0, QdrKind Qdrknd0, int Nodes0, auto Tolerance0, auto MaxItr0, bound_type_c BndType, 
                     int VarID1, QdrKind Qdrknd1, int Nodes1, auto Tolerance1, auto MaxItr1, intg_bound_c LbType1, intg_bound_c UbType1,
                     int VarID2, QdrKind Qdrknd2, int Nodes2, auto Tolerance2, auto MaxItr2, intg_bound_c LbType2, intg_bound_c UbType2,
                     typename FuncType>
            auto bind_integral(std::tuple< IntCmd<VarID0, Qdrknd0, Nodes0, Tolerance0, MaxItr0, BndType, BndType>,
                                           IntCmd<VarID1, Qdrknd1, Nodes1, Tolerance1, MaxItr1, LbType1, UbType1>,
                                           IntCmd<VarID2, Qdrknd2, Nodes2, Tolerance2, MaxItr2, LbType2, UbType2>> cmds, FuncType&& f)
            {       
                std::array<BndType, 3> args{};

                auto ff = [&](BndType v)
                {
                    args[VarID0] = v;

                    auto ff = [&](BndType v)
                    {
                        args[VarID1] = v;

                        auto ff = [&](BndType v)
                        {
                            args[VarID2] = v;

                            return evaluate(f, args);
                        };

                        auto bound = evaluate_bound(std::get<2>(cmds), args[VarID0], args[VarID1] );
   
                        return gaussian_quadrature<Qdrknd2, Nodes2, Tolerance2, MaxItr2>(ff, bound);
                    };

                    auto bound = evaluate_bound(std::get<1>(cmds), args[VarID0]);
   
                    return gaussian_quadrature<Qdrknd1, Nodes1, Tolerance1, MaxItr1>(ff, bound );
                };

                auto [lbound, ubound] = std::get<0>(cmds);
   
                return gaussian_quadrature<Qdrknd0, Nodes0, Tolerance0, MaxItr0>(ff, std::array{lbound, ubound} );
            }

            
            template<int pCount, int VarID0, QdrKind Qdrknd0, int Nodes0, auto Tolerance0, auto MaxItr0, bound_type_c BndType, 
                     int VarID1, QdrKind Qdrknd1, int Nodes1, auto Tolerance1, auto MaxItr1, intg_bound_c LbType1, intg_bound_c UbType1,
                     int VarID2, QdrKind Qdrknd2, int Nodes2, auto Tolerance2, auto MaxItr2, intg_bound_c LbType2, intg_bound_c UbType2,
                     int VarID3, QdrKind Qdrknd3, int Nodes3, auto Tolerance3, auto MaxItr3, intg_bound_c LbType3, intg_bound_c UbType3,
                     typename FuncType>
            auto bind_integral(std::tuple< IntCmd<VarID0, Qdrknd0, Nodes0, Tolerance0, MaxItr0, BndType, BndType>,
                                           IntCmd<VarID1, Qdrknd1, Nodes1, Tolerance1, MaxItr1, LbType1, UbType1>,
                                           IntCmd<VarID2, Qdrknd2, Nodes2, Tolerance2, MaxItr2, LbType2, UbType2>,
                                           IntCmd<VarID3, Qdrknd3, Nodes3, Tolerance3, MaxItr3, LbType3, UbType3>> cmds, FuncType&& f)
            {       
                std::array<BndType, 4> args{};

                auto ff = [&](BndType v)
                {
                    args[VarID0] = v;

                    auto ff = [&](BndType v)
                    {
                        args[VarID1] = v;

                        auto ff = [&](BndType v)
                        {
                            args[VarID2] = v;

                            auto ff = [&](BndType v)
                            {
                                args[VarID3] = v;

                                return evaluate(f, args);
                            };

                            auto bound = evaluate_bound(std::get<3>(cmds), args[VarID0], args[VarID1], args[VarID2]);
   
                            return gaussian_quadrature<Qdrknd3, Nodes3, Tolerance3, MaxItr3>(ff, bound);
                        };

                        auto bound = evaluate_bound(std::get<2>(cmds), args[VarID0], args[VarID1] );
   
                        return gaussian_quadrature<Qdrknd2, Nodes2, Tolerance2, MaxItr2>(ff, bound);
                    };

                    auto bound = evaluate_bound(std::get<1>(cmds), args[VarID0]);
   
                    return gaussian_quadrature<Qdrknd1, Nodes1, Tolerance1, MaxItr1>(ff, bound);
                };

                auto [lbound, ubound] = std::get<0>(cmds);
   
                return gaussian_quadrature<Qdrknd0, Nodes0, Tolerance0, MaxItr0>(ff, std::array{lbound, ubound} );
            }


            template<int pCount, int VarID0, QdrKind Qdrknd0, int Nodes0, auto Tolerance0, auto MaxItr0, bound_type_c BndType, 
                     int VarID1, QdrKind Qdrknd1, int Nodes1, auto Tolerance1, auto MaxItr1, intg_bound_c LbType1, intg_bound_c UbType1,
                     int VarID2, QdrKind Qdrknd2, int Nodes2, auto Tolerance2, auto MaxItr2, intg_bound_c LbType2, intg_bound_c UbType2,
                     int VarID3, QdrKind Qdrknd3, int Nodes3, auto Tolerance3, auto MaxItr3, intg_bound_c LbType3, intg_bound_c UbType3,
                     int VarID4, QdrKind Qdrknd4, int Nodes4, auto Tolerance4, auto MaxItr4, intg_bound_c LbType4, intg_bound_c UbType4,
                     typename FuncType>
            auto bind_integral(std::tuple< IntCmd<VarID0, Qdrknd0, Nodes0, Tolerance0, MaxItr0, BndType, BndType>,
                                           IntCmd<VarID1, Qdrknd1, Nodes1, Tolerance1, MaxItr1, LbType1, UbType1>,
                                           IntCmd<VarID2, Qdrknd2, Nodes2, Tolerance2, MaxItr2, LbType2, UbType2>,
                                           IntCmd<VarID3, Qdrknd3, Nodes3, Tolerance3, MaxItr3, LbType3, UbType3>,
                                           IntCmd<VarID4, Qdrknd4, Nodes4, Tolerance4, MaxItr4, LbType4, UbType4>> cmds, FuncType&& f)
            {       
                std::array<BndType, 4> args{};

                auto ff = [&](BndType v)
                {
                    args[VarID0] = v;

                    auto ff = [&](BndType v)
                    {
                        args[VarID1] = v;

                        auto ff = [&](BndType v)
                        {
                            args[VarID2] = v;

                            auto ff = [&](BndType v)
                            { 
                                args[VarID3] = v;

                                auto ff = [&](BndType v)
                                {
                                    args[VarID4] = v;
                                    return evaluate(f, args);
                                };

                                auto bound = evaluate_bound(std::get<4>(cmds), args[VarID0], args[VarID1], args[VarID2], args[VarID3]);
   
                                return gaussian_quadrature<Qdrknd4, Nodes4, Tolerance4, MaxItr4>(ff, bound);

                            };

                            auto bound = evaluate_bound(std::get<3>(cmds), args[VarID0], args[VarID1], args[VarID2]);
   
                            return gaussian_quadrature<Qdrknd3, Nodes3, Tolerance3, MaxItr3>(ff, bound);
                        };

                        auto bound = evaluate_bound(std::get<2>(cmds), args[VarID0], args[VarID1] );
   
                        return gaussian_quadrature<Qdrknd2, Nodes2, Tolerance2, MaxItr2>(ff, bound);
                    };

                    auto bound = evaluate_bound(std::get<1>(cmds), args[VarID0]);
   
                    return gaussian_quadrature<Qdrknd1, Nodes1, Tolerance1, MaxItr1>(ff, bound);
                };

                auto [lbound, ubound] = std::get<0>(cmds);
   
                return gaussian_quadrature<Qdrknd0, Nodes0, Tolerance0, MaxItr0>(ff, std::array{lbound, ubound} );
            }
            
        }
        // end of namespace hidden

        // Laguerre-Ln(x)
        namespace hidden
        {
            auto Lna(unsigned n, unsigned alpha, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;

                if (n == 0) return T{1};

                T sum{0};

                for (unsigned k = 0; k <= n; ++k)
                {
                    const T sign     = (k & 1) ? T{-1} : T{1};                                // (–1)ᵏ
                    const auto binom = gmp::binomial(n + alpha, n - k);                      // C(n + α, n − k)
                    const auto fact  = gmp::tgamma(k+1);                                    // k!
                    const T coeff    = sign * T(binom) / T(fact);                            // (–1)ᵏ · C(n + α, n − k) / k!

                    sum += coeff * gmp::pow(x, k);                                           // xᵏ
                }

                return sum;
            }

            auto dLna(unsigned n, unsigned alpha, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;

                if (n == 0) return T{0}; // dL₀^{(α)} = 0

                return -Lna(n - 1, alpha + 1, x);
            }

            auto Lna_over_dLna(unsigned n, unsigned alpha, auto x)
            {
                return Lna(n, alpha, x) / dLna(n, alpha, x);
            }

            auto Lna_over_dLna_r(unsigned n, unsigned alpha, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;

                if (n == 0) return std::numeric_limits<T>::infinity();

                T Ln = T{0};
                T Lnm1 = T{0};

                for (unsigned k = 0; k <= n; ++k)
                {
                    const T sign = (k & 1) ? T{-1} : T{1};
                    const T xk = gmp::pow(x, k);
                    const T fact = gmp::tgamma(k + 1);

                    const auto binom_Ln    = gmp::binomial(n + alpha, n - k);
                    const auto binom_Lnm1  = (k <= n - 1) ? gmp::binomial(n + alpha, n - 1 - k) : intnum{0};

                    Ln   += sign * T(binom_Ln)   * xk / fact;
                    Lnm1 += sign * T(binom_Lnm1) * xk / fact;
                }

                return -Ln / Lnm1;
            }

            auto compute_node_Lna(unsigned n, unsigned alpha, auto x)
            {
                using ArgType = std::remove_cvref_t<decltype(x)>;
                using T = real_type_t<ArgType, float>;

            #if GMP_CACHE_TOLERANCE == TRUE
                static
            #endif
                const T tolerance = []
                {
                    if constexpr(std::same_as<T, gmp::real_quadruple_t>)
                        return T::constant_epsilon() * 1e10;
                    else if constexpr(std::same_as<T, gmp::real_octuple_t>)
                        return T::constant_epsilon() * 1e10;
                    else if constexpr(std::same_as<T, gmp::real_huge_t>)
                        return T::constant_epsilon() * 1e20;
                    else if constexpr(std::same_as<T, gmp::real_super_huge_t>)
                        return T::constant_epsilon() * 1e20;
                    else if constexpr(std::same_as<T, gmp::real_extreme_t>)
                        return T::constant_epsilon() * 1e300 * 1e300 * 1e300 *1e300 * 1e300 * 1e39;
                }();

                unsigned count = 0;

                unsigned max_count = 2000;

                while (gmp::abs(Lna(n, alpha, x)) > tolerance && count < max_count)
                {
                    // Newton step: Δ = Lna / dLna
                    x -= Lna_over_dLna_r(n, alpha, x);
                    
                    ++count;
                }

                if (count >= max_count)
                    std::cout << "count = " << count << std::endl;

                return x;
            }

            // Laguerre-Lₙ(x) using the closed-form binomial expression
            auto Ln(unsigned n, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;

                if (n == 0) return T{1};

                T sum{0};

                for (unsigned k = 0; k <= n; ++k)
                {
                    const T sign     = (k & 1) ? T{-1} : T{1};                    // (–1)ᵏ
                    const auto binom = gmp::binomial(n, k);                      // C(n, k)
                    const auto fact  = gmp::tgamma(k+1);                        // k!
                    const T coeff    = sign * T(binom) / T(fact);                // (–1)ᵏ · C(n, k) / k!

                    sum += coeff * gmp::pow(x, k);                               // xᵏ
                }

                return sum;
            }

            // derivative  Lₙ′(x) via term-wise differentiation of the closed-form series
            auto dLn(unsigned n, auto x)
            {
                using T = std::remove_cvref_t<decltype(x)>;
                if (n == 0) return T{0}; // L₀′(x) = 0

                T sum{0};

                for (unsigned k = 1; k <= n; ++k)
                {
                    const T sign     = (k & 1) ? T{-1} : T{1};             // (–1)ᵏ
                    const auto binom = gmp::binomial(n, k);                // C(n, k)
                    const auto fact  = gmp::tgamma(k);                     // (k−1)!
                    const T coeff    = sign * T(binom) / T(fact);          // (–1)ᵏ C(n,k)/(k−1)!

                    sum += coeff * gmp::pow(x, k - 1);                     // xᵏ⁻¹
                }

                return sum;
            }

           auto Ln_over_dLn(unsigned n, auto x)
            {
                return Ln(n, x) / dLn(n, x);
            }

            auto compute_weight_Ln(unsigned n, auto xk)
            {
                using T = std::remove_cvref_t<decltype(xk)>;

                const T dLn_xk = dLn(n, xk);  // Lₙ′(xₖ)

                return xk / (dLn_xk * dLn_xk);  // wₖ = xₖ / [Lₙ′(xₖ)]²
            }

            auto compute_node_Ln(unsigned n, auto x) 
            {
                using ArgType = std::remove_cvref_t<decltype(x)>;
                using T = real_type_t<ArgType, float>;

            #if GMP_CACHE_TOLERANCE == TRUE
                static
            #endif
                const T tolerance = []
                {
                    if constexpr(std::same_as<T, gmp::real_quadruple_t>)
                        return T::constant_epsilon() * 1e10;
                    else if constexpr(std::same_as<T, gmp::real_octuple_t>)
                        return T::constant_epsilon() * 1e60;
                    else if constexpr(std::same_as<T, gmp::real_huge_t>)
                        return T::constant_epsilon() * 1e100;
                    else if constexpr(std::same_as<T, gmp::real_super_huge_t>)
                        return T::constant_epsilon() * 1e120;
                    else if constexpr(std::same_as<T, gmp::real_extreme_t>)
                        return T::constant_epsilon() * 1e260;
                }();

                unsigned count = 0;

                while (gmp::abs(Ln(n, x)) > tolerance && count < 500)
                {
                    x -= Ln_over_dLn(n, x);  // Newton step: Δ = Ln / Ln′
                    ++count;
                }

                if (count >= 500)
                    std::cout << "count = " << count << std::endl;

                return x;
            }

            auto compute_weight_Lna(unsigned n, auto alpha, auto xk)
            {
                using T = std::remove_cvref_t<decltype(xk)>;

                const T Lna_next = Lna(n, alpha + 1, xk);  // Lₙ^{(α+1)}(xₖ)

                return gmp::pow(xk, alpha + 1) / (Lna_next * Lna_next);
            }

            // PairType = std::pair<ArgType, ArgType>
            // returns container< std::pair< weight, node > >
            template<int N, int Order = 0, typename ArgType, typename PairType = std::pair<ArgType, ArgType>>
            auto get_gauss_laguerre_weights_nodes() noexcept
            {
                auto wn =[]
                {
                    if constexpr(Order == 0)
                        return gauss_laguerre_weights_nodes_0<N, double>();
                    else if  constexpr(Order == 1)
                        return gauss_laguerre_weights_nodes_1<N, double>();
                    else if  constexpr(Order == 2)
                        return gauss_laguerre_weights_nodes_2<N, double>();
                    else if  constexpr(Order == 3)
                        return gauss_laguerre_weights_nodes_3<N, double>();
                    else if  constexpr(Order == 4)
                        return gauss_laguerre_weights_nodes_4<N, double>();
                    else if  constexpr(Order == 5)
                        return gauss_laguerre_weights_nodes_5<N, double>();
                    else if  constexpr(Order == 6)
                        return gauss_laguerre_weights_nodes_6<N, double>();
                    else if  constexpr(Order == 7)
                        return gauss_laguerre_weights_nodes_7<N, double>();
                    else if  constexpr(Order == 8)
                        return gauss_laguerre_weights_nodes_8<N, double>();
                    else if  constexpr(Order == 9)
                        return gauss_laguerre_weights_nodes_9<N, double>();
                    else if  constexpr(Order == 10)
                        return gauss_laguerre_weights_nodes_10<N, double>();
                    else if  constexpr(Order == 11)
                        return gauss_laguerre_weights_nodes_11<N, double>();
                    else if  constexpr(Order == 12)
                        return gauss_laguerre_weights_nodes_12<N, double>();
                    else if  constexpr(Order == 13)
                        return gauss_laguerre_weights_nodes_13<N, double>();
                    else if  constexpr(Order == 14)
                        return gauss_laguerre_weights_nodes_14<N, double>();
                    else if  constexpr(Order == 15)
                        return gauss_laguerre_weights_nodes_15<N, double>();
                    else if  constexpr(Order == 16)
                        return gauss_laguerre_weights_nodes_16<N, double>();
                    else if  constexpr(Order == 17)
                        return gauss_laguerre_weights_nodes_17<N, double>();
                    else if  constexpr(Order == 18)
                        return gauss_laguerre_weights_nodes_18<N, double>();
                    else if  constexpr(Order == 19)
                        return gauss_laguerre_weights_nodes_19<N, double>();
                    else if  constexpr(Order == 20)
                        return gauss_laguerre_weights_nodes_20<N, double>();
                    else if  constexpr(Order == 21)
                        return gauss_laguerre_weights_nodes_21<N, double>();
                    else if  constexpr(Order == 22)
                        return gauss_laguerre_weights_nodes_22<N, double>();
                    else if  constexpr(Order == 23)
                        return gauss_laguerre_weights_nodes_23<N, double>();
                    else if  constexpr(Order == 24)
                        return gauss_laguerre_weights_nodes_24<N, double>();
                    else if  constexpr(Order == 25)
                        return gauss_laguerre_weights_nodes_25<N, double>();
                    else if  constexpr(Order == 26)
                        return gauss_laguerre_weights_nodes_26<N, double>();
                    else if  constexpr(Order == 27)
                        return gauss_laguerre_weights_nodes_27<N, double>();
                    else if  constexpr(Order == 28)
                        return gauss_laguerre_weights_nodes_28<N, double>();
                    else if  constexpr(Order == 29)
                        return gauss_laguerre_weights_nodes_29<N, double>();
                    else if  constexpr(Order == 30)
                        return gauss_laguerre_weights_nodes_30<N, double>();
                    else if  constexpr(Order == 31)
                        return gauss_laguerre_weights_nodes_31<N, double>();
                    else if  constexpr(Order == 32)
                        return gauss_laguerre_weights_nodes_32<N, double>();
                    else if  constexpr(Order == 33)
                        return gauss_laguerre_weights_nodes_33<N, double>();
                    else if  constexpr(Order == 34)
                        return gauss_laguerre_weights_nodes_34<N, double>();
                    else if  constexpr(Order == 35)
                        return gauss_laguerre_weights_nodes_35<N, double>();
                    else if  constexpr(Order == 36)
                        return gauss_laguerre_weights_nodes_36<N, double>();
                    else if  constexpr(Order == 37)
                        return gauss_laguerre_weights_nodes_37<N, double>();
                    else if  constexpr(Order == 38)
                        return gauss_laguerre_weights_nodes_38<N, double>();
                    else if  constexpr(Order == 39)
                        return gauss_laguerre_weights_nodes_39<N, double>();
                    else if  constexpr(Order == 40)
                        return gauss_laguerre_weights_nodes_40<N, double>();
                    else if  constexpr(Order == 41)
                        return gauss_laguerre_weights_nodes_41<N, double>();
                    else if  constexpr(Order == 42)
                        return gauss_laguerre_weights_nodes_42<N, double>();
                    else if  constexpr(Order == 43)
                        return gauss_laguerre_weights_nodes_43<N, double>();
                    else if  constexpr(Order == 44)
                        return gauss_laguerre_weights_nodes_44<N, double>();
                    else if  constexpr(Order == 45)
                        return gauss_laguerre_weights_nodes_45<N, double>();
                    else if  constexpr(Order == 46)
                        return gauss_laguerre_weights_nodes_46<N, double>();
                    else if  constexpr(Order == 47)
                        return gauss_laguerre_weights_nodes_47<N, double>();
                    else if  constexpr(Order == 48)
                        return gauss_laguerre_weights_nodes_48<N, double>();
                    else if  constexpr(Order == 49)
                        return gauss_laguerre_weights_nodes_49<N, double>();
                    else if  constexpr(Order == 50)
                        return gauss_laguerre_weights_nodes_50<N, double>();
                    else if  constexpr(Order == 51)
                        return gauss_laguerre_weights_nodes_51<N, double>();
                    else if  constexpr(Order == 52)
                        return gauss_laguerre_weights_nodes_52<N, double>();
                    else if  constexpr(Order == 53)
                        return gauss_laguerre_weights_nodes_53<N, double>();
                    else if  constexpr(Order == 54)
                        return gauss_laguerre_weights_nodes_54<N, double>();
                    else if  constexpr(Order == 55)
                        return gauss_laguerre_weights_nodes_55<N, double>();
                    else if  constexpr(Order == 56)
                        return gauss_laguerre_weights_nodes_56<N, double>();
                    else if  constexpr(Order == 57)
                        return gauss_laguerre_weights_nodes_57<N, double>();
                    else if  constexpr(Order == 58)
                        return gauss_laguerre_weights_nodes_58<N, double>();
                    else if  constexpr(Order == 59)
                        return gauss_laguerre_weights_nodes_59<N, double>();
                    else if  constexpr(Order == 60)
                        return gauss_laguerre_weights_nodes_60<N, double>();
                    else if  constexpr(Order == 61)
                        return gauss_laguerre_weights_nodes_61<N, double>();
                    else if  constexpr(Order == 62)
                        return gauss_laguerre_weights_nodes_62<N, double>();
                    else if  constexpr(Order == 63)
                        return gauss_laguerre_weights_nodes_63<N, double>();
                    else if  constexpr(Order == 64)
                        return gauss_laguerre_weights_nodes_64<N, double>();
                }();
                
                std::vector<PairType> weights_nodes;
                weights_nodes.reserve(N);

                for(int k = 0; k < N; ++k)
                {
                    auto [xk, wk] = wn[k];

                    auto x = compute_node_Lna(N, Order, ArgType{ xk });

                    weights_nodes.emplace_back(x, compute_weight_Lna(N, Order, x));
                }
                return weights_nodes;
            }

            
        }
        // end of namespace hidden

        template<int VarID1, QdrKind Qdrknd1, int Nodes1, auto Tolerance1, auto MaxItr1, intg_bound_c LbType1, intg_bound_c UbType1,
                 int VarID2, QdrKind Qdrknd2, int Nodes2, auto Tolerance2, auto MaxItr2, intg_bound_c LbType2, intg_bound_c UbType2>
        auto operator* (IntCmd<VarID1, Qdrknd1, Nodes1, Tolerance1, MaxItr1, LbType1, UbType1> cmd1,
                        IntCmd<VarID2, Qdrknd2, Nodes2, Tolerance2, MaxItr2, LbType2, UbType2> cmd2)
        {
            return std::tuple{ std::move(cmd1), std::move(cmd2) };
        }

        template<intcmd_c... Cmds, int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance, auto MaxItr, intg_bound_c LbType, intg_bound_c UbType>
        auto operator* (std::tuple<Cmds...> cmds, IntCmd<VarID, Qdrknd, Nodes, Tolerance, MaxItr, LbType, UbType> cmd)
        {
            return std::tuple_cat(std::move(cmds), std::make_tuple(std::move(cmd)));
        }
       
        template<int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance, auto MaxItr, bound_type_c BndType,
            intcmd_c... Cmds, typename FuncType>
        auto operator | (std::tuple<IntCmd<VarID, Qdrknd, Nodes, Tolerance, MaxItr, BndType, BndType>, Cmds...> cmds, FuncType&& f)
        {
            return hidden::bind_integral<parameter_count_v<FuncType, BndType>>
                ( std::move(cmds), f);
        }

        template<int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance, auto MaxItr, bound_type_c BndType, typename FuncType>
        auto operator | (IntCmd<VarID, Qdrknd, Nodes, Tolerance, MaxItr, BndType, BndType> cmd, FuncType&& f)
        {
            return hidden::bind_integral<parameter_count_v<FuncType, BndType>>
                ( std::tuple{ std::move(cmd) }, f);
        }

        template<typename FuncType, intcmd_c Cmd, intcmd_c... Cmds>
        auto operator| (FuncType&& f, std::tuple<Cmd, Cmds...> cmds)
            requires(cmd_start_c<last_tuple_element_t<std::tuple<Cmd, Cmds...>>>)
        {
            return reverse_tuple(std::move(cmds)) | f;
        }

        template<typename FuncType, int VarID, QdrKind Qdrknd, int Nodes, auto Tolerance, auto MaxItr, bound_type_c BndType>
        auto operator | (FuncType&& f, IntCmd<VarID, Qdrknd, Nodes, Tolerance, MaxItr, BndType, BndType> cmd)
        {
            return  std::tuple{ std::move(cmd) } | f;
        }


    template<typename DegreeType>
    constexpr auto power_of_two(DegreeType degree)
    {
        unsigned long long n = 1;

        while((degree + 8) > n) n <<= 1;
        
        return n;
    }

    namespace hidden
    {
        std::size_t reverse_bits(int n, int log2n)
        {
            int result = 0;

            for(int i=0; i < log2n; ++i)
            {
                if( n & (1 << i) )
                    result |= (1 << (log2n - 1 - i));
            }

            return result;
        }

        template<complex_c CplxType, typename Allocator, 
        template<complex_c, typename> class Cntr>
        void shuffle_data(Cntr<CplxType, Allocator>& data)
        {
            int n = data.size();
            int log2n = std::log2(n);

            // bit reversal permutation
            for(int i = 0; i < n; ++i)
            {
                int j = reverse_bits(i, log2n);
                
                if(i < j) 
                {
                    if constexpr(cplxnum_c<CplxType>)
                        gmp::swap( data[i], data[j] );
                    else
                        std::swap( data[i], data[j] );
                }
            }
        }

        template<complex_c CplxType, typename Allocator, 
        template<complex_c, typename> class Cntr>
        void fft_impl(Cntr<CplxType, Allocator>& data, bool negative)
        {
            using real_t = typename CplxType::value_type;

            int N = data.size();
            int log2n = std::log2(N);

            auto pi = []
                {
                    if constexpr(cplxnum_c<CplxType>)
                        return real_t::constant_pi();
                    else
                        return std::numbers::pi_v<real_t>;
                }();
            
            shuffle_data(data);

            for(int len = 2; len <= N; len *= 2)
            {
                auto half_len = len / 2;
                              
                auto w = [negative, pi](auto k, auto len) -> CplxType
                    {
                        if constexpr(cplxnum_c<CplxType>)
                            return gmp::exp(CplxType{(real_t)0, (negative ? -2 * pi * k / len : 2 * pi * k / len) });
                        else
                            return std::exp(CplxType{(real_t)0, (negative ? -2 * pi * k / len : 2 * pi * k / len) });
                    };

                for(int i = 0; i < N; i += len )
                {
                    for(int j = 0; j < half_len; ++j)
                    {
                        auto lower_index = i + j;
                        auto upper_index = i + j + half_len;

                        auto left_even = data[lower_index];
                        auto right_odd = data[upper_index];
                        
                        data[lower_index] = left_even + w(j, len) * right_odd;
                        data[upper_index] = left_even - w(j, len) * right_odd;
                    }
                }
            }
        }
    }
    // end of namespace hidden

    enum class fft_scaling_mode { No_Scaling, Fft_N, Ifft_N, Both_Sqrt_N};

    template<fft_scaling_mode ScaleMode>
    auto get_fft_ifft()
    {
        if constexpr(ScaleMode == fft_scaling_mode::No_Scaling)
        {
            auto fft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, true);
                };

            auto ifft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, false);
                };

            return std::tuple{ std::move(fft), std::move(ifft) };
        }
        else if constexpr(ScaleMode == fft_scaling_mode::Fft_N)
        {
            auto fft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, true);

                    int N = data.size();
                    for(auto& d: data) d /= N;
                };

            auto ifft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, false);
                };

            return std::tuple{ std::move(fft), std::move(ifft) };
        }
        else if constexpr(ScaleMode == fft_scaling_mode::Ifft_N)
        {
            auto fft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, true);
                };

            auto ifft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, false);

                    int N = data.size();
                    for(auto& d: data) d /= N;
                };

            return std::tuple{ std::move(fft), std::move(ifft) };
        }

        else // if constexpr(ScaleMode == fft_scaling_mode::Both_Sqrt_N)
        {
            auto fft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, true);

                    int N = data.size();
                    auto reciprocal_sqrt_N = [N]
                        {
                            if constexpr(cplxnum_c<CplxType>)
                                return 1 / gmp::sqrt( CplxType{ N } );
                            else
                                return 1 / std::sqrt( N );
                        }();

                    for(auto& d: data) d *= reciprocal_sqrt_N;
                };

            auto ifft = []<complex_c CplxType>(std::vector<CplxType>& data)
                {
                    hidden::fft_impl(data, false);

                    int N = data.size();
                    auto reciprocal_sqrt_N = [N]
                        {
                            if constexpr(cplxnum_c<CplxType>)
                                return 1 / gmp::sqrt( CplxType{ N } );
                            else
                                return 1 / std::sqrt( N );
                        }();

                    for(auto& d: data) d *= reciprocal_sqrt_N;
                };

            return std::tuple{ std::move(fft), std::move(ifft) };
        }
    }

    template<complex_c CplxType = std::complex<double>, typename FuncType>
    auto sample_for_taylor_series(FuncType&& f, int N, CplxType center = 0)
    {
        std::vector<CplxType> data(N);

        using real_t = typename CplxType::value_type;
        
        auto _2_pi = []
            {
                if constexpr(cplxnum_c<CplxType>)
                    return real_t::constant_pi() * 2;
                else
                    return std::numbers::pi_v<real_t> * 2;
            }();

        auto w = [&](int kk)->CplxType
            {
                if constexpr(cplxnum_c<CplxType>)
                {
                    return center + gmp::exp(CplxType{ 0, _2_pi * kk / N });
                }
                else
                {
                    return center + std::exp(CplxType{ 0, _2_pi * kk / N });
                }
            };

        for(int k = 0; k < N; ++k)
            data[k] = f(w(k));

        return data;
    }
    
    namespace hidden
    {
        template<vector_c PolynomialType>
        auto split_polynomial_terms(PolynomialType&& P)
        {
            // Gmp_MemLeakCheck(split);

            using ContainerType = std::remove_cvref_t<PolynomialType>;
            
            std::size_t size = P.size();
            std::size_t reserve_half_size = size / 2;
            ContainerType even_terms, odd_terms;

            even_terms.reserve(reserve_half_size);
            odd_terms.reserve(reserve_half_size);

            for(std::size_t i{}; i < size; ++i)
            {
                if(i % 2 == 0) // i is even
                    even_terms.emplace_back(std::move(P[i]));
                else // i is odd
                    odd_terms.emplace_back(std::move(P[i]));
            }

            return std::tuple{ std::move(even_terms), std::move(odd_terms) };        
        }

        template<vector_c PolynomialType>
        auto fft_interpolation(PolynomialType&& P)
        {
            using ContainerType = 
                std::remove_cvref_t<PolynomialType>;

            // 5 + 3x + 2x^2 + x^3, n = 4, d+1
            int n = P.size();
            using ele_t = typename ContainerType::value_type;

            if(n == 1)
                return P;
            else if(n == 2)
            {
                // auto P1 = P[1]; P[1] -= P[0]; P[0] += P1;
                return ContainerType{ P[0] + P[1], P[0] - P[1] };
            }
            else
            {
                auto even_odd_terms = 
                    hidden::split_polynomial_terms(std::forward<PolynomialType>(P));
                
                auto& [Pe, Po] = even_odd_terms;
                
                auto Ye = fft_interpolation(std::move(Pe));
                auto Yo = fft_interpolation(std::move(Po));

                ContainerType Y(n);

                int half_n = n / 2;
                
                for(int j = 0; j < half_n; ++j)
                {
                    // 𝜔ₙʲ = 𝑒^i(2𝜋ʲ/𝑛)
                    auto w_j_Yo = Yo[j] * gmp::omega<ele_t>(n, j);

                    Y[j]        = Ye[j] + w_j_Yo;
                    Y[j+half_n] = std::move(Ye[j]) - w_j_Yo;
                }
                            
                return Y;
            }
        }

        template<complex_c CplxType, typename T, 
        template<complex_c, typename> class Cntr>
        void fft_interpolation_loop(Cntr<CplxType, T>& data)
        {
            using real_t = typename CplxType::value_type;

            std::size_t n = data.size();
            int log2n = std::log2(n);

            // bit reversal permutation
            for(size_t i = 0; i < (std::size_t)n; ++i)
            {
                std::size_t j = reverse_bits(i, log2n);
                
                if(i < j) 
                {
                    if constexpr(cplxnum_c<CplxType>)
                        gmp::swap( data[i], data[j] );
                    else
                        std::swap( data[i], data[j] );
                }
            }
            
            auto pi = []()
                    {
                        if constexpr(cplxnum_c<CplxType>)
                            return real_t::constant_pi();
                        else
                            return std::numbers::pi_v<typename CplxType::value_type>;
                    }();

            // step = 2, 4, 8, 16, 32, 64
            for(size_t step = 2; step <= n; step <<= 1)
            {
                // Negative for forward FFT
                real_t angle = 2 * pi / step;
                
                // CplxType w_step{ gmp::cos(angle), gmp::sin(angle) };
                CplxType w_step = [&angle]()->CplxType
                    {
                        // e^-i(2 π k j / N  )
                        if constexpr(cplxnum_c<CplxType>)
                            return { gmp::cos(angle), gmp::sin(angle) };
                        else
                            return { std::cos(angle), std::sin(angle) };
                    }();

                for(size_t k = 0; k < n; k += step)
                {
                    CplxType w{ 1.0 };

                    for(std::size_t j = 0; j < step / 2; ++j)
                    {
                        CplxType u = data[k + j];      // even
                        CplxType t = w * data[k + j + step/2]; // odd

                        data[k + j]            = u + t;
                        data[k + j + step / 2] = u - t;

                        w *= w_step; // update twiddle factor
                    }
                }
            }
        }
    }
    // end of namespace hidden

    /*
        Bit-reversal permutation
        https://en.wikipedia.org/wiki/Bit-reversal_permutation

        Fast Fourier transform
        https://en.wikipedia.org/wiki/Fast_Fourier_transform

        The Discrete Fourier Transform
        https://www.youtube.com/watch?v=T8XZxR5H04E&list=PLs8w1Cdi-zvY_BI7Fe0nYETCVoVhptFaf&index=1

        When is a sequence periodic? The Discrete Fourier Transform will tell us
        https://www.youtube.com/watch?v=bk9VGJNzQM0

        The Fast Fourier Transform
        https://www.youtube.com/watch?v=0bCfCGTkL9w

        What is a Discrete Fourier Transform (DFT) and an FFT?
        https://www.youtube.com/watch?v=BPf_pw_1Mg4

        Shor's Algorithm
        https://en.wikipedia.org/wiki/Shor%27s_algorithm

        The Discrete Fourier Transform
        https://www.youtube.com/watch?v=T8XZxR5H04E
        
        Discrete Fourier Transform - Simple Step by Step
        https://www.youtube.com/watch?v=mkGsMWi_j4Q

        Understanding the Discrete Fourier Transform and the FFT
        https://www.youtube.com/watch?v=QmgJmh2I3Fw

        To Understand the Fourier Transform, Start From Quantum Mechanics
        https://www.youtube.com/watch?v=W8QZ-yxebFA

        The intuition behind Fourier and Laplace transforms I was never taught in school
        https://www.youtube.com/watch?v=3gjJDuCAEQQ

        The Discrete Fourier Transform: Most Important Algorithm Ever?
        https://www.youtube.com/watch?v=yYEMxqreA10

        The Fast Fourier Transform (FFT): Most Ingenious Algorithm Ever?
        https://www.youtube.com/watch?v=h7apO7q16V0&t=231s
    */
        template<vector_c PolynomialType>
        auto fft_evaluation(PolynomialType&& P)
        {
            using ContainerType = std::remove_cvref_t<PolynomialType>;
            using ele_t = typename ContainerType::value_type;

            // 5 + 3x + 2x^2 + x^3, n = 4, d+1
            int n = P.size();
            using ele_t = typename ContainerType::value_type;

            if(n == 1)
                return P;
            else if(n == 2)
            {
                // auto P1 = P[1]; P[1] -= P[0]; P[0] += P1;
                return ContainerType{ P[0] + P[1], P[0] - P[1] };
            }
            else
            {
                auto even_odd_terms = 
                    hidden::split_polynomial_terms(std::forward<PolynomialType>(P));
                
                auto& [Pe, Po] = even_odd_terms;

                auto Ye = fft_evaluation(std::move(Pe));
                auto Yo = fft_evaluation(std::move(Po));

                ContainerType Y(n);

                auto half_n = n / 2;

                for(int j = 0; j < half_n; ++j)
                {
                    // 𝜔ₙʲ = 𝑒^-i(2𝜋ʲ/𝑛)
                    auto w_j_Yo = std::move(Yo[j]) * gmp::omega<ele_t>(n, -j);

                    Y[j]        = Ye[j] + w_j_Yo;
                    Y[j+half_n] = std::move(Ye[j]) - w_j_Yo;
                }

                return Y;
            }
        }

        template<vector_c PolynomialType>
        auto fft_transform(const PolynomialType& Y)
        {
            auto P = Y;
            return fft_evaluation(std::move(P));
        }
        
        template<vector_c PolynomialType>
        auto fft_inverse(PolynomialType&& P)
        {
            auto Y = hidden::fft_interpolation(std::forward<PolynomialType>(P));

            for(auto& y: Y) y /= (unsigned long)Y.size();

            return Y;
        }
        
        template<complex_c CplxType, typename T, 
            template<complex_c, typename> class Cntr>
        auto fft_evaluation_loop(Cntr<CplxType, T> data)
        {
            using real_t = typename CplxType::value_type;

            std::size_t n = data.size();
            int log2n = std::log2(n);

            // bit reversal permutation
            for(size_t i = 0; i < (std::size_t)n; ++i)
            {
                std::size_t j = hidden::reverse_bits(i, log2n);
                
                if(i < j) 
                {
                    if constexpr(cplxnum_c<CplxType>)
                        gmp::swap( data[i], data[j] );
                    else
                        std::swap( data[i], data[j] );
                }
            }
            
            auto pi = []()
                    {
                        if constexpr(cplxnum_c<CplxType>)
                            return real_t::constant_pi();
                        else
                            return std::numbers::pi_v<typename CplxType::value_type>;
                    }();

            // step = 2, 4, 8, 16, 32, 64
            for(size_t step = 2; step <= n; step <<= 1)
            {
                // Negative for forward FFT
                real_t angle = -2 * pi / step;
                
                // CplxType w_step{ gmp::cos(angle), gmp::sin(angle) };
                CplxType w_step = [&angle]()->CplxType
                    {
                        // e^-i(2 π k j / N  )
                        if constexpr(cplxnum_c<CplxType>)
                            return { gmp::cos(angle), gmp::sin(angle) };
                        else
                            return { std::cos(angle), std::sin(angle) };
                    }();

                for(size_t k = 0; k < n; k += step)
                {
                    CplxType w{ 1.0 };

                    for(std::size_t j = 0; j < step / 2; ++j)
                    {
                        CplxType u = data[k + j];      // even
                        CplxType t = w * data[k + j + step/2]; // odd

                        data[k + j]            = u + t;
                        data[k + j + step / 2] = u - t;

                        w *= w_step; // update twiddle factor
                    }
                }
            }

            return data;
        }

        template<complex_c CplxType, typename T, 
            template<complex_c, typename> class Cntr>
            auto fft_inverse_loop(const Cntr<CplxType, T>& data)
        {
            auto P = data;
            
            hidden::fft_interpolation_loop(P);

            for(auto& p: P) p /= CplxType{ P.size() };

            return P;
        }

        template<complex_c CplxType, typename T, 
            template<complex_c, typename> class Cntr>
            auto fft_inverse_flat(const Cntr<CplxType, T>& data)
        {
            int n = data.size();

            Cntr<CplxType, T> c(n);

            auto pi = []
                {
                    if constexpr(cplxnum_c<CplxType>)
                        return CplxType::value_type::constant_pi();
                    else
                        return std::numbers::pi_v<typename CplxType::value_type>;
                }();

            for(int k = 0; k < n; ++k)
            {
                    // gmp::omega<CplxType>(n , k * j);
                    // = e^i(2πkj/N)
                    
                    // = cos(2πkj/N) + i sin(2πkj/N)
                    
                
                for(int j = 0; j < n; ++j)
                { 
                    auto angle = 2 * pi * k * j / n;

                    // auto angle = CplxType{2 * pi * k * j / n};
                    // auto [ cos, sin ] = gmp::cos_sin(angle);

                    c[k] += data[j] * // ( gmp::cos(angle) + gmp::sin(angle) * 1_im);
                                        gmp::omega<CplxType>(n, k * j);
                }
            }
            
            for(int k = 0; k < n; ++k) c[k] /= n;

            return c;
        }

        template<int Order, complex_c CplxType, typename T, 
            template<complex_c, typename> class Cntr>
            auto fft_derivative_flat(const Cntr<CplxType, T>& data)
        {
            int n = data.size();

            CplxType c{};

            const auto pi = []
                {
                    if constexpr(cplxnum_c<CplxType>)
                        return CplxType::value_type::constant_pi();
                    else if constexpr(realnum_c<CplxType>)
                        return CplxType::constant_pi();
                    else
                        return std::numbers::pi_v<typename CplxType::value_type>;
                }();

            for(int j = 0; j < n; ++j)
            { 
                // auto angle = 2 * pi * k * j / n;

                // auto angle = CplxType{2 * pi * k * j / n};
                // auto [ cos, sin ] = gmp::cos_sin(angle);

                c += gmp::omega<CplxType>(n, Order * j) * data[j] ;
            }
            
            c /= n; return c;
        }
    
        template<int Order = 0, typename FuncType, typename ArgType>
        auto fft_derivative(FuncType&& f, ArgType c, int N)
        {
            using Cplx = typename cplx_type_traits<ArgType>::type;

            auto ff = [f, c](auto x)
            {
                return f(x + c);
            };

            std::vector<Cplx> ValuesOf_f(N);

            for(int j = 0; j < N; ++j)
            {
                // 𝜔ₙʲ = e^-i(2πj/N)
                ValuesOf_f[j] = ff(omega<Cplx>(N, -j));
            }

            auto a = 
                fft_derivative_flat<Order>(ValuesOf_f);

            using rType = typename real_type_traits<Cplx>::type;

            return static_cast<rType>(gmp::fact(Order)) * a;
        }

        template<int VarID = 0, int Order = 0, int nodes = 32,
            typename FuncType, int pCount = parameter_count_v<FuncType>>
            requires (pCount > 0 && pCount < MaxInvocableCount)
        auto derivative_fft(FuncType&& f)
        {
            return [f]<typename S, typename... T>
                    (S&& arg, T&& ... args)
                    requires (sizeof...(T) + 1 == pCount)
            { 
                using ArgType = common_type_t<
                        std::remove_cvref_t<S>, std::remove_cvref_t<T>...>;
                
                if constexpr(complex_c<ArgType>)
                {
                    // we copied args from outer lambda
                    auto prm = std::tuple{ arg, args...};

                    auto ff = [f, &prm ](auto x)
                    {
                        std::get<VarID>(prm) = x;
                        return gmp::apply(f, prm);
                    };

                    return fft_derivative<Order>(ff, std::get<VarID>(prm), nodes);
                }
                else
                {
                    using Cplx = typename cplx_type_traits<ArgType>::type;

                    // we copied args from outer lambda
                    auto prm = std::tuple{ Cplx{arg}, Cplx{args}... };

                    auto ff = [f, &prm ](auto x)
                    {
                        std::get<VarID>(prm) = x;
                        return std::apply(f, prm);
                    };

                    return fft_derivative<Order>(ff, std::get<VarID>(prm), nodes).real();
                }
            };
        }
         
        namespace hidden
        {
            template<int pCount, auto StencilKnd, auto PivotKnd, auto VarID, auto Order, auto DX,
            drv_cmd_c... DrvCmds, typename FuncType>
            auto bind_derivative(drv_cmds<
                    drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>, DrvCmds...>, FuncType&& f)
            {          
                if constexpr(DrvStencil::fft_method == StencilKnd)
                {
                    if constexpr(sizeof...(DrvCmds) == 0)
                    {
                        return derivative_fft<VarID, Order, DX>(f);
                    }
                    else
                    {
                        return bind_derivative<pCount>
                            ( drv_cmds<DrvCmds...>{}, derivative_fft<VarID, Order, DX>(f) );
                    }
                }
                else
                {
                    if constexpr(sizeof...(DrvCmds) == 0)
                    {
                        return [f](auto... args)
                                    requires( sizeof...(args) == pCount)
                            {                 
                                return derivative_stencil<StencilKnd, PivotKnd, VarID, Order>
                                    (f, DX, std::array{ args... } );
                            };
                    }
                    else
                    {
                        return bind_derivative<pCount>
                            ( 
                                drv_cmds<DrvCmds...>{}, 
                                
                                [f](auto... args)
                                    requires( sizeof...(args) == pCount )
                                {
                                    return derivative_stencil<StencilKnd, PivotKnd, VarID, Order>
                                        (f, DX, std::array{ args... } );
                                }
                            );
                    }
                }
            }
        }
        // end of namespace hidden

        // ////////////////////////////////////////////////////////////////////////////////
        template<auto StencilKnd1, auto PivotKnd1, auto VarID1, auto Order1, auto DX1,
                 auto StencilKnd2, auto PivotKnd2, auto VarID2, auto Order2, auto DX2>
        constexpr auto operator* (drv_cmd<StencilKnd1, PivotKnd1, VarID1, Order1, DX1>, 
                                    drv_cmd<StencilKnd2, PivotKnd2, VarID2, Order2, DX2>)
        {
            return drv_cmds<drv_cmd<StencilKnd2, PivotKnd2, VarID2, Order2, DX2>,
                                  drv_cmd<StencilKnd1, PivotKnd1, VarID1, Order1, DX1>>{};
        }

        template<auto... StencilKnds, auto... PivotKnds, auto... VarIDs, auto... Orders, auto... DXs,
            auto StencilKnd, auto PivotKnd, auto VarID, auto Order, auto DX>
        constexpr auto operator* (
                drv_cmds<drv_cmd<StencilKnds, PivotKnds, VarIDs, Orders, DXs>...>,
                drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>)
        {
            return drv_cmds<drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>,
                drv_cmd<StencilKnds, PivotKnds, VarIDs, Orders, DXs>...>{};
        }
                
        template<auto StencilKnd, auto PivotKnd, auto VarID, auto Order, auto DX,
            drv_cmd_c... DrvCmds, extended_function_c<float> FuncType>
        auto operator* (drv_cmds< 
                drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>, DrvCmds...>, FuncType&& f)
        {          
            if constexpr(number_c<FuncType>)
                return std::remove_cvref_t<FuncType>(0);
            else
                return hidden::bind_derivative<parameter_count_v<FuncType, float>>
                    ( drv_cmds<drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>, DrvCmds...>{}, f );
        }

        template<auto StencilKnd, auto PivotKnd, auto VarID, auto Order, auto DX, 
            extended_function_c<float> FuncType>
        auto operator* (drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>, FuncType&& f)
        {
            if constexpr(number_c<FuncType>)
                return std::remove_cvref_t<FuncType>(0);
            else
                return drv_cmds<drv_cmd<StencilKnd, PivotKnd, VarID, Order, DX>>{} * f;
        }

        // PolyMode::standard: returns coefficients in ascending degree
        // PolyMode::canonical:   returns coefficients in descending degree
        // ArgType c: center of the taylor series polynomial
        // int N: should be N = 2ᵏ where k is 2, 3, 4, ...
        // int Degree: if degree = 0, the degree of the polynomial is determined heuristically
        template<PolyMode PolyMode = PolyMode::standard,
                int Degree = 0, typename FuncType, realnum_c ArgType>
        auto fft_taylor_series_flat(FuncType&& f, ArgType c, int N = 16)
        {
            constexpr auto Prec = realnum_prec_v<ArgType>;
            constexpr auto Rnd = realnum_rnd_v<ArgType>;
            using Cplx = typename ArgType::cplxnum_type;

            auto ff = [f, c](auto x)
            {
                return f(x + c);
            };

            std::vector<Cplx> ValuesOf_f(N);

            for(int j = 0; j < N; ++j)
            {
                            // 𝜔ₙʲ = e^-i(2πj/N)
                ValuesOf_f[j] = ff(omega<Cplx>(N, -j));
            }

            auto coeffs = fft_inverse_flat(std::move(ValuesOf_f));
        
            if constexpr(Degree == 0)
            {
                std::vector<ArgType> Coeffs;
                Coeffs.reserve(N);
                auto zero = ArgType::constant_as_zero();
                bool bZeroNotSeen = true;

                for(int i=N-1; i >= 0 ; --i)
                {
                    if(bZeroNotSeen)
                    {
                        if(abs(coeffs[i].real()) < zero)
                            continue;
                        else
                        {
                            bZeroNotSeen = false; 
                            Coeffs.emplace_back(std::move(coeffs[i].real()));
                            continue;
                        }
                    }
                    else
                    {
                        Coeffs.emplace_back( abs(coeffs[i].real()) < zero ?
                            ArgType{} : std::move(coeffs[i].real()) );
                    }
                }

                if constexpr(PolyMode == PolyMode::canonical)
                {
                    std::reverse(Coeffs.begin(), Coeffs.end());
                }

                return Coeffs;
            }
            else // Degree != 0
            {
                std::vector<ArgType> Coeffs;
                Coeffs.reserve(Degree+1);

                auto zero = ArgType::constant_as_zero();

                for(int i = 0; i <= Degree; ++i)
                    Coeffs.emplace_back(abs(coeffs[i].real()) < zero ?
                            ArgType{} : std::move(coeffs[i].real()));
                
                if constexpr(PolyMode == PolyMode::standard)
                {
                    std::reverse(Coeffs.begin(), Coeffs.end());
                }
                
                return Coeffs;
            }
        }
        
        // PolyMode::standard: returns coefficients in ascending degree
        // PolyMode::canonical:   returns coefficients in descending degree
        // ArgType c: center of the taylor series polynomial
        // int N: should be N = 2ᵏ where k is 2, 3, 4, ...
        // int Degree: if degree = 0, the degree of the polynomial is determined heuristically
        template<PolyMode PolyMode = PolyMode::standard,
                int Degree = 0, typename FuncType, realnum_c ArgType>
        auto fft_taylor_series_recursion(FuncType&& f, ArgType c, int N = 16)
        {
            constexpr auto Prec = realnum_prec_v<ArgType>;
            constexpr auto Rnd = realnum_rnd_v<ArgType>;
            using Cplx = typename ArgType::cplxnum_type;

            auto ff = [f, c](auto x)
            {
                return f(x + c);
            };

            std::vector<Cplx> ValuesOf_f(N);

            for(int j = 0; j < N; ++j)
            {
                            // 𝜔ₙʲ = e^-i(2πj/N)
                ValuesOf_f[j] = ff(omega<Cplx>(N, -j));
            }

            auto coeffs = fft_inverse(std::move(ValuesOf_f));
        
            if constexpr(Degree == 0)
            {
                std::vector<ArgType> Coeffs;
                Coeffs.reserve(N);
                auto zero = ArgType::constant_as_zero();
                bool bZeroNotSeen = true;

                for(int i=N-1; i >= 0 ; --i)
                {
                    if(bZeroNotSeen)
                    {
                        if(abs(coeffs[i].real()) < zero)
                            continue;
                        else
                        {
                            bZeroNotSeen = false; 
                            Coeffs.emplace_back(std::move(coeffs[i].real()));
                            continue;
                        }
                    }
                    else
                    {
                        Coeffs.emplace_back( abs(coeffs[i].real()) < zero ?
                            ArgType{} : std::move(coeffs[i].real()) );
                    }
                }

                if constexpr(PolyMode == PolyMode::canonical)
                {
                    std::reverse(Coeffs.begin(), Coeffs.end());
                }

                return Coeffs;
            }
            else // Degree != 0
            {
                std::vector<ArgType> Coeffs;
                Coeffs.reserve(Degree+1);

                auto zero = ArgType::constant_as_zero();

                for(int i = 0; i <= Degree; ++i)
                    Coeffs.emplace_back(abs(coeffs[i].real()) < zero ?
                            ArgType{} : std::move(coeffs[i].real()));
                
                if constexpr(PolyMode == PolyMode::standard)
                {
                    std::reverse(Coeffs.begin(), Coeffs.end());
                }
                
                return Coeffs;
            }
        }

        // PolyMode::standard: returns coefficients in ascending degree
        // PolyMode::canonical:   returns coefficients in descending degree
        // ArgType c: center of the taylor series polynomial
        // int N: should be N = 2ᵏ where k is 2, 3, 4, ...
        // int Degree: if degree = 0, the degree of the polynomial is determined heuristically
        template<PolyMode PolyMode = PolyMode::standard,
                int Degree = 0, typename FuncType, realnum_c ArgType>
        auto fft_taylor_series_loop(FuncType&& f, ArgType c, int N = 16)
        {
            constexpr auto Prec = realnum_prec_v<ArgType>;
            constexpr auto Rnd = realnum_rnd_v<ArgType>;
            using Cplx = typename ArgType::cplxnum_type;

            auto ff = [f, c](auto x)
            {
                return f(x + c);
            };

            std::vector<Cplx> ValuesOf_f(N);

            for(int j = 0; j < N; ++j)
            {
                            // 𝜔ₙʲ = e^-i(2πj/N)
                ValuesOf_f[j] = ff(omega<Cplx>(N, -j));
            }

            auto coeffs = fft_inverse_loop(std::move(ValuesOf_f));
        
            if constexpr(Degree == 0)
            {
                std::vector<ArgType> Coeffs;
                Coeffs.reserve(N);
                auto zero = ArgType::constant_as_zero();
                bool bZeroNotSeen = true;

                for(int i=N-1; i >= 0 ; --i)
                {
                    if(bZeroNotSeen)
                    {
                        if(gmp::abs(coeffs[i].real()) < zero)
                            continue;
                        else
                        {
                            bZeroNotSeen = false; 
                            Coeffs.emplace_back(std::move(coeffs[i].real()));
                            continue;
                        }
                    }
                    else
                    {
                        Coeffs.emplace_back( gmp::abs(coeffs[i].real()) < zero ?
                            ArgType{} : std::move(coeffs[i].real()) );
                    }
                }

                if constexpr(PolyMode == PolyMode::canonical)
                {
                    std::reverse(Coeffs.begin(), Coeffs.end());
                }

                return Coeffs;
            }
            else // Degree != 0
            {
                std::vector<ArgType> Coeffs;
                Coeffs.reserve(Degree+1);

                auto zero = ArgType::constant_as_zero();

                for(int i = 0; i <= Degree; ++i)
                    Coeffs.emplace_back(abs(coeffs[i].real()) < zero ?
                            ArgType{} : std::move(coeffs[i].real()));
                
                if constexpr(PolyMode == PolyMode::standard)
                {
                    std::reverse(Coeffs.begin(), Coeffs.end());
                }
                
                return Coeffs;
            }
        }
    }
    // end of namespace calculus
}


#endif
// end of file GMP_SOLVER_HPP