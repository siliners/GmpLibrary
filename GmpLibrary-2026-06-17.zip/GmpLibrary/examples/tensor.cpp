﻿/*
    Author: Chang Hee Kim (Thomas Kim)
    
    First Edit: 2025.08.17
    License: Creative Commons Attribution 4.0 International (CC BY 4.0)

    You are free to:
      - Share — copy and redistribute the material in any medium or format
      - Adapt — remix, transform, and build upon the material for any purpose, even commercially.

    Under the following terms:
      - Attribution — You must give appropriate credit, provide a link to the license, 
        and indicate if changes were made. You may do so in any reasonable manner, 
        but not in any way that suggests the licensor endorses you or your use.

    License details: https://creativecommons.org/licenses/by/4.0/    

    icx-cl tensor.cpp -o i.exe -Qstd=c++23 /EHsc /nologo
    g++ tensor.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    clang++ tensor.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    cl tensor.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
*/

#include <gmp/gmp_tensor.hpp>


using namespace gmp::precision_quadruple;
using namespace std::complex_literals;
using gmp::operators::operator+;

void test_tensors()
{
    Gmp_DisplayFunctionName();

    auto f = [](auto x) { return x; };
    auto g = [](auto x, auto y) { return x + y; };

    auto p = gmp::create_tensor(1, 2);

    std::cout << "p = " << p.base() << std::endl;
    std::cout << "p's type: " >> p << endl;

    auto zn = gmp::create_tensor(1, 2_zn);

    std::cout << "zn = " << zn.base() << std::endl;
    std::cout << "zn's type: " >> zn << endl;

    auto b = gmp::create_tensor(f, g);

    auto [rf, rg] = b.base();

    std::cout << "rf = " << rf(3.5) << endl;
    std::cout << "rg = " << rg(3.5, 6.7) << endl;

    auto A = gmp::create_tensor<2, 3, 1>(1, 2, 3, 4, 5, 6);
    std::cout <<"A = " << A.base() << endl;

    auto B = gmp::create_tensor<2, 3>( 1, f, 3, g, 5, 6);
    std::cout <<"B = " << B.base() << endl;

    auto C = gmp::create_tensor<2, 3, 2>( 1, f, 3,
                                          g, 5, 6,
                                          1, f, 3,
                                          g, 5, 6 );

    std::cout <<"C = " << C.base() << endl;

    auto D = gmp::create_tensor<2, 3, 2>( 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6);
    std::cout <<"D = " << D.base() << endl;

    auto E = gmp::create_tensor<2, 3, 2, 2>
        ( 1, 2.5, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6,
          1.6f, 2, 3, 4, 5u, 6, 1, 2, 3, 4, 5, 6);

    std::cout <<"E = " << E.base() << endl;

    auto F = gmp::create_tensor<3, 3, 4>
        ( 1.1, std::complex<double>{2}, 3, 4, 5, 6, 7, 8, 9,
          1.2, 2, 3, 4, 5, 6, 7, 8, 9,
          1.3, 2, 3_re, 4, 5, 6, 7, 8, 9,
          1.4, 2, 3, 4, 5, 6, 7, 8, 9 );
          
    std::cout <<"F = " << F.base() << endl;

    auto G = gmp::create_tensor<3, 3, 4>
        ( 1.1, 2, 3, 4, 5, 6, 7, 8, 9,
          1.2, 2, 3, 4, 5, 6, 7, 8, 9,
          1.3, 2, 3, 4, 5, 6, 7, 8, 9,
          1.4, 2, 3, 4, 5, 6, 7, f, g );
          
    std::cout <<"G = " << G.base() << endl;

    auto d = gmp::create_tensor<double, 2>();

    auto& dd = d.base();

    dd[0] = 3.5;
    dd[1] = 5.7;

    std::cout << "d = " << d.base() << endl;

    auto h = gmp::create_tensor<real_type, 10>();

    auto& hh = h.base();
    
    hh[0] = 5.6;

    std::cout << "h = " << hh << endl;

    auto k = h;

    std::cout << "k = " << k.base() << endl;
}

void test_vectors()
{
    Gmp_DisplayFunctionName();

    auto f = [](auto x, auto y) { return x * y; };
    auto g = [](auto x, auto y) { return x + y; };

    auto A = gmp::create_tensor(1,   2,   3, 4_rn,   5);
    auto B = gmp::create_tensor(1.5, 2.6, 3, 4, 4.5);

    // std::cout <<"A = " << A << endl;
    // std::cout <<"B = " << B << endl;

    auto C = A + B;
    std::cout << "A + B = " << C << endl;

    auto D = A - B;
    std::cout << "A - B = " << D << endl;

    auto dot = A * B;

    std::cout <<"A * B = " << dot << endl;

    auto F = gmp::create_tensor(1, 2);
    auto G = gmp::create_tensor(3, 1);

    std::cout <<"F = " << Gmp_GetTypeCategory(F) << endl;
    std::cout <<"G = " << Gmp_GetTypeCategory(G) << endl;
    
    auto cross = F % G;

    std::cout <<"F % G = " << cross << endl;

    auto dot_FG = F * G;

    std::cout <<"F % G = " << dot_FG << endl;
}

void test_vectors_binary()
{
    Gmp_DisplayFunctionName();

    auto x = 1.0;
    auto y = 2.0;

    auto xy = std::array{x, y};

    std::cout <<"xy = " << xy << endL;

    auto f = [](auto x, auto y) { return x * y; };
    auto g = [](auto x, auto y) { return x + y; };
    auto h = [](auto x, auto y) { return 2 * x - y; };

    auto A = gmp::create_tensor(f, 2, 3);
    auto B = gmp::create_tensor(g, 5, h);

    auto C = A + B;

    std::cout <<"(A + B)_0"<< xy <<" = " << eval(C.get<0>(), x, y) << endl;
    std::cout <<"(A + B)_1"<< xy <<" = " << eval(C.get<1>(), xy) << endl;
    std::cout <<"(A + B)_2"<< xy <<" = " << eval(C.get<2>(), xy) << endl;
    std::cout <<"A + B    "<< xy <<" = " << eval(C, xy) << endl;
    std::cout <<"A + B    "<< xy <<" = " << C.eval(x, y) << endl;
    std::cout <<"A + B    "<< xy <<" = " << C.eval(xy) << endL;

    auto D = A - B;

    std::cout <<"(A - B)_0"<< xy <<" = " << eval(D.get<0>(), x, y) << endl;
    std::cout <<"(A - B)_1"<< xy <<" = " << eval(D.get<1>(), xy) << endl;
    std::cout <<"(A - B)_2"<< xy <<" = " << eval(D.get<2>(), xy) << endl;
    std::cout <<"A - B    "<< xy <<" = " << eval(D, xy) << endl;
    std::cout <<"A - B    "<< xy <<" = " << D.eval(x, y) << endl;
    std::cout <<"A - B    "<< xy <<" = " << D.eval(xy) << endL;

    auto cross = A % B;

    std::cout <<"(A % B)_0"<< xy <<" = " << eval(cross.get<0>(), x, y) << endl;
    std::cout <<"(A % B)_1"<< xy <<" = " << eval(cross.get<1>(), xy) << endl;
    std::cout <<"(A % B)_2"<< xy <<" = " << eval(cross.get<2>(), xy) << endl;
    std::cout <<"A % B    "<< xy <<" = " << eval(cross, xy) << endl;
    std::cout <<"A % B    "<< xy <<" = " << cross.eval(x, y) << endl;
    std::cout <<"A % B    "<< xy <<" = " << cross.eval(xy) << endL;

    auto dot = A * B;

    std::cout <<"A * B "<< xy <<" = " << eval(dot, xy) << endl;
    std::cout <<"A * B "<< xy <<" = " << eval(dot, x, y) << endL;
}

void test_vectors_binary_std_complex()
{
    Gmp_DisplayFunctionName();

    auto x = 1.0 + 3.2i;
    auto y = 2.0 + 1.5i;

    auto xy = std::array{x, y};

    std::cout <<"xy = " << xy << endL;

    auto f = [](auto x, auto y) { return x * y; };
    auto g = [](auto x, auto y) { return x + y; };
    auto h = [](auto x, auto y) { return 2 * x - y; };

    auto A = gmp::create_tensor(f, 2, 3);
    auto B = gmp::create_tensor(g, 5, h);

    auto C = A + B;

    std::cout <<"(A + B)_0"<< xy <<" = " << eval(C.get<0>(), x, y) << endl;
    std::cout <<"(A + B)_1"<< xy <<" = " << eval(C.get<1>(), xy) << endl;
    std::cout <<"(A + B)_2"<< xy <<" = " << eval(C.get<2>(), xy) << endl;
    std::cout <<"A + B    "<< xy <<" = " << eval(C, xy) << endl;
    std::cout <<"A + B    "<< xy <<" = " << C.eval(x, y) << endl;
    std::cout <<"A + B    "<< xy <<" = " << C.eval(xy) << endL;

    auto D = A - B;

    std::cout <<"(A - B)_0"<< xy <<" = " << eval(D.get<0>(), x, y) << endl;
    std::cout <<"(A - B)_1"<< xy <<" = " << eval(D.get<1>(), xy) << endl;
    std::cout <<"(A - B)_2"<< xy <<" = " << eval(D.get<2>(), xy) << endl;
    std::cout <<"A - B    "<< xy <<" = " << eval(D, xy) << endl;
    std::cout <<"A - B    "<< xy <<" = " << D.eval(x, y) << endl;
    std::cout <<"A - B    "<< xy <<" = " << D.eval(xy) << endL;

    auto cross = A % B;

    std::cout <<"(A % B)_0"<< xy <<" = " << eval(cross.get<0>(), x, y) << endl;
    std::cout <<"(A % B)_1"<< xy <<" = " << eval(cross.get<1>(), xy) << endl;
    std::cout <<"(A % B)_2"<< xy <<" = " << eval(cross.get<2>(), xy) << endl;
    std::cout <<"A % B    "<< xy <<" = " << eval(cross, xy) << endl;
    std::cout <<"A % B    "<< xy <<" = " << cross.eval(x, y) << endl;
    std::cout <<"A % B    "<< xy <<" = " << cross.eval(xy) << endL;

    auto dot = A * B;

    std::cout <<"A * B "<< xy <<" = " << eval(dot, xy) << endl;
    std::cout <<"A * B "<< xy <<" = " << eval(dot, x, y) << endL;
}

void test_vectors_binary_gmp_complex()
{
    Gmp_DisplayFunctionName();

    auto x = 1.0_re + 3.2_im;
    auto y = 2.0_re + 1.5_im;

    auto xy = std::array{x, y};

    std::cout <<"xy = " << xy << endL;

    auto f = [](auto x, auto y) { return x * y; };
    auto g = [](auto x, auto y) { return x + y; };
    auto h = [](auto x, auto y) { return 2 * x - y; };

    auto A = gmp::create_tensor(f, 2, 3);
    auto B = gmp::create_tensor(g, 5, h);

    auto C = A + B;

    std::cout <<"(A + B)_0"<< xy <<" = " << eval(C.get<0>(), x, y) << endl;
    std::cout <<"(A + B)_1"<< xy <<" = " << eval(C.get<1>(), xy) << endl;
    std::cout <<"(A + B)_2"<< xy <<" = " << eval(C.get<2>(), xy) << endl;
    std::cout <<"A + B    "<< xy <<" = " << eval(C, xy) << endl;
    std::cout <<"A + B    "<< xy <<" = " << C.eval(x, y) << endl;
    std::cout <<"A + B    "<< xy <<" = " << C.eval(xy) << endL;

    auto D = A - B;

    std::cout <<"(A - B)_0"<< xy <<" = " << eval(D.get<0>(), x, y) << endl;
    std::cout <<"(A - B)_1"<< xy <<" = " << eval(D.get<1>(), xy) << endl;
    std::cout <<"(A - B)_2"<< xy <<" = " << eval(D.get<2>(), xy) << endl;
    std::cout <<"A - B    "<< xy <<" = " << eval(D, xy) << endl;
    std::cout <<"A - B    "<< xy <<" = " << D.eval(x, y) << endl;
    std::cout <<"A - B    "<< xy <<" = " << D.eval(xy) << endL;

    auto cross = A % B;

    std::cout <<"(A % B)_0"<< xy <<" = " << eval(cross.get<0>(), x, y) << endl;
    std::cout <<"(A % B)_1"<< xy <<" = " << eval(cross.get<1>(), xy) << endl;
    std::cout <<"(A % B)_2"<< xy <<" = " << eval(cross.get<2>(), xy) << endl;
    std::cout <<"A % B    "<< xy <<" = " << eval(cross, xy) << endl;
    std::cout <<"A % B    "<< xy <<" = " << cross.eval(x, y) << endl;
    std::cout <<"A % B    "<< xy <<" = " << cross.eval(xy) << endL;

    auto dot = A * B;

    std::cout <<"A * B "<< xy <<" = " << eval(dot, xy) << endl;
    std::cout <<"A * B "<< xy <<" = " << eval(dot, x, y) << endL;
}

int main()
{
    
    Gmp_DisplayCompilerInfo();

    std::cout << std::boolalpha;

    test_tensors();

    test_vectors();

    test_vectors_binary();
    
    test_vectors_binary_std_complex();

    test_vectors_binary_gmp_complex();
}