#ifndef _GMP_MATH_HPP
#define _GMP_MATH_HPP

// operable functions are defined in this file

#include "gmp_base.hpp"

namespace gmp::math
{
    using namespace operators;

    template<auto> struct base_expo{ };

    template<auto value>
    constexpr auto pwr = base_expo<value>{};

    template<auto value>
    constexpr auto bse = base_expo<value>{};
    
    namespace hidden
    {
        inline auto abs  = [](auto num) { return gmp::abs(num); };

        inline auto sin  = [](auto num) { return gmp::sin(num); };
        inline auto cos  = [](auto num) { return gmp::cos(num); };
        inline auto tan  = [](auto num) { return gmp::tan(num); };

        inline auto asin  = [](auto num) { return gmp::asin(num); };
        inline auto acos  = [](auto num) { return gmp::acos(num); };
        inline auto atan  = [](auto num) { return gmp::atan(num); };
        inline auto atan2  = [](auto y, auto x) { return gmp::atan2(y, x); };

        template<size_t N>
        auto hypot() noexcept
        {
            return [](auto... args)
                requires (sizeof...(args) == N)
            {
                return gmp::hypot(args...);
            };
        }
        
        inline auto sinh  = [](auto num) { return gmp::sinh(num); };
        inline auto cosh  = [](auto num) { return gmp::cosh(num); };
        inline auto tanh  = [](auto num) { return gmp::tanh(num); };

        inline auto asinh  = [](auto num) { return gmp::asinh(num); };
        inline auto acosh  = [](auto num) { return gmp::acosh(num); };
        inline auto atanh  = [](auto num) { return gmp::atanh(num); };

        inline auto sqrt = [](auto num) { return gmp::sqrt(num);};

        inline auto exp  = [](auto num) { return gmp::exp(num); };
        inline auto log  = [](auto num) { return gmp::log(num); };
        inline auto log10  = [](auto num) { return gmp::log10(num); };

        inline auto polar = [](auto radius, auto theta) 
        { 
            return gmp::polar(radius, theta); 
        };
    }
    // end of namespace hidden
    
    inline auto abs = []<number_or_function_c ArgType>(ArgType&& arg)
        { return call_redirect(hidden::abs, std::forward<ArgType>(arg)); };

    inline auto sqrt = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::sqrt, arg); };

    inline auto polar = []<number_or_function_c ArgType1,
            number_or_function_c ArgType2>(ArgType1&& arg1, ArgType2&& arg2) 
        { return call_redirect<CastRtnType::dont, float>(hidden::polar, arg1, arg2); };

    inline auto sin = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::sin, std::forward<ArgType>(arg)); };

    inline auto cos = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::cos, std::forward<ArgType>(arg)); };

    inline auto tan = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::tan, std::forward<ArgType>(arg)); };

    ///////////////////////////////////////////////////////

    inline auto asin = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::asin, std::forward<ArgType>(arg)); };

    inline auto acos = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::acos, std::forward<ArgType>(arg)); };

    inline auto atan = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::atan, std::forward<ArgType>(arg)); };

    inline auto atan2 = []<number_or_function_c yType, 
        number_or_function_c xType>(yType&& y, xType&& x) 
        { return call_redirect(hidden::atan2, std::forward<yType>(y), std::forward<xType>(x)); };

    template<number_or_function_c... ArgTypes, int N = sizeof...(ArgTypes)>
        requires ( N >= 2 )
    inline auto hypot(ArgTypes&&... args) 
        {
            if constexpr(all_numbers_c<ArgTypes...>)
            {
                using ele_t = elevated_common_type_t<ArgTypes...>;
                return gmp::hypot( static_cast<ele_t>( std::forward<ArgTypes>(args) )... );
            }
            else
            {
                return call_redirect( hidden::hypot<N>(),
                            std::forward<ArgTypes>(args) ... );
            }
        };
    
    ////////////////////////////////////////////////////////

    inline auto sinh = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::sinh, std::forward<ArgType>(arg)); };

    inline auto cosh = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::cosh, std::forward<ArgType>(arg)); };

    inline auto tanh = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::tanh, std::forward<ArgType>(arg)); };

    inline auto asinh = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::asinh, std::forward<ArgType>(arg)); };

    inline auto acosh = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::acosh, std::forward<ArgType>(arg)); };

    inline auto atanh = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::atanh, std::forward<ArgType>(arg)); };

    inline auto exp = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::exp, std::forward<ArgType>(arg)); };

    inline auto log = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::log, std::forward<ArgType>(arg)); };

    inline auto log10 = []<number_or_function_c ArgType>(ArgType&& arg) 
        { return call_redirect(hidden::log10, std::forward<ArgType>(arg)); };

    template<number_c ExpType, numeric_function_c<float> FuncType>
    auto pow(FuncType arg, ExpType ex) 
        { 
            return [=](auto... args)
                requires (sizeof...(args) == parameter_size_v<FuncType, float>)
            {
                return gmp::pow( arg(args...), ex);
            };
        };

    template<number_c BaseType, numeric_function_c<float> ExpType>
    auto pow(BaseType arg, ExpType ex)
        { 
            return [=](auto... args)
                requires (sizeof...(args) == parameter_size_v<ExpType, float>)
            {
                return gmp::pow(arg, ex(args...));
            };
        };

    template<number_c BaseType, number_c ExpType>
    auto pow(BaseType arg, ExpType ex)
    {
        return gmp::pow(arg, ex);
    }

    template<typename S, typename T>
    concept opr_hat_c = requires (S s, T t) { s ^ t; };

    template<numeric_function_c BaseType, number_c ExpType>
    auto operator%(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<number_c BaseType, numeric_function_c ExpType>
    auto operator%(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<gmp_type_c BaseType, number_c ExpType>
    auto operator%(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<number_c BaseType, gmp_type_c ExpType>
    auto operator%(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<number_or_function_c BaseType, auto expo>
    auto operator%(BaseType base, base_expo<expo>)
    {
        return pow(base, expo);
    }

    template<auto base, number_or_function_c ExpType>
    auto operator%(base_expo<base>, ExpType expo)
    {
        return pow(base, expo);
    }

    ///////////////////////////////////////////////////////
    template<numeric_function_c BaseType, number_c ExpType>
    auto operator^(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<number_c BaseType, numeric_function_c ExpType>
    auto operator^(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<gmp_type_c BaseType, number_c ExpType>
    auto operator^(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<number_c BaseType, gmp_type_c ExpType>
    auto operator^(BaseType base, ExpType ex)
    {
        return pow(base, ex);
    }

    template<number_or_function_c BaseType, auto expo>
    auto operator^(BaseType base, base_expo<expo>)
    {
        return pow(base, expo);
    }

    template<auto base, number_or_function_c ExpType>
    auto operator^(base_expo<base>, ExpType expo)
    {
        return pow(base, expo);
    }

    ////////////////////////////////////////
    
}
// end of namespace gmp::math

#endif
// end of file _GMP_MATH_HPP